import React, { useState, useEffect, useCallback } from 'react';
import { 
  DEFAULT_INITIAL_PRESET,
  INITIAL_POPULAR_PRESETS,
  generateOfflineIndianSeries,
  STOCK_COVARIATE_DEFINITIONS
} from './data/presets';
import { 
  DatasetPreset, 
  ModelConfig, 
  ForecastResult, 
  TimeSeriesPoint, 
  CovariateDefinition, 
  AIAnalysisReport,
  ProviderFetchConfig
} from './types';
import { runTimesFmForecast } from './lib/timesfmEngine';
import { Header } from './components/Header';
import { TimeSeriesChart } from './components/TimeSeriesChart';
import { ModelControlsBar } from './components/ModelControlsBar';
import { AnomalyInspector } from './components/AnomalyInspector';
import { DecompositionView } from './components/DecompositionView';
import { DataUploadModal } from './components/DataUploadModal';
import { AIAnalysisModal } from './components/AIAnalysisModal';
import { MarketDataProviderModal } from './components/MarketDataProviderModal';
import { IndianMarketSearchFetchBar, FetchWarningInfo } from './components/IndianMarketSearchFetchBar';
import { validateTickerSymbol } from './lib/tickerValidation';
import { StockSummaryReport } from './components/StockSummaryReport';
import { MarketFetchResult, fetchMarketData } from './lib/marketProvider';
import { calculateStockSummaryReport } from './lib/stockSummaryCalculator';
import { getCachedMarketCandles } from './lib/localDatabase';
import { evaluateQuantSetup } from './lib/quantSetupEngine';
import { MobileBottomNav } from './components/MobileBottomNav';
import { QuantSetupCard } from './components/QuantSetupCard';
import { SeparateReportWindow } from './components/SeparateReportWindow';
import { GeminiChatModal } from './components/GeminiChatModal';
import { FinalVerdictModal } from './components/FinalVerdictModal';
import { MobileAppHeader } from './components/MobileAppHeader';
import { WatchlistScanModal } from './components/WatchlistScanModal';
import { AdvanceChartModal } from './components/AdvanceChartModal';
import { getWatchlistFromStorage, getWatchlists, saveWatchlistToStorage, type WatchlistScanItem } from './lib/watchlistStore';
import { normalizeSymbol } from './lib/upstoxInstruments';
import { AuthProvider } from './context/AuthContext';
import { AuthModal } from './components/AuthModal';
import { PaperTradingModal } from './components/PaperTradingModal';
import { WalkForwardBacktestModal } from './components/WalkForwardBacktestModal';
import { AlertWebhookModal } from './components/AlertWebhookModal';
import { SectorHeatmapBar } from './components/SectorHeatmapBar';
import { WatchlistSidebarDrawer } from './components/WatchlistSidebarDrawer';
import { LiveOptionChainModal } from './components/LiveOptionChainModal';
import { MySetupsModal } from './components/MySetupsModal';
import { getActiveSetupsCount, subscribeToSetups, syncSetupsFromWatchlistScan, isQualifyingSetup, type SetupTimeframe } from './lib/mySetupsStore';
import { computeMultiEngineWatchlistAnalysis, fetchCandlesForTimeframe, markTimeframeDataUnavailable, MIN_WATCHLIST_CANDLES, hasSufficientWatchlistHistory } from './lib/watchlistAnalysisEngine';

export default function App() {
  // Execution Mode (Local on-device browser inference vs Hybrid Cloud)
  const [isLocalMode, setIsLocalMode] = useState<boolean>(() => {
    return localStorage.getItem('timesfm_local_mode') !== 'false';
  });

  // Firebase Authentication & Secure Proxy Modal state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // New High-Impact Feature Modals: Paper Trading, Walk-Forward, and Alerts
  const [isPaperTradingOpen, setIsPaperTradingOpen] = useState(false);
  const [isWalkForwardOpen, setIsWalkForwardOpen] = useState(false);
  const [isAlertsOpen, setIsAlertsOpen] = useState(false);

  // Active presets list (preloaded with top Indian benchmarks)
  const [presets, setPresets] = useState<DatasetPreset[]>(INITIAL_POPULAR_PRESETS);
  const [currentPreset, setCurrentPreset] = useState<DatasetPreset>(DEFAULT_INITIAL_PRESET);
  const [historyData, setHistoryData] = useState<TimeSeriesPoint[]>(DEFAULT_INITIAL_PRESET.data);
  const [futureCovariates, setFutureCovariates] = useState<Record<string, number>[]>(DEFAULT_INITIAL_PRESET.futureCovariates || []);
  const [recentFetches, setRecentFetches] = useState<MarketFetchResult[]>([]);
  const [isFetchingMarket, setIsFetchingMarket] = useState(false);
  const [dataQualityState, setDataQualityState] = useState<'LIVE' | 'CACHED' | 'SIMULATED' | 'UNAVAILABLE'>('SIMULATED');
  const [lastFetchedAt, setLastFetchedAt] = useState<string>(new Date().toISOString());
  const [marketStatusMsg, setMarketStatusMsg] = useState<string | undefined>('Initial simulated benchmark loaded.');

  // User Request 1: Persisted Market Data API Provider (once selected, automatically used for next searches)
  const [selectedApiConfig, setSelectedApiConfig] = useState<ProviderFetchConfig>(() => {
    try {
      const saved = localStorage.getItem('timesfm_active_market_provider');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed?.customUrl && (parsed.customUrl.includes('api.myserver.com') || parsed.customUrl.includes('myserver.com') || parsed.customUrl.includes('example.com'))) {
          // Reset corrupted placeholder domain back to standard Yahoo provider
          return {
            provider: 'yahoo',
            symbol: 'RELIANCE',
            range: '1y',
            interval: '1h'
          };
        }
        return parsed;
      }
    } catch (e) {
      console.warn('Failed to parse saved provider config:', e);
    }
    return {
      provider: 'yahoo',
      symbol: 'RELIANCE',
      range: '1y',
      interval: '1h'
    };
  });

  const handleSelectProviderConfig = (newConfig: ProviderFetchConfig) => {
    setSelectedApiConfig(newConfig);
    try {
      localStorage.setItem('timesfm_active_market_provider', JSON.stringify(newConfig));
    } catch (e) {
      console.warn('Failed to persist provider config:', e);
    }
  };

  // Model Hyperparameters (Optimized for TimesFM: max context, 32-step horizon, auto frequency token, 95% cone)
  const [modelConfig, setModelConfig] = useState<ModelConfig>({
    model: 'timesfm-3.0',
    horizon: 32,
    contextLength: 1024,
    frequency: 'auto',
    confidenceLevel: 95,
    useCovariates: true,
    normalisation: 'revin',
    patchLength: 32,
    anomalyThreshold: 2.5,
    executionMode: isLocalMode ? 'local_device' : 'server_cloud'
  });

  // Navigation & Modals
  const [activeTab, setActiveTab] = useState<'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition'>('forecast');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isAIReportOpen, setIsAIReportOpen] = useState(false);
  const [isMarketProviderOpen, setIsMarketProviderOpen] = useState(false);
  const [isSeparateWindowOpen, setIsSeparateWindowOpen] = useState(false);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [isFinalVerdictOpen, setIsFinalVerdictOpen] = useState(false);
  const [isWatchlistScanOpen, setIsWatchlistScanOpen] = useState(false);
  const [isMySetupsOpen, setIsMySetupsOpen] = useState(false);
  const [mySetupsCount, setMySetupsCount] = useState<number>(() => getActiveSetupsCount());
  const [isAdvanceChartOpen, setIsAdvanceChartOpen] = useState(false);
  const [isOptionChainOpen, setIsOptionChainOpen] = useState(false);
  const [isWatchlistDrawerOpen, setIsWatchlistDrawerOpen] = useState(false);
  const [isDeepQuantAnalyticsOpen, setIsDeepQuantAnalyticsOpen] = useState(false);
  const [watchlistCount, setWatchlistCount] = useState<number>(() => {
    try {
      return getWatchlistFromStorage().length;
    } catch {
      return 0;
    }
  });

  useEffect(() => {
    const refreshMySetupsCount = () => setMySetupsCount(getActiveSetupsCount());
    refreshMySetupsCount();
    return subscribeToSetups(refreshMySetupsCount);
  }, []);

  // Forecast state
  const [forecastResult, setForecastResult] = useState<ForecastResult | null>(null);
  const [isForecasting, setIsForecasting] = useState(false);
  const [fetchWarning, setFetchWarning] = useState<FetchWarningInfo | null>(null);

  // AI report state
  const [aiReport, setAiReport] = useState<AIAnalysisReport | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  // Toggle local vs cloud
  const handleToggleLocalMode = (val: boolean) => {
    setIsLocalMode(val);
    localStorage.setItem('timesfm_local_mode', String(val));
    const nextConfig: ModelConfig = {
      ...modelConfig,
      executionMode: val ? 'local_device' : 'server_cloud'
    };
    setModelConfig(nextConfig);
    if (historyData.length > 0) {
      executeForecast(historyData, nextConfig, futureCovariates, val);
    }
  };

  // Core forecast runner
  const executeForecast = useCallback(async (
    points: TimeSeriesPoint[] = historyData,
    cfg: ModelConfig = modelConfig,
    futureCovs: Record<string, number>[] = futureCovariates,
    useLocalOnly: boolean = isLocalMode
  ) => {
    if (!points || points.length === 0) return;
    setIsForecasting(true);
    try {
      if (useLocalOnly) {
        // Run 100% on-device local inference in browser thread / Web Worker
        const localResult = runTimesFmForecast(points, cfg, futureCovs);
        setForecastResult(localResult);
        return;
      }

      // Hybrid Cloud API call
      const response = await fetch('/api/forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          history: points,
          config: cfg,
          futureCovariates: futureCovs
        })
      });

      if (response.ok) {
        const data = await response.json();
        setForecastResult(data);
      } else {
        // Fallback to local on-device engine
        const fallback = runTimesFmForecast(points, cfg, futureCovs);
        setForecastResult(fallback);
      }
    } catch {
      // Offline fallback
      const fallback = runTimesFmForecast(points, cfg, futureCovs);
      setForecastResult(fallback);
    } finally {
      setIsForecasting(false);
    }
  }, [historyData, modelConfig, futureCovariates, isLocalMode]);

  // When changing preset
  const handleSelectPreset = (preset: DatasetPreset) => {
    setCurrentPreset(preset);
    setHistoryData(preset.data);
    const newFutureCovs = preset.futureCovariates || [];
    setFutureCovariates(newFutureCovs);
    setDataQualityState('SIMULATED');
    setLastFetchedAt(new Date().toISOString());
    setMarketStatusMsg('Loaded benchmark historical sample series.');

    const updatedConfig: ModelConfig = {
      ...modelConfig,
      horizon: 32,
      frequency: preset.frequency,
      contextLength: Math.max(512, preset.data.length),
      confidenceLevel: 95,
      useCovariates: preset.covariates.length > 0
    };
    setModelConfig(updatedConfig);
    setAiReport(null);
    executeForecast(preset.data, updatedConfig, newFutureCovs);
  };

  // Model config updates
  const handleUpdateConfig = (updates: Partial<ModelConfig>) => {
    const nextConfig = { ...modelConfig, ...updates };
    setModelConfig(nextConfig);
    executeForecast(historyData, nextConfig, futureCovariates);
  };

  // Market Provider Data Loaded (Names appear after fetch)
  const handleMarketDataLoaded = (result: MarketFetchResult) => {
    const isCommodity = result.symbol.includes('GOLD') || result.symbol.includes('SILVER') || result.symbol.includes('CRUDE') || result.symbol.includes('GAS') || result.symbol.includes('COPPER');
    const isIndex = result.symbol.includes('NIFTY') || result.symbol.includes('SENSEX');

    setDataQualityState(result.sourceState || (result.isLiveFeed ? 'LIVE' : 'CACHED'));
    setLastFetchedAt(result.fetchedAt || new Date().toISOString());
    setMarketStatusMsg(result.statusMessage);

    const newPreset: DatasetPreset = {
      id: `market-${result.symbol.toLowerCase()}`,
      symbol: result.symbol,
      title: result.name, // Formal name verified after fetch
      category: isCommodity ? 'Indian Commodity' : isIndex ? 'Indian Index' : 'Indian Equity',
      description: result.sourceState === 'CACHED'
        ? `Cached candlestick data for ${result.name} (${result.symbol}) from ${result.source}.`
        : result.sourceState === 'UNAVAILABLE'
        ? `Market feed currently unavailable for ${result.symbol}.`
        : `Live candlestick data stream for ${result.name} (${result.symbol}) from ${result.source}.`,
      unit: result.unit,
      frequency: result.frequency,
      recommendedHorizon: result.frequency === 'hourly' ? 24 : 15,
      covariates: result.covariates,
      data: result.data
    };

    // Update active presets
    setPresets(prev => {
      const filtered = prev.filter(p => p.symbol !== result.symbol);
      return [newPreset, ...filtered];
    });

    // Update recent fetches
    setRecentFetches(prev => {
      const filtered = prev.filter(r => r.symbol !== result.symbol);
      return [result, ...filtered].slice(0, 8);
    });

    setCurrentPreset(newPreset);
    setHistoryData(result.data);
    setFutureCovariates([]);

    const updatedConfig: ModelConfig = {
      ...modelConfig,
      horizon: 32,
      frequency: 'auto',
      contextLength: Math.max(512, result.data.length),
      confidenceLevel: 95,
      useCovariates: result.covariates.length > 0
    };
    setModelConfig(updatedConfig);
    setAiReport(null);
    executeForecast(result.data, updatedConfig, []);
  };

  // Indian Market / Custom API Fetch Handler with Client-Side Validation Layer
  const handleFetchIndianMarket = async (symbol: string, range: string = '1y', interval: string = '1h') => {
    // 1. Client-Side Validation: Cross-reference against local registry and detect 400 error risks
    const validation = validateTickerSymbol(symbol, selectedApiConfig);

    if (!validation.isValid) {
      // Immediate warning - Prevent hitting provider API with invalid format that causes 400 error
      setFetchWarning({
        message: validation.warning || 'Invalid symbol format. Please verify your input.',
        type: 'error',
        suggestion: validation.suggestion
      });
      return;
    }

    if (validation.warning) {
      // Display immediate non-blocking warning (e.g. unverified format or typo suggestion)
      setFetchWarning({
        message: validation.warning,
        type: 'warning',
        suggestion: validation.suggestion
      });
    } else {
      setFetchWarning(null);
    }

    setIsFetchingMarket(true);
    const targetSym = validation.normalizedSymbol;
    const effectiveRange = range || selectedApiConfig.range || '1y';
    const effectiveInterval = interval || selectedApiConfig.interval || '1h';

    // Update active provider configuration with newly searched symbol
    const updatedApiConfig: ProviderFetchConfig = {
      ...selectedApiConfig,
      symbol: targetSym,
      range: effectiveRange,
      interval: effectiveInterval
    };
    setSelectedApiConfig(updatedApiConfig);
    try {
      localStorage.setItem('timesfm_active_market_provider', JSON.stringify(updatedApiConfig));
      if (updatedApiConfig.provider === 'custom_api') {
        localStorage.setItem('timesfm_custom_api_config', JSON.stringify(updatedApiConfig));
      }
    } catch (e) {
      console.warn('Storage sync error:', e);
    }

    try {
      const result = await fetchMarketData(updatedApiConfig);
      handleMarketDataLoaded(result);
    } catch (err: any) {
      console.warn('Market fetch failed for provider:', selectedApiConfig.provider, targetSym, err);
      // Try to retrieve verified cached data from local SQLite
      try {
        const cached = await getCachedMarketCandles(targetSym, effectiveInterval);
        if (cached && cached.data && cached.data.length > 0) {
          const cachedResult: MarketFetchResult = {
            symbol: targetSym,
            name: `${targetSym} (Cached)`,
            data: cached.data,
            covariates: STOCK_COVARIATE_DEFINITIONS,
            unit: 'INR (₹)',
            frequency: effectiveInterval.includes('h') ? 'hourly' : 'daily',
            source: 'Local SQLite Cache',
            sourceState: 'CACHED',
            fetchedAt: cached.fetchedAt,
            isLiveFeed: false,
            statusMessage: `Live stream unreachable. Displaying cached candles from ${new Date(cached.fetchedAt).toLocaleString()}.`
          };
          handleMarketDataLoaded(cachedResult);
          return;
        }
      } catch (cacheErr) {
        console.warn('Cache lookup failed:', cacheErr);
      }

      // If no live and no cached data, report truthful unavailable error
      const unavailableResult: MarketFetchResult = {
        symbol: targetSym,
        name: `${targetSym} (Unavailable)`,
        data: [],
        covariates: STOCK_COVARIATE_DEFINITIONS,
        unit: 'INR (₹)',
        frequency: effectiveInterval.includes('h') ? 'hourly' : 'daily',
        source: 'Provider Offline',
        sourceState: 'UNAVAILABLE',
        fetchedAt: new Date().toISOString(),
        isLiveFeed: false,
        statusMessage: `Market data feed unavailable for "${targetSym}": ${err?.message || 'Check network connection'}.`
      };
      handleMarketDataLoaded(unavailableResult);
    } finally {
      setIsFetchingMarket(false);
    }
  };

  // Initial mount: Execute immediate prediction on default preset and refresh live market data in background
  useEffect(() => {
    executeForecast(DEFAULT_INITIAL_PRESET.data, modelConfig, DEFAULT_INITIAL_PRESET.futureCovariates || []);
    handleFetchIndianMarket('RELIANCE', '1y', '1h');
  }, []);

  // Custom CSV imported
  const handleDatasetLoaded = (
    data: TimeSeriesPoint[],
    title: string,
    covariates: CovariateDefinition[],
    unit: string
  ) => {
    const customPreset: DatasetPreset = {
      id: `custom-${Date.now()}`,
      symbol: title.slice(0, 6).toUpperCase(),
      title,
      category: 'Indian Stocks & Commodities',
      description: `User-imported custom dataset (${data.length} candles)`,
      unit,
      frequency: 'daily',
      recommendedHorizon: Math.min(30, Math.max(12, Math.floor(data.length * 0.2))),
      covariates,
      data
    };

    setPresets(prev => [customPreset, ...prev.filter(p => p.id !== customPreset.id)]);
    setCurrentPreset(customPreset);
    setHistoryData(data);
    setFutureCovariates([]);

    const updatedConfig: ModelConfig = {
      ...modelConfig,
      horizon: customPreset.recommendedHorizon,
      contextLength: Math.min(128, data.length),
      useCovariates: covariates.length > 0
    };
    setModelConfig(updatedConfig);
    setAiReport(null);
    executeForecast(data, updatedConfig, []);
  };

  // AI Analysis Report trigger
  const handleGenerateAIReport = async () => {
    if (!forecastResult) return;
    setIsGeneratingReport(true);
    try {
      const historyPoints = forecastResult.history;
      const forecasts = forecastResult.forecasts;
      const lastPoint = historyPoints[historyPoints.length - 1];
      const endForecast = forecasts[forecasts.length - 1];

      const res = await fetch('/api/analyze-forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          datasetTitle: currentPreset.title,
          historySummary: {
            length: historyPoints.length,
            lastValue: lastPoint?.value,
            mean: Math.round(historyPoints.reduce((s, p) => s + p.value, 0) / historyPoints.length),
            trend: (endForecast?.p50 || 0) >= (lastPoint?.value || 0) ? 'Bullish Drift' : 'Bearish Pullback'
          },
          forecastSummary: {
            horizon: forecasts.length,
            meanEnd: endForecast?.p50,
            p10End: endForecast?.p10,
            p90End: endForecast?.p90,
            spreadPct: Math.round(((endForecast?.p90 - endForecast?.p10) / Math.max(1, endForecast?.p50 || 1)) * 100)
          },
          hyperparameters: modelConfig,
          anomaliesCount: forecastResult.anomalies.length,
          covariatesUsed: currentPreset.covariates.map(c => c.name)
        })
      });

      if (res.ok) {
        const report = await res.json();
        setAiReport(report);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingReport(false);
    }
  };

  const handleFindSetups = async (reportProgress: (message: string) => void) => {
    const lists = getWatchlists();
    const timeframes: SetupTimeframe[] = ['5m', '15m', '1h', '1d'];
    const tfItems = new Map<SetupTimeframe, Map<string, WatchlistScanItem>>(timeframes.map(tf => [tf, new Map()]));
    const unavailableKeys = new Map<SetupTimeframe, Set<string>>(timeframes.map(tf => [tf, new Set()]));
    const total = lists.reduce((sum, list) => sum + list.items.length * timeframes.length, 0);
    let completed = 0;
    let unavailableChecks = 0;
    const scanChanges: string[] = [];
    const horizonFor = (tf: SetupTimeframe) => tf === '5m' || tf === '15m' ? 'Intraday (5m/15m)' as const : 'Swing (3–4 Days)' as const;
    const tier = (item: WatchlistScanItem) => !isQualifyingSetup(item) ? 0 : item.setupGrade === 'GRADE_A_PLUS' ? 2 : 1;

    for (let listIndex = 0; listIndex < lists.length; listIndex++) {
      const list = lists[listIndex];
      let currentItems = [...list.items];
      for (const timeframe of timeframes) {
        for (let symbolIndex = 0; symbolIndex < currentItems.length; symbolIndex++) {
          const item = currentItems[symbolIndex];
          completed++;
          reportProgress(`Watchlist ${listIndex + 1}/${lists.length} · ${timeframe} · ${item.symbol} (${completed}/${total})`);
          let analyzed: WatchlistScanItem;
          try {
            const candles = await fetchCandlesForTimeframe(item.symbol, timeframe);
            analyzed = hasSufficientWatchlistHistory(timeframe, candles.length)
              ? computeMultiEngineWatchlistAnalysis(item.symbol, item.name || item.symbol, candles, horizonFor(timeframe), timeframe, '₹', item).item
              : markTimeframeDataUnavailable(item, timeframe, `Only ${candles.length} fresh ${timeframe} candles available; ${MIN_WATCHLIST_CANDLES[timeframe]} are required for the timeframe's price/volume baseline. Setup not assessed.`);
          } catch (error) {
            console.warn(`Find Setups failed for ${item.symbol} @ ${timeframe}`, error);
            analyzed = markTimeframeDataUnavailable(item, timeframe, `Fetch/analysis failed for ${timeframe}; setup not assessed.`);
          }
          currentItems[symbolIndex] = analyzed;
          const candidates = tfItems.get(timeframe)!;
          const key = item.symbol.toUpperCase().trim();
          if (analyzed.analysisDataStatus) {
            unavailableKeys.get(timeframe)!.add(key);
            unavailableChecks++;
          }
          const old = candidates.get(key);
          if (!old || tier(analyzed) > tier(old) || (tier(analyzed) === tier(old) && (analyzed.confluenceScorePct ?? 0) > (old.confluenceScorePct ?? 0))) candidates.set(key, analyzed);
        }
        saveWatchlistToStorage(currentItems, list.id);
      }
    }

    for (const timeframe of timeframes) {
      const unavailable = unavailableKeys.get(timeframe)!;
      const completeResults = [...tfItems.get(timeframe)!.entries()]
        .filter(([symbol, item]) => isQualifyingSetup(item) || !unavailable.has(symbol))
        .map(([, item]) => item);
      const syncResult = syncSetupsFromWatchlistScan(completeResults, timeframe, undefined, true);
      scanChanges.push(...syncResult.changes);
    }
    const changeSummary = scanChanges.length
      ? ` · ${scanChanges.length} setup change${scanChanges.length === 1 ? '' : 's'}: ${scanChanges.slice(-5).join(' | ')}`
      : ' · No qualifying setup changes';
    reportProgress(`Scan complete · ${lists.length} watchlists · ${total} checks · ${unavailableChecks} data unavailable (prior setups retained)${changeSummary}`);
  };

  const hasCovariates = currentPreset.covariates && currentPreset.covariates.length > 0;
  const lastPoint = historyData[historyData.length - 1];
  const lastClosePrice = lastPoint?.value;

  const [stockReportDirectionOverride, setStockReportDirectionOverride] = useState<'BULLISH' | 'BEARISH' | undefined>(undefined);

  const stockSummaryReport = React.useMemo(() => {
    if (!historyData || historyData.length === 0) return null;
    return calculateStockSummaryReport({
      symbol: currentPreset.symbol || currentPreset.title,
      name: currentPreset.title,
      unit: currentPreset.unit,
      history: forecastResult?.history || historyData,
      forecasts: forecastResult?.forecasts || [],
      tradingMetrics: forecastResult?.tradingMetrics,
      frequency: modelConfig.frequency,
      overrideDirection: stockReportDirectionOverride
    });
  }, [currentPreset, historyData, forecastResult, modelConfig.frequency, stockReportDirectionOverride]);

  // Compute active institutional quantitative trade setup (100-pt engine)
  const activeQuantSetup = React.useMemo(() => {
    return evaluateQuantSetup(
      currentPreset.symbol || currentPreset.title || 'NIFTY',
      currentPreset.title || 'Market Instrument',
      forecastResult?.history || historyData,
      'Swing (3–4 Days)',
      currentPreset.unit.includes('INR') || currentPreset.unit.includes('₹') ? '₹' : '$',
      true, // aligned with index
      false, // news catalyst
      forecastResult?.forecasts
    );
  }, [currentPreset, forecastResult, historyData]);

  return (
    <AuthProvider>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30">
      {/* Mobile-Native App Header (Visible on Mobile / Small screens) */}
      <div className="md:hidden">
        <MobileAppHeader
          currentPreset={currentPreset}
          presets={presets}
          onSelectPreset={handleSelectPreset}
          lastClosePrice={lastClosePrice}
          currency={currentPreset.unit}
          onOpenSearch={() => {
            const el = document.getElementById('indian-market-search-input') || document.getElementById('search-input-indian-market');
            if (el) {
              el.focus();
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }}
          onOpenMarketProvider={() => setIsMarketProviderOpen(true)}
          onOpenFinalVerdict={() => setIsFinalVerdictOpen(true)}
          onOpenWatchlistScan={() => setIsWatchlistScanOpen(true)}
          onOpenMySetups={() => setIsMySetupsOpen(true)}
          watchlistCount={watchlistCount}
          onRunForecast={() => executeForecast()}
          isLoading={isForecasting || isFetchingMarket}
          isLocalMode={isLocalMode}
          onToggleLocalMode={handleToggleLocalMode}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          quantScore={activeQuantSetup?.scorePct || 78}
          selectedApiConfig={selectedApiConfig}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenPaperTrading={() => setIsPaperTradingOpen(true)}
        />
      </div>

      {/* Desktop Navigation & Controls Header (Hidden on mobile) */}
      <div className="hidden md:block">
        <Header
          presets={presets}
          currentPreset={currentPreset}
          onSelectPreset={handleSelectPreset}
          modelConfig={modelConfig}
          onChangeModelConfig={handleUpdateConfig}
          onRunForecast={() => executeForecast()}
          isLoading={isForecasting || isFetchingMarket}
          onOpenUpload={() => setIsUploadOpen(true)}
          onOpenAIReport={() => {
            setIsAIReportOpen(true);
            if (!aiReport) handleGenerateAIReport();
          }}
          onOpenMarketProvider={() => setIsMarketProviderOpen(true)}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenAdvanceChart={() => setIsAdvanceChartOpen(true)}
          onOpenFinalVerdict={() => setIsFinalVerdictOpen(true)}
          onOpenWatchlistScan={() => setIsWatchlistScanOpen(true)}
          onOpenMySetups={() => setIsMySetupsOpen(true)}
          mySetupsCount={mySetupsCount}
          onToggleWatchlistDrawer={() => setIsWatchlistDrawerOpen(!isWatchlistDrawerOpen)}
          watchlistCount={watchlistCount}
          anomaliesCount={forecastResult?.anomalies.length || 0}
          hasCovariates={hasCovariates}
          executionTimeMs={forecastResult?.executionTimeMs}
          isLocalMode={isLocalMode}
          onToggleLocalMode={handleToggleLocalMode}
          lastClosePrice={lastClosePrice}
          currency={currentPreset.unit}
          onSearchAndFetch={handleFetchIndianMarket}
          isSearchingOrFetching={isFetchingMarket}
          selectedApiConfig={selectedApiConfig}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          onOpenPaperTrading={() => setIsPaperTradingOpen(true)}
          onOpenWalkForwardBacktest={() => setIsWalkForwardOpen(true)}
          onOpenAlerts={() => setIsAlertsOpen(true)}
        />
      </div>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 pb-[calc(6rem+env(safe-area-inset-bottom))] sm:pb-8 space-y-4 sm:space-y-5">
        {/* Prominent Indian Market Search & Ticker Fetcher Bar (Names appear after fetch) */}
        <IndianMarketSearchFetchBar
          onFetch={handleFetchIndianMarket}
          isLoading={isFetchingMarket || isForecasting}
          activeSymbol={currentPreset.symbol}
          activeName={currentPreset.title}
          currency={currentPreset.unit}
          lastClosePrice={lastClosePrice}
          recentFetches={recentFetches}
          onSelectRecent={handleMarketDataLoaded}
          selectedApiConfig={selectedApiConfig}
          fetchWarning={fetchWarning}
          onDismissWarning={() => setFetchWarning(null)}
          onApplySuggestion={(suggestion) => handleFetchIndianMarket(suggestion)}
        />

        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => setIsOptionChainOpen(true)}
            className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-cyan-500/50 bg-cyan-950/60 px-4 py-2 text-sm font-bold text-cyan-100 shadow-lg shadow-cyan-950/30 transition hover:border-cyan-300 hover:bg-cyan-900/70 active:scale-[0.98]"
            aria-label={`Open F&O option chain for ${currentPreset.symbol || currentPreset.title}`}
          >
            <span aria-hidden="true">📊</span>
            <span>F&amp;O Option Chain</span>
            <span className="rounded-md border border-cyan-700/60 bg-slate-950/70 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-cyan-300">
              Quotes + OI
            </span>
          </button>
        </div>

        {/* Live Sector Heatmap & Market Breadth Bar */}
        <SectorHeatmapBar
          currentSymbol={currentPreset.symbol || currentPreset.title}
          onSelectSectorSymbol={(sym) => handleFetchIndianMarket(sym)}
        />

        {/* Tab 1: Primary Trading Canvas & Controls */}
        {activeTab === 'forecast' && (
          <div className="space-y-4 sm:space-y-5">
            {/* Primary Time Series Forecast Chart */}
            <div id="primary-charts-section">
              <TimeSeriesChart
                history={forecastResult?.history || historyData}
                forecasts={forecastResult?.forecasts || []}
                anomalies={forecastResult?.anomalies || []}
                unit={currentPreset.unit}
                title={currentPreset.symbol ? `${currentPreset.title} (${currentPreset.symbol}) — TimesFM Prediction Corridor` : 'Market Forecast Corridor'}
                confidenceLevel={modelConfig.confidenceLevel}
                onOpenAdvanceChart={() => setIsAdvanceChartOpen(true)}
                dataQualityState={dataQualityState}
                fetchedAt={lastFetchedAt}
                statusMessage={marketStatusMsg}
                engineName={forecastResult?.engineName}
              />
            </div>

            {/* Stock Summary Report Card (CMP, Target 1, Target 2, Target 3, Strict Stoploss & Voice Copilot) */}
            {stockSummaryReport && (
              <StockSummaryReport
                report={stockSummaryReport}
                onToggleDirection={(dir) => setStockReportDirectionOverride(dir)}
                history={forecastResult?.history || historyData}
                confidenceLevel={modelConfig.confidenceLevel}
              />
            )}

            {/* Institutional Quantitative Trader Setup Engine Card */}
            <div id="quant-setup-card-section">
              <QuantSetupCard
                currentPreset={currentPreset}
                presets={presets}
                onSelectPreset={handleSelectPreset}
                onFetchSymbol={handleFetchIndianMarket}
                currencySymbol={currentPreset.unit.includes('INR') || currentPreset.unit.includes('₹') ? '₹' : '$'}
                onOpenWatchlistScan={() => setIsWatchlistScanOpen(true)}
                forecasts={forecastResult?.forecasts || []}
              />
            </div>

            {/* Model Hyperparameters Adjustment Bar */}
            <ModelControlsBar
              config={modelConfig}
              onChange={handleUpdateConfig}
              hasCovariates={hasCovariates}
              historyLength={historyData.length}
            />

            {/* Collapsible Deep Quantitative Analytics (STL Decomposition & Volatility Anomalies) */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900/60 overflow-hidden shadow-lg">
              <button
                type="button"
                onClick={() => setIsDeepQuantAnalyticsOpen(!isDeepQuantAnalyticsOpen)}
                className="w-full px-4 py-3 bg-slate-900/90 hover:bg-slate-850 flex items-center justify-between text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <span className="text-cyan-400">🔬</span>
                  <span>Deep Quant Analytics & Anomaly Engine (Decomposition & Outliers)</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-cyan-300 border border-slate-700">
                  {isDeepQuantAnalyticsOpen ? 'Hide ▲' : 'Inspect ▼'}
                </span>
              </button>

              {isDeepQuantAnalyticsOpen && (
                <div className="p-4 space-y-4 border-t border-slate-800 bg-slate-950/70 animate-in fade-in">
                  <DecompositionView
                    decomposition={forecastResult?.decomposition}
                    unit={currentPreset.unit}
                  />
                  <AnomalyInspector
                    anomalies={forecastResult?.anomalies || []}
                    unit={currentPreset.unit}
                    threshold={modelConfig.anomalyThreshold}
                    onThresholdChange={(t) => handleUpdateConfig({ anomalyThreshold: t })}
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab: Dedicated Institutional Quant Setup Engine Workspace */}
        {activeTab === 'quant' && (
          <div id="institutional-quant-setup-container" className="space-y-4 sm:space-y-5">
            <QuantSetupCard
              currentPreset={currentPreset}
              presets={presets}
              onSelectPreset={handleSelectPreset}
              onFetchSymbol={handleFetchIndianMarket}
              currencySymbol={currentPreset.unit.includes('INR') || currentPreset.unit.includes('₹') ? '₹' : '$'}
              onOpenWatchlistScan={() => setIsWatchlistScanOpen(true)}
              forecasts={forecastResult?.forecasts || []}
            />

            <TimeSeriesChart
              history={forecastResult?.history || historyData}
              forecasts={forecastResult?.forecasts || []}
              anomalies={forecastResult?.anomalies || []}
              unit={currentPreset.unit}
              title={`${currentPreset.title} (${currentPreset.symbol}) — Technical Validation Chart`}
              confidenceLevel={modelConfig.confidenceLevel}
              dataQualityState={dataQualityState}
              fetchedAt={lastFetchedAt}
              engineName={forecastResult?.engineName}
            />
          </div>
        )}

        {/* Tab 3: Anomaly Inspector */}
        {activeTab === 'anomalies' && (
          <div className="space-y-4 sm:space-y-5">
            <TimeSeriesChart
              history={forecastResult?.history || historyData}
              forecasts={[]}
              anomalies={forecastResult?.anomalies || []}
              unit={currentPreset.unit}
              title={`${currentPreset.title} — Market Volatility Anomalies & Residual Breaches`}
              confidenceLevel={modelConfig.confidenceLevel}
              dataQualityState={dataQualityState}
              fetchedAt={lastFetchedAt}
              engineName={forecastResult?.engineName}
            />

            <AnomalyInspector
              anomalies={forecastResult?.anomalies || []}
              unit={currentPreset.unit}
              threshold={modelConfig.anomalyThreshold}
              onThresholdChange={(t) => handleUpdateConfig({ anomalyThreshold: t })}
            />
          </div>
        )}

        {/* Tab 4: STL Decomposition */}
        {activeTab === 'decomposition' && (
          <div className="space-y-4 sm:space-y-5">
            <DecompositionView
              decomposition={forecastResult?.decomposition}
              unit={currentPreset.unit}
            />
          </div>
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (Fixed for Android & Mobile) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAdvanceChart={() => setIsAdvanceChartOpen(true)}
        onOpenFinalVerdict={() => setIsFinalVerdictOpen(true)}
        onOpenWatchlistScan={() => setIsWatchlistScanOpen(true)}
        watchlistCount={watchlistCount}
        onOpenBacktestModal={() => setIsWalkForwardOpen(true)}
        onOpenChatModal={() => setIsChatModalOpen(true)}
        onScrollToTargets={() => {
          const el = document.getElementById('stock-summary-report-card');
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }}
        onRunForecast={() => executeForecast()}
        isLoading={isForecasting || isFetchingMarket}
      />

      {/* Dedicated Advance Chart Modal (TimesFM Base + Multi-Timeframe + VWAP, Bollinger, Pivots, Supertrend, Volume & Imp. Levels) */}
      <AdvanceChartModal
        isOpen={isAdvanceChartOpen}
        onClose={() => setIsAdvanceChartOpen(false)}
        symbol={stockSummaryReport?.symbol || currentPreset.symbol || 'NIFTY'}
        name={stockSummaryReport?.name || currentPreset.title}
        history={forecastResult?.history || historyData}
        forecasts={forecastResult?.forecasts || []}
        anomalies={forecastResult?.anomalies || []}
        confidenceLevel={modelConfig.confidenceLevel}
        unit={currentPreset.unit}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
        stockSummaryReport={stockSummaryReport}
      />

      <LiveOptionChainModal
        isOpen={isOptionChainOpen}
        onClose={() => setIsOptionChainOpen(false)}
        symbol={currentPreset.symbol || 'NIFTY'}
        name={currentPreset.title || 'NIFTY 50 Index'}
        cmp={lastClosePrice || 0}
        currencySymbol={currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$'}
        onSelectStockSymbol={(symbol) => handleFetchIndianMarket(symbol)}
      />

      {/* Watchlist manager: named lists, 38 unique symbols per list, scan timestamps */}
      <WatchlistScanModal
        isOpen={isWatchlistScanOpen}
        onClose={() => {
          setIsWatchlistScanOpen(false);
          setWatchlistCount(getWatchlistFromStorage().length);
        }}
        currentPreset={currentPreset}
        presets={presets}
        onSelectStock={(preset) => {
          handleSelectPreset(preset);
          setWatchlistCount(getWatchlistFromStorage().length);
        }}
        onFetchSymbol={handleFetchIndianMarket}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
        onWatchlistChange={setWatchlistCount}
        onOpenFinalVerdictModal={() => setIsFinalVerdictOpen(true)}
      />

      <MySetupsModal
        isOpen={isMySetupsOpen}
        onClose={() => setIsMySetupsOpen(false)}
        onSelectStock={symbol => { void handleFetchIndianMarket(symbol); }}
        onFindSetups={handleFindSetups}
      />

      {/* Final Verdict Modal (Calculates both TimesFM and Institutional Quant Setup with levels, targets & stoploss) */}
      <FinalVerdictModal
        isOpen={isFinalVerdictOpen}
        onClose={() => setIsFinalVerdictOpen(false)}
        symbol={stockSummaryReport?.symbol || currentPreset.symbol || 'NIFTY'}
        name={stockSummaryReport?.name || currentPreset.title}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
        history={forecastResult?.history || historyData}
        timeframe={(['5m', '15m', '1h', '1d'].includes(selectedApiConfig.interval || '') ? selectedApiConfig.interval : '1h') as '5m' | '15m' | '1h' | '1d'}
        stockContext={stockSummaryReport}
        activeQuantSetup={activeQuantSetup}
        onOpenPaperTrading={() => {
          setIsFinalVerdictOpen(false);
          setIsPaperTradingOpen(true);
        }}
        onOpenAlerts={() => {
          setIsFinalVerdictOpen(false);
          setIsAlertsOpen(true);
        }}
      />

      {/* Gemini AI Multi-turn Chatbot Modal (Opened via center bottom nav button) */}
      <GeminiChatModal
        isOpen={isChatModalOpen}
        onClose={() => setIsChatModalOpen(false)}
        stockContext={stockSummaryReport}
        quantSetup={activeQuantSetup}
        history={forecastResult?.history || historyData}
        forecasts={forecastResult?.forecasts || []}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
      />

      {/* Fast Watchlist Side Drawer */}
      <WatchlistSidebarDrawer
        isOpen={isWatchlistDrawerOpen}
        onClose={() => setIsWatchlistDrawerOpen(false)}
        activeSymbol={stockSummaryReport?.symbol || currentPreset.symbol || ''}
        onSelectStock={(sym) => {
          handleFetchIndianMarket(sym);
        }}
        onOpenFullModal={() => {
          setIsWatchlistDrawerOpen(false);
          setIsWatchlistScanOpen(true);
        }}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
      />

      {/* Separate Window for Stock Summary */}
      {stockSummaryReport && (
        <SeparateReportWindow
          report={stockSummaryReport}
          history={forecastResult?.history || historyData}
          confidenceLevel={modelConfig.confidenceLevel}
          isOpen={isSeparateWindowOpen}
          onClose={() => setIsSeparateWindowOpen(false)}
          initialTab="backtest"
        />
      )}

      {/* Modals */}
      <MarketDataProviderModal
        isOpen={isMarketProviderOpen}
        onClose={() => setIsMarketProviderOpen(false)}
        onDataLoaded={handleMarketDataLoaded}
        activeSymbol={currentPreset.symbol}
        isLocalMode={isLocalMode}
        onToggleLocalMode={handleToggleLocalMode}
        selectedConfig={selectedApiConfig}
        onSelectProviderConfig={handleSelectProviderConfig}
      />

      <DataUploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onDatasetLoaded={handleDatasetLoaded}
      />

      <AIAnalysisModal
        isOpen={isAIReportOpen}
        onClose={() => setIsAIReportOpen(false)}
        report={aiReport}
        isLoading={isGeneratingReport}
        onRegenerate={handleGenerateAIReport}
        datasetTitle={currentPreset.title}
      />

      {/* Firebase Authentication & Secure Proxy Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentSymbol={stockSummaryReport?.symbol || currentPreset.symbol || 'NIFTY50'}
        currentPrice={stockSummaryReport?.currentMarketPrice || currentPreset.data[currentPreset.data.length - 1]?.value || 24250}
      />

      {/* Institutional Virtual Paper Trading Simulator Modal */}
      <PaperTradingModal
        isOpen={isPaperTradingOpen}
        onClose={() => setIsPaperTradingOpen(false)}
        activeSetup={activeQuantSetup}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
      />

      {/* Walk-Forward Backtesting Engine Modal */}
      <WalkForwardBacktestModal
        isOpen={isWalkForwardOpen}
        onClose={() => setIsWalkForwardOpen(false)}
        symbol={stockSummaryReport?.symbol || currentPreset.symbol || 'NIFTY50'}
        history={forecastResult?.history || historyData}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
        timeframe={(['5m', '15m', '1h', '1d'].includes(selectedApiConfig.interval || '') ? selectedApiConfig.interval : '1h') as SetupTimeframe}
        onOpenPaperTrading={() => {
          setIsWalkForwardOpen(false);
          setIsPaperTradingOpen(true);
        }}
      />

      {/* Webhook Alert Test Modal */}
      <AlertWebhookModal
        isOpen={isAlertsOpen}
        onClose={() => setIsAlertsOpen(false)}
        activeSetup={activeQuantSetup}
        currencySymbol={stockSummaryReport?.currencySymbol || (currentPreset.unit.includes('₹') || currentPreset.unit.includes('INR') ? '₹' : '$')}
      />
    </div>
  </AuthProvider>
  );
}
