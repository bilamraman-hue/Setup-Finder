import { DatasetPreset, TimeSeriesPoint, CovariateDefinition } from '../types';
import { enrichTimeSeriesWithIndicators } from '../lib/technicalIndicators';
import { enrichTimeSeriesWithNewsSentiment } from '../lib/newsSentimentEngine';

export const STOCK_COVARIATE_DEFINITIONS: CovariateDefinition[] = [
  { name: 'rsi_14', type: 'numeric', description: 'Relative Strength Index (14 periods, 0-100)', defaultValue: 54, min: 10, max: 90 },
  { name: 'macd_histogram', type: 'numeric', description: 'MACD Momentum Histogram', defaultValue: 0.8, min: -5, max: 5 },
  { name: 'volume_ratio', type: 'numeric', description: 'Trading Volume Ratio vs 20d Average', defaultValue: 1.1, min: 0.2, max: 4.0 },
  { name: 'bollinger_pct', type: 'numeric', description: '% Band Position (0 = Lower, 100 = Upper Band)', defaultValue: 62, min: 0, max: 100 },
  { name: 'volatility_atr_pct', type: 'numeric', description: 'Average True Range (ATR) Volatility %', defaultValue: 2.2, min: 0.5, max: 8.0 }
];

export interface IndianMarketTicker {
  symbol: string;
  name: string;
  type: 'stock' | 'commodity' | 'index';
  exchange: 'NSE' | 'BSE' | 'MCX';
  displayTicker: string;
}

export const INDIAN_MARKET_TICKERS: IndianMarketTicker[] = [
  // Indian Equities (NSE / BSE)
  { symbol: 'SYRMA', name: 'Syrma SGS Technology', type: 'stock', exchange: 'NSE', displayTicker: 'SYRMA SGS' },
  { symbol: 'RELIANCE', name: 'Reliance Industries', type: 'stock', exchange: 'NSE', displayTicker: 'RELIANCE' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', type: 'stock', exchange: 'NSE', displayTicker: 'TCS' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', type: 'stock', exchange: 'NSE', displayTicker: 'HDFCBANK' },
  { symbol: 'INFY', name: 'Infosys', type: 'stock', exchange: 'NSE', displayTicker: 'INFY' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors', type: 'stock', exchange: 'NSE', displayTicker: 'TATAMOTORS' },
  { symbol: 'SBIN', name: 'State Bank of India', type: 'stock', exchange: 'NSE', displayTicker: 'SBIN' },
  { symbol: 'ITC', name: 'ITC Limited', type: 'stock', exchange: 'NSE', displayTicker: 'ITC' },
  { symbol: 'ICICIBANK', name: 'ICICI Bank', type: 'stock', exchange: 'NSE', displayTicker: 'ICICIBANK' },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel', type: 'stock', exchange: 'NSE', displayTicker: 'BHARTIARTL' },
  { symbol: 'LT', name: 'Larsen & Toubro', type: 'stock', exchange: 'NSE', displayTicker: 'LT' },
  { symbol: 'ZOMATO', name: 'Zomato Ltd', type: 'stock', exchange: 'NSE', displayTicker: 'ZOMATO' },
  { symbol: 'SUZLON', name: 'Suzlon Energy', type: 'stock', exchange: 'NSE', displayTicker: 'SUZLON' },
  { symbol: 'TATASTEEL', name: 'Tata Steel', type: 'stock', exchange: 'NSE', displayTicker: 'TATASTEEL' },

  // Indian Indices
  { symbol: 'NIFTY 50', name: 'NIFTY 50 Index', type: 'index', exchange: 'NSE', displayTicker: 'NIFTY 50' },
  { symbol: 'BANKNIFTY', name: 'NIFTY Bank Index', type: 'index', exchange: 'NSE', displayTicker: 'BANK NIFTY' },
  { symbol: 'SENSEX', name: 'BSE SENSEX 30', type: 'index', exchange: 'BSE', displayTicker: 'SENSEX' },

  // Indian Commodities (MCX / Commodity Futures & ETFs)
  { symbol: 'GOLD', name: 'Gold Futures (MCX)', type: 'commodity', exchange: 'MCX', displayTicker: 'MCX GOLD' },
  { symbol: 'SILVER', name: 'Silver Futures (MCX)', type: 'commodity', exchange: 'MCX', displayTicker: 'MCX SILVER' },
  { symbol: 'CRUDEOIL', name: 'Crude Oil Futures (MCX)', type: 'commodity', exchange: 'MCX', displayTicker: 'MCX CRUDE' },
  { symbol: 'NATURALGAS', name: 'Natural Gas (MCX)', type: 'commodity', exchange: 'MCX', displayTicker: 'MCX NAT GAS' },
  { symbol: 'COPPER', name: 'Copper Futures (MCX)', type: 'commodity', exchange: 'MCX', displayTicker: 'MCX COPPER' },
  { symbol: 'GOLDBEES', name: 'Nippon Gold ETF (NSE)', type: 'commodity', exchange: 'NSE', displayTicker: 'GOLDBEES' }
];

/**
 * Generates an offline simulated fallback candlestick series if no internet connection is present.
 */
export function generateOfflineIndianSeries(symbol: string): { data: TimeSeriesPoint[]; futureCovariates: Record<string, number>[] } {
  const points: TimeSeriesPoint[] = [];
  const futureCovariates: Record<string, number>[] = [];
  const days = 90;

  const isCommodity = symbol.includes('GOLD') || symbol.includes('SILVER') || symbol.includes('CRUDE') || symbol.includes('GAS') || symbol.includes('COPPER');
  const isIndex = symbol.includes('NIFTY') || symbol.includes('SENSEX');

  let currentClose = 1850;
  if (symbol.includes('GOLD')) {
    currentClose = 76500; // ₹ per 10g
  } else if (symbol.includes('SILVER')) {
    currentClose = 91200; // ₹ per kg
  } else if (symbol.includes('CRUDE')) {
    currentClose = 6050; // ₹ per barrel
  } else if (symbol.includes('GAS')) {
    currentClose = 245; // ₹ per mmBtu
  } else if (symbol.includes('COPPER')) {
    currentClose = 815; // ₹ per kg
  } else if (symbol.includes('SENSEX')) {
    currentClose = 82400;
  } else if (symbol.includes('NIFTY')) {
    currentClose = 24800;
  } else if (symbol.includes('SYRMA')) {
    currentClose = 1680;
  } else if (symbol.includes('RELIANCE')) {
    currentClose = 1260; // Post-bonus share adjusted price
  } else if (symbol.includes('TCS')) {
    currentClose = 3950;
  } else if (symbol.includes('HDFCBANK')) {
    currentClose = 1680;
  } else if (symbol.includes('DIXON')) {
    currentClose = 12700;
  }
  const drift = 0.15;
  const volatility = isCommodity ? 2.5 : isIndex ? 0.9 : 1.8;
  const baseVolume = isIndex ? 350000 : isCommodity ? 15000 : 4500000;

  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 130);

  let seed = 12345;
  const pseudoRand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  for (let i = 0; i < days; i++) {
    const d = new Date(startDate.getTime() + i * 24 * 3600 * 1000);
    if (d.getUTCDay() === 0 || d.getUTCDay() === 6) continue;

    const r1 = pseudoRand() - 0.48;
    const r2 = pseudoRand() - 0.5;
    const cyclical = Math.sin(i * 0.15) * 0.8;
    const pctChange = (drift + cyclical * 0.3 + r1 * volatility) / 100;

    const open = currentClose * (1 + (r2 * volatility * 0.4) / 100);
    currentClose = Math.max(10, currentClose * (1 + pctChange));
    const high = Math.max(open, currentClose) * (1 + (pseudoRand() * volatility * 0.6) / 100);
    const low = Math.min(open, currentClose) * (1 - (pseudoRand() * volatility * 0.6) / 100);

    const volFactor = 1 + (pseudoRand() - 0.3) * 0.8 + (Math.abs(pctChange) * 12);
    const volume = Math.round(baseVolume * volFactor);

    points.push({
      timestamp: d.toISOString().split('T')[0],
      value: Math.round(currentClose * 100) / 100,
      open: Math.round(open * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      volume
    });
  }

  const enrichedData = enrichTimeSeriesWithIndicators(points);

  for (let h = 1; h <= 32; h++) {
    futureCovariates.push({
      rsi_14: Math.min(85, Math.max(20, 52 + Math.sin(h * 0.3) * 15)),
      macd_histogram: Math.round(Math.cos(h * 0.25) * 1.5 * 100) / 100,
      volume_ratio: 1.0 + (h % 5 === 0 ? 0.6 : 0.1),
      bollinger_pct: Math.min(95, Math.max(10, 60 + Math.sin(h * 0.3) * 20)),
      volatility_atr_pct: 2.0 + (h > 20 ? 0.5 : 0)
    });
  }

  const enrichedWithSentiment = enrichTimeSeriesWithNewsSentiment(enrichedData, symbol);

  return { data: enrichedWithSentiment, futureCovariates };
}

const defaultReliance = generateOfflineIndianSeries('RELIANCE');
const defaultSyrma = generateOfflineIndianSeries('SYRMA');
const defaultNifty = generateOfflineIndianSeries('NIFTY 50');
const defaultGold = generateOfflineIndianSeries('GOLD');

export const DEFAULT_INITIAL_PRESET: DatasetPreset = {
  id: 'preset-reliance',
  symbol: 'RELIANCE',
  title: 'Reliance Industries Ltd',
  category: 'Indian Equity',
  description: 'National Stock Exchange (NSE: RELIANCE) energy, retail & telecom benchmark.',
  unit: 'INR (₹)',
  frequency: 'daily',
  recommendedHorizon: 32,
  covariates: STOCK_COVARIATE_DEFINITIONS,
  data: defaultReliance.data,
  futureCovariates: defaultReliance.futureCovariates
};

export const INITIAL_POPULAR_PRESETS: DatasetPreset[] = [
  DEFAULT_INITIAL_PRESET,
  {
    id: 'preset-syrma',
    symbol: 'SYRMA',
    title: 'Syrma SGS Technology',
    category: 'Indian Equity',
    description: 'National Stock Exchange (NSE: SYRMA) precision electronics manufacturing leader.',
    unit: 'INR (₹)',
    frequency: 'daily',
    recommendedHorizon: 32,
    covariates: STOCK_COVARIATE_DEFINITIONS,
    data: defaultSyrma.data,
    futureCovariates: defaultSyrma.futureCovariates
  },
  {
    id: 'preset-nifty50',
    symbol: 'NIFTY 50',
    title: 'NIFTY 50 Index',
    category: 'Indian Index',
    description: 'National Stock Exchange flagship benchmark 50 bluechip index.',
    unit: 'INR (₹)',
    frequency: 'daily',
    recommendedHorizon: 32,
    covariates: STOCK_COVARIATE_DEFINITIONS,
    data: defaultNifty.data,
    futureCovariates: defaultNifty.futureCovariates
  },
  {
    id: 'preset-gold',
    symbol: 'GOLD',
    title: 'Gold Futures (MCX)',
    category: 'Indian Commodity',
    description: 'Multi Commodity Exchange (MCX) Gold 10g 995 benchmark futures.',
    unit: 'INR (₹)',
    frequency: 'daily',
    recommendedHorizon: 32,
    covariates: STOCK_COVARIATE_DEFINITIONS,
    data: defaultGold.data,
    futureCovariates: defaultGold.futureCovariates
  }
];

export const INITIAL_PLACEHOLDER_PRESET: DatasetPreset = DEFAULT_INITIAL_PRESET;

// Export active presets array
export const DATASET_PRESETS: DatasetPreset[] = INITIAL_POPULAR_PRESETS;

