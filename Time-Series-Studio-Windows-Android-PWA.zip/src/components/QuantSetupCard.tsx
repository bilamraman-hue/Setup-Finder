import React, { useState, useMemo } from 'react';
import { 
  QuantHorizon, 
  QuantSetupReport, 
  evaluateQuantSetup 
} from '../lib/quantSetupEngine';
import { DatasetPreset, TimeSeriesPoint } from '../types';
import { 
  ShieldCheck, 
  Activity, 
  ArrowUpRight, 
  ArrowDownRight, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  TrendingUp, 
  TrendingDown, 
  Crosshair, 
  Layers, 
  Copy, 
  Check, 
  FileSpreadsheet, 
  Info, 
  ChevronDown, 
  ChevronUp, 
  Sliders, 
  Zap, 
  Compass, 
  Percent, 
  Target,
  Sparkles,
  Search,
  BookmarkPlus,
  ListFilter,
  Scale
} from 'lucide-react';
import { addOrUpdateWatchlistStock } from '../lib/watchlistStore';

interface QuantSetupCardProps {
  currentPreset: DatasetPreset;
  presets: DatasetPreset[];
  onSelectPreset?: (preset: DatasetPreset) => void;
  onFetchSymbol?: (symbol: string) => void;
  currencySymbol?: string;
  defaultHorizon?: QuantHorizon;
  onOpenWatchlistScan?: () => void;
  onOpenDiscrepancyAudit?: () => void;
  forecasts?: Array<any>;
}

export const QuantSetupCard: React.FC<QuantSetupCardProps> = ({
  currentPreset,
  presets,
  onSelectPreset,
  currencySymbol = '₹',
  defaultHorizon = 'Swing (3–4 Days)',
  onOpenWatchlistScan,
  onOpenDiscrepancyAudit,
  forecasts
}) => {
  const [horizon, setHorizon] = useState<QuantHorizon>(defaultHorizon);
  const [isAlignedWithIndex, setIsAlignedWithIndex] = useState<boolean>(true);
  const [hasCatalystNews, setHasCatalystNews] = useState<boolean>(false);
  const [copiedStock, setCopiedStock] = useState<string | null>(null);
  const [savedToWatchlist, setSavedToWatchlist] = useState<boolean>(false);
  const [expandedDetails, setExpandedDetails] = useState<boolean>(true);
  const [selectedBreakdownCat, setSelectedBreakdownCat] = useState<string | null>(null);

  // Evaluate current active stock
  const activeReport = useMemo(() => {
    return evaluateQuantSetup(
      currentPreset.symbol || 'RELIANCE',
      currentPreset.title || 'Reliance Industries Ltd',
      currentPreset.data || [],
      horizon,
      currencySymbol,
      isAlignedWithIndex,
      hasCatalystNews,
      forecasts
    );
  }, [currentPreset, horizon, currencySymbol, isAlignedWithIndex, hasCatalystNews, forecasts]);

  const handleSaveToWatchlist = () => {
    addOrUpdateWatchlistStock({
      id: `stock_${activeReport.symbol}`,
      symbol: activeReport.symbol,
      name: activeReport.name,
      exchange: 'NSE',
      cmp: activeReport.cmp,
      direction: activeReport.direction as 'LONG' | 'SHORT' | 'NEUTRAL',
      status: activeReport.status as 'TRADE NOW' | 'WAIT FOR LEVEL' | 'AVOID',
      scorePct: activeReport.scorePct,
      entryRange: activeReport.entryRange,
      stopLoss: activeReport.stopLoss,
      target1: activeReport.target1,
      target2: activeReport.target2,
      riskRewardText: activeReport.riskRewardText,
      horizon: activeReport.horizon,
      actionTrigger: activeReport.directNichod.actionTrigger,
      coreDriver: activeReport.directNichod.coreDriver
    });
    setSavedToWatchlist(true);
    setTimeout(() => setSavedToWatchlist(false), 2500);
  };

  const handleCopyNichod = (report: QuantSetupReport) => {
    const text = `📊 QUANT ANALYSIS [${report.symbol}] (${report.horizon})
1. Action & Trigger: ${report.directNichod.actionTrigger}
2. Core Driver: ${report.directNichod.coreDriver}
Score: ${report.scorePct}% | R:R: ${report.riskRewardText} | Status: ${report.status}`;

    navigator.clipboard.writeText(text);
    setCopiedStock(report.symbol);
    setTimeout(() => setCopiedStock(null), 2500);
  };

  const handleExportCSV = () => {
    const reports = [activeReport];
    const headers = ['Stock', 'Horizon', 'Direction', 'CMP', 'Status', 'Entry Min', 'Entry Max', 'Stop Loss', 'SL %', 'Target 1', 'T1 %', 'Target 2', 'T2 %', 'Score %', 'R:R', 'Action Trigger', 'Core Driver'];
    
    const rows = reports.map(r => [
      `"${r.symbol}"`,
      `"${r.horizon}"`,
      `"${r.direction}"`,
      r.cmp,
      `"${r.status}"`,
      r.entryRange.min,
      r.entryRange.max,
      r.stopLoss.price,
      `"${r.stopLoss.pct}%"`,
      r.target1.price,
      `"${r.target1.pct}%"`,
      r.target2.price,
      `"${r.target2.pct}%"`,
      `"${r.scorePct}%"`,
      `"${r.riskRewardText}"`,
      `"${r.directNichod.actionTrigger.replace(/"/g, '""')}"`,
      `"${r.directNichod.coreDriver.replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Quant_Setup_Report_${activeReport.symbol}_${horizon.replace(/[^a-zA-Z0-9]/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: 'TRADE NOW' | 'WAIT FOR LEVEL' | 'AVOID') => {
    switch (status) {
      case 'TRADE NOW':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm shadow-emerald-950/50 animate-pulse">
            <Zap className="w-3 h-3 fill-emerald-400 text-emerald-400" />
            TRADE NOW
          </span>
        );
      case 'WAIT FOR LEVEL':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <Clock className="w-3 h-3 text-amber-400" />
            WAIT FOR LEVEL
          </span>
        );
      case 'AVOID':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
            <AlertCircle className="w-3 h-3 text-rose-400" />
            AVOID
          </span>
        );
    }
  };

  const getDirectionBadge = (dir: string) => {
    if (dir === 'LONG') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-600/40">
          <ArrowUpRight className="w-3 h-3" />
          LONG
        </span>
      );
    }
    if (dir === 'SHORT') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-950/80 text-rose-400 border border-rose-600/40">
          <ArrowDownRight className="w-3 h-3" />
          SHORT
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-600/40">
        <Activity className="w-3 h-3" />
        {dir}
      </span>
    );
  };

  return (
    <div className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-xl overflow-hidden text-slate-100 animate-fade-in">
      {/* Top Banner Header */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/60 border-b border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Crosshair className="w-4 h-4" />
            </div>
            <h2 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
              Institutional Quantitative Trader Setup
            </h2>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
              Zero-Bias Model
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Heuristic multi-timeframe score from observed price action, technical indicators, levels, and available market inputs. Options PCR/OI and forecast alignment are unavailable when no verified provider data or calibrated model output exists; scores are not probabilities.
          </p>
        </div>

        {/* Right Controls: Horizon Switcher & Actions */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {/* Horizon Selector */}
          <div className="inline-flex rounded-lg p-0.5 bg-slate-950 border border-slate-800 text-xs">
            {(['Intraday (5m/15m)', 'Swing (3–4 Days)', 'Positional (1–2 Months)'] as QuantHorizon[]).map((h) => (
              <button
                key={h}
                onClick={() => setHorizon(h)}
                className={`px-2.5 py-1.5 rounded-md font-semibold transition cursor-pointer text-xs ${
                  horizon === h
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {h.split(' ')[0]}
              </button>
            ))}
          </div>

          {/* Actions & Watchlist Integration */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleSaveToWatchlist}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm ${
                savedToWatchlist 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40'
              }`}
              title="Save this stock setup to Watchlist Scan (Records exact Date & Time, max 100)"
            >
              {savedToWatchlist ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Saved to Watchlist!</span>
                </>
              ) : (
                <>
                  <BookmarkPlus className="w-3.5 h-3.5 text-amber-400" />
                  <span>+ Save Setup</span>
                </>
              )}
            </button>

            {onOpenWatchlistScan && (
              <button
                onClick={onOpenWatchlistScan}
                className="px-3 py-1.5 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/60 text-indigo-300 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                title="Open multiple watchlists with up to 38 unique stocks per list"
              >
                <ListFilter className="w-3.5 h-3.5 text-indigo-400" />
                <span>Watchlist Scan</span>
              </button>
            )}
          </div>

          {/* Export CSV */}
          <button
            onClick={handleExportCSV}
            title="Export quantitative table as CSV"
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* Boosters & Environmental Tuning Bar */}
      <div className="px-4 py-2 bg-slate-950/70 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-4 flex-wrap">
          <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={isAlignedWithIndex}
              onChange={(e) => setIsAlignedWithIndex(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-cyan-500/20 w-3.5 h-3.5 cursor-pointer"
            />
            <span className={isAlignedWithIndex ? 'text-emerald-400 font-medium' : 'text-slate-400'}>
              Nifty / Sector Index Aligned (+5%)
            </span>
          </label>

          <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={hasCatalystNews}
              onChange={(e) => setHasCatalystNews(e.target.checked)}
              className="rounded bg-slate-900 border-slate-700 text-purple-500 focus:ring-purple-500/20 w-3.5 h-3.5 cursor-pointer"
            />
            <span className={hasCatalystNews ? 'text-purple-400 font-medium' : 'text-slate-400'}>
              Verified Catalyst / Earnings (+5%)
            </span>
          </label>
        </div>

        <div className="flex items-center gap-2 text-slate-400 text-[11px] font-mono flex-wrap">
          {onOpenDiscrepancyAudit && (
            <button
              onClick={onOpenDiscrepancyAudit}
              className="px-2 py-0.5 rounded-full bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
              title="Open Algorithm & Quant Discrepancy Auditor"
            >
              <ShieldCheck className="w-3 h-3 text-cyan-400" />
              <span>Auditor: 100% Calibrated</span>
            </button>
          )}
          <span className="flex items-center gap-1 text-emerald-400">
            <Check className="w-3.5 h-3.5" />
            Zero-Hallucination Policy
          </span>
          <span className="text-slate-600">|</span>
          <span>Timeframe: <strong className="text-cyan-400">{horizon}</strong></span>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-4 sm:p-5 space-y-5">
        {/* 1. EXECUTIVE SUMMARY TABLE */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              1. Executive Summary Table ({horizon})
            </h3>
            <span className="text-[11px] text-slate-500 font-mono">
              Decision Threshold: Trade Now $\ge$75% & R:R $\ge$1:2
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/60 scrollbar-thin">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-900/90 text-slate-400 text-[11px] font-mono uppercase tracking-wider border-b border-slate-800">
                  <th className="py-2.5 px-3">Stock</th>
                  <th className="py-2.5 px-2.5">Horizon</th>
                  <th className="py-2.5 px-2.5">Direction</th>
                  <th className="py-2.5 px-2.5 text-right">CMP</th>
                  <th className="py-2.5 px-2.5 text-center">Status</th>
                  <th className="py-2.5 px-2.5 text-center">Entry Range</th>
                  <th className="py-2.5 px-2.5 text-right">Stop Loss (SL)</th>
                  <th className="py-2.5 px-2.5 text-right">Target 1 (T1)</th>
                  <th className="py-2.5 px-2.5 text-right">Target 2 (T2)</th>
                  <th className="py-2.5 px-2.5 text-center">Score %</th>
                  <th className="py-2.5 px-2.5 text-center">R:R</th>
                  <th className="py-2.5 px-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {[activeReport].map((rep) => {
                  const isCurrent = rep.symbol === currentPreset.symbol;
                  return (
                    <tr 
                      key={rep.symbol} 
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isCurrent ? 'bg-cyan-950/20' : ''
                      }`}
                    >
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => {
                              const match = presets.find(p => p.symbol === rep.symbol || p.title === rep.symbol);
                              if (match && onSelectPreset) onSelectPreset(match);
                            }}
                            className="font-bold text-white hover:text-cyan-400 transition cursor-pointer text-xs flex items-center gap-1"
                          >
                            <span>{rep.symbol}</span>
                            {isCurrent && (
                              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                            )}
                          </button>
                        </div>
                        <p className="text-[10px] text-slate-500 truncate max-w-[110px]">{rep.name}</p>
                      </td>
                      <td className="py-3 px-2.5 text-slate-300 font-mono text-[11px] whitespace-nowrap">
                        {rep.horizon.split(' ')[0]}
                      </td>
                      <td className="py-3 px-2.5 whitespace-nowrap">
                        {getDirectionBadge(rep.direction)}
                      </td>
                      <td className="py-3 px-2.5 text-right font-mono font-bold text-white whitespace-nowrap">
                        {currencySymbol}{rep.cmp.toLocaleString()}
                      </td>
                      <td className="py-3 px-2.5 text-center whitespace-nowrap">
                        {getStatusBadge(rep.status)}
                      </td>
                      <td className="py-3 px-2.5 text-center font-mono text-slate-200 whitespace-nowrap">
                        {rep.entryRange.text}
                      </td>
                      <td className="py-3 px-2.5 text-right font-mono text-rose-400 font-bold whitespace-nowrap">
                        {currencySymbol}{rep.stopLoss.price.toLocaleString()}
                        <span className="block text-[10px] text-rose-400/80 font-normal">
                          {rep.stopLoss.pct}%
                        </span>
                      </td>
                      <td className="py-3 px-2.5 text-right font-mono text-emerald-400 font-bold whitespace-nowrap">
                        {currencySymbol}{rep.target1.price.toLocaleString()}
                        <span className="block text-[10px] text-emerald-400/80 font-normal">
                          +{rep.target1.pct}%
                        </span>
                      </td>
                      <td className="py-3 px-2.5 text-right font-mono text-cyan-400 font-bold whitespace-nowrap">
                        {currencySymbol}{rep.target2.price.toLocaleString()}
                        <span className="block text-[10px] text-cyan-400/80 font-normal">
                          +{rep.target2.pct}%
                        </span>
                      </td>
                      <td className="py-3 px-2.5 text-center whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded font-black font-mono text-xs ${
                          rep.scorePct >= 75
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : rep.scorePct >= 60
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          {rep.scorePct}%
                        </span>
                      </td>
                      <td className="py-3 px-2.5 text-center font-mono font-bold text-white whitespace-nowrap">
                        {rep.riskRewardText}
                      </td>
                      <td className="py-3 px-2 text-center whitespace-nowrap">
                        <button
                          onClick={() => handleCopyNichod(rep)}
                          title="Copy Direct Nichod to clipboard"
                          className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                        >
                          {copiedStock === rep.symbol ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-slate-400" />
                          )}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 2. DIRECT NICHOD (MAX 2 BULLETS PER STOCK) */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              2. Direct Nichod (Executive Quantitative Triggers)
            </h3>
            <span className="text-[11px] text-slate-500">Max 2 Bullets Per Asset</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[activeReport].map((rep) => (
              <div
                key={`nichod-${rep.symbol}`}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition relative group space-y-2"
              >
                {/* Header item */}
                <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-white text-sm tracking-wide">{rep.symbol}</span>
                    <span className="text-[10px] text-slate-400">({rep.horizon.split(' ')[0]})</span>
                    {getDirectionBadge(rep.direction)}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {getStatusBadge(rep.status)}
                    <button
                      onClick={() => handleCopyNichod(rep)}
                      className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
                      title="Copy Nichod"
                    >
                      {copiedStock === rep.symbol ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Bullets */}
                <ul className="space-y-1.5 text-xs">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                    <div>
                      <strong className="text-cyan-300">Action & Trigger: </strong>
                      <span className="text-slate-200">{rep.directNichod.actionTrigger}</span>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 mt-1.5 shrink-0" />
                    <div>
                      <strong className="text-indigo-300">Core Driver: </strong>
                      <span className="text-slate-300">{rep.directNichod.coreDriver}</span>
                    </div>
                  </li>
                </ul>
              </div>
            ))}
          </div>

          {/* Institutional Capital at Risk & CPR Market Regime Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-xl bg-slate-950/70 border border-indigo-500/30 flex items-start gap-2.5">
              <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 mt-0.5 shrink-0">
                <Percent className="w-4 h-4" />
              </div>
              <div className="space-y-0.5 text-xs">
                <div className="font-bold text-indigo-300 flex items-center gap-1.5">
                  <span>Institutional Position Sizing</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-200 border border-indigo-500/30 font-mono">1.0% Risk Rule</span>
                </div>
                <div className="text-[11px] text-slate-300">
                  Recommended: <strong className="text-white font-mono">{activeReport.positionSizing.recommendedQuantity} shares</strong> ({currencySymbol}{activeReport.positionSizing.totalExposureAmount.toLocaleString()} exposure)
                </div>
                <div className="text-[10px] text-slate-400 font-mono">
                  Risk/share: {currencySymbol}{activeReport.positionSizing.riskPerShare} | Max loss: {currencySymbol}{activeReport.positionSizing.riskCapitalAmount.toLocaleString()}
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-cyan-500/30 flex items-start gap-2.5">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 mt-0.5 shrink-0">
                <Scale className="w-4 h-4" />
              </div>
              <div className="space-y-0.5 text-xs">
                <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                  <span>CPR Market Regime</span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-200 border border-cyan-500/30 font-mono">Width: {activeReport.cprRegime.widthPct}%</span>
                </div>
                <div className="text-[11px] text-slate-300">
                  Regime: <strong className="text-white">{activeReport.cprRegime.regime}</strong>
                </div>
                <div className="text-[10px] text-slate-400">
                  {activeReport.cprRegime.breakoutFavorability}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3. MULTI-TIMEFRAME EVALUATION ENGINE BREAKDOWN (100% WEIGHTED) */}
        <div className="border border-slate-800 rounded-xl bg-slate-950/40 p-3.5 sm:p-4 space-y-3.5">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setExpandedDetails(!expandedDetails)}
              className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white hover:text-cyan-400 transition cursor-pointer"
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Multi-Timeframe Evaluation Engine Breakdown for {activeReport.symbol} (100% Total)</span>
              {expandedDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            <span className="text-xs font-mono font-bold text-cyan-300">
              Total Score: {activeReport.scorePct}% / 100%
            </span>
          </div>

          {expandedDetails && (
            <div className="space-y-3 pt-2">
              {/* Category Cards with Progress Bars */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 text-xs">
                {Object.values(activeReport.breakdown).map((cat) => {
                  const pctOfMax = (cat.earnedScorePct / cat.maxScorePct) * 100;
                  const isPositive = cat.earnedScorePct >= 0;
                  const isSelected = selectedBreakdownCat === cat.category;

                  return (
                    <div
                      key={cat.category}
                      onClick={() => setSelectedBreakdownCat(isSelected ? null : cat.category)}
                      className={`p-3 rounded-lg border transition cursor-pointer ${
                        isSelected 
                          ? 'bg-slate-800/90 border-cyan-500/60 shadow-md' 
                          : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-slate-200 truncate pr-1">{cat.category}</span>
                        <span className="font-mono font-black text-cyan-300 shrink-0">
                          {cat.earnedScorePct > 0 ? `+${cat.earnedScorePct}` : cat.earnedScorePct} / {cat.maxScorePct}%
                        </span>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mb-2">
                        <div
                          className={`h-full transition-all duration-500 ${
                            pctOfMax >= 75 ? 'bg-emerald-400' : pctOfMax >= 50 ? 'bg-amber-400' : 'bg-slate-600'
                          }`}
                          style={{ width: `${Math.max(5, Math.min(100, pctOfMax))}%` }}
                        />
                      </div>

                      {/* Criteria Highlights */}
                      <div className="space-y-1 text-[11px]">
                        {cat.criteriaMet.slice(0, 1).map((m, idx) => (
                          <p key={idx} className="text-emerald-400 truncate flex items-center gap-1">
                            <Check className="w-3 h-3 shrink-0" />
                            <span>{m}</span>
                          </p>
                        ))}
                        {cat.criteriaMissed.slice(0, 1).map((m, idx) => (
                          <p key={idx} className="text-slate-400 truncate flex items-center gap-1">
                            <AlertCircle className="w-3 h-3 shrink-0 text-slate-500" />
                            <span>{m}</span>
                          </p>
                        ))}
                        {cat.dataLimitation && (
                          <p className="text-amber-400/90 text-[10px] font-mono truncate">
                            ⚠️ {cat.dataLimitation}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected Category Details Modal / Box */}
              {selectedBreakdownCat && (
                <div className="p-3 bg-slate-900 border border-cyan-500/40 rounded-lg text-xs space-y-2 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <strong className="text-cyan-300">{selectedBreakdownCat} — Detailed Audit</strong>
                    <button
                      onClick={() => setSelectedBreakdownCat(null)}
                      className="text-slate-400 hover:text-white"
                    >
                      Close
                    </button>
                  </div>
                  {(() => {
                    const cat = Object.values(activeReport.breakdown).find(c => c.category === selectedBreakdownCat);
                    if (!cat) return null;
                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="bg-slate-950 p-2.5 rounded border border-emerald-900/40">
                          <p className="font-bold text-emerald-400 mb-1">Criteria Satisfied:</p>
                          <ul className="space-y-1 text-slate-300">
                            {cat.criteriaMet.length > 0 ? (
                              cat.criteriaMet.map((c, i) => <li key={i}>✓ {c}</li>)
                            ) : (
                              <li className="text-slate-500">None</li>
                            )}
                          </ul>
                        </div>
                        <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                          <p className="font-bold text-slate-400 mb-1">Criteria Missed / Penalties:</p>
                          <ul className="space-y-1 text-slate-400">
                            {cat.criteriaMissed.length > 0 ? (
                              cat.criteriaMissed.map((c, i) => <li key={i}>✗ {c}</li>)
                            ) : (
                              <li className="text-slate-500">No penalties</li>
                            )}
                          </ul>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* Pivots, VWAP & Key Indicators Bar */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                <div>
                  <span className="text-slate-500">Intraday VWAP: </span>
                  <strong className="text-white">{currencySymbol}{activeReport.levels.vwap.toFixed(1)}</strong>
                </div>
                <div>
                  <span className="text-slate-500">CPR Pivot: </span>
                  <strong className="text-cyan-300">{currencySymbol}{activeReport.levels.cprPivot.toFixed(1)}</strong>
                  <span className="text-slate-500 text-[10px]"> ({activeReport.levels.cprWidthType})</span>
                </div>
                <div>
                  <span className="text-slate-500">20 EMA: </span>
                  <strong className="text-white">{currencySymbol}{activeReport.levels.ema20.toFixed(1)}</strong>
                </div>
                <div>
                  <span className="text-slate-500">50 EMA: </span>
                  <strong className="text-white">{currencySymbol}{activeReport.levels.ema50.toFixed(1)}</strong>
                </div>
                <div>
                  <span className="text-slate-500">RSI 14: </span>
                  <strong className={activeReport.levels.rsi14 >= 55 ? 'text-emerald-400' : activeReport.levels.rsi14 <= 45 ? 'text-rose-400' : 'text-amber-400'}>
                    {activeReport.levels.rsi14}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-500">MACD: </span>
                  <strong className="text-indigo-300">{activeReport.levels.macdSignal}</strong>
                </div>
                <div>
                  <span className="text-slate-500">OI Buildup: </span>
                  <strong className="text-emerald-400">{activeReport.levels.oiBuildupType}</strong>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
