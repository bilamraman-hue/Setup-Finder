import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Upload, 
  Download, 
  Play, 
  Sliders, 
  Database, 
  AlertTriangle, 
  RefreshCw, 
  Wand2,
  Layers,
  ChevronDown,
  Globe,
  Zap,
  Cpu,
  TrendingUp,
  WifiOff,
  Search,
  X,
  Crosshair,
  ShieldCheck,
  ListFilter,
  CandlestickChart,
  Wallet,
  BarChart3,
  Bell
} from 'lucide-react';
import { DatasetPreset, ModelConfig, ModelVersion, ProviderFetchConfig } from '../types';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import { searchMarketSymbols, SearchResultItem } from '../lib/marketProvider';
import { normalizeSymbol } from '../lib/upstoxInstruments';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  presets: DatasetPreset[];
  currentPreset: DatasetPreset;
  onSelectPreset: (preset: DatasetPreset) => void;
  modelConfig: ModelConfig;
  onChangeModelConfig: (config: Partial<ModelConfig>) => void;
  onRunForecast: () => void;
  isLoading: boolean;
  onOpenUpload: () => void;
  onOpenSynthetic?: () => void;
  onOpenAIReport: () => void;
  onOpenMarketProvider: () => void;
  activeTab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition';
  setActiveTab: (tab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition') => void;
  onOpenAdvanceChart?: () => void;
  onOpenFinalVerdict?: () => void;
  onOpenWatchlistScan?: () => void;
  onOpenMySetups?: () => void;
  mySetupsCount?: number;
  watchlistCount?: number;
  anomaliesCount: number;
  hasCovariates: boolean;
  executionTimeMs?: number;
  isLocalMode: boolean;
  onToggleLocalMode: (isLocal: boolean) => void;
  lastClosePrice?: number;
  currency?: string;
  onSearchAndFetch?: (symbol: string) => Promise<void> | void;
  isSearchingOrFetching?: boolean;
  selectedApiConfig?: ProviderFetchConfig;
  onOpenAuthModal?: () => void;
  onOpenPaperTrading?: () => void;
  onOpenWalkForwardBacktest?: () => void;
  onOpenAlerts?: () => void;
  onToggleWatchlistDrawer?: () => void;
}

const QUICK_INSTRUMENTS = [
  { symbol: 'SYRMA', name: 'Syrma SGS Tech', type: 'Stock' },
  { symbol: 'RELIANCE', name: 'Reliance Industries', type: 'Stock' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', type: 'Stock' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', type: 'Stock' },
  { symbol: 'INFY', name: 'Infosys Ltd', type: 'Stock' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors', type: 'Stock' },
  { symbol: 'NIFTY 50', name: 'NIFTY 50 Index', type: 'Index' },
  { symbol: 'BANKNIFTY', name: 'Bank Nifty Index', type: 'Index' },
  { symbol: 'SENSEX', name: 'BSE SENSEX 30', type: 'Index' },
  { symbol: 'GOLD', name: 'MCX Gold Futures (₹/10g)', type: 'Commodity' },
  { symbol: 'SILVER', name: 'MCX Silver Futures (₹/kg)', type: 'Commodity' },
  { symbol: 'CRUDEOIL', name: 'MCX Crude Oil (₹/bbl)', type: 'Commodity' },
  { symbol: 'NATURALGAS', name: 'MCX Natural Gas (₹/mmBtu)', type: 'Commodity' },
  { symbol: 'COPPER', name: 'MCX Copper (₹/kg)', type: 'Commodity' }
];

export const Header: React.FC<HeaderProps> = ({
  presets,
  currentPreset,
  onSelectPreset,
  modelConfig,
  onChangeModelConfig,
  onRunForecast,
  isLoading,
  onOpenUpload,
  onOpenSynthetic,
  onOpenAIReport,
  onOpenMarketProvider,
  activeTab,
  setActiveTab,
  onOpenAdvanceChart,
  onOpenFinalVerdict,
  onOpenWatchlistScan,
  onOpenMySetups,
  mySetupsCount,
  watchlistCount,
  anomaliesCount,
  hasCovariates,
  executionTimeMs,
  isLocalMode,
  onToggleLocalMode,
  lastClosePrice,
  currency = 'INR',
  onSearchAndFetch,
  isSearchingOrFetching,
  selectedApiConfig,
  onOpenAuthModal,
  onOpenPaperTrading,
  onOpenWalkForwardBacktest,
  onOpenAlerts,
  onToggleWatchlistDrawer
}) => {
  const isOnline = useOnlineStatus();
  const { user } = useAuth();
  const currSym = currency.includes('INR') || currency.includes('₹') ? '₹' : '$';

  // Search input state for header search bar
  const [headerSearchQuery, setHeaderSearchQuery] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [isSearchingApi, setIsSearchingApi] = useState(false);
  const searchBarContainerRef = useRef<HTMLDivElement>(null);

  // Active API label
  const isCustomConnected = selectedApiConfig?.provider === 'custom_api' && (selectedApiConfig?.isConnected || Boolean(selectedApiConfig?.apiKey));
  const activeApiLabel = selectedApiConfig?.provider === 'binance' 
    ? 'Binance (Crypto ₹)' 
    : selectedApiConfig?.provider === 'custom_api' 
      ? `Custom API ${isCustomConnected ? `🟢 (${selectedApiConfig.dataType === 'live' ? 'Live' : 'Historical'})` : '(Key Setup)'}` 
      : 'Yahoo Finance';

  // Debounced search when user types in header search bar
  useEffect(() => {
    const q = headerSearchQuery.trim();
    if (q.length < 2) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearchingApi(true);
      try {
        const results = await searchMarketSymbols(q);
        setSearchResults(results);
      } catch {
        setSearchResults([]);
      } finally {
        setIsSearchingApi(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [headerSearchQuery]);

  // Click outside to close header search dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchBarContainerRef.current && !searchBarContainerRef.current.contains(e.target as Node)) {
        setShowSearchDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleExecuteSearch = (targetSymbol: string) => {
    const sym = normalizeSymbol(targetSymbol);
    if (!sym) return;
    setShowSearchDropdown(false);
    setHeaderSearchQuery('');
    if (onSearchAndFetch) {
      onSearchAndFetch(sym);
    }
  };

  return (
    <header className="border-b border-slate-800 bg-slate-900/95 backdrop-blur sticky top-0 z-30">
      {/* Top Banner / Brand Row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Logo and Model Badge */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-950/50 border border-cyan-400/30 shrink-0">
            <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm sm:text-base font-bold tracking-tight text-white flex items-center gap-1.5">
                Time Series Studio <span className="text-cyan-400 text-[10px] sm:text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800/60 font-mono">NSE • BSE • MCX</span>
              </h1>
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 hidden md:block">
              Local statistical forecast baseline · estimated bands are uncalibrated
            </p>
          </div>
        </div>

        {/* Center: Active Market Display, Blank Search Bar & Provider API Button */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-1 max-w-xl justify-end md:justify-center">
          {/* Active Instrument / Fetched Selector */}
          {presets.filter(p => !!p.symbol).length > 0 && (
            <div className="relative hidden lg:block">
              <select
                id="preset-selector"
                value={currentPreset.id}
                onChange={(e) => {
                  const found = presets.find(p => p.id === e.target.value);
                  if (found) onSelectPreset(found);
                }}
                className="bg-slate-800/95 hover:bg-slate-800 text-xs font-medium text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1.5 pr-7 focus:outline-none focus:ring-1 focus:ring-cyan-500 appearance-none cursor-pointer max-w-[140px] truncate"
              >
                {presets.filter(p => !!p.symbol).map(p => (
                  <option key={p.id} value={p.id}>
                    {p.symbol} - {p.title}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          )}

          {/* User Request 2: Blank Search Bar located directly to the left of the API icon symbol button */}
          <div className="relative flex-1 max-w-xs sm:max-w-sm" ref={searchBarContainerRef}>
            <div className="relative flex items-center w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 pointer-events-none" />
              <input
                id="header-market-search-bar"
                type="text"
                value={headerSearchQuery}
                onChange={(e) => {
                  setHeaderSearchQuery(e.target.value);
                  setShowSearchDropdown(true);
                }}
                onFocus={() => setShowSearchDropdown(true)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && headerSearchQuery.trim()) {
                    e.preventDefault();
                    handleExecuteSearch(headerSearchQuery.trim());
                  } else if (e.key === 'Escape') {
                    setShowSearchDropdown(false);
                  }
                }}
                placeholder="Search stock, index, commodity..."
                disabled={isSearchingOrFetching}
                className="w-full pl-8 pr-7 py-1.5 sm:py-2 bg-slate-950/90 hover:bg-slate-950 focus:bg-slate-950 border border-slate-700/80 focus:border-cyan-400 text-white placeholder-slate-500 rounded-lg text-xs font-mono transition-all shadow-inner focus:outline-none focus:ring-1 focus:ring-cyan-400 disabled:opacity-50"
              />
              {isSearchingOrFetching || isSearchingApi ? (
                <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin absolute right-2.5 pointer-events-none" />
              ) : headerSearchQuery ? (
                <button
                  type="button"
                  onClick={() => {
                    setHeaderSearchQuery('');
                    setShowSearchDropdown(false);
                  }}
                  className="absolute right-2 text-slate-500 hover:text-slate-300 p-0.5 cursor-pointer"
                >
                  <X className="w-3 h-3" />
                </button>
              ) : null}
            </div>

            {/* Dropdown Suggestions for Stock, Index or Commodity */}
            {showSearchDropdown && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden text-xs py-1 max-h-72 overflow-y-auto">
                {headerSearchQuery.trim().length >= 2 ? (
                  searchResults.length > 0 ? (
                    <div>
                      <div className="px-3 py-1 text-[10px] uppercase font-mono text-slate-400 tracking-wider bg-slate-950/50 border-b border-slate-800">
                        Matches from {activeApiLabel}
                      </div>
                      {searchResults.map((item) => {
                        const displaySym = item.cleanSymbol || normalizeSymbol(item.symbol);
                        return (
                          <button
                            key={item.symbol}
                            type="button"
                            onClick={() => handleExecuteSearch(displaySym)}
                            className="w-full px-3 py-2 text-left hover:bg-slate-800 flex items-center justify-between transition cursor-pointer border-b border-slate-800/40 last:border-0"
                          >
                            <div className="flex items-center gap-2 overflow-hidden">
                              <span className="font-bold text-white font-mono shrink-0">{displaySym}</span>
                              <span className="text-slate-400 text-[11px] truncate">{item.name}</span>
                            </div>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/70 border border-cyan-800/50 text-cyan-300 shrink-0">
                              Fetch (₹)
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  ) : !isSearchingApi ? (
                    <div className="px-3 py-2.5 text-slate-400 text-center">
                      <span>No direct symbols found. Press </span>
                      <strong className="text-cyan-400 font-mono">Enter ↵</strong>
                      <span> to query {activeApiLabel} for "{headerSearchQuery}"</span>
                    </div>
                  ) : null
                ) : (
                  <div>
                    <div className="px-3 py-1 text-[10px] uppercase font-mono text-slate-400 tracking-wider bg-slate-950/50 border-b border-slate-800">
                      Popular Indian Stocks, Indices & MCX Commodities
                    </div>
                    {QUICK_INSTRUMENTS.map((inst) => (
                      <button
                        key={inst.symbol}
                        type="button"
                        onClick={() => handleExecuteSearch(inst.symbol)}
                        className="w-full px-3 py-1.5 text-left hover:bg-slate-800 flex items-center justify-between transition cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white font-mono">{inst.symbol}</span>
                          <span className="text-slate-400 text-[11px] truncate">{inst.name}</span>
                        </div>
                        <span className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                          inst.type === 'Commodity'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800/50'
                            : inst.type === 'Index'
                              ? 'bg-indigo-950 text-indigo-300 border border-indigo-800/50'
                              : 'bg-slate-800 text-slate-300'
                        }`}>
                          {inst.type}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Provider API Fetch Button (API Icon Symbol Option) */}
          <button
            id="btn-open-market-provider"
            type="button"
            onClick={onOpenMarketProvider}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg bg-gradient-to-r from-cyan-950 to-blue-950 hover:from-cyan-900 hover:to-blue-900 text-cyan-300 text-xs font-semibold border border-cyan-700/60 shadow-sm transition-all cursor-pointer shrink-0"
            title={`Active API: ${activeApiLabel}. Click to switch API or configure provider.`}
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow shrink-0" />
            <span className="hidden sm:inline font-mono text-[11px] text-cyan-200">
              {activeApiLabel}
            </span>
            <span className="sm:hidden text-[10px]">API</span>
          </button>

          {/* Local vs Cloud Engine Toggle */}
          <button
            id="btn-toggle-engine-mode"
            type="button"
            onClick={() => onToggleLocalMode(!isLocalMode)}
            className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-mono transition cursor-pointer ${
              isLocalMode
                ? 'bg-emerald-950/40 border-emerald-700/50 text-emerald-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-300'
            }`}
            title={isLocalMode ? 'Running 100% on-device local' : 'Running via hybrid server'}
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isLocalMode ? 'Local Engine' : 'Cloud Proxy'}</span>
          </button>

          {/* Import CSV / Data */}
          <button
            id="btn-upload-csv"
            onClick={onOpenUpload}
            className="hidden xl:flex items-center gap-1.5 px-2.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
            title="Import custom CSV / TradingView export"
          >
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Import CSV</span>
          </button>
        </div>

        {/* Right: PWA Install, AI Report & Forecast Action */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Offline indicator if disconnected */}
          {!isOnline && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-950/70 border border-amber-800/60 text-amber-300 text-xs font-mono" title="Offline mode: using cached data and on-device model">
              <WifiOff className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Offline (Local)</span>
            </div>
          )}

          {/* Firebase Authentication & Profile Button */}
          {onOpenAuthModal && (
            <button
              id="btn-auth-profile"
              onClick={onOpenAuthModal}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                user
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
              title={user ? `Signed in as ${user.email}. Click for Auth & Secure Proxy` : 'Sign in with Google / Firebase'}
            >
              {user ? (
                <>
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-4 h-4 rounded-full object-cover border border-emerald-400/50" />
                  ) : (
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  <span className="hidden md:inline truncate max-w-[100px] text-[11px] font-mono">
                    {user.displayName?.split(' ')[0] || 'User'}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">Sign In</span>
                </>
              )}
            </button>
          )}

          {/* AI Trading Analysis */}
          <button
            id="btn-ai-insights"
            onClick={onOpenAIReport}
            className="hidden sm:flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-lg bg-gradient-to-r from-purple-950 to-indigo-950 hover:from-purple-900 hover:to-indigo-900 text-purple-200 text-xs font-medium border border-purple-700/50 shadow-sm transition-all cursor-pointer"
            title="Generate AI Trading Report"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden md:inline">AI Analysis</span>
          </button>

          {/* Run Forecast Button */}
          <button
            id="btn-run-forecast"
            onClick={onRunForecast}
            disabled={isLoading}
            className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-cyan-900/40 border border-cyan-400/30 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isLoading ? (
              <RefreshCw className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin text-white" />
            ) : (
              <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-white" />
            )}
            <span>{isLoading ? 'Forecasting...' : 'Predict'}</span>
          </button>
        </div>
      </div>

      {/* Sub-navigation Tabs */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 flex items-center justify-between border-t border-slate-800/80 text-xs font-medium">
        <div className="flex items-center gap-1 py-1.5 overflow-x-auto scrollbar-none">
          <button
            id="tab-forecast"
            onClick={() => setActiveTab('forecast')}
            className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'forecast'
                ? 'bg-slate-800 text-cyan-400 border border-slate-700 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Trading Canvas</span>
          </button>

          <button
            id="tab-quant"
            onClick={() => setActiveTab('quant')}
            className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'quant'
                ? 'bg-gradient-to-r from-indigo-950 to-slate-800 text-indigo-300 border border-indigo-500/50 font-bold shadow-sm'
                : 'text-slate-300 hover:text-indigo-300 hover:bg-slate-800/60'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5 text-indigo-400" />
            <span>⚡ Quant Setup Engine</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-mono">
              30/20/20/15/15
            </span>
          </button>

          {onOpenAdvanceChart && (
            <button
              id="header-advance-chart-btn"
              onClick={onOpenAdvanceChart}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 text-purple-300 border border-purple-500/40 hover:border-purple-400 font-bold shadow-sm group"
              title="Open Dedicated Advance Chart (Local Forecast Baseline + Technical Indicators)"
            >
              <CandlestickChart className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
              <span>📈 Advance Chart</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] bg-purple-500/20 text-purple-200 border border-purple-500/30 font-bold">
                Multi-TF
              </span>
            </button>
          )}

          {onOpenFinalVerdict && (
            <button
              id="header-final-verdict-btn"
              onClick={onOpenFinalVerdict}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 text-amber-300 border border-amber-500/40 hover:border-amber-400 font-bold shadow-sm group"
              title="Open Final Trading Verdict (Heuristic Forecast + Technical Analysis)"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span>🎯 Final Verdict</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-200 border border-amber-500/30 font-bold">
                Buy/Sell/Hold
              </span>
            </button>
          )}

          {onOpenWatchlistScan && (
            <button
              id="header-watchlist-scan-btn"
              onClick={onOpenWatchlistScan}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-slate-900 hover:bg-slate-800 text-indigo-300 border border-indigo-700/60 font-bold shadow-sm group"
              title="Open Watchlist Scan (multiple lists, up to 38 unique stocks per list)"
            >
              <ListFilter className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>📋 Watchlist Scan</span>
              {watchlistCount !== undefined && watchlistCount > 0 && (
                <span className="px-1.5 py-0.2 rounded text-[9px] bg-indigo-500/20 text-indigo-200 border border-indigo-500/40 font-mono font-bold">
                  {watchlistCount}/38
                </span>
              )}
            </button>
          )}

          {onOpenMySetups && (
            <button id="header-my-setups-btn" onClick={onOpenMySetups} className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-cyan-950/60 hover:bg-cyan-900/70 text-cyan-300 border border-cyan-700/60 font-bold shadow-sm" title="Open saved, qualified Grade A setups">
              <Layers className="w-3.5 h-3.5" /><span>My Setups</span>
              {!!mySetupsCount && <span className="rounded bg-cyan-500/20 px-1.5 text-[9px] font-mono">{mySetupsCount}</span>}
            </button>
          )}

          {onToggleWatchlistDrawer && (
            <button
              id="header-watchlist-drawer-btn"
              onClick={onToggleWatchlistDrawer}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-slate-900 hover:bg-slate-800 text-indigo-300 border border-indigo-700/60 font-bold shadow-sm group"
              title="Toggle Fast Watchlist Side Drawer"
            >
              <ListFilter className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>Side Drawer</span>
            </button>
          )}

          {onOpenPaperTrading && (
            <button
              id="header-paper-trading-btn"
              onClick={onOpenPaperTrading}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 text-emerald-300 border border-emerald-500/40 hover:border-emerald-400 font-bold shadow-sm group"
              title="Open Virtual Paper Trading Simulator (1-Click virtual execution, P&L tracking)"
            >
              <Wallet className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span>💼 Paper Trade</span>
            </button>
          )}

          {onOpenWalkForwardBacktest && (
            <button
              id="header-walk-forward-btn"
              onClick={onOpenWalkForwardBacktest}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-slate-900 hover:bg-slate-800 text-purple-300 border border-purple-700/50 font-bold shadow-sm group"
              title="Open Walk-Forward Backtesting Engine (Sharpe Ratio, Win Rate %, Equity Curve)"
            >
              <BarChart3 className="w-3.5 h-3.5 text-purple-400 group-hover:scale-110 transition-transform" />
              <span>📊 Walk-Forward</span>
            </button>
          )}

          {onOpenAlerts && (
            <button
              id="header-alerts-btn"
              onClick={onOpenAlerts}
              className="px-3 py-1.5 rounded-md transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-700/50 font-bold shadow-sm group"
              title="Configure webhook alert test"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span>🔔 Alerts</span>
            </button>
          )}

          {hasCovariates && (
            <button
              id="tab-scenario"
              onClick={() => setActiveTab('scenario')}
              className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === 'scenario'
                  ? 'bg-slate-800 text-cyan-400 border border-slate-700 font-semibold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 text-amber-400" />
              <span>What-If Indicators</span>
            </button>
          )}

          <button
            id="tab-anomalies"
            onClick={() => setActiveTab('anomalies')}
            className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'anomalies'
                ? 'bg-slate-800 text-red-400 border border-slate-700 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            <span>Market Anomalies</span>
            {anomaliesCount > 0 && (
              <span className="px-1.5 py-0.2 bg-red-900/60 text-red-300 rounded-full text-[10px] font-bold border border-red-700/50 font-mono">
                {anomaliesCount}
              </span>
            )}
          </button>

          <button
            id="tab-decomposition"
            onClick={() => setActiveTab('decomposition')}
            className={`px-3 py-1.5 rounded-md transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'decomposition'
                ? 'bg-slate-800 text-indigo-400 border border-slate-700 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>Trend & Cycles</span>
          </button>
        </div>

        {/* Latency & device info */}
        <div className="hidden md:flex items-center gap-3 text-slate-500 text-[11px] font-mono">
          {lastClosePrice !== undefined && (
            <span>Last: <strong className="text-slate-300">{currSym}{lastClosePrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
          )}
          {executionTimeMs !== undefined && (
            <span>Inference: <strong className="text-cyan-400">{executionTimeMs}ms</strong></span>
          )}
        </div>
      </div>
    </header>
  );
};
