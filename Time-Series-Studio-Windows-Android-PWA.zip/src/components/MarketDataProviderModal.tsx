import React, { useState, useEffect } from 'react';
import { MarketProvider, ProviderFetchConfig, TimeSeriesPoint } from '../types';
import { 
  fetchMarketData, 
  MarketFetchResult, 
  parseCustomApiResponse,
  testCustomApiConnection,
  ApiTestResult
} from '../lib/marketProvider';
import { resolveUpstoxInstrumentKey } from '../lib/upstoxInstruments';
import { 
  Globe, 
  Zap, 
  Search, 
  RefreshCw, 
  Key, 
  TrendingUp, 
  Cpu, 
  CheckCircle2, 
  AlertCircle, 
  X,
  Code,
  Sliders,
  ChevronDown,
  ChevronUp,
  FileJson,
  Play,
  Clipboard,
  Eye,
  EyeOff,
  Trash2,
  Radio,
  RadioTower,
  History,
  Link,
  Unlink,
  Sparkles,
  Check,
  ShieldCheck,
  Clock,
  ArrowRight
} from 'lucide-react';

interface MarketDataProviderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataLoaded: (result: MarketFetchResult) => void;
  activeSymbol?: string;
  isLocalMode: boolean;
  onToggleLocalMode: (isLocal: boolean) => void;
  selectedConfig?: ProviderFetchConfig;
  onSelectProviderConfig?: (config: ProviderFetchConfig) => void;
}

const POPULAR_TICKERS = [
  { symbol: 'RELIANCE', name: 'Reliance Ind (NSE)', type: 'stock' },
  { symbol: 'TCS', name: 'TCS (NSE)', type: 'stock' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank (NSE)', type: 'stock' },
  { symbol: 'INFY', name: 'Infosys (NSE)', type: 'stock' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors (NSE)', type: 'stock' },
  { symbol: 'NIFTY 50', name: 'NSE Benchmark Index', type: 'index' },
  { symbol: 'BANKNIFTY', name: 'NSE Bank Index', type: 'index' },
  { symbol: 'GOLD', name: 'MCX Gold (₹/10g)', type: 'commodity' },
  { symbol: 'SILVER', name: 'MCX Silver (₹/kg)', type: 'commodity' },
  { symbol: 'CRUDEOIL', name: 'MCX Crude (₹/bbl)', type: 'commodity' },
  { symbol: 'BTCUSDT', name: 'Bitcoin (Binance ₹)', type: 'crypto' }
];

interface CustomApiPreset {
  id: string;
  name: string;
  providerTag: string;
  desc: string;
  badge: string;
  url: string;
  method: 'GET' | 'POST';
  path: string;
  authHeader?: string;
  authType: 'Bearer' | 'ApiKey' | 'Custom';
  keyPlaceholder: string;
  keyHelp: string;
  currency: string;
  defaultInterval: string;
  defaultRange: string;
  supportedModes: ('live' | 'historical')[];
}

const PRESET_TEMPLATES: CustomApiPreset[] = [
  {
    id: 'angel_smartapi',
    name: 'Angel One SmartAPI (Live Market & F&O)',
    providerTag: 'AngelOne SmartAPI',
    desc: 'Live option quotes, broker Greeks, OI and snapshot-based buildup',
    badge: 'Angel One Official',
    url: 'https://apiconnect.angelone.in/rest/secure/angelbroking/market/v1/quote',
    method: 'POST',
    path: 'data.fetched',
    authHeader: 'Authorization',
    authType: 'Bearer',
    keyPlaceholder: 'Paste Angel One SmartAPI JWT access token',
    keyHelp: 'Paste the JWT access token here. Add your SmartAPI key and client headers in Advanced → SmartAPI headers.',
    currency: 'INR (₹)',
    defaultInterval: '1d',
    defaultRange: '1mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'dhan_api',
    name: 'Dhan HQ API (Option Chain & Live Quotes)',
    providerTag: 'Dhan HQ',
    desc: 'Real-time NSE/BSE Equity and Option Chain quotes with instant Greeks & depth',
    badge: 'Dhan HQ Live',
    url: 'https://api.dhan.co/v2/marketfeed/ltp',
    method: 'POST',
    path: 'data',
    authHeader: 'access-token',
    authType: 'Custom',
    keyPlaceholder: 'Paste Dhan HQ Access Token',
    keyHelp: 'Get your access token from Dhan Developer portal',
    currency: 'INR (₹)',
    defaultInterval: '1d',
    defaultRange: '1mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'twelvedata',
    name: 'Twelve Data API',
    providerTag: 'TwelveData',
    desc: 'Top choice for Indian Equities (NSE/BSE), MCX, US Stocks & Crypto',
    badge: 'Recommended for India',
    url: 'https://api.twelvedata.com/time_series?symbol={symbol}&interval={interval}&outputsize=100&apikey={apiKey}',
    method: 'GET',
    path: 'values',
    authType: 'ApiKey',
    keyPlaceholder: 'Paste TwelveData API Key (e.g. 7f98a2...3b)',
    keyHelp: 'Free key available at twelvedata.com (Supports NSE, BSE & Global)',
    currency: 'INR (₹)',
    defaultInterval: '1day',
    defaultRange: '6mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'alphavantage',
    name: 'Alpha Vantage API',
    providerTag: 'AlphaVantage',
    desc: 'Daily & Intraday OHLCV time series for global stocks & Indian equities',
    badge: 'High Historical Depth',
    url: 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&apikey={apiKey}',
    method: 'GET',
    path: 'Time Series (Daily)',
    authType: 'ApiKey',
    keyPlaceholder: 'Paste Alpha Vantage API Key',
    keyHelp: 'Free API key from alphavantage.co',
    currency: 'INR (₹)',
    defaultInterval: '1d',
    defaultRange: '6mo',
    supportedModes: ['historical']
  },
  {
    id: 'finnhub',
    name: 'Finnhub Live Candles',
    providerTag: 'Finnhub',
    desc: 'Real-time quotes, live minute candles, and technical market metrics',
    badge: 'Live Low Latency',
    url: 'https://finnhub.io/api/v1/stock/candle?symbol={symbol}&resolution={interval}&count=100&token={apiKey}',
    method: 'GET',
    path: '',
    authType: 'ApiKey',
    keyPlaceholder: 'Paste Finnhub API Token',
    keyHelp: 'Free token from finnhub.io',
    currency: 'USD ($)',
    defaultInterval: 'D',
    defaultRange: '3mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'indian_broker',
    name: 'Upstox API v2 (NSE / BSE / MCX)',
    providerTag: 'Upstox',
    desc: 'Upstox v2 Historical & Intraday Candles for Indian Equities, NIFTY & MCX',
    badge: 'Upstox v2 Ready',
    url: 'https://api.upstox.com/v2/historical-candle/{instrumentKey}/day/{to_date}/{from_date}',
    method: 'GET',
    path: 'data.candles',
    authHeader: 'Authorization',
    authType: 'Bearer',
    keyPlaceholder: 'Paste Upstox Access Token (JWT Bearer Token)',
    keyHelp: 'Enter any symbol (e.g. RELIANCE, TCS, NIFTY 50); it auto-converts to valid Instrument Key',
    currency: 'INR (₹)',
    defaultInterval: 'day',
    defaultRange: '6mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'binance_public',
    name: 'Binance Spot REST',
    providerTag: 'Binance',
    desc: '24/7 Live Crypto candlestick feed (BTC, ETH, SOL) in INR (₹)',
    badge: 'Instant / No Key Needed',
    url: 'https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit=100',
    method: 'GET',
    path: '',
    authType: 'ApiKey',
    keyPlaceholder: 'Optional Binance API Key (Leave blank for public data)',
    keyHelp: 'Public endpoints work without key; key gives higher rate limits',
    currency: 'INR (₹)',
    defaultInterval: '1d',
    defaultRange: '6mo',
    supportedModes: ['live', 'historical']
  },
  {
    id: 'custom_rest',
    name: 'Custom REST URL / Webhook',
    providerTag: 'Custom URL',
    desc: 'Any custom REST endpoint returning JSON arrays or candlestick objects',
    badge: 'Universal',
    url: 'https://api.twelvedata.com/time_series?symbol={symbol}&interval={interval}&apikey={apiKey}',
    method: 'GET',
    path: 'values',
    authType: 'ApiKey',
    keyPlaceholder: 'Paste your API Key, Token, or Secret',
    keyHelp: 'Enter your custom API endpoint URL. Supports dynamic tags: {symbol}, {apiKey}, {interval}, {range}',
    currency: 'INR (₹)',
    defaultInterval: '1d',
    defaultRange: '6mo',
    supportedModes: ['live', 'historical']
  }
];

export const MarketDataProviderModal: React.FC<MarketDataProviderModalProps> = ({
  isOpen,
  onClose,
  onDataLoaded,
  activeSymbol,
  isLocalMode,
  onToggleLocalMode,
  selectedConfig,
  onSelectProviderConfig
}) => {
  // Provider tabs: custom_api, yahoo, binance
  const [activeProvider, setActiveProvider] = useState<MarketProvider>(
    selectedConfig?.provider || 'custom_api'
  );

  // Connection mode: Live vs Historical vs Both
  const [dataType, setDataType] = useState<'live' | 'historical' | 'both'>(
    selectedConfig?.dataType || 'historical'
  );

  // Selected Preset Template
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(() =>
    /angel one|angelone/i.test(selectedConfig?.customApiName || '') || /angelone\.in/i.test(selectedConfig?.customUrl || '')
      ? 'angel_smartapi'
      : 'twelvedata'
  );

  // Core Form Fields
  const [symbol, setSymbol] = useState(
    activeSymbol || selectedConfig?.symbol || 'RELIANCE'
  );
  const [apiKey, setApiKey] = useState(selectedConfig?.apiKey || '');
  const [showApiKey, setShowApiKey] = useState(false);
  const [pasteSuccess, setPasteSuccess] = useState(false);

  const [customUrl, setCustomUrl] = useState(
    selectedConfig?.customUrl || PRESET_TEMPLATES[0].url
  );
  const [customPath, setCustomPath] = useState(selectedConfig?.customPath || PRESET_TEMPLATES[0].path);
  const [customMethod, setCustomMethod] = useState<'GET' | 'POST'>(
    selectedConfig?.customMethod || 'GET'
  );
  const [customAuthHeader, setCustomAuthHeader] = useState(
    selectedConfig?.customAuthHeader || 'Authorization'
  );
  const [customAuthType, setCustomAuthType] = useState<'Bearer' | 'ApiKey' | 'Custom'>(
    selectedConfig?.customAuthType || 'ApiKey'
  );
  const [customCurrency, setCustomCurrency] = useState(
    selectedConfig?.customCurrency || 'INR (₹)'
  );

  // Resolution & Horizon
  const [interval, setInterval] = useState(selectedConfig?.interval || '1d');
  const [range, setRange] = useState(selectedConfig?.range || '6mo');

  // Advanced toggles
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [customHeadersJson, setCustomHeadersJson] = useState(
    selectedConfig?.customHeaders ? JSON.stringify(selectedConfig.customHeaders, null, 2) : ''
  );
  const [customBody, setCustomBody] = useState(selectedConfig?.customBody || '');
  const [inputMode, setInputMode] = useState<'url' | 'paste'>('url');
  const [customDataSample, setCustomDataSample] = useState(selectedConfig?.customDataSample || '');

  // Connection Status & Testing State
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<ApiTestResult | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(() => {
    return Boolean(selectedConfig?.isConnected && selectedConfig?.provider === 'custom_api');
  });

  // Action status
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Sync state if selectedConfig changes
  useEffect(() => {
    if (selectedConfig) {
      setActiveProvider(selectedConfig.provider);
      if (selectedConfig.symbol) setSymbol(selectedConfig.symbol);
      if (selectedConfig.apiKey) setApiKey(selectedConfig.apiKey);
      if (selectedConfig.customUrl) setCustomUrl(selectedConfig.customUrl);
      const matchingTemplate = PRESET_TEMPLATES.find(template =>
        template.name === selectedConfig.customApiName || template.url === selectedConfig.customUrl
      );
      if (matchingTemplate) setSelectedTemplateId(matchingTemplate.id);
      if (selectedConfig.customHeaders) setCustomHeadersJson(JSON.stringify(selectedConfig.customHeaders, null, 2));
      if (selectedConfig.dataType) setDataType(selectedConfig.dataType);
      if (selectedConfig.isConnected) setIsConnected(true);
    }
  }, [selectedConfig]);

  if (!isOpen) return null;

  // Build current ProviderFetchConfig object
  const buildCurrentConfig = (overrideProv?: MarketProvider, overrideSym?: string): ProviderFetchConfig => {
    let parsedHeaders: Record<string, string> | undefined = undefined;
    if (customHeadersJson.trim()) {
      try {
        parsedHeaders = JSON.parse(customHeadersJson.trim());
      } catch {
        // ignore JSON parse error in headers during editing
      }
    }

    const currentTemplate = PRESET_TEMPLATES.find(t => t.id === selectedTemplateId);

    return {
      provider: overrideProv || activeProvider,
      symbol: (overrideSym || symbol).trim().toUpperCase(),
      range,
      interval,
      dataType,
      apiKey: apiKey.trim(),
      customApiName: currentTemplate ? currentTemplate.name : 'Custom REST API',
      customUrl: customUrl.trim(),
      customPath: customPath.trim(),
      customMethod,
      customBody: customBody.trim(),
      customAuthHeader,
      customAuthType,
      customCurrency,
      customHeaders: parsedHeaders,
      customDataSample: inputMode === 'paste' ? customDataSample.trim() : undefined,
      isConnected,
      lastTestedAt: testResult?.success ? new Date().toISOString() : undefined
    };
  };

  // Quick Apply Template
  const handleSelectTemplate = (template: CustomApiPreset) => {
    setSelectedTemplateId(template.id);
    setCustomUrl(template.url);
    setCustomMethod(template.method);
    setCustomPath(template.path);
    setCustomAuthType(template.authType);
    if (template.authHeader) setCustomAuthHeader(template.authHeader);
    if (template.currency) setCustomCurrency(template.currency);

    // Adjust interval for live vs historical
    if (dataType === 'live') {
      setInterval('15m');
      setRange('1mo');
    } else {
      setInterval(template.defaultInterval);
      setRange(template.defaultRange);
    }

    setTestResult(null);
    setErrorMsg(null);
  };

  // Handle Clipboard Paste
  const handlePasteApiKey = async () => {
    try {
      if (navigator?.clipboard?.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          setApiKey(text.trim());
          setPasteSuccess(true);
          setTimeout(() => setPasteSuccess(false), 2000);
          setTestResult(null);
        }
      }
    } catch {
      // If permission is denied, focus input so user can Ctrl+V
      const el = document.getElementById('custom-api-key-input');
      if (el) el.focus();
    }
  };

  // Test Connection
  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    setErrorMsg(null);
    setSuccessToast(null);

    const config = buildCurrentConfig();

    try {
      if (selectedTemplateId === 'angel_smartapi') {
        if (!config.apiKey || !config.customHeaders) {
          throw new Error('Add the JWT access token and valid SmartAPI headers before testing.');
        }
        const startedAt = performance.now();
        const response = await fetch(`/api/market/options?symbol=${encodeURIComponent(config.symbol)}&expiryIndex=0`, {
          headers: { 'x-custom-api-config': encodeURIComponent(JSON.stringify(config)) }
        });
        const data = await response.json().catch(() => ({}));
        const latencyMs = Math.round(performance.now() - startedAt);
        const optionCount = Array.isArray(data.options) ? data.options.length : 0;
        const result: ApiTestResult = {
          success: response.ok && data.sourceState === 'LIVE' && optionCount > 0,
          statusCode: response.status,
          latencyMs,
          candleCount: optionCount,
          latestPrice: data.underlyingPrice,
          symbol: config.symbol,
          source: 'Angel One SmartAPI Option Feed',
          preview: [],
          message: response.ok && data.sourceState === 'LIVE'
            ? `Received ${optionCount} live strikes for ${data.selectedExpiry?.dateStr || 'nearest expiry'}.`
            : (data.error || 'Angel One did not return a verified live option chain.'),
          dataType
        };
        setTestResult(result);
        if (result.success) setSuccessToast(`✅ Angel One option feed verified · ${latencyMs}ms`);
        else setErrorMsg(result.message);
        return;
      }
      const result = await testCustomApiConnection(config);
      setTestResult(result);
      if (result.success) {
        setSuccessToast(`✅ Connection Verified! Latency: ${result.latencyMs}ms | Found ${result.candleCount} candles.`);
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        latencyMs: 0,
        candleCount: 0,
        symbol: config.symbol,
        source: config.customApiName || 'Custom API',
        preview: [],
        message: err.message || 'Connection test failed. Check API key, URL, or JSON path.',
        dataType
      });
      setErrorMsg(err.message || 'Connection failed.');
    } finally {
      setIsTesting(false);
    }
  };

  // Connect & Save API to application
  const handleConnectAndSave = async () => {
    setIsLoading(true);
    setErrorMsg(null);

    const config = buildCurrentConfig();
    config.isConnected = true;
    config.lastTestedAt = new Date().toISOString();

    try {
      // 1. Persist config in localStorage
      try {
        localStorage.setItem('timesfm_active_market_provider', JSON.stringify(config));
        localStorage.setItem('timesfm_custom_api_config', JSON.stringify(config));
      } catch (e) {
        console.warn('LocalStorage save error:', e);
      }

      if (onSelectProviderConfig) {
        onSelectProviderConfig(config);
      }

      setIsConnected(true);

      // 2. Fetch market data directly to load candles into TimesFM
      const result = await fetchMarketData(config);
      onDataLoaded(result);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to stream data from custom API.');
    } finally {
      setIsLoading(false);
    }
  };

  // Disconnect API
  const handleDisconnect = () => {
    setIsConnected(false);
    setTestResult(null);
    const fallbackConfig: ProviderFetchConfig = {
      provider: 'yahoo',
      symbol: symbol || 'RELIANCE',
      range: '6mo',
      interval: '1d',
      isConnected: false
    };
    try {
      localStorage.setItem('timesfm_active_market_provider', JSON.stringify(fallbackConfig));
    } catch (e) {
      console.warn(e);
    }
    if (onSelectProviderConfig) {
      onSelectProviderConfig(fallbackConfig);
    }
    setActiveProvider('yahoo');
    setSuccessToast('Disconnected from Custom API. Switched to Yahoo Finance.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-slate-900">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-700/50 flex items-center justify-center text-cyan-400 shadow">
              <RadioTower className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-white">
                  Connect Custom API & Market Data
                </h2>
                {isConnected && activeProvider === 'custom_api' && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    Connected 🟢
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                Paste your API key, test the connection, and load live or historical market data for analysis
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto text-xs">
          {/* Main Provider Selection Switch */}
          <div className="space-y-1.5">
            <label className="text-slate-300 font-semibold text-xs flex items-center justify-between">
              <span>Select Data Provider</span>
              <span className="text-[10px] text-slate-400 font-normal">Active provider streams directly into predictions</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Option 1: Custom API */}
              <button
                type="button"
                onClick={() => setActiveProvider('custom_api')}
                className={`p-3 rounded-xl border text-left transition-all relative cursor-pointer ${
                  activeProvider === 'custom_api'
                    ? 'bg-gradient-to-br from-cyan-950/70 to-slate-900 border-cyan-400 text-white shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-500/50'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <div className="flex items-center gap-1.5">
                    <Key className={`w-4 h-4 ${activeProvider === 'custom_api' ? 'text-cyan-400' : 'text-slate-500'}`} />
                    <span className="font-bold text-xs text-white">Custom REST API</span>
                  </div>
                  {activeProvider === 'custom_api' && (
                    <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 text-[9px] font-mono font-bold border border-cyan-500/40">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-tight">
                  Paste API Key / Token for Live & Historical Data
                </p>
              </button>

              {/* Option 2: Yahoo Finance */}
              <button
                type="button"
                onClick={() => setActiveProvider('yahoo')}
                className={`p-3 rounded-xl border text-left transition-all relative cursor-pointer ${
                  activeProvider === 'yahoo'
                    ? 'bg-gradient-to-br from-indigo-950/70 to-slate-900 border-indigo-400 text-white shadow-lg ring-1 ring-indigo-500/50'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <div className="flex items-center gap-1.5">
                    <TrendingUp className={`w-4 h-4 ${activeProvider === 'yahoo' ? 'text-indigo-400' : 'text-slate-500'}`} />
                    <span className="font-semibold text-xs text-slate-200">Yahoo Finance</span>
                  </div>
                  {activeProvider === 'yahoo' && (
                    <span className="px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 text-[9px] font-mono font-bold border border-indigo-500/40">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-tight">
                  Free Indian Equities (NSE/BSE) & MCX in ₹
                </p>
              </button>

              {/* Option 3: Binance Spot */}
              <button
                type="button"
                onClick={() => setActiveProvider('binance')}
                className={`p-3 rounded-xl border text-left transition-all relative cursor-pointer ${
                  activeProvider === 'binance'
                    ? 'bg-gradient-to-br from-amber-950/70 to-slate-900 border-amber-400 text-white shadow-lg ring-1 ring-amber-500/50'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <div className="flex items-center gap-1.5">
                    <Zap className={`w-4 h-4 ${activeProvider === 'binance' ? 'text-amber-400' : 'text-slate-500'}`} />
                    <span className="font-semibold text-xs text-slate-200">Binance Spot</span>
                  </div>
                  {activeProvider === 'binance' && (
                    <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-mono font-bold border border-amber-500/40">
                      Active
                    </span>
                  )}
                </div>
                <p className="text-[10px] text-slate-400 leading-tight">
                  Live 24/7 Crypto Spot market in ₹ INR
                </p>
              </button>
            </div>
          </div>

          {/* CUSTOM API CONFIGURATION PANEL */}
          {activeProvider === 'custom_api' ? (
            <div className="space-y-4">
              {/* STEP 1: Select Data Type (Live vs Historical) */}
              <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-200 font-bold text-xs flex items-center gap-1.5">
                    <Radio className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step 1: Choose Data Feed Mode</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Select Live or Historical data stream
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {/* Live Data */}
                  <button
                    type="button"
                    onClick={() => {
                      setDataType('live');
                      setInterval('15m');
                      setRange('1mo');
                      setTestResult(null);
                    }}
                    className={`p-2.5 rounded-lg border text-left transition flex items-start gap-2 cursor-pointer ${
                      dataType === 'live'
                        ? 'bg-rose-950/40 border-rose-500 text-white shadow-sm ring-1 ring-rose-500/40'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span className="w-2 h-2 rounded-full bg-rose-500 mt-1 shrink-0 animate-ping" />
                    <div>
                      <div className="font-bold text-xs text-rose-300 flex items-center gap-1">
                        <span>Live Real-Time Data</span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Live CMP, 5m/15m/1h intraday ticks & live price stream
                      </p>
                    </div>
                  </button>

                  {/* Historical Data */}
                  <button
                    type="button"
                    onClick={() => {
                      setDataType('historical');
                      setInterval('1d');
                      setRange('6mo');
                      setTestResult(null);
                    }}
                    className={`p-2.5 rounded-lg border text-left transition flex items-start gap-2 cursor-pointer ${
                      dataType === 'historical'
                        ? 'bg-cyan-950/40 border-cyan-500 text-white shadow-sm ring-1 ring-cyan-500/40'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <History className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-xs text-cyan-300 flex items-center gap-1">
                        <span>Historical Data</span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Daily/Weekly EOD candles (6M–2Y) for local forecasts and backtesting
                      </p>
                    </div>
                  </button>

                  {/* Combined Live + Historical */}
                  <button
                    type="button"
                    onClick={() => {
                      setDataType('both');
                      setInterval('1d');
                      setRange('6mo');
                      setTestResult(null);
                    }}
                    className={`p-2.5 rounded-lg border text-left transition flex items-start gap-2 cursor-pointer ${
                      dataType === 'both'
                        ? 'bg-purple-950/40 border-purple-500 text-white shadow-sm ring-1 ring-purple-500/40'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold text-xs text-purple-300 flex items-center gap-1">
                        <span>Combined (Both)</span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Loads deep history + binds latest live tick for real-time target calculations
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* STEP 2: Pre-Configured Templates */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-bold text-xs flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step 2: Choose API Provider / Template</span>
                  </label>
                  <span className="text-[10px] text-slate-400">Click to auto-configure URL & format</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {PRESET_TEMPLATES.map((tmpl) => {
                    const isSelected = selectedTemplateId === tmpl.id;
                    return (
                      <button
                        key={tmpl.id}
                        type="button"
                        onClick={() => handleSelectTemplate(tmpl)}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-cyan-950/50 border-cyan-400 text-white shadow-sm ring-1 ring-cyan-500/40'
                            : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="font-bold text-xs text-slate-100 truncate">
                              {tmpl.name}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">
                            {tmpl.desc}
                          </p>
                        </div>
                        <div className="mt-2 flex items-center justify-between text-[9px] font-mono text-cyan-400 font-semibold">
                          <span>{tmpl.badge}</span>
                          <span className="text-slate-500 uppercase">{tmpl.method}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* STEP 3: Prominent Paste API Key Card */}
              <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/40 p-4 rounded-xl border border-cyan-500/40 shadow-lg space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-white font-bold text-xs flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-cyan-400" />
                    <span>Step 3: Paste Your API Key / Token</span>
                    <span className="text-cyan-400 text-[10px] font-mono font-normal">
                      (Stored in this browser)
                    </span>
                  </label>
                  <span className="text-[10px] text-slate-400">
                    Sent to the selected provider when making API requests
                  </span>
                </div>

                <div className="relative flex items-center">
                  <input
                    id="custom-api-key-input"
                    type={showApiKey ? 'text' : 'password'}
                    value={apiKey}
                    onChange={(e) => {
                      setApiKey(e.target.value);
                      setTestResult(null);
                    }}
                    placeholder={
                      PRESET_TEMPLATES.find(t => t.id === selectedTemplateId)?.keyPlaceholder ||
                      'Paste your API Key or Token here...'
                    }
                    className="w-full pl-3.5 pr-28 py-2.5 bg-slate-950 border border-cyan-500/50 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 shadow-inner"
                  />

                  {/* Quick Action Buttons inside input */}
                  <div className="absolute right-2 flex items-center gap-1">
                    {/* Paste Button */}
                    <button
                      type="button"
                      onClick={handlePasteApiKey}
                      className="px-2 py-1 rounded-lg bg-cyan-900/60 hover:bg-cyan-800 text-cyan-300 text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer border border-cyan-700/60"
                      title="Paste from clipboard"
                    >
                      {pasteSuccess ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-300">Pasted!</span>
                        </>
                      ) : (
                        <>
                          <Clipboard className="w-3 h-3 text-cyan-300" />
                          <span>Paste</span>
                        </>
                      )}
                    </button>

                    {/* Show/Hide Button */}
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
                      title={showApiKey ? 'Hide API Key' : 'Show API Key'}
                    >
                      {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>

                    {/* Clear Button */}
                    {apiKey && (
                      <button
                        type="button"
                        onClick={() => {
                          setApiKey('');
                          setTestResult(null);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 transition cursor-pointer"
                        title="Clear Key"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <p className="text-slate-400">
                    {PRESET_TEMPLATES.find(t => t.id === selectedTemplateId)?.keyHelp || 
                      'Key is passed via Authorization Bearer header or {apiKey} query tag.'}
                  </p>
                  {apiKey && (
                    <span className="font-mono text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3 h-3" /> Key Detected ({apiKey.length} chars)
                    </span>
                  )}
                </div>
              </div>

              {/* STEP 4: Instrument Symbol & Parameters */}
              <div className="bg-slate-950/70 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-slate-200 font-bold text-xs flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Step 4: Target Instrument & Horizon</span>
                  </label>
                  <span className="text-[10px] text-slate-400">Specify symbol and time frame</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Symbol input */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <label className="text-slate-300 text-[11px] font-medium">
                        Ticker Symbol <span className="text-cyan-400">*</span>
                      </label>
                      {customUrl.includes('api.upstox.com') && (
                        <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                          Upstox Auto-Format
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={symbol}
                      onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                      placeholder={customUrl.includes('api.upstox.com') ? 'RELIANCE or NSE_EQ|INE002A01018' : 'e.g. RELIANCE, TCS, BTCUSDT'}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
                    />
                    {customUrl.includes('api.upstox.com') && symbol && (
                      <div className="mt-1 flex items-center gap-1.5 text-[10px] font-mono text-cyan-300 bg-cyan-950/70 border border-cyan-800/60 rounded px-2 py-0.5">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span className="truncate">Upstox Key: <strong>{resolveUpstoxInstrumentKey(symbol)}</strong></span>
                      </div>
                    )}
                  </div>

                  {/* Resolution / Interval */}
                  <div className="space-y-1">
                    <label className="text-slate-300 text-[11px] font-medium">Candle Resolution</label>
                    <select
                      value={interval}
                      onChange={(e) => {
                        setInterval(e.target.value);
                        setTestResult(null);
                      }}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-cyan-500"
                    >
                      {dataType === 'live' ? (
                        <>
                          <option value="1m">1 Minute (Live Tick)</option>
                          <option value="5m">5 Minutes (Intraday)</option>
                          <option value="15m">15 Minutes (Active Scalp)</option>
                          <option value="1h">1 Hour (Intraday Trend)</option>
                        </>
                      ) : (
                        <>
                          <option value="1d">1 Day (EOD Standard)</option>
                          <option value="1day">1 Day (TwelveData Format)</option>
                          <option value="1h">1 Hour (Swing Horizon)</option>
                          <option value="1wk">1 Week (Macro Cycles)</option>
                        </>
                      )}
                    </select>
                  </div>

                  {/* Currency */}
                  <div className="space-y-1">
                    <label className="text-slate-300 text-[11px] font-medium">Display Currency</label>
                    <select
                      value={customCurrency}
                      onChange={(e) => setCustomCurrency(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-cyan-500"
                    >
                      <option value="INR (₹)">Indian Rupees (INR ₹)</option>
                      <option value="USD ($)">US Dollars (USD $)</option>
                      <option value="EUR (€)">Euros (EUR €)</option>
                      <option value="USDT">Tether (USDT)</option>
                    </select>
                  </div>
                </div>

                {/* Advanced Endpoint & Header Accordion */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => setShowAdvanced(!showAdvanced)}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 transition cursor-pointer"
                  >
                    <Sliders className="w-3 h-3" />
                    <span>{showAdvanced ? 'Hide Advanced URL & Headers' : 'Show Advanced URL Endpoint & Header Config'}</span>
                    {showAdvanced ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>

                  {showAdvanced && (
                    <div className="mt-2.5 p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                      <div className="space-y-1">
                        <label className="text-slate-300 text-[10px] font-medium">API Endpoint URL</label>
                        <div className="flex items-center gap-2">
                          <select
                            value={customMethod}
                            onChange={(e) => setCustomMethod(e.target.value as 'GET' | 'POST')}
                            className="px-2 py-1.5 bg-slate-950 border border-slate-700 rounded text-white font-mono text-xs"
                          >
                            <option value="GET">GET</option>
                            <option value="POST">POST</option>
                          </select>
                          <input
                            type="url"
                            value={customUrl}
                            onChange={(e) => setCustomUrl(e.target.value)}
                            placeholder="https://api.mybroker.com/v2/historical/{symbol}"
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded text-white font-mono text-xs"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-slate-300 text-[10px] font-medium">Auth Type</label>
                          <select
                            value={customAuthType}
                            onChange={(e) => setCustomAuthType(e.target.value as any)}
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded text-slate-200 text-xs"
                          >
                            <option value="ApiKey">X-API-KEY: &lt;key&gt; or URL Tag</option>
                            <option value="Bearer">Authorization: Bearer &lt;token&gt;</option>
                            <option value="Custom">Custom Header Name</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-slate-300 text-[10px] font-medium">JSON Array Path (Optional)</label>
                          <input
                            type="text"
                            value={customPath}
                            onChange={(e) => setCustomPath(e.target.value)}
                            placeholder="e.g. data.candles or values"
                            className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded text-white font-mono text-xs"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-300 text-[10px] font-medium">
                          {selectedTemplateId === 'angel_smartapi' ? 'SmartAPI Headers (JSON)' : 'Custom Headers (JSON)'}
                        </label>
                        <textarea
                          value={customHeadersJson}
                          onChange={(e) => setCustomHeadersJson(e.target.value)}
                          rows={selectedTemplateId === 'angel_smartapi' ? 5 : 3}
                          spellCheck={false}
                          placeholder={selectedTemplateId === 'angel_smartapi'
                            ? '{\n  "X-PrivateKey": "YOUR_SMARTAPI_KEY",\n  "X-UserType": "USER",\n  "X-SourceID": "WEB",\n  "X-ClientLocalIP": "YOUR_LOCAL_IP",\n  "X-ClientPublicIP": "YOUR_PUBLIC_IP",\n  "X-MACAddress": "YOUR_MAC_ADDRESS"\n}'
                            : '{\n  "X-API-KEY": "your-key"\n}'}
                          className="w-full px-2.5 py-2 bg-slate-950 border border-slate-700 rounded text-white font-mono text-[10px] focus:outline-none focus:border-cyan-500"
                        />
                        {selectedTemplateId === 'angel_smartapi' && (
                          <p className="text-[10px] leading-relaxed text-amber-300/90">
                            SmartAPI key and client IP/device headers are required. Replace every placeholder with values from your Angel One SmartAPI setup; the JWT token goes in Step 3.
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* STEP 5: TEST CONNECTION SECTION */}
              <div className="bg-slate-950/90 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Play className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Step 5: Test API Key & Verify Response</span>
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      {selectedTemplateId === 'angel_smartapi'
                        ? 'Checks Angel One option quotes and Greeks using the selected symbol and nearest expiry.'
                        : 'Pings the endpoint to confirm API key authentication and candle structure'}
                    </p>
                  </div>

                  <button
                    id="btn-test-custom-api"
                    type="button"
                    onClick={handleTestConnection}
                    disabled={isTesting}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-700 to-blue-700 hover:from-cyan-600 hover:to-blue-600 text-white font-bold text-xs shadow-md shadow-cyan-950/50 flex items-center gap-2 transition active:scale-95 cursor-pointer disabled:opacity-50 shrink-0"
                  >
                    {isTesting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-white" />
                        <span>Testing Connection & Latency...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 fill-white" />
                        <span>{selectedTemplateId === 'angel_smartapi' ? '⚡ Test Option Feed' : '⚡ Test Connection Now'}</span>
                      </>
                    )}
                  </button>
                </div>

                {/* TEST RESULT LIVE FEEDBACK */}
                {testResult && (
                  <div className={`p-3.5 rounded-xl border transition-all animate-fade-in ${
                    testResult.success
                      ? 'bg-emerald-950/50 border-emerald-600/60 text-emerald-200'
                      : 'bg-rose-950/50 border-rose-600/60 text-rose-200'
                  }`}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {testResult.success ? (
                          <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500 flex items-center justify-center shrink-0">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          </div>
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-rose-500/20 border border-rose-500 flex items-center justify-center shrink-0">
                            <AlertCircle className="w-4 h-4 text-rose-400" />
                          </div>
                        )}
                        <div>
                          <div className="font-bold text-xs">
                            {testResult.success 
                              ? `✅ Connection Verified! (HTTP 200 OK • ${testResult.latencyMs} ms)` 
                              : '❌ Connection Failed'}
                          </div>
                          <p className="text-[11px] opacity-90 mt-0.5">{testResult.message}</p>
                        </div>
                      </div>

                      {testResult.success && (
                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-emerald-400 font-mono block">LTP / Last Close</span>
                          <span className="text-sm font-black text-white font-mono">
                            {customCurrency.includes('INR') || customCurrency.includes('₹') ? '₹' : '$'}
                            {testResult.latestPrice?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) ?? '-'}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Preview Table of Recent Candles */}
                    {testResult.success && testResult.preview && testResult.preview.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-emerald-800/40">
                        <div className="flex items-center justify-between text-[10px] font-mono uppercase text-emerald-400/90 mb-1.5">
                          <span>Recent Candles Parsed ({testResult.candleCount} Total):</span>
                          <span>Ready to load market data</span>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-left font-mono text-[10px] border-collapse bg-slate-950/80 rounded border border-emerald-800/30">
                            <thead>
                              <tr className="border-b border-emerald-800/40 text-emerald-400">
                                <th className="p-1.5">Timestamp</th>
                                <th className="p-1.5">Close</th>
                                <th className="p-1.5">High</th>
                                <th className="p-1.5">Low</th>
                                <th className="p-1.5">Volume</th>
                              </tr>
                            </thead>
                            <tbody>
                              {testResult.preview.map((pt, i) => (
                                <tr key={i} className="border-b border-slate-900 hover:bg-slate-800/40">
                                  <td className="p-1.5 text-cyan-300">{pt.timestamp}</td>
                                  <td className="p-1.5 text-white font-bold">{pt.value}</td>
                                  <td className="p-1.5 text-slate-300">{pt.high ?? '-'}</td>
                                  <td className="p-1.5 text-slate-300">{pt.low ?? '-'}</td>
                                  <td className="p-1.5 text-slate-400">{pt.volume?.toLocaleString() ?? 0}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* YAHOO FINANCE & BINANCE PANELS */
            <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-4">
              <div className="space-y-1">
                <span className="text-slate-400 font-medium text-[11px] uppercase tracking-wider">
                  Quick Popular Instruments
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR_TICKERS.map(t => (
                    <button
                      key={t.symbol}
                      type="button"
                      onClick={() => setSymbol(t.symbol)}
                      className={`px-2.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition cursor-pointer flex items-center gap-1 ${
                        symbol === t.symbol
                          ? 'bg-cyan-600 text-white border-cyan-400 shadow-md shadow-cyan-950/50'
                          : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-cyan-500/60 hover:text-white'
                      }`}
                    >
                      <span>{t.symbol}</span>
                      <span className="text-[10px] opacity-60 font-sans">{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">
                    {activeProvider === 'binance' ? 'Crypto Pair' : 'Stock / Index Symbol'}
                  </label>
                  <input
                    type="text"
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                    placeholder={activeProvider === 'binance' ? 'BTCUSDT' : 'RELIANCE, TCS'}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Candle Resolution</label>
                  <select
                    value={interval}
                    onChange={(e) => setInterval(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="15m">15 Minutes (Intraday)</option>
                    <option value="1h">1 Hour (Swing)</option>
                    <option value="1d">1 Day (EOD)</option>
                    <option value="1wk">1 Week (Macro)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Historical Horizon</label>
                  <select
                    value={range}
                    onChange={(e) => setRange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-200 text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="1mo">1 Month</option>
                    <option value="3mo">3 Months</option>
                    <option value="6mo">6 Months (Recommended)</option>
                    <option value="1y">1 Year</option>
                    <option value="2y">2 Years</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Local vs Cloud Engine Switch */}
          <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-white">Engine Execution</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                  isLocalMode ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-600/40' : 'bg-slate-800 text-slate-300'
                }`}>
                  {isLocalMode ? 'On-Device Local Engine' : 'Hybrid Cloud Proxy (Zero CORS)'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {isLocalMode 
                  ? 'Runs inference locally in your browser.' 
                  : 'Queries backend proxy to eliminate browser CORS blocks and authenticate secure REST feeds.'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => onToggleLocalMode(!isLocalMode)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition self-end sm:self-auto cursor-pointer"
            >
              Switch to {isLocalMode ? 'Cloud Proxy' : 'On-Device Local'}
            </button>
          </div>

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-950/50 border border-red-800/60 text-red-200 flex items-start gap-2 text-xs">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Success Toast */}
          {successToast && (
            <div className="p-3 rounded-lg bg-emerald-950/50 border border-emerald-800/60 text-emerald-200 flex items-start gap-2 text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>{successToast}</span>
            </div>
          )}
        </div>

        {/* Footer with CONNECT ACTION */}
        <div className="px-5 py-3.5 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950/80">
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            {activeProvider === 'custom_api' && isConnected && (
              <button
                type="button"
                onClick={handleDisconnect}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-400 border border-slate-700 transition flex items-center gap-1 text-[11px] cursor-pointer"
              >
                <Unlink className="w-3 h-3" />
                <span>Disconnect API</span>
              </button>
            )}
            <span className="font-mono">
              Provider: <strong className="text-cyan-400">{activeProvider.toUpperCase()}</strong>
              {activeProvider === 'custom_api' && (
                <span className="ml-1 text-slate-300">
                  ({dataType === 'live' ? '🔴 Live Data' : '📅 Historical Data'})
                </span>
              )}
            </span>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              Cancel
            </button>

            {/* CONNECT BUTTON (Connect ho jaye) */}
            <button
              id="btn-connect-stream-api"
              type="button"
              disabled={isLoading}
              onClick={handleConnectAndSave}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg flex items-center gap-2 transition active:scale-95 cursor-pointer disabled:opacity-50 ${
                testResult?.success
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-slate-950 font-black shadow-emerald-950/60 ring-2 ring-emerald-400/50 animate-pulse'
                  : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-cyan-950/50'
              }`}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Connecting & Loading Data...</span>
                </>
              ) : (
                <>
                  <Link className="w-4 h-4" />
                  <span>
                    {activeProvider === 'custom_api' 
                      ? (testResult?.success ? '🔗 Connect API & Stream Data' : '🔗 Connect API & Fetch Data')
                      : 'Load Market Data for Analysis'}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
