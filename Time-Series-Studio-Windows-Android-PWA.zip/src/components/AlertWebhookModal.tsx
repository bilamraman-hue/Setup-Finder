import React, { useState } from 'react';
import { 
  X, 
  Bell, 
  Send, 
  AlertCircle, 
  Copy
} from 'lucide-react';
import { QuantSetupReport } from '../lib/quantSetupEngine';

interface AlertWebhookModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSetup?: QuantSetupReport | null;
  currencySymbol?: string;
}

export const AlertWebhookModal: React.FC<AlertWebhookModalProps> = ({
  isOpen,
  onClose,
  activeSetup,
  currencySymbol = '₹'
}) => {
  const [webhookUrl, setWebhookUrl] = useState(() => localStorage.getItem('timesfm_alert_webhook_url') || '');
  const [isSending, setIsSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'notice' | 'error'; text: string } | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Formatted alert payload
  const alertText = activeSetup ? `🚨 *INSTITUTIONAL QUANT ALERT: ${activeSetup.symbol}*
━━━━━━━━━━━━━━━━━━
• *Decision:* [${activeSetup.status}]
• *Direction:* ${activeSetup.direction}
• *Current Price:* ${currencySymbol}${activeSetup.cmp}
• *Score:* ${activeSetup.scorePct}% (High Confluence)
• *Entry Range:* ${activeSetup.entryRange.text}
• *Stop Loss:* ${currencySymbol}${activeSetup.stopLoss.price} (${activeSetup.stopLoss.pct}%)
• *Target 1:* ${currencySymbol}${activeSetup.target1.price} (+${activeSetup.target1.pct}%)
• *Target 2:* ${currencySymbol}${activeSetup.target2.price} (+${activeSetup.target2.pct}%)
• *Risk:Reward:* ${activeSetup.riskRewardText}
━━━━━━━━━━━━━━━━━━
*Key Driver:* ${activeSetup.directNichod.coreDriver}
*Trigger:* ${activeSetup.directNichod.actionTrigger}` : 'No active setup loaded.';

  const handleCopyAlert = () => {
    navigator.clipboard.writeText(alertText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSaveAndTest = async () => {
    localStorage.setItem('timesfm_alert_webhook_url', webhookUrl);

    if (!webhookUrl.trim()) {
      setStatusMessage({ type: 'error', text: 'Enter a webhook URL. Direct Telegram delivery is not implemented.' });
      return;
    }

    setIsSending(true);
    setStatusMessage(null);

    try {
      if (webhookUrl) {
        const response = await fetch(webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'QUANT_TRADE_ALERT',
            text: alertText,
            timestamp: new Date().toISOString(),
            setup: activeSetup
          }),
          mode: 'cors'
        });
        if (!response.ok) throw new Error(`Webhook returned HTTP ${response.status}`);
        setStatusMessage({ type: 'notice', text: `Webhook endpoint returned HTTP ${response.status}. This confirms an HTTP response only; downstream notification delivery is not verified.` });
      }
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: `Webhook request failed or was blocked by endpoint CORS. Delivery cannot be confirmed: ${err.message}` });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-t-2xl sm:rounded-2xl shadow-2xl flex flex-col max-h-[92dvh] sm:max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-b border-slate-700/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                Webhook Alert Test
              </h3>
              <p className="text-[11px] text-slate-400">
                Send the current setup as a webhook payload
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
          <div className="p-4 sm:p-5 overflow-y-auto space-y-4 pb-[calc(1rem+env(safe-area-inset-bottom))] text-xs sm:text-sm">
          
          {/* Status Message */}
          {statusMessage && (
            <div className={`p-3 rounded-xl flex items-center gap-2 ${
              statusMessage.type === 'notice'
                ? 'bg-amber-950/80 border border-amber-700 text-amber-200'
                : 'bg-rose-950/80 border border-rose-800 text-rose-200'
            }`}>
              {statusMessage.type === 'notice' ? (
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span className="text-xs">{statusMessage.text}</span>
            </div>
          )}

          {/* Webhook Configuration Inputs */}
          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-300">
                Webhook URL (Discord / Slack / Zapier / Make / Custom Server)
              </label>
              <input
                type="url"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="https://discord.com/api/webhooks/... or https://hooks.zapier.com/..."
                className="w-full mt-1 px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs font-mono text-white placeholder:text-slate-600 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <p className="text-[11px] leading-relaxed text-amber-300">Telegram bot delivery is not connected in this build. Webhook endpoints using browser CORS restrictions may accept a request without exposing a delivery receipt.</p>
          </div>

          {/* Live Alert Preview Box */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Formatted Alert Message
              </label>
              <button
                onClick={handleCopyAlert}
                className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer font-semibold"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copied ? 'Copied!' : 'Copy Text'}</span>
              </button>
            </div>
            <pre className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-200 whitespace-pre-wrap max-h-44 overflow-y-auto leading-relaxed">
              {alertText}
            </pre>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            <button
              onClick={handleSaveAndTest}
              disabled={isSending}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs sm:text-sm transition-all shadow-lg shadow-amber-950/60 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              <span>{isSending ? 'Sending test request…' : 'Save & Send Test Webhook'}</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
