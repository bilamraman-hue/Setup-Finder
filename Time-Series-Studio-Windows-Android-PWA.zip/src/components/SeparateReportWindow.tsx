import React, { useState } from 'react';
import { StockSummaryReportData, TimeSeriesPoint } from '../types';
import { BacktestAccuracyOverlay } from './BacktestAccuracyOverlay';
import { 
  Target, 
  ShieldAlert, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Check, 
  Copy, 
  X, 
  Maximize2, 
  Minimize2, 
  Layers, 
  BarChart2, 
  Zap, 
  Crosshair,
  Flame,
  Download,
  Calendar,
  Compass,
  AlertTriangle
} from 'lucide-react';
import { downloadStockSummaryHtmlReport } from '../lib/htmlReportGenerator';

interface SeparateReportWindowProps {
  report: StockSummaryReportData;
  history?: TimeSeriesPoint[];
  confidenceLevel?: number;
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'targets' | 'backtest' | 'split';
}

export const SeparateReportWindow: React.FC<SeparateReportWindowProps> = ({
  report,
  history = [],
  confidenceLevel = 90,
  isOpen,
  onClose,
  initialTab = 'split'
}) => {
  const [activeWindowTab, setActiveWindowTab] = useState<'targets' | 'backtest' | 'split'>(initialTab);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [activePlan, setActivePlan] = useState<'BULLISH' | 'BEARISH'>(report.direction === 'BEARISH' ? 'BEARISH' : 'BULLISH');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const {
    symbol,
    name,
    currentMarketPrice,
    currencySymbol,
    actionRecommendation,
    actionBadgeText,
    actionReason,
    historicalSpan,
    entryGuide,
    targetOne,
    targetTwo,
    targetThree,
    strictStoploss
  } = report;

  const fmtCurr = (val?: number) => {
    if (val === undefined || val === null || isNaN(val)) return '—';
    return `${currencySymbol}${val.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
  };

  const handleCopyPlan = () => {
    const text = `📊 TIMESFM 3.0 INSTITUTIONAL REPORT: ${name} (${symbol})
📅 Historical Scope: ${historicalSpan.durationText} (${historicalSpan.startDate} → ${historicalSpan.endDate}) | ${historicalSpan.frequency}
CMP: ${currencySymbol}${currentMarketPrice.toLocaleString()} | Direction: ${activePlan}

🎯 Action Verdict: ${actionBadgeText}
💡 ${actionReason}

• Ideal Entry Range: ${entryGuide.idealEntryRange} (Dip Buy: ${fmtCurr(entryGuide.conservativePullbackEntry)})
• Target 1: ${currencySymbol}${targetOne.targetPrice.toLocaleString()} (${targetOne.returnPct >= 0 ? '+' : ''}${targetOne.returnPct}%) | ${targetOne.timeframeText} | Exit: ${targetOne.exitStrategy || 'Book 50% & SL to Cost'}
• Target 2: ${currencySymbol}${targetTwo.targetPrice.toLocaleString()} (${targetTwo.returnPct >= 0 ? '+' : ''}${targetTwo.returnPct}%) | ${targetTwo.timeframeText} | Exit: ${targetTwo.exitStrategy || 'Book 30% & Trail 20 EMA'}
• Target 3: ${currencySymbol}${targetThree.targetPrice.toLocaleString()} (${targetThree.returnPct >= 0 ? '+' : ''}${targetThree.returnPct}%) | ${targetThree.timeframeText} | Exit: ${targetThree.exitStrategy || 'Final exit or 1.5 ATR trail'}
• Strict Stoploss: ${currencySymbol}${strictStoploss.stoplossPrice.toLocaleString()} (${strictStoploss.riskPct}%) | Risk:Reward = 1:${strictStoploss.riskRewardRatio}

Trailing Rule: ${strictStoploss.trailingRule}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // If Minimized: Show sleek floating Picture-in-Picture bar in bottom-right corner
  if (isMinimized) {
    return (
      <div className="fixed bottom-20 sm:bottom-6 right-4 z-50 animate-bounce-subtle select-none">
        <div className="bg-slate-950/95 border-2 border-emerald-500/80 rounded-2xl p-3 shadow-2xl shadow-emerald-950/80 backdrop-blur-xl flex items-center gap-3 text-xs text-white ring-4 ring-emerald-500/20">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400" />
            </span>
            <strong className="text-white font-mono tracking-wider">{symbol}</strong>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              {actionRecommendation === 'TRADE_NOW' ? 'TRADE NOW' : actionBadgeText.split('—')[0]}
            </span>
          </div>

          <div className="h-4 w-px bg-slate-800" />

          <div className="font-mono text-slate-300 hidden sm:block">
            CMP: <strong className="text-white">{fmtCurr(currentMarketPrice)}</strong>
          </div>

          <div className="font-mono text-emerald-400 hidden md:block">
            T1: <strong>{fmtCurr(targetOne.targetPrice)}</strong> ({targetOne.returnPct >= 0 ? '+' : ''}{targetOne.returnPct}%)
          </div>

          <div className="flex items-center gap-1.5 ml-1">
            <button
              onClick={() => setIsMinimized(false)}
              className="p-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 transition cursor-pointer"
              title="Restore Separate Window"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Full / Normal Window Mode
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-2 sm:p-4 md:p-6 overflow-y-auto animate-fade-in">
      <div 
        className={`bg-slate-900 border border-cyan-500/60 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100 transition-all duration-300 ${
          isMaximized 
            ? 'w-full h-full max-w-none rounded-none' 
            : 'w-full max-w-6xl max-h-[92vh] ring-1 ring-cyan-500/30'
        }`}
      >
        {/* Window Title Bar */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-3 select-none shrink-0 flex-wrap">
          {/* Left Title */}
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>{name}</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  {symbol}
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                  {actionBadgeText}
                </span>
              </h3>
            </div>
          </div>

          {/* Center: Tabs Switcher */}
          <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              onClick={() => setActiveWindowTab('split')}
              className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeWindowTab === 'split'
                  ? 'bg-cyan-600 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Full View</span>
            </button>
            <button
              onClick={() => setActiveWindowTab('targets')}
              className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeWindowTab === 'targets'
                  ? 'bg-cyan-600 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>Targets Only</span>
            </button>
            <button
              onClick={() => setActiveWindowTab('backtest')}
              className={`px-3 py-1 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                activeWindowTab === 'backtest'
                  ? 'bg-cyan-600 text-slate-950 font-bold shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <BarChart2 className="w-3.5 h-3.5" />
              <span>Backtest Only</span>
            </button>
          </div>

          {/* Right: Window Controls */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyPlan}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              title="Copy trade plan"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => setIsMinimized(true)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              title="Minimize to floating corner widget"
            >
              <Minimize2 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setIsMaximized(!isMaximized)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              title={isMaximized ? 'Restore window size' : 'Maximize window'}
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 transition cursor-pointer"
              title="Close window"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Window Content Body (Scrollable) */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Subheader bar with live CMP & Historical Calculation Span */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-3 bg-slate-950/90 rounded-xl border border-slate-800 text-xs">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-slate-400">Current Market Price:</span>
              <span className="text-xl font-black font-mono text-white">
                {fmtCurr(currentMarketPrice)}
              </span>
              <span className="px-2 py-0.5 rounded font-mono font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                Data Scope: {historicalSpan.durationText}
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center p-0.5 bg-slate-900 rounded-lg border border-slate-800 text-xs">
                <button
                  onClick={() => setActivePlan('BULLISH')}
                  className={`px-2.5 py-1 rounded font-semibold transition cursor-pointer flex items-center gap-1 ${
                    activePlan === 'BULLISH'
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <TrendingUp className="w-3 h-3 text-emerald-300" />
                  Bullish
                </button>
                <button
                  onClick={() => setActivePlan('BEARISH')}
                  className={`px-2.5 py-1 rounded font-semibold transition cursor-pointer flex items-center gap-1 ${
                    activePlan === 'BEARISH'
                      ? 'bg-rose-600 text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <TrendingDown className="w-3 h-3 text-rose-300" />
                  Bearish
                </button>
              </div>

              <button
                onClick={() => downloadStockSummaryHtmlReport(report)}
                className="px-2.5 py-1 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1 shadow transition cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>Download Report</span>
              </button>
            </div>
          </div>

          {/* Action Verdict & Entry Guide Bar */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Verdict */}
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                Timing Verdict
              </div>
              <div className="text-sm font-black font-mono text-cyan-400">
                {actionBadgeText}
              </div>
              <p className="text-[11px] text-slate-300">
                {actionReason}
              </p>
            </div>

            {/* Entry Guide */}
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                Entry Recommendation
              </div>
              <div className="text-sm font-black font-mono text-emerald-400">
                Ideal Buy: {entryGuide.idealEntryRange}
              </div>
              <p className="text-[11px] text-slate-300">
                Aggressive CMP: {fmtCurr(entryGuide.aggressiveEntry)} • Dip Support: {fmtCurr(entryGuide.conservativePullbackEntry)}
              </p>
            </div>
          </div>

          {/* VIEW: Targets Only or Split View */}
          {(activeWindowTab === 'targets' || activeWindowTab === 'split') && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5 text-cyan-400" />
                  <span>local statistical baseline Price Targets & Exit Discipline</span>
                </h4>
                <span className="text-[11px] font-mono text-emerald-400 font-bold">
                  Risk-Reward: 1:{strictStoploss.riskRewardRatio}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                {/* TARGET 1 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/40 relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider block">
                      Target 1 ({targetOne.timeframeText})
                    </span>
                    <div className="text-xl font-black font-mono text-white mt-1">
                      {fmtCurr(targetOne.targetPrice)}
                    </div>
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      +{targetOne.returnPct}% Gain
                    </span>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                    🚪 <strong>Exit:</strong> {targetOne.exitStrategy || 'Book 50% & SL to Cost.'}
                  </div>
                </div>

                {/* TARGET 2 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/40 relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block">
                      Target 2 ({targetTwo.timeframeText})
                    </span>
                    <div className="text-xl font-black font-mono text-white mt-1">
                      {fmtCurr(targetTwo.targetPrice)}
                    </div>
                    <span className="text-xs font-bold text-emerald-400 font-mono">
                      +{targetTwo.returnPct}% Gain
                    </span>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                    🚪 <strong>Exit:</strong> {targetTwo.exitStrategy || 'Book 30% & Trail 20 EMA.'}
                  </div>
                </div>

                {/* TARGET 3 */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-purple-500/40 relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-wider block">
                      Target 3 ({targetThree.timeframeText})
                    </span>
                    <div className="text-xl font-black font-mono text-white mt-1">
                      {fmtCurr(targetThree.targetPrice)}
                    </div>
                    <span className="text-xs font-bold text-purple-400 font-mono">
                      +{targetThree.returnPct}% Gain
                    </span>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                    🚪 <strong>Exit:</strong> {targetThree.exitStrategy || 'Final exit or 1.5 ATR trail.'}
                  </div>
                </div>

                {/* STOP LOSS */}
                <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/40 relative overflow-hidden flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider block">
                      Strict Stoploss (SL)
                    </span>
                    <div className="text-xl font-black font-mono text-rose-400 mt-1">
                      {fmtCurr(strictStoploss.stoplossPrice)}
                    </div>
                    <span className="text-xs font-bold text-rose-400 font-mono">
                      {strictStoploss.riskPct}% Risk ({fmtCurr(strictStoploss.riskAmount)})
                    </span>
                  </div>
                  <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-rose-300/80">
                    🛡 Hard daily closing invalidation.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* VIEW: Backtest Only or Split View */}
          {(activeWindowTab === 'backtest' || activeWindowTab === 'split') && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Historical Accuracy & Previous Signals</span>
                </h4>
              </div>

              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <BacktestAccuracyOverlay
                  symbol={symbol}
                  name={name}
                  currencySymbol={currencySymbol}
                  history={history}
                  onClose={() => {}}
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
