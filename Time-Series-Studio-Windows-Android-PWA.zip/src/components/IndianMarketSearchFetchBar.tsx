import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  RefreshCw, 
  TrendingUp, 
  Flame, 
  Layers, 
  Check, 
  Sparkles,
  Globe,
  Coins,
  ChevronDown,
  AlertTriangle,
  AlertCircle,
  X,
  ArrowRight
} from 'lucide-react';
import { INDIAN_MARKET_TICKERS, IndianMarketTicker } from '../data/presets';
import { MarketFetchResult, searchMarketSymbols, SearchResultItem } from '../lib/marketProvider';
import { ProviderFetchConfig } from '../types';
import { normalizeSymbol } from '../lib/upstoxInstruments';

export interface FetchWarningInfo {
  message: string;
  type: 'error' | 'warning' | 'info';
  suggestion?: string;
}

interface IndianMarketSearchFetchBarProps {
  onFetch: (symbol: string, range?: string, interval?: string) => Promise<void>;
  isLoading: boolean;
  activeSymbol?: string;
  activeName?: string;
  currency?: string;
  lastClosePrice?: number;
  recentFetches: MarketFetchResult[];
  onSelectRecent: (result: MarketFetchResult) => void;
  selectedApiConfig?: ProviderFetchConfig;
  fetchWarning?: FetchWarningInfo | null;
  onDismissWarning?: () => void;
  onApplySuggestion?: (suggestion: string) => void;
}

export const IndianMarketSearchFetchBar: React.FC<IndianMarketSearchFetchBarProps> = ({
  onFetch,
  isLoading,
  activeSymbol,
  activeName,
  currency = 'INR',
  lastClosePrice,
  recentFetches,
  onSelectRecent,
  selectedApiConfig,
  fetchWarning,
  onDismissWarning,
  onApplySuggestion
}) => {
  const [inputSymbol, setInputSymbol] = useState('');
  const [selectedRange, setSelectedRange] = useState(selectedApiConfig?.range || '1y');
  const [selectedInterval, setSelectedInterval] = useState(selectedApiConfig?.interval || '1h');
  const [activeTab, setActiveTab] = useState<'all' | 'stocks' | 'commodities' | 'indices'>('all');
  const [localInputWarning, setLocalInputWarning] = useState<string | null>(null);
  
  // Sync with selectedApiConfig updates
  useEffect(() => {
    if (selectedApiConfig?.interval) {
      setSelectedInterval(selectedApiConfig.interval);
    }
    if (selectedApiConfig?.range) {
      setSelectedRange(selectedApiConfig.range);
    }
  }, [selectedApiConfig?.interval, selectedApiConfig?.range]);
  
  // Live autocomplete search state
  const [suggestions, setSuggestions] = useState<SearchResultItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Debounce search query to /api/market/search & live character checks
  useEffect(() => {
    const trimmed = inputSymbol.trim();
    if (!trimmed) {
      setLocalInputWarning(null);
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    // Immediate character check for 400 error prevention
    if (/[^a-zA-Z0-9\s.\-&^=|]/.test(trimmed)) {
      setLocalInputWarning('Special characters detected — only alphanumeric characters (e.g. RELIANCE, TATAMOTORS) are supported.');
    } else {
      setLocalInputWarning(null);
    }

    if (trimmed.length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      const results = await searchMarketSymbols(trimmed);
      setSuggestions(results);
      setShowSuggestions(results.length > 0);
      setIsSearching(false);
    }, 280);

    return () => clearTimeout(timer);
  }, [inputSymbol]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuggestions(false);
    const sym = inputSymbol.trim();
    if (sym) {
      onFetch(sym, selectedRange, selectedInterval);
    }
  };

  const handleSelectSuggestion = (item: SearchResultItem) => {
    const displaySym = item.cleanSymbol || item.symbol.replace(/\.NS$/i, '').replace(/\.BO$/i, '');
    setInputSymbol(displaySym);
    setShowSuggestions(false);
    onFetch(item.symbol || displaySym, selectedRange, selectedInterval);
  };

  const handleQuickSelect = (ticker: IndianMarketTicker) => {
    setInputSymbol(ticker.displayTicker || ticker.symbol);
    setShowSuggestions(false);
    onFetch(ticker.symbol, selectedRange, selectedInterval);
  };

  const handleUseSuggestionClick = (suggested: string) => {
    setInputSymbol(suggested);
    if (onApplySuggestion) {
      onApplySuggestion(suggested);
    } else {
      onFetch(suggested, selectedRange, selectedInterval);
    }
  };

  const filteredTickers = INDIAN_MARKET_TICKERS.filter(t => {
    if (activeTab === 'stocks') return t.type === 'stock';
    if (activeTab === 'commodities') return t.type === 'commodity';
    if (activeTab === 'indices') return t.type === 'index';
    return true;
  });

  const currencySymbol = currency.includes('INR') || currency.includes('₹') ? '₹' : '$';
  const effectiveWarning = fetchWarning || (localInputWarning ? { message: localInputWarning, type: 'warning' as const } : null);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4 backdrop-blur-sm">
      {/* Top Banner: Status & Active Instrument Display (Names appear after fetch) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="px-2 py-0.5 rounded-md bg-emerald-950/80 border border-emerald-700/50 text-emerald-400 text-[10px] font-mono font-bold tracking-wider uppercase">
              Indian Markets & MCX
            </div>
            {selectedApiConfig?.provider === 'custom_api' && (
              <span className="px-2 py-0.5 rounded-md bg-cyan-950/80 border border-cyan-600/50 text-cyan-300 text-[10px] font-mono font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                API: {selectedApiConfig.customApiName || 'Custom'} ({selectedApiConfig.dataType === 'live' ? 'Live' : 'Historical'})
              </span>
            )}
            {activeSymbol ? (
              <span className="text-[11px] font-mono text-cyan-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                Live Market Data Loaded
              </span>
            ) : (
              <span className="text-[11px] font-mono text-amber-400/90 font-medium">
                Enter any Indian stock or commodity to fetch data
              </span>
            )}
          </div>
          
          {/* Active Name — Only displayed when data is fetched */}
          {activeName && activeSymbol ? (
            <div className="mt-1 flex items-baseline gap-2.5 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <span>{activeName}</span>
                <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono border border-cyan-800/60">
                  {activeSymbol}
                </span>
              </h2>
              {lastClosePrice !== undefined && (
                <span className="text-sm sm:text-base font-mono font-bold text-emerald-400">
                  {currencySymbol}{lastClosePrice.toLocaleString()}
                </span>
              )}
            </div>
          ) : (
            <h2 className="mt-1 text-sm sm:text-base font-semibold text-slate-300">
              Fetch Indian Equities (NSE/BSE) or MCX Commodities to analyze
            </h2>
          )}
        </div>

        {/* Recent Fetched Items in this session (Names appear dynamically) */}
        {recentFetches.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto max-w-full sm:max-w-md pb-1 sm:pb-0 scrollbar-none">
            <span className="text-[10px] uppercase font-mono text-slate-500 whitespace-nowrap">
              Recent:
            </span>
            {recentFetches.map(item => (
              <button
                key={item.symbol}
                type="button"
                onClick={() => onSelectRecent(item)}
                className={`px-2 py-1 rounded text-xs font-mono transition flex items-center gap-1 shrink-0 ${
                  activeSymbol === item.symbol
                    ? 'bg-cyan-600 text-white font-bold border border-cyan-400'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                }`}
                title={item.name}
              >
                <span>{item.symbol}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Client-Side Validation Warning Banner (Immediate 400 Prevention) */}
      {effectiveWarning && (
        <div className={`p-3 rounded-xl border flex items-start justify-between gap-3 text-xs transition-all animate-fadeIn ${
          effectiveWarning.type === 'error'
            ? 'bg-red-950/70 border-red-800/80 text-red-200'
            : 'bg-amber-950/60 border-amber-800/70 text-amber-200'
        }`}>
          <div className="flex items-start gap-2.5">
            {effectiveWarning.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <p className="font-medium leading-relaxed">{effectiveWarning.message}</p>
              {effectiveWarning.suggestion && (
                <div className="flex items-center gap-2 pt-0.5">
                  <span className="text-slate-400 text-[11px]">Recommended match:</span>
                  <button
                    type="button"
                    onClick={() => handleUseSuggestionClick(effectiveWarning.suggestion!)}
                    className="px-2 py-0.5 rounded bg-cyan-900/80 hover:bg-cyan-800 text-cyan-200 border border-cyan-700 font-mono font-bold text-[11px] flex items-center gap-1 transition"
                  >
                    <span>Use {effectiveWarning.suggestion}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          </div>
          {onDismissWarning && (
            <button
              type="button"
              onClick={onDismissWarning}
              className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800/60 transition"
              title="Dismiss warning"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Main Search & Control Form */}
      <form onSubmit={handleSubmit} className="grid grid-cols-2 md:grid-cols-12 gap-2 sm:gap-2.5">
        {/* Ticker Search Input with Live Autocomplete */}
        <div ref={searchContainerRef} className="col-span-2 md:col-span-6 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="indian-market-search-input"
            type="text"
            value={inputSymbol}
            onFocus={() => {
              if (suggestions.length > 0) setShowSuggestions(true);
            }}
            onChange={(e) => setInputSymbol(e.target.value)}
            placeholder="Type Indian stock (SYRMA SGS, RELIANCE, TCS) or commodity (GOLD, CRUDEOIL)..."
            className={`w-full pl-9 pr-8 py-2.5 bg-slate-950 border rounded-xl text-xs sm:text-sm text-white placeholder:text-slate-500 font-mono focus:outline-none focus:ring-2 transition ${
              localInputWarning 
                ? 'border-amber-600/80 focus:ring-amber-500 focus:border-amber-500' 
                : 'border-slate-700 focus:ring-cyan-500 focus:border-cyan-500'
            }`}
          />
          {isSearching && (
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin absolute right-3 top-1/2 -translate-y-1/2" />
          )}

          {/* Autocomplete Dropdown */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1.5 z-50 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl max-h-64 overflow-y-auto divide-y divide-slate-800/80">
              <div className="px-3 py-1.5 text-[10px] font-mono text-slate-400 bg-slate-950/80 flex items-center justify-between">
                <span>Matching Indian Instruments & Commodities</span>
                <span>Select to fetch</span>
              </div>
              {suggestions.map((s, idx) => (
                <button
                  key={`${s.symbol}-${idx}`}
                  type="button"
                  onClick={() => handleSelectSuggestion(s)}
                  className="w-full px-3 py-2 text-left hover:bg-slate-800/90 transition flex items-center justify-between group cursor-pointer"
                >
                  <div className="min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-cyan-300 text-xs group-hover:text-cyan-200">
                        {s.cleanSymbol || normalizeSymbol(s.symbol)}
                      </span>
                      {s.exchange && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700 font-mono">
                          {s.exchange}
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-300 truncate mt-0.5">
                      {s.name}
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-slate-500 shrink-0 capitalize">
                    {s.type}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Interval Dropdown */}
        <div className="col-span-1 md:col-span-2">
          <select
            id="market-interval-select"
            value={selectedInterval}
            onChange={(e) => {
              const newInterval = e.target.value;
              setSelectedInterval(newInterval);
              const sym = normalizeSymbol(inputSymbol || activeSymbol || 'RELIANCE');
              if (sym) {
                onFetch(sym, selectedRange, newInterval);
              }
            }}
            className="w-full py-2.5 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition cursor-pointer"
            title="Candle Resolution: 15m, 1h, 1d, 1wk"
          >
            <option value="15m">15m (15 Minutes)</option>
            <option value="1h">1h (1 Hour)</option>
            <option value="1d">1d (Daily EOD)</option>
            <option value="1wk">1wk (Weekly)</option>
          </select>
        </div>

        {/* Range Dropdown */}
        <div className="col-span-1 md:col-span-2">
          <select
            id="market-range-select"
            value={selectedRange}
            onChange={(e) => {
              const newRange = e.target.value;
              setSelectedRange(newRange);
              const sym = normalizeSymbol(inputSymbol || activeSymbol || 'RELIANCE');
              if (sym) {
                onFetch(sym, newRange, selectedInterval);
              }
            }}
            className="w-full py-2.5 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition cursor-pointer"
            title="History Horizon"
          >
            <option value="1mo">1 Month</option>
            <option value="3mo">3 Months</option>
            <option value="6mo">6 Months</option>
            <option value="1y">1 Year</option>
            <option value="2y">2 Years</option>
          </select>
        </div>

        {/* Fetch Action Button */}
        <div className="col-span-2 md:col-span-2">
          <button
            id="btn-fetch-indian-market"
            type="submit"
            disabled={isLoading || !inputSymbol.trim()}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-950/50 border border-cyan-400/30 transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Fetching...</span>
              </>
            ) : (
              <>
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Fetch Data</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Quick Select Category Tabs & Chips */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              Quick Fetch Instruments:
            </span>
            {selectedApiConfig && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800/60 text-cyan-300">
                API: {selectedApiConfig.provider === 'binance' ? 'Binance' : selectedApiConfig.provider === 'custom_api' ? 'Custom REST' : 'Yahoo Finance'}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-lg border border-slate-800 text-[11px]">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`px-2 py-0.5 rounded transition ${activeTab === 'all' ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-white'}`}
            >
              All
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('stocks')}
              className={`px-2 py-0.5 rounded transition ${activeTab === 'stocks' ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-white'}`}
            >
              Equities
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('commodities')}
              className={`px-2 py-0.5 rounded transition ${activeTab === 'commodities' ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-white'}`}
            >
              Commodities (MCX)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('indices')}
              className={`px-2 py-0.5 rounded transition ${activeTab === 'indices' ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-white'}`}
            >
              Indices
            </button>
          </div>
        </div>

        {/* Ticker Chips */}
        <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto scrollbar-none py-0.5">
          {filteredTickers.map((t) => {
            const isSelected = activeSymbol === t.symbol || activeSymbol === `${t.symbol}.NS`;
            return (
              <button
                key={t.symbol}
                type="button"
                onClick={() => handleQuickSelect(t)}
                className={`px-2.5 py-1 rounded-lg border text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-950/90 border-cyan-500 text-white font-bold shadow-sm'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                }`}
              >
                <span>{t.displayTicker}</span>
                <span className="text-[10px] text-slate-500 font-sans">
                  {t.exchange}
                </span>
                {isSelected && <Check className="w-3 h-3 text-cyan-400 ml-0.5" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
