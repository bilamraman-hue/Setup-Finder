import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  ShieldAlert, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Crosshair, 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Target, 
  Clock, 
  Percent, 
  Zap, 
  Copy, 
  Check, 
  Sparkles,
  ArrowRight,
  Info,
  Compass,
  Lock,
  Ban,
  Scale,
  Calculator,
  Play,
  Bell,
  Award,
  CircleDollarSign,
  Activity,
  Bookmark,
  Newspaper,
  Globe,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { VoiceCopilotButton } from './VoiceCopilotButton';
import { TimeSeriesPoint, StockSummaryReportData } from '../types';
import { evaluateQuantSetup, QuantSetupReport, QuantHorizon } from '../lib/quantSetupEngine';
import { analyzeOptionChainOi, analyzeVolumeSpike, detectPriceVolumeTrap, cacheLiveFuturesOiSignal, cacheLiveOptionChainSignal, type MarketFlowSignals } from '../lib/marketFlowSignals';
import { calculateSyntheticBuildupMatrix, syntheticBuildupSupportScore, type SyntheticBuildupTimeframe } from '../lib/syntheticBuildupMatrix';
import { calculateTimeframeWeightedVerdict, type VerdictWeightProfile } from '../lib/timeframeVerdictWeights';
import type { OptionChainPayload } from '../lib/indianOptionsEngine';

export type SetupGradeType = 'GRADE_A_PLUS' | 'GRADE_A' | 'GRADE_B' | 'NO_TRADE';

export interface NewsHeadlineItem {
  title: string;
  source: string;
  sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  impact: 'HIGH' | 'MEDIUM' | 'LOW';
  timeAgo: string;
  snippet?: string;
  url?: string;
}

export interface NewsSentimentData {
  symbol: string;
  name: string;
  overallSentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  sentimentScore: number; // -100 to +100
  sentimentConfidence: 'HIGH' | 'MEDIUM' | 'LOW';
  scoreImpactPct: number; // -10 to +10
  sentimentSummary: string;
  headlines: NewsHeadlineItem[];
  keyBullishFactors?: string[];
  keyBearishRisks?: string[];
  timestamp?: string;
}

export interface FinalVerdictResult {
  horizon: 'Intraday (5m/15m)' | 'Swing (3–4 Days)';
  timeframe: string;
  verdict: 'BUY / ACCUMULATE' | 'SELL / SHORT' | 'CONFLICT — AVOID / WAIT' | 'NEUTRAL CONSOLIDATION';
  verdictBadge: string;
  verdictColor: 'emerald' | 'rose' | 'amber' | 'slate';
  setupGrade: SetupGradeType;
  gradeLabel: string;
  gradeDesc: string;
  capitalAllocationPct: number;
  isDualEngineAligned: boolean;
  confluenceScorePct: number;
  directionalScorePct: number;
  timeframeWeights: VerdictWeightProfile;
  hasDirectionalVerdict: boolean;
  hasActionableVerdict: boolean;
  rawConfluenceScorePct: number;
  newsImpactBoost: number;
  newsSentiment?: NewsSentimentData | null;
  timesFmScorePct: number;
  quantScorePct: number;
  timesFmDirection: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  quantDirection: 'BULLISH' | 'BEARISH';
  direction: 'BULLISH' | 'BEARISH' | 'CONFLICT / NEUTRAL';
  cmp: number;
  currencySymbol: string;
  mtfMatrix: {
    dailyMacro: { trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS'; detail: string; aligned: boolean };
    hourlyStructure: { trend: 'BULLISH' | 'BEARISH' | 'RANGE'; detail: string; aligned: boolean };
    fifteenMinTrigger: { trend: 'BULLISH' | 'BEARISH' | 'CONSOLIDATING'; detail: string; aligned: boolean };
    cascadingStatus: string;
  };
  optionsRecommendation?: {
    atmStrike: number;
    recommendedContract: string;
    action: 'BUY CE' | 'BUY PE' | 'BULL CALL SPREAD' | 'BEAR PUT SPREAD' | 'IRON CONDOR / AVOID';
    estimatedPremium: number;
    optionSl: number;
    optionT1: number;
    optionT2: number;
    pcrRatio: number;
    pcrBias: string;
    maxPainStrike: number;
  };
  smcFvgLevel: {
    fvg50PctCe: number;
    liquiditySweepStatus: string;
    equilibriumZone: string;
  };
  entryZone: {
    min: number;
    max: number;
    text: string;
    aggressiveEntry: number;
    conservativeDip: number;
    strategyText: string;
  };
  strictStopLoss: {
    price: number;
    pct: number;
    riskAmount: number;
    invalidationText: string;
    trailingBreakevenRule: string;
    timesFmBasis: string;
    quantBasis: string;
  };
  target1: {
    price: number;
    pct: number;
    label: string;
    timeframe: string;
    exitRule: string;
  };
  target2: {
    price: number;
    pct: number;
    label: string;
    timeframe: string;
    exitRule: string;
  };
  target3: {
    price: number;
    pct: number;
    label: string;
    timeframe: string;
    exitRule: string;
  };
  neutralTriggers?: {
    bullishBreakout: number;
    bearishBreakdown: number;
    guidance: string;
  };
  riskRewardRatio: number;
  riskRewardText: string;
  summaryRationale: string;
  timesFmAlignment: string;
  quantSetupAlignment: string;
  marketFlow: MarketFlowSignals;
  trapBlocksVerdict: boolean;
}

interface FinalVerdictModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  name: string;
  currencySymbol?: string;
  history: TimeSeriesPoint[];
  timeframe?: SyntheticBuildupTimeframe;
  stockContext?: StockSummaryReportData | null;
  activeQuantSetup?: QuantSetupReport | null;
  onOpenPaperTrading?: () => void;
  onOpenAlerts?: () => void;
}

/**
 * Combines the local statistical forecast baseline with heuristic technical setup inputs.
 * Includes Multi-Timeframe Cascading Matrix, Setup Grading, Options Strategy, and Position Sizing.
 */
export function calculateFinalVerdict(
  horizon: 'Intraday (5m/15m)' | 'Swing (3–4 Days)',
  history: TimeSeriesPoint[],
  symbol: string,
  name: string,
  currencySymbol: string = '₹',
  stockContext?: Partial<StockSummaryReportData> | null,
  providedQuantSetup?: QuantSetupReport | null,
  newsSentiment?: NewsSentimentData | null,
  providedMarketFlow?: Partial<MarketFlowSignals>
): FinalVerdictResult {
  const quant = (providedQuantSetup && providedQuantSetup.horizon === horizon)
    ? providedQuantSetup
    : evaluateQuantSetup(
        symbol,
        name,
        history,
        horizon as QuantHorizon,
        currencySymbol,
        true,
        false
      );

  const cmp = stockContext?.currentMarketPrice || quant.cmp || (history.length > 0 ? history[history.length - 1].value : 100);

  // 1. TimesFM Parameters & Direction
  const timesFmDirection: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = stockContext?.direction || 'BULLISH';
  const timesFmT1 = stockContext?.targetOne?.targetPrice || (timesFmDirection === 'BULLISH' ? cmp * 1.02 : cmp * 0.98);
  const timesFmT2 = stockContext?.targetTwo?.targetPrice || (timesFmDirection === 'BULLISH' ? cmp * 1.05 : cmp * 0.95);
  const timesFmT3 = stockContext?.targetThree?.targetPrice || (timesFmDirection === 'BULLISH' ? cmp * 1.08 : cmp * 0.92);
  const timesFmSL = stockContext?.strictStoploss?.stoplossPrice || (timesFmDirection === 'BULLISH' ? cmp * 0.975 : cmp * 1.025);
  const timesFmScore = timesFmDirection === 'NEUTRAL' ? 50 : 65;

  // 2. Institutional Quant Setup Parameters & Direction
  const quantDirection: 'BULLISH' | 'BEARISH' = quant.direction.includes('LONG') || quant.direction.includes('Bounceback') ? 'BULLISH' : 'BEARISH';
  const quantScore = quant.scorePct;
  const quantT1 = quant.target1.price;
  const quantT2 = quant.target2.price;
  const quantSL = quant.stopLoss.price;

  // 3. Strict Confluence Verification & News Sentiment Score Modulation
  const isDualEngineAligned = timesFmDirection === quantDirection;
  const newsImpactBoost = newsSentiment ? (newsSentiment.scoreImpactPct || 0) : 0;
  const volumeSpike = providedMarketFlow?.volumeSpike || analyzeVolumeSpike(history);
  const syntheticBuildup = providedMarketFlow?.syntheticBuildup || calculateSyntheticBuildupMatrix(history, horizon === 'Intraday (5m/15m)' ? '15m' : '1d');
  const trapRisk = providedMarketFlow?.trapRisk || detectPriceVolumeTrap(history);
  const marketFlow: MarketFlowSignals = { ...providedMarketFlow, volumeSpike, syntheticBuildup, trapRisk };
  const verifiedDirectionalFlows = [marketFlow.optionChainOi, marketFlow.futuresOi]
    .filter(signal => signal?.available) as NonNullable<MarketFlowSignals['optionChainOi']>[];
  const timeframe = syntheticBuildup.timeframe || (horizon === 'Intraday (5m/15m)' ? '15m' : '1d');
  const timesFmVote = timesFmDirection === 'BULLISH' ? 1 : timesFmDirection === 'BEARISH' ? -1 : 0;
  const quantVote = quantDirection === 'BULLISH' ? 1 : -1;
  const priceActionSigned = (timesFmVote * 50 + quantVote * quantScore) / 2;
  const weightedVerdict = calculateTimeframeWeightedVerdict({
    timeframe,
    priceActionSigned,
    volumeAvailable: volumeSpike.available,
    volumeDirection: volumeSpike.direction,
    volumeStrengthPct: volumeSpike.isSpike ? Math.min(100, volumeSpike.ratio / 3 * 100) : 0,
    syntheticBuildup,
    liveOiSignals: verifiedDirectionalFlows
  });
  const expectedDirection = weightedVerdict.direction;
  const hasDirectionalVerdict = expectedDirection !== 'NEUTRAL';
  const rawConfluenceScorePct = weightedVerdict.confidencePct;
  const hasTrap = trapRisk.available && trapRisk.kind !== 'NONE' && trapRisk.scorePct >= 55;
  const trapConflictsWithSignal = hasTrap && expectedDirection !== 'NEUTRAL' && trapRisk.direction !== expectedDirection;
  const trapBlocksVerdict = trapConflictsWithSignal && trapRisk.scorePct >= 70;
  const trapAdjustment = hasTrap && expectedDirection !== 'NEUTRAL'
    ? (trapConflictsWithSignal ? -Math.min(12, Math.round(trapRisk.scorePct * 0.12)) : Math.min(4, Math.round(trapRisk.scorePct * 0.04)))
    : 0;
  const confluenceScorePct = Math.max(10, Math.min(99, Math.round(weightedVerdict.confidencePct + newsImpactBoost + trapAdjustment)));

  // 4. Multi-Timeframe Cascading Confluence Calculation
  const isIntraday = horizon === 'Intraday (5m/15m)';
  const lastClose = history.length > 0 ? history[history.length - 1].value : cmp;
  const sma20 = history.length >= 20 
    ? history.slice(-20).reduce((acc, p) => acc + p.value, 0) / 20 
    : cmp;
  const sma50 = history.length >= 50 
    ? history.slice(-50).reduce((acc, p) => acc + p.value, 0) / 50 
    : sma20;

  const dailyTrend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS' = lastClose > sma50 ? 'BULLISH' : lastClose < sma50 * 0.98 ? 'BEARISH' : 'SIDEWAYS';
  const hourlyTrend: 'BULLISH' | 'BEARISH' | 'RANGE' = quant.levels.marketStructure.includes('Higher') || lastClose > quant.levels.vwap ? 'BULLISH' : lastClose < quant.levels.vwap ? 'BEARISH' : 'RANGE';
  const m15Trend: 'BULLISH' | 'BEARISH' | 'CONSOLIDATING' = expectedDirection === 'BULLISH' ? 'BULLISH' : expectedDirection === 'BEARISH' ? 'BEARISH' : 'CONSOLIDATING';

  const mtfDailyAligned = (expectedDirection === 'BULLISH' && dailyTrend === 'BULLISH') || (expectedDirection === 'BEARISH' && dailyTrend === 'BEARISH');
  const mtfHourlyAligned = (expectedDirection === 'BULLISH' && hourlyTrend === 'BULLISH') || (expectedDirection === 'BEARISH' && hourlyTrend === 'BEARISH');
  const mtf15mAligned = hasDirectionalVerdict;

  let cascadingStatus = '';
  if (mtfDailyAligned && mtfHourlyAligned && mtf15mAligned) {
    cascadingStatus = 'Triple-Timeframe Macro Alignment (High Conviction)';
  } else if (!mtfDailyAligned && mtf15mAligned) {
    cascadingStatus = 'Counter-Trend Intraday Scalp (Daily Macro Divergence)';
  } else if (!hasDirectionalVerdict) {
    cascadingStatus = 'Conflicting Timeframe Regimes (Capital Preservation)';
  } else {
    cascadingStatus = 'Dual-Timeframe Alignment with Pullback Structure';
  }

  // 5. Setup Grading & Capital Allocation
  let setupGrade: SetupGradeType = 'NO_TRADE';
  let gradeLabel = 'NO TRADE / NEUTRAL';
  let gradeDesc = 'Price-action and available flow evidence are balanced or insufficient. Zero capital deployed.';
  let capitalAllocationPct = 0;

  if (hasDirectionalVerdict) {
    if (confluenceScorePct >= 80 && quant.riskRewardRatio >= 2.0 && mtfDailyAligned) {
      setupGrade = 'GRADE_A_PLUS';
      gradeLabel = 'GRADE A+ (ELITE SETUP)';
      gradeDesc = 'Strong timeframe-weighted price-action and available flow alignment. Score is not a calibrated probability.';
      capitalAllocationPct = 100;
    } else if (confluenceScorePct >= 68 && quant.riskRewardRatio >= 1.5) {
      setupGrade = 'GRADE_A';
      gradeLabel = 'GRADE A (CORE SETUP)';
      gradeDesc = 'Strong weighted setup evidence. Standard risk parameters and disciplined targets.';
      capitalAllocationPct = 75;
    } else {
      setupGrade = 'GRADE_B';
      gradeLabel = 'GRADE B (TACTICAL SCALP)';
      gradeDesc = 'Counter-trend or elevated volatility corridor. Tight quick T1 booking advised.';
      capitalAllocationPct = 50;
    }
  }

  if (trapBlocksVerdict) {
    setupGrade = 'NO_TRADE';
    gradeLabel = 'NO TRADE / TRAP RISK';
    gradeDesc = 'A high-volume range rejection conflicts with the directional thesis. Wait for a later completed-bar confirmation.';
    capitalAllocationPct = 0;
  }

  // 6. Verdict State
  let verdict: 'BUY / ACCUMULATE' | 'SELL / SHORT' | 'CONFLICT — AVOID / WAIT' | 'NEUTRAL CONSOLIDATION';
  let verdictBadge: string;
  let verdictColor: 'emerald' | 'rose' | 'amber' | 'slate';
  let direction: 'BULLISH' | 'BEARISH' | 'CONFLICT / NEUTRAL';

  if (trapBlocksVerdict) {
    verdict = 'CONFLICT — AVOID / WAIT';
    verdictBadge = `${trapRisk.label.toUpperCase()} (${trapRisk.scorePct}/100) — WAIT FOR CONFIRMATION`;
    verdictColor = 'amber';
    direction = 'CONFLICT / NEUTRAL';
  } else if (!hasDirectionalVerdict) {
    verdict = 'NEUTRAL CONSOLIDATION';
    verdictBadge = `BALANCED / WEAK EVIDENCE (${weightedVerdict.directionalScorePct}/100 bullish support)`;
    verdictColor = 'slate';
    direction = 'CONFLICT / NEUTRAL';
  } else if (expectedDirection === 'BULLISH') {
    direction = 'BULLISH';
    if (confluenceScorePct >= 65 && quant.riskRewardRatio >= 1.35) {
      verdict = 'BUY / ACCUMULATE';
      verdictBadge = `${gradeLabel} • WEIGHTED BULLISH SETUP`;
      verdictColor = 'emerald';
    } else {
      verdict = 'NEUTRAL CONSOLIDATION';
      verdictBadge = 'BULLISH BIAS — WAIT FOR PULLBACK TO SUPPORT';
      verdictColor = 'amber';
    }
  } else {
    direction = 'BEARISH';
    if (confluenceScorePct >= 65 && quant.riskRewardRatio >= 1.35) {
      verdict = 'SELL / SHORT';
      verdictBadge = `${gradeLabel} • WEIGHTED BEARISH SETUP`;
      verdictColor = 'rose';
    } else {
      verdict = 'NEUTRAL CONSOLIDATION';
      verdictBadge = 'BEARISH BIAS — WAIT FOR PULLBACK TO RESISTANCE';
      verdictColor = 'amber';
    }
  }
  const hasActionableVerdict = verdict === 'BUY / ACCUMULATE' || verdict === 'SELL / SHORT';
  if (!hasActionableVerdict && !trapBlocksVerdict && hasDirectionalVerdict) {
    setupGrade = 'NO_TRADE';
    gradeLabel = 'NO TRADE / WAIT';
    gradeDesc = 'Directional bias is present, but the alignment score or risk/reward gate is not met.';
    capitalAllocationPct = 0;
  }

  // 7. Perfect Entry Syntheses & SMC FVG Retest Levels
  let entryMin = 0;
  let entryMax = 0;
  let aggressiveEntry = cmp;
  let conservativeDip = cmp;
  let entryStrategyText = '';

  const fvgCe = Math.round((direction === 'BULLISH' ? cmp * 0.994 : cmp * 1.006) * 100) / 100;

  if (hasDirectionalVerdict && direction === 'BULLISH') {
    const quantMin = quant.entryRange.min || cmp * 0.995;
    const quantMax = quant.entryRange.max || cmp * 1.002;
    const timesMin = stockContext?.entryGuide?.idealEntryMin || cmp * 0.994;
    const timesMax = stockContext?.entryGuide?.idealEntryMax || cmp * 1.003;

    entryMin = Math.round(Math.min(quantMin, timesMin) * 100) / 100;
    entryMax = Math.round(Math.max(quantMax, timesMax) * 100) / 100;
    aggressiveEntry = cmp;
    conservativeDip = Math.round(Math.min(quant.levels.vwap, quant.levels.cprBottom, cmp * 0.992) * 100) / 100;
    
    entryStrategyText = isIntraday
      ? `Ideal accumulation zone ${currencySymbol}${entryMin.toLocaleString()} – ${currencySymbol}${entryMax.toLocaleString()}. Enter 60% around CMP/VWAP; deploy remaining 40% on test of FVG 50% CE (${currencySymbol}${fvgCe.toLocaleString()}) or CPR floor.`
      : `Institutional swing accumulation zone ${currencySymbol}${entryMin.toLocaleString()} – ${currencySymbol}${entryMax.toLocaleString()}. Enter 60% on breakout, 40% on pullback test of 20 EMA.`;
  } else if (hasDirectionalVerdict && direction === 'BEARISH') {
    const quantMin = quant.entryRange.min || cmp * 0.998;
    const quantMax = quant.entryRange.max || cmp * 1.006;
    const timesMin = stockContext?.entryGuide?.idealEntryMin || cmp * 0.997;
    const timesMax = stockContext?.entryGuide?.idealEntryMax || cmp * 1.005;

    entryMin = Math.round(Math.min(quantMin, timesMin) * 100) / 100;
    entryMax = Math.round(Math.max(quantMax, timesMax) * 100) / 100;
    aggressiveEntry = cmp;
    conservativeDip = Math.round(Math.max(quant.levels.vwap, quant.levels.cprTop, cmp * 1.008) * 100) / 100;

    entryStrategyText = isIntraday
      ? `Ideal short corridor ${currencySymbol}${entryMin.toLocaleString()} – ${currencySymbol}${entryMax.toLocaleString()}. Initiate shorts on breakdown or bounce rejection near CPR top (${currencySymbol}${conservativeDip.toLocaleString()}).`
      : `Institutional swing short corridor ${currencySymbol}${entryMin.toLocaleString()} – ${currencySymbol}${entryMax.toLocaleString()}. Short on bounce test of 20 EMA resistance.`;
  } else {
    entryMin = Math.round((cmp * 0.995) * 100) / 100;
    entryMax = Math.round((cmp * 1.005) * 100) / 100;
    aggressiveEntry = cmp;
    conservativeDip = cmp;
    entryStrategyText = `Direct entry is not suggested because the local forecast estimate (${timesFmDirection}) and technical setup (${quantDirection}) disagree.`;
  }

  // 8. Aligned Targets
  let t1Price = 0;
  let t2Price = 0;
  let t3Price = 0;
  const t1Timeframe = isIntraday ? '1 to 3 Hours' : '1 to 2 Trading Days';
  const t2Timeframe = isIntraday ? 'Session Close' : '3 to 5 Trading Days';
  const t3Timeframe = isIntraday ? 'Multi-Session Ext.' : '6 to 10 Trading Days';

  if (hasDirectionalVerdict && direction === 'BULLISH') {
    t1Price = Math.round(((timesFmT1 + quantT1) / 2) * 100) / 100;
    if (t1Price <= cmp) t1Price = Math.round(cmp * (isIntraday ? 1.012 : 1.025) * 100) / 100;

    t2Price = Math.round(((timesFmT2 + quantT2) / 2) * 100) / 100;
    if (t2Price <= t1Price) t2Price = Math.round(Math.max(t1Price * 1.015, cmp * (isIntraday ? 1.022 : 1.055)) * 100) / 100;

    t3Price = Math.round(((timesFmT3 + (quantT2 * 1.025)) / 2) * 100) / 100;
    if (t3Price <= t2Price) t3Price = Math.round(Math.max(t2Price * 1.02, cmp * (isIntraday ? 1.035 : 1.09)) * 100) / 100;
  } else if (hasDirectionalVerdict && direction === 'BEARISH') {
    t1Price = Math.round(((timesFmT1 + quantT1) / 2) * 100) / 100;
    if (t1Price >= cmp) t1Price = Math.round(cmp * (isIntraday ? 0.988 : 0.975) * 100) / 100;

    t2Price = Math.round(((timesFmT2 + quantT2) / 2) * 100) / 100;
    if (t2Price >= t1Price) t2Price = Math.round(Math.min(t1Price * 0.985, cmp * (isIntraday ? 0.978 : 0.945)) * 100) / 100;

    t3Price = Math.round(((timesFmT3 + (quantT2 * 0.975)) / 2) * 100) / 100;
    if (t3Price >= t2Price) t3Price = Math.round(Math.min(t2Price * 0.98, cmp * (isIntraday ? 0.965 : 0.91)) * 100) / 100;
  } else {
    t1Price = Math.round((cmp * 1.02) * 100) / 100;
    t2Price = Math.round((cmp * 1.045) * 100) / 100;
    t3Price = Math.round((cmp * 1.07) * 100) / 100;
  }

  const t1Pct = Math.round((Math.abs(t1Price - cmp) / cmp) * 1000) / 10;
  const t2Pct = Math.round((Math.abs(t2Price - cmp) / cmp) * 1000) / 10;
  const t3Pct = Math.round((Math.abs(t3Price - cmp) / cmp) * 1000) / 10;

  // 9. Aligned Strict Stop Loss & Trailing Rules
  let slPrice = 0;
  let invalidationText = '';
  let timesFmBasis = '';
  let quantBasis = '';

  if (hasDirectionalVerdict && direction === 'BULLISH') {
    const candidateSL = Math.min(timesFmSL, quantSL);
    slPrice = candidateSL < cmp ? candidateSL : Math.round(cmp * (isIntraday ? 0.992 : 0.975) * 100) / 100;
    if (slPrice >= cmp) slPrice = Math.round((cmp * 0.985) * 100) / 100;

    timesFmBasis = `TimesFM p10 quantile support boundary floor.`;
    quantBasis = `Institutional CPR Bottom / 20 EMA invalidation zone.`;
    invalidationText = isIntraday
      ? `Strict invalidation: Exit immediately if 5-minute candle closes below ${currencySymbol}${slPrice.toLocaleString()} or breaks under VWAP floor.`
      : `Strict invalidation: Daily candle closing below ${currencySymbol}${slPrice.toLocaleString()} invalidates the bullish structure.`;
  } else if (hasDirectionalVerdict && direction === 'BEARISH') {
    const candidateSL = Math.max(timesFmSL, quantSL);
    slPrice = candidateSL > cmp ? candidateSL : Math.round(cmp * (isIntraday ? 1.008 : 1.025) * 100) / 100;
    if (slPrice <= cmp) slPrice = Math.round((cmp * 1.015) * 100) / 100;

    timesFmBasis = `TimesFM p90 quantile resistance boundary ceiling.`;
    quantBasis = `Institutional CPR Top / 20 EMA resistance breakdown pivot.`;
    invalidationText = isIntraday
      ? `Strict invalidation: Cover short immediately if 5-minute candle closes above ${currencySymbol}${slPrice.toLocaleString()} or pierces CPR roof.`
      : `Strict invalidation: Daily candle closing above ${currencySymbol}${slPrice.toLocaleString()} terminates the short thesis.`;
  } else {
    slPrice = Math.round((cmp * 0.985) * 100) / 100;
    timesFmBasis = `TimesFM model is positioned for ${timesFmDirection}.`;
    quantBasis = `Quant engine is positioned for ${quantDirection}.`;
    invalidationText = `No active stoploss since directional trade is disabled due to engine divergence.`;
  }

  const slRiskAmount = Math.round(Math.abs(cmp - slPrice) * 100) / 100;
  const slPct = Math.round((slRiskAmount / cmp) * 1000) / 10;
  const rewardDist = Math.abs(t2Price - cmp);
  const riskDist = Math.max(0.01, slRiskAmount);
  const rrrNum = Math.round((rewardDist / riskDist) * 10) / 10;
  const rrText = hasDirectionalVerdict ? `1:${rrrNum}` : 'N/A (Neutral)';

  // 10. Options Strike & Derivatives Recommendation
  const strikeInterval = cmp > 30000 ? 500 : cmp > 15000 ? 100 : cmp > 4000 ? 50 : cmp > 1000 ? 20 : 5;
  const atmStrike = Math.round(cmp / strikeInterval) * strikeInterval;
  // 11. Neutral Triggers
  const bullishBreakout = Math.round((cmp * 1.015) * 100) / 100;
  const bearishBreakdown = Math.round((cmp * 0.985) * 100) / 100;
  const neutralTriggers = !hasDirectionalVerdict ? {
    bullishBreakout,
    bearishBreakdown,
    guidance: `Wait for confirmed breakout above ${currencySymbol}${bullishBreakout.toLocaleString()} with volume to realign to Bullish, or breakdown below ${currencySymbol}${bearishBreakdown.toLocaleString()} to realign to Bearish.`
  } : undefined;

  // 12. Summary Rationale
  let summaryRationale = '';
  if (trapBlocksVerdict) {
    summaryRationale = `⚠️ ${trapRisk.detail} The directional setup is blocked until a later completed bar confirms a breakout or breakdown.`;
  } else if (!hasDirectionalVerdict) {
    summaryRationale = `⚖️ Price-action, volume and available live-OI evidence are balanced or insufficient (${weightedVerdict.directionalScorePct}/100 bullish support). Wait for a confirmed move out of the neutral band.`;
  } else if (direction === 'BULLISH') {
    summaryRationale = `✅ ${gradeLabel} (${confluenceScorePct}% heuristic alignment score): timeframe-weighted price action and available volume/OI evidence point upward. Score is not a probability. Displayed risk-reward estimate: 1:${rrrNum}.`;
  } else {
    summaryRationale = `✅ ${gradeLabel} (${confluenceScorePct}% heuristic alignment score): timeframe-weighted price action and available volume/OI evidence point downward. Score is not a probability. Displayed risk-reward estimate: 1:${rrrNum}.`;
  }
  if (hasTrap) summaryRationale += ` ${trapRisk.detail}${trapBlocksVerdict ? ' The trap-risk gate has disabled the trade verdict.' : ''}`;
  if (syntheticBuildup.available) summaryRationale += ` ${syntheticBuildup.detail} Its nominal weight is 15%; timeframe weighting is ${JSON.stringify(weightedVerdict.weights)}.`;

  return {
    horizon,
    timeframe,
    verdict,
    verdictBadge,
    verdictColor,
    setupGrade,
    gradeLabel,
    gradeDesc,
    capitalAllocationPct,
    isDualEngineAligned,
    confluenceScorePct,
    directionalScorePct: weightedVerdict.directionalScorePct,
    timeframeWeights: weightedVerdict.weights,
    hasDirectionalVerdict,
    hasActionableVerdict,
    timesFmScorePct: timesFmScore,
    quantScorePct: quantScore,
    timesFmDirection,
    quantDirection,
    direction,
    cmp,
    currencySymbol,
    mtfMatrix: {
      dailyMacro: {
        trend: dailyTrend,
        detail: `50 EMA (${currencySymbol}${Math.round(sma50)}), 200 EMA baseline`,
        aligned: mtfDailyAligned
      },
      hourlyStructure: {
        trend: hourlyTrend,
        detail: `CPR (${quant.levels.cprWidthType}), VWAP confluence`,
        aligned: mtfHourlyAligned
      },
      fifteenMinTrigger: {
        trend: m15Trend,
        detail: `TimesFM patch trajectory & breakout corridor`,
        aligned: mtf15mAligned
      },
      cascadingStatus
    },
    smcFvgLevel: {
      fvg50PctCe: fvgCe,
      liquiditySweepStatus: 'Buy-Side & Sell-Side Liquidity Swept prior to displacement',
      equilibriumZone: `${currencySymbol}${Math.round(cmp * 0.997)} – ${currencySymbol}${Math.round(cmp * 1.003)}`
    },
    entryZone: {
      min: entryMin,
      max: entryMax,
      text: hasDirectionalVerdict
        ? `${currencySymbol}${entryMin.toLocaleString()} – ${currencySymbol}${entryMax.toLocaleString()}`
        : 'NO ENTRY (AWAIT CONFLUENCE)',
      aggressiveEntry,
      conservativeDip,
      strategyText: entryStrategyText
    },
    strictStopLoss: {
      price: slPrice,
      pct: slPct,
      riskAmount: slRiskAmount,
      invalidationText,
      trailingBreakevenRule: 'Lock Stoploss strictly at Cost (Break-Even) once Target 1 is achieved. Trail remaining with 1.5× ATR.',
      timesFmBasis,
      quantBasis
    },
    target1: {
      price: t1Price,
      pct: t1Pct,
      label: isIntraday ? 'T1 Scalp (Initial Momentum)' : 'T1 Primary Swing (Initial Resistance)',
      timeframe: t1Timeframe,
      exitRule: hasDirectionalVerdict
        ? 'Book 40%–50% profit at T1 and immediately move stoploss to Cost Price (Break-Even).'
        : 'Theoretical level only.'
    },
    target2: {
      price: t2Price,
      pct: t2Pct,
      label: isIntraday ? 'T2 Core (Session Range Pivot)' : 'T2 Core Swing (Local Forecast Estimate + Technical Level)',
      timeframe: t2Timeframe,
      exitRule: hasDirectionalVerdict
        ? 'Book 30%–40% additional profit at T2. Trail remaining balance with 20-period EMA.'
        : 'Theoretical level only.'
    },
    target3: {
      price: t3Price,
      pct: t3Pct,
      label: isIntraday ? 'T3 Extension (Volatility Surge)' : 'T3 Upper Quantile Extension (p75/p90)',
      timeframe: t3Timeframe,
      exitRule: hasDirectionalVerdict
        ? 'Final target exit or trail with 1.5 ATR trailing stop.'
        : 'Theoretical level only.'
    },
    neutralTriggers,
    riskRewardRatio: rrrNum,
    riskRewardText: rrText,
    summaryRationale,
    rawConfluenceScorePct,
    newsImpactBoost,
    newsSentiment: newsSentiment || null,
    timesFmAlignment: `TimesFM 3.0 indicates ${timesFmDirection} corridor with target anchor at ${currencySymbol}${timesFmT1.toLocaleString()}.`,
    quantSetupAlignment: `Institutional Quant Setup indicates ${quantDirection} (${quantScore}% score) with ${quant.levels.oiBuildupType}.`,
    marketFlow,
    trapBlocksVerdict
  };
}

export const FinalVerdictModal: React.FC<FinalVerdictModalProps> = ({
  isOpen,
  onClose,
  symbol,
  name,
  currencySymbol = '₹',
  history,
  timeframe: selectedTimeframe,
  stockContext,
  activeQuantSetup,
  onOpenPaperTrading,
  onOpenAlerts
}) => {
  const [horizon, setHorizon] = useState<'Intraday (5m/15m)' | 'Swing (3–4 Days)'>('Intraday (5m/15m)');
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'NEWS_SENTIMENT' | 'MTF_OPTIONS' | 'POSITION_SIZER'>('OVERVIEW');
  const [copied, setCopied] = useState(false);
  const [newsSentiment, setNewsSentiment] = useState<NewsSentimentData | null>(null);
  const [isNewsLoading, setIsNewsLoading] = useState<boolean>(false);
  const [optionChainSignal, setOptionChainSignal] = useState<MarketFlowSignals['optionChainOi']>();
  const [futuresOiSignal, setFuturesOiSignal] = useState<MarketFlowSignals['futuresOi']>();

  // Position Sizing Calculator state
  const [accountCapital, setAccountCapital] = useState<number>(200000);
  const [riskPct, setRiskPct] = useState<number>(1.0);

  const fetchLiveNewsSentiment = async (sym: string, nm: string, currentPrice?: number) => {
    try {
      setIsNewsLoading(true);
      const queryParam = new URLSearchParams({
        symbol: sym,
        name: nm,
        ...(currentPrice ? { cmp: currentPrice.toString() } : {})
      });
      const res = await fetch(`/api/market/news-sentiment?${queryParam.toString()}`);
      if (res.ok) {
        const data: NewsSentimentData = await res.json();
        setNewsSentiment(data);
      }
    } catch (e) {
      console.warn('Could not fetch news sentiment:', e);
    } finally {
      setIsNewsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      const cmpPrice = stockContext?.currentMarketPrice || (history.length > 0 ? history[history.length - 1].value : undefined);
      fetchLiveNewsSentiment(symbol, name, cmpPrice);
      setOptionChainSignal(undefined);
      setFuturesOiSignal(undefined);
      const savedConfigStr = typeof window !== 'undefined' ? localStorage.getItem('timesfm_custom_api_config') : null;
      const headers: Record<string, string> = {};
      if (savedConfigStr) headers['x-custom-api-config'] = encodeURIComponent(savedConfigStr);
      const cmpQuery = cmpPrice && cmpPrice > 0 ? `&cmp=${encodeURIComponent(String(cmpPrice))}` : '';
      const refreshFlow = async () => {
        try {
          const chainRes = await fetch(`/api/market/options?symbol=${encodeURIComponent(symbol)}${cmpQuery}`, { headers });
          if (chainRes.ok) {
            const chain = await chainRes.json() as OptionChainPayload;
            const signal = analyzeOptionChainOi(chain);
            setOptionChainSignal(signal);
            cacheLiveOptionChainSignal(symbol, signal);
          }
        } catch { /* Optional broker signal: leave it out when unavailable. */ }
        try {
          const oiRes = await fetch(`/api/market/futures-oi?symbol=${encodeURIComponent(symbol)}`, { headers });
          if (oiRes.ok) {
            const oi = await oiRes.json();
            if (oi?.available) {
              setFuturesOiSignal(oi.signal);
              cacheLiveFuturesOiSignal(symbol, oi.signal);
            }
          }
        } catch { /* Optional broker signal: leave it out when unavailable. */ }
      };
      void refreshFlow();
      const refreshTimer = window.setTimeout(() => { void refreshFlow(); }, 6000);
      return () => window.clearTimeout(refreshTimer);
    }
  }, [isOpen, symbol, name]);

  if (!isOpen) return null;

  const result = calculateFinalVerdict(
    horizon,
    history,
    symbol,
    name,
    currencySymbol,
    stockContext,
    activeQuantSetup,
    newsSentiment,
    {
      optionChainOi: optionChainSignal,
      futuresOi: futuresOiSignal,
      syntheticBuildup: calculateSyntheticBuildupMatrix(history, selectedTimeframe || (horizon === 'Intraday (5m/15m)' ? '15m' : '1d'))
    }
  );

  const fmtCurr = (val: number) =>
    `${currencySymbol}${val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  // Position Size calculation
  const maxRiskAmount = (accountCapital * riskPct) / 100;
  const perShareRisk = Math.max(0.1, result.strictStopLoss.riskAmount);
  const calculatedShares = Math.max(1, Math.floor(maxRiskAmount / perShareRisk));
  const tradeValue = Math.round(calculatedShares * result.cmp);
  const expectedProfitT1 = Math.round(calculatedShares * Math.abs(result.target1.price - result.cmp));
  const expectedProfitT2 = Math.round(calculatedShares * Math.abs(result.target2.price - result.cmp));

  const handleCopyLevels = () => {
    const text = `🎯 **INSTITUTIONAL FINAL VERDICT: ${symbol} (${name})**
📅 Horizon: ${result.horizon}
📊 CMP: ${fmtCurr(result.cmp)}
🎖️ **Setup Grade**: ${result.gradeLabel} (${result.capitalAllocationPct}% Allocation)
⚖️ **Signal balance**: ${result.hasDirectionalVerdict ? `✅ ${result.direction} bias (${result.directionalScorePct}/100 bullish support)` : `⚖️ NEUTRAL (${result.directionalScorePct}/100 bullish support)`}
📌 **Verdict**: ${result.verdict}
🎯 **Heuristic Alignment Score**: ${result.confluenceScorePct}% (Local estimate: ${result.timesFmDirection} | Technical: ${result.quantDirection}; not a probability)
🌐 **Multi-Timeframe Status**: ${result.mtfMatrix.cascadingStatus}

${result.hasActionableVerdict ? `
1️⃣ **Perfect Entry Zone**: ${result.entryZone.text}
   • Aggressive CMP: ${fmtCurr(result.entryZone.aggressiveEntry)}
   • Conservative Dip: ${fmtCurr(result.entryZone.conservativeDip)}
   • 50% FVG Retest CE: ${fmtCurr(result.smcFvgLevel.fvg50PctCe)}
   • Strategy: ${result.entryZone.strategyText}

2️⃣ **Aligned Target 1**: ${fmtCurr(result.target1.price)} (${result.direction === 'BULLISH' ? '+' : '-'}${result.target1.pct}%)
   • Exit: ${result.target1.exitRule}

3️⃣ **Aligned Target 2**: ${fmtCurr(result.target2.price)} (${result.direction === 'BULLISH' ? '+' : '-'}${result.target2.pct}%)
   • Exit: ${result.target2.exitRule}

4️⃣ **Aligned Target 3**: ${fmtCurr(result.target3.price)} (${result.direction === 'BULLISH' ? '+' : '-'}${result.target3.pct}%)
   • Exit: ${result.target3.exitRule}

🛡 **Strict Stoploss**: ${fmtCurr(result.strictStopLoss.price)} (Risk: ${result.strictStopLoss.pct}% | ${fmtCurr(result.strictStopLoss.riskAmount)})
   • R:R Profile: ${result.riskRewardText}
   • Trailing Rule: ${result.strictStopLoss.trailingBreakevenRule}
   • Invalidation: ${result.strictStopLoss.invalidationText}

📊 **Option Strike Suggestion**:
   • Options chain, premiums, PCR and max pain: unavailable (no verified chain input)
` : `
⚠️ **Divergence Rationale**: ${result.summaryRationale}
🚫 **Capital Protection Mode**:
   • Bullish Breakout: ${fmtCurr(result.neutralTriggers?.bullishBreakout || 0)}
   • Bearish Breakdown: ${fmtCurr(result.neutralTriggers?.bearishBreakdown || 0)}
   • Guidance: ${result.neutralTriggers?.guidance}
`}

💼 **Position Sizing Plan**:
   • Account Base: ${currencySymbol}${accountCapital.toLocaleString()} (${riskPct}% Risk = ${currencySymbol}${maxRiskAmount.toLocaleString()})
   • Recommended Shares: ${calculatedShares} (Trade Value: ${currencySymbol}${tradeValue.toLocaleString()})
   • Expected T1 Gain: +${currencySymbol}${expectedProfitT1.toLocaleString()} | T2 Gain: +${currencySymbol}${expectedProfitT2.toLocaleString()}

🔬 Synthesized via local statistical baseline and technical heuristics; scores are not calibrated probabilities`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700/90 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] text-slate-100 ring-1 ring-cyan-500/20">
        
        {/* Header */}
        <div className="px-4 py-3.5 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white shadow-md ${
              result.hasDirectionalVerdict 
                ? 'bg-gradient-to-br from-emerald-500 via-cyan-500 to-indigo-600 shadow-emerald-500/20'
                : 'bg-gradient-to-br from-amber-500 via-rose-500 to-indigo-600 shadow-amber-500/20'
            }`}>
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-wide">
                  Institutional Final Verdict
                </h3>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                  result.setupGrade === 'GRADE_A_PLUS'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                    : result.setupGrade === 'GRADE_A'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                    : result.setupGrade === 'GRADE_B'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  {result.gradeLabel}
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  Alloc: {result.capitalAllocationPct}%
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {symbol} • {name} • CMP: <strong className="text-cyan-300 font-mono">{fmtCurr(result.cmp)}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <VoiceCopilotButton
              symbol={symbol}
              name={name}
              cmp={result.cmp}
              direction={result.direction === 'CONFLICT / NEUTRAL' ? 'NEUTRAL' : result.direction}
              grade={result.gradeLabel}
              confluenceScore={result.confluenceScorePct}
              entryZoneMin={result.entryZone.min}
              entryZoneMax={result.entryZone.max}
              target1={result.target1.price}
              stopLoss={result.strictStopLoss.price}
              currencySymbol={currencySymbol}
              riskReward={result.riskRewardText}
              compact={true}
            />

            <button
              onClick={handleCopyLevels}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 text-xs font-semibold border border-slate-700 transition cursor-pointer"
              title="Copy Trade Plan"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation & Horizon Sub-Bar */}
        <div className="bg-slate-950/90 px-4 py-2 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0 flex-wrap">
          {/* Horizon Switcher */}
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setHorizon('Intraday (5m/15m)')}
              className={`px-2.5 py-1 rounded-md text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                horizon === 'Intraday (5m/15m)'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>Intraday (5m/15m)</span>
            </button>
            <button
              onClick={() => setHorizon('Swing (3–4 Days)')}
              className={`px-2.5 py-1 rounded-md text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                horizon === 'Swing (3–4 Days)'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-3 h-3" />
              <span>Swing (3–4 Days)</span>
            </button>
          </div>

          {/* Section View Tabs */}
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('OVERVIEW')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer ${
                activeTab === 'OVERVIEW' ? 'bg-slate-800 text-cyan-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Overview & Levels
            </button>
            <button
              onClick={() => setActiveTab('NEWS_SENTIMENT')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer flex items-center gap-1 ${
                activeTab === 'NEWS_SENTIMENT' ? 'bg-slate-800 text-amber-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Newspaper className="w-3 h-3" />
              <span>News Sentiment</span>
              {newsSentiment && (
                <span className={`px-1 py-0.2 rounded text-[9px] font-mono font-bold ${
                  newsSentiment.overallSentiment === 'BULLISH'
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : newsSentiment.overallSentiment === 'BEARISH'
                    ? 'bg-rose-500/20 text-rose-300'
                    : 'bg-slate-700 text-slate-300'
                }`}>
                  {newsSentiment.scoreImpactPct > 0 ? `+${newsSentiment.scoreImpactPct}%` : `${newsSentiment.scoreImpactPct}%`}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('MTF_OPTIONS')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer flex items-center gap-1 ${
                activeTab === 'MTF_OPTIONS' ? 'bg-slate-800 text-indigo-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Layers className="w-3 h-3" />
              <span>MTF & Options</span>
            </button>
            <button
              onClick={() => setActiveTab('POSITION_SIZER')}
              className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer flex items-center gap-1 ${
                activeTab === 'POSITION_SIZER' ? 'bg-slate-800 text-emerald-300 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Calculator className="w-3 h-3" />
              <span>Position Sizer</span>
            </button>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* TAB 1: OVERVIEW & LEVELS */}
          {activeTab === 'OVERVIEW' && (
            <>
              {/* Main Verdict Banner */}
              <div className={`p-4 rounded-2xl border ${
                result.verdictColor === 'emerald'
                  ? 'bg-emerald-950/40 border-emerald-500/60 ring-1 ring-emerald-500/30'
                  : result.verdictColor === 'rose'
                  ? 'bg-rose-950/40 border-rose-500/60 ring-1 ring-rose-500/30'
                  : result.verdictColor === 'amber'
                  ? 'bg-amber-950/40 border-amber-500/60 ring-1 ring-amber-500/30'
                  : 'bg-slate-800/40 border-slate-700'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400 block mb-0.5 font-mono">
                      Synthesized Execution Verdict ({horizon})
                    </span>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h2 className={`text-xl sm:text-2xl font-black tracking-tight ${
                        result.verdictColor === 'emerald'
                          ? 'text-emerald-400'
                          : result.verdictColor === 'rose'
                          ? 'text-rose-400'
                          : result.verdictColor === 'amber'
                          ? 'text-amber-400'
                          : 'text-slate-300'
                      }`}>
                        {result.verdict}
                      </h2>
                      <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-950/90 border border-slate-700 font-mono font-bold text-slate-200">
                        R:R {result.riskRewardText}
                      </span>
                    </div>
                  </div>

                  {/* Confluence Gauge Badge */}
                  <div className="text-left sm:text-right">
                    <div className="text-2xl sm:text-3xl font-black font-mono text-cyan-300">
                      {result.confluenceScorePct}%
                    </div>
                    <span className="text-[9px] text-slate-400 uppercase tracking-wider block font-mono">
                      Weighted Evidence Score
                    </span>
                  </div>
                </div>

                <div className="pt-3 grid gap-2 text-[11px] text-slate-300">
                  <div className="rounded-lg bg-slate-950/50 px-3 py-2"><span className="font-bold text-cyan-300">Volume:</span> {result.marketFlow.volumeSpike.detail}</div>
                  <div className="rounded-lg bg-slate-950/50 px-3 py-2"><span className="font-bold text-cyan-300">{result.timeframe} verdict weights:</span> Price action {result.timeframeWeights.priceAction}% · Volume {result.timeframeWeights.volume}% · Synthetic matrix {result.timeframeWeights.syntheticMatrix}% · Verified live OI {result.timeframeWeights.liveOi}%. Bullish support {result.directionalScorePct}/100; neutral band 41–59. Missing feeds are excluded and their weights redistributed.</div>
                  {result.marketFlow.syntheticBuildup && <div className="rounded-lg bg-slate-950/50 px-3 py-2"><span className="font-bold text-cyan-300">Synthetic buildup matrix (15% verdict weight):</span> {result.marketFlow.syntheticBuildup.detail} {result.marketFlow.syntheticBuildup.available ? `Support score ${syntheticBuildupSupportScore(result.marketFlow.syntheticBuildup, result.direction === 'BULLISH' || result.direction === 'BEARISH' ? result.direction : 'NEUTRAL')} / 100.` : ''}</div>}
                  {result.marketFlow.trapRisk?.available && <div className={`rounded-lg px-3 py-2 ${result.marketFlow.trapRisk.kind === 'NONE' ? 'bg-slate-950/50' : 'border border-amber-900/60 bg-amber-950/30'}`}><span className="font-bold text-amber-300">Trap check:</span> {result.marketFlow.trapRisk.detail}</div>}
                  {result.marketFlow.optionChainOi?.available && <div className="rounded-lg bg-slate-950/50 px-3 py-2"><span className="font-bold text-cyan-300">Live option-chain OI:</span> {result.marketFlow.optionChainOi.detail}</div>}
                  {result.marketFlow.futuresOi?.available && <div className="rounded-lg bg-slate-950/50 px-3 py-2"><span className="font-bold text-cyan-300">Symbol futures OI:</span> {result.marketFlow.futuresOi.detail}</div>}
                  {!result.marketFlow.optionChainOi?.available && !result.marketFlow.futuresOi?.available && <div className="text-[10px] text-slate-500">Live option/futures OI buildup is unavailable or waiting for a second broker snapshot; it is excluded from this verdict.</div>}
                </div>
                <p className="text-xs text-slate-200 mt-3 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
                  {result.summaryRationale}
                </p>
              </div>

              {/* LIVE NEWS & CATALYST SENTIMENT BANNER */}
              <div className="bg-slate-950/90 border border-amber-500/30 rounded-xl p-3.5 space-y-2.5 shadow-md">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center">
                      <Newspaper className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                          Live News & Catalyst Sentiment
                        </span>
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-800">
                          Google Grounded
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Real-time headlines analyzed by Gemini 3.8 Flash
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {newsSentiment && (
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                        newsSentiment.overallSentiment === 'BULLISH'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                          : newsSentiment.overallSentiment === 'BEARISH'
                          ? 'bg-rose-950 text-rose-300 border-rose-700'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}>
                        {newsSentiment.overallSentiment} ({newsSentiment.scoreImpactPct > 0 ? `+${newsSentiment.scoreImpactPct}%` : `${newsSentiment.scoreImpactPct}%`} Confluence Shift)
                      </span>
                    )}
                    <button
                      onClick={() => setActiveTab('NEWS_SENTIMENT')}
                      className="px-2 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold transition cursor-pointer flex items-center gap-1"
                    >
                      <span>View Headlines</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {isNewsLoading ? (
                  <div className="flex items-center gap-2 text-xs text-amber-300/80 py-1 font-mono animate-pulse">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>Analyzing live financial search headlines...</span>
                  </div>
                ) : newsSentiment ? (
                  <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                    {newsSentiment.sentimentSummary}
                  </p>
                ) : (
                  <p className="text-xs text-slate-400">
                    Click "View Headlines" or tab to load search-grounded news catalysts.
                  </p>
                )}
              </div>

              {/* DUAL-ENGINE STATUS COMPARISON */}
              <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400 uppercase font-bold tracking-wider font-mono">
                  <span className="flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-cyan-400" />
                    Dual-Engine Alignment Validation
                  </span>
                  <span className={`px-2 py-0.5 rounded font-bold ${
                    result.isDualEngineAligned
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}>
                    {result.isDualEngineAligned ? 'ALIGNED IN SAME DIRECTION' : 'CONFLICTING DIRECTIONS'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {/* TimesFM View */}
                  <div className={`p-2.5 rounded-lg border flex items-center justify-between ${
                    result.timesFmDirection === 'BULLISH'
                      ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-950/30 border-rose-500/30 text-rose-300'
                  }`}>
                    <div>
                      <span className="text-[10px] text-slate-400 block font-mono">1. Local forecast baseline</span>
                      <strong className="font-mono text-sm">{result.timesFmDirection}</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Heuristic alignment score</span>
                      <span className="font-mono text-xs font-semibold">{result.timesFmScorePct}% · not probability</span>
                    </div>
                  </div>

                  {/* Quant Engine View */}
                  <div className={`p-2.5 rounded-lg border flex items-center justify-between ${
                    result.quantDirection === 'BULLISH'
                      ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-950/30 border-rose-500/30 text-rose-300'
                  }`}>
                    <div>
                      <span className="text-[10px] text-slate-400 block font-mono">2. Institutional Quant</span>
                      <strong className="font-mono text-sm">{result.quantDirection}</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">100-Pt Setup Score</span>
                      <span className="font-mono text-xs font-semibold">{result.quantScorePct}% Score</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* IF NOT ALIGNED: Neutral Breakout Watch Levels */}
              {!result.hasDirectionalVerdict && result.neutralTriggers && (
                <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 space-y-3">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Capital Protection Active: Neutral Breakout Triggers</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div className="bg-slate-950/80 p-3 rounded-lg border border-emerald-500/30">
                      <span className="text-[10px] uppercase font-mono text-emerald-400 font-bold block">
                        Bullish Breakout Re-alignment Trigger
                      </span>
                      <div className="text-base font-black font-mono text-white mt-1">
                        Above {fmtCurr(result.neutralTriggers.bullishBreakout)}
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1">
                        Re-evaluate Buy only if candle closes above this level with heavy volume.
                      </p>
                    </div>

                    <div className="bg-slate-950/80 p-3 rounded-lg border border-rose-500/30">
                      <span className="text-[10px] uppercase font-mono text-rose-400 font-bold block">
                        Bearish Breakdown Re-alignment Trigger
                      </span>
                      <div className="text-base font-black font-mono text-white mt-1">
                        Below {fmtCurr(result.neutralTriggers.bearishBreakdown)}
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1">
                        Short only if price breaks down under this support level.
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-amber-200/90 leading-relaxed font-mono">
                    💡 {result.neutralTriggers.guidance}
                  </p>
                </div>
              )}

              {/* IF ALIGNED: Perfect Entry & Targets Grid */}
              {result.hasActionableVerdict && (
                <>
                  {/* Perfect Entry Levels Card */}
                  <div className="bg-slate-950/90 border border-cyan-500/30 rounded-xl p-4 space-y-3 shadow-lg">
                    <div className="flex items-center justify-between text-xs text-cyan-400 font-bold uppercase tracking-wider">
                      <span className="flex items-center gap-1.5 font-mono">
                        <Compass className="w-4 h-4 text-cyan-400" />
                        Synthesized Perfect Entry Levels
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono font-bold">
                        50% FVG CE: {fmtCurr(result.smcFvgLevel.fvg50PctCe)}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      <div className="bg-slate-900/90 p-3 rounded-lg border border-cyan-500/40">
                        <span className="text-[10px] text-cyan-300 font-mono uppercase font-bold block">
                          🎯 Ideal Entry Zone
                        </span>
                        <div className="text-base font-black font-mono text-cyan-300 mt-1">
                          {result.entryZone.text}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          Institutional corridor
                        </span>
                      </div>

                      <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                        <span className="text-[10px] text-emerald-400 font-mono uppercase font-bold block">
                          ⚡ Aggressive Entry
                        </span>
                        <div className="text-base font-black font-mono text-white mt-1">
                          {fmtCurr(result.entryZone.aggressiveEntry)}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          CMP Market Execution
                        </span>
                      </div>

                      <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
                        <span className="text-[10px] text-amber-400 font-mono uppercase font-bold block">
                          🛡 Conservative Dip Support
                        </span>
                        <div className="text-base font-black font-mono text-amber-300 mt-1">
                          {fmtCurr(result.entryZone.conservativeDip)}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          CPR Floor / 20 EMA
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 pt-1 border-t border-slate-800/80 leading-relaxed">
                      <strong className="text-white">Execution Strategy:</strong> {result.entryZone.strategyText}
                    </p>
                  </div>

                  {/* Core Targets & Stoploss Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    {/* TARGET 1 */}
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/40 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider">
                          <span>Target 1 (T1)</span>
                          <span className="text-slate-400 font-normal">⏱ {result.target1.timeframe}</span>
                        </div>
                        <div className="text-xl font-black font-mono text-amber-400 mt-1">
                          {fmtCurr(result.target1.price)}
                        </div>
                        <span className="text-xs font-bold text-amber-300 font-mono">
                          {result.direction === 'BULLISH' ? '+' : '-'}{result.target1.pct}% Return
                        </span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                        🚪 <strong>Exit:</strong> {result.target1.exitRule}
                      </div>
                    </div>

                    {/* TARGET 2 */}
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/40 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider">
                          <span>Target 2 (T2)</span>
                          <span className="text-slate-400 font-normal">⏱ {result.target2.timeframe}</span>
                        </div>
                        <div className="text-xl font-black font-mono text-emerald-400 mt-1">
                          {fmtCurr(result.target2.price)}
                        </div>
                        <span className="text-xs font-bold text-emerald-300 font-mono">
                          {result.direction === 'BULLISH' ? '+' : '-'}{result.target2.pct}% Return
                        </span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                        🚪 <strong>Exit:</strong> {result.target2.exitRule}
                      </div>
                    </div>

                    {/* TARGET 3 */}
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-purple-500/40 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] font-mono font-bold text-purple-400 uppercase tracking-wider">
                          <span>Target 3 (T3)</span>
                          <span className="text-slate-400 font-normal">⏱ {result.target3.timeframe}</span>
                        </div>
                        <div className="text-xl font-black font-mono text-purple-300 mt-1">
                          {fmtCurr(result.target3.price)}
                        </div>
                        <span className="text-xs font-bold text-purple-300 font-mono">
                          {result.direction === 'BULLISH' ? '+' : '-'}{result.target3.pct}% Return
                        </span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                        🚪 <strong>Exit:</strong> {result.target3.exitRule}
                      </div>
                    </div>

                    {/* STRICT STOP LOSS */}
                    <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-500/40 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider">
                          <span>Strict Stoploss</span>
                          <span className="text-rose-300 font-mono font-bold">1:{result.riskRewardRatio} RRR</span>
                        </div>
                        <div className="text-xl font-black font-mono text-rose-400 mt-1">
                          {fmtCurr(result.strictStopLoss.price)}
                        </div>
                        <span className="text-xs font-bold text-rose-400 font-mono">
                          {result.strictStopLoss.pct}% Risk ({fmtCurr(result.strictStopLoss.riskAmount)})
                        </span>
                      </div>
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[10px] text-rose-300/80">
                        🛡 {result.strictStopLoss.trailingBreakevenRule}
                      </div>
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {/* TAB: LIVE NEWS & CATALYST SENTIMENT (GOOGLE SEARCH GROUNDED) */}
          {activeTab === 'NEWS_SENTIMENT' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Sentiment Gauge & Impact Header */}
              <div className="p-4 bg-slate-950 border border-amber-500/40 rounded-xl space-y-3 shadow-lg">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold">
                      <Newspaper className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5 font-mono">
                        Google Search Grounded Financial Sentiment
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-cyan-950 text-cyan-300 border border-cyan-800">
                          Gemini 3.8 Flash
                        </span>
                      </h4>
                      <p className="text-[10px] text-slate-400">
                        {symbol} • {name} • Live market intelligence & institutional catalyst stream
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => fetchLiveNewsSentiment(symbol, name, result.cmp)}
                      disabled={isNewsLoading}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
                      title="Re-scrape latest financial news via Google Search"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isNewsLoading ? 'animate-spin text-amber-400' : ''}`} />
                      <span>{isNewsLoading ? 'Scanning...' : 'Refresh News'}</span>
                    </button>
                  </div>
                </div>

                {/* Score Breakdown Cards */}
                {newsSentiment && (
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 text-xs pt-2 border-t border-slate-800">
                    <div className={`p-3 rounded-lg border ${
                      newsSentiment.overallSentiment === 'BULLISH'
                        ? 'bg-emerald-950/40 border-emerald-500/50'
                        : newsSentiment.overallSentiment === 'BEARISH'
                        ? 'bg-rose-950/40 border-rose-500/50'
                        : 'bg-slate-900 border-slate-800'
                    }`}>
                      <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">
                        Overall Sentiment
                      </span>
                      <div className={`text-base font-black font-mono mt-1 ${
                        newsSentiment.overallSentiment === 'BULLISH'
                          ? 'text-emerald-400'
                          : newsSentiment.overallSentiment === 'BEARISH'
                          ? 'text-rose-400'
                          : 'text-slate-300'
                      }`}>
                        {newsSentiment.overallSentiment}
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Confidence: {newsSentiment.sentimentConfidence}
                      </span>
                    </div>

                    <div className="p-3 rounded-lg border bg-slate-900 border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">
                        Sentiment Score
                      </span>
                      <div className={`text-base font-black font-mono mt-1 ${
                        newsSentiment.sentimentScore > 0 ? 'text-emerald-400' : newsSentiment.sentimentScore < 0 ? 'text-rose-400' : 'text-slate-300'
                      }`}>
                        {newsSentiment.sentimentScore > 0 ? `+${newsSentiment.sentimentScore}` : newsSentiment.sentimentScore} / 100
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        -100 (Bear) to +100 (Bull)
                      </span>
                    </div>

                    <div className="p-3 rounded-lg border bg-slate-900 border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">
                        Verdict Impact
                      </span>
                      <div className={`text-base font-black font-mono mt-1 ${
                        newsSentiment.scoreImpactPct > 0 ? 'text-emerald-400' : newsSentiment.scoreImpactPct < 0 ? 'text-rose-400' : 'text-slate-300'
                      }`}>
                        {newsSentiment.scoreImpactPct > 0 ? `+${newsSentiment.scoreImpactPct}%` : `${newsSentiment.scoreImpactPct}%`}
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Confluence Score Shift
                      </span>
                    </div>

                    <div className="p-3 rounded-lg border bg-slate-900 border-slate-800">
                      <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block">
                        Net Confluence Score
                      </span>
                      <div className="text-base font-black font-mono text-cyan-300 mt-1">
                        {result.confluenceScorePct}%
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Base ({result.rawConfluenceScorePct}%) + News
                      </span>
                    </div>
                  </div>
                )}

                {/* Executive Synopsis */}
                {newsSentiment && (
                  <div className="bg-slate-900/80 p-3 rounded-lg border border-slate-800 text-xs text-slate-200 leading-relaxed">
                    <strong className="text-white block mb-1 font-mono uppercase text-[10px] text-amber-300">
                      📰 Catalyst Executive Summary:
                    </strong>
                    {newsSentiment.sentimentSummary}
                  </div>
                )}
              </div>

              {/* Bullish Drivers vs Bearish Risks */}
              {newsSentiment && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {/* Bullish Factors */}
                  <div className="p-3.5 bg-emerald-950/20 border border-emerald-500/30 rounded-xl space-y-2">
                    <div className="flex items-center gap-1.5 text-emerald-300 font-bold font-mono uppercase text-[11px]">
                      <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Key Bullish Catalysts</span>
                    </div>
                    <ul className="space-y-1.5 text-slate-300">
                      {newsSentiment.keyBullishFactors?.map((f, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-[11px]">
                          <span className="text-emerald-400 font-bold">✓</span>
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Bearish Risks */}
                  <div className="p-3.5 bg-rose-950/20 border border-rose-500/30 rounded-xl space-y-2">
                    <div className="flex items-center gap-1.5 text-rose-300 font-bold font-mono uppercase text-[11px]">
                      <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                      <span>Key Downside Risks</span>
                    </div>
                    <ul className="space-y-1.5 text-slate-300">
                      {newsSentiment.keyBearishRisks?.map((r, i) => (
                        <li key={i} className="flex items-start gap-1.5 text-[11px]">
                          <span className="text-rose-400 font-bold">✕</span>
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Grounded News Headlines Feed */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 font-mono">
                    <Globe className="w-3.5 h-3.5 text-cyan-400" />
                    Grounded Real-Time Financial Headlines
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {newsSentiment?.headlines?.length || 0} Grounded Stories
                  </span>
                </div>

                {isNewsLoading ? (
                  <div className="p-8 text-center bg-slate-950 rounded-xl border border-slate-800 space-y-2 animate-pulse">
                    <RefreshCw className="w-6 h-6 animate-spin text-amber-400 mx-auto" />
                    <p className="text-xs text-slate-300 font-mono">
                      Querying Google Search grounding index for latest {symbol} news...
                    </p>
                  </div>
                ) : newsSentiment && newsSentiment.headlines?.length > 0 ? (
                  <div className="space-y-2">
                    {newsSentiment.headlines.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-800/90 rounded-xl transition flex flex-col justify-between gap-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-slate-850 text-slate-300 border border-slate-700">
                                {item.source}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                • {item.timeAgo}
                              </span>
                              <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold font-mono uppercase ${
                                item.sentiment === 'POSITIVE'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : item.sentiment === 'NEGATIVE'
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                  : 'bg-slate-800 text-slate-300'
                              }`}>
                                {item.sentiment}
                              </span>
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold font-mono bg-slate-900 text-slate-400 border border-slate-800">
                                Impact: {item.impact}
                              </span>
                            </div>

                            <h5 className="text-xs font-bold text-white hover:text-cyan-300 transition">
                              {item.title}
                            </h5>
                          </div>

                          {item.url && (
                            <a
                              href={item.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-cyan-300 border border-slate-750 transition shrink-0"
                              title="Open original news source in new tab"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>

                        {item.snippet && (
                          <p className="text-[11px] text-slate-400 leading-relaxed pl-2 border-l-2 border-slate-800">
                            {item.snippet}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center bg-slate-950 rounded-xl border border-slate-800">
                    <p className="text-xs text-slate-400">
                      No headlines fetched yet. Click "Refresh News" to run Google Search grounding.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: MULTI-TIMEFRAME MATRIX & OPTIONS CONFLUENCE */}
          {activeTab === 'MTF_OPTIONS' && (
            <div className="space-y-4 animate-in fade-in">
              {/* Multi-Timeframe Matrix */}
              <div className="p-4 bg-slate-950 border border-indigo-500/40 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5 font-mono">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    Multi-Timeframe Cascading Alignment Matrix
                  </span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                    {result.mtfMatrix.cascadingStatus}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  {/* Daily Macro */}
                  <div className={`p-3 rounded-lg border ${
                    result.mtfMatrix.dailyMacro.aligned ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-mono font-bold">Daily (Macro Trend)</span>
                      <span className={`text-[10px] font-bold ${result.mtfMatrix.dailyMacro.trend === 'BULLISH' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {result.mtfMatrix.dailyMacro.trend}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1">{result.mtfMatrix.dailyMacro.detail}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">50 & 200 EMA Regime</span>
                  </div>

                  {/* 1-Hour Structure */}
                  <div className={`p-3 rounded-lg border ${
                    result.mtfMatrix.hourlyStructure.aligned ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-mono font-bold">1-Hour (Pivots & CPR)</span>
                      <span className={`text-[10px] font-bold ${result.mtfMatrix.hourlyStructure.trend === 'BULLISH' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {result.mtfMatrix.hourlyStructure.trend}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1">{result.mtfMatrix.hourlyStructure.detail}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Central Floor & VWAP</span>
                  </div>

                  {/* 15-Minute Trigger */}
                  <div className={`p-3 rounded-lg border ${
                    result.mtfMatrix.fifteenMinTrigger.aligned ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-900 border-slate-800'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-mono font-bold">15-Min (Execution Trigger)</span>
                      <span className={`text-[10px] font-bold ${result.mtfMatrix.fifteenMinTrigger.trend === 'BULLISH' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {result.mtfMatrix.fifteenMinTrigger.trend}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1">{result.mtfMatrix.fifteenMinTrigger.detail}</p>
                    <span className="text-[10px] text-slate-500 mt-1 block">Forecast estimate breakout</span>
                  </div>
                </div>
              </div>

              {/* Options & Derivatives Confluence Card */}
              {result.optionsRecommendation && (
                <div className="p-4 bg-slate-950 border border-cyan-500/30 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5 font-mono">
                      <Activity className="w-4 h-4 text-cyan-400" />
                      Derivatives & Option Strike Strategy Recommendation
                    </span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                      PCR: {result.optionsRecommendation.pcrRatio}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5 text-xs font-mono">
                    <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Recommended Contract</span>
                      <strong className="text-white text-sm">{result.optionsRecommendation.recommendedContract}</strong>
                      <span className="text-[10px] text-cyan-400 block mt-0.5">{result.optionsRecommendation.action}</span>
                    </div>

                    <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Est. Entry Premium</span>
                      <strong className="text-emerald-400 text-sm">₹{result.optionsRecommendation.estimatedPremium}</strong>
                      <span className="text-[10px] text-slate-400 block mt-0.5">SL: ₹{result.optionsRecommendation.optionSl}</span>
                    </div>

                    <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Option T1 / T2</span>
                      <strong className="text-cyan-300 text-sm">₹{result.optionsRecommendation.optionT1} / ₹{result.optionsRecommendation.optionT2}</strong>
                      <span className="text-[10px] text-emerald-400 block mt-0.5">Target R:R 1:2+</span>
                    </div>

                    <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Max Pain (requires option chain)</span>
                      <strong className="text-purple-300 text-sm">{currencySymbol}{result.optionsRecommendation.maxPainStrike}</strong>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{result.optionsRecommendation.pcrBias}</span>
                    </div>
                  </div>

                  <div className="p-2.5 bg-slate-900/60 rounded-lg border border-slate-850 text-[11px] text-slate-300 flex items-center justify-between">
                    <span>💡 <strong>F&O Rule:</strong> Never buy OTM options far from CMP. Trade ATM Strike ({currencySymbol}{result.optionsRecommendation.atmStrike}) with strict stoploss at ₹{result.optionsRecommendation.optionSl}.</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: POSITION SIZING CALCULATOR */}
          {activeTab === 'POSITION_SIZER' && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 bg-slate-950 border border-emerald-500/30 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5 font-mono">
                    <Calculator className="w-4 h-4 text-emerald-400" />
                    Capital Allocation & Kelly Criterion Position Sizer
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                    Risk-Adjusted Quantity
                  </span>
                </div>

                {/* Sizer Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 text-[11px] font-semibold block mb-1">
                      Total Account Portfolio Capital ({currencySymbol})
                    </label>
                    <input
                      type="number"
                      value={accountCapital}
                      onChange={(e) => setAccountCapital(Math.max(1000, Number(e.target.value)))}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-slate-400 text-[11px] font-semibold block mb-1">
                      Max Risk Per Trade (%)
                    </label>
                    <div className="flex items-center gap-1.5">
                      {[0.5, 1.0, 1.5, 2.0].map((r) => (
                        <button
                          key={r}
                          onClick={() => setRiskPct(r)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold transition cursor-pointer flex-1 ${
                            riskPct === r ? 'bg-emerald-600 text-white' : 'bg-slate-900 border border-slate-700 text-slate-300'
                          }`}
                        >
                          {r}%
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Calculation Output Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono pt-2 border-t border-slate-800">
                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Max Risk Allowed</span>
                    <strong className="text-rose-400 text-sm">{currencySymbol}{maxRiskAmount.toLocaleString()}</strong>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-emerald-500/40">
                    <span className="text-[10px] text-emerald-400 block font-bold">Recommended Quantity</span>
                    <strong className="text-emerald-300 text-base">{calculatedShares} Shares</strong>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Required Capital</span>
                    <strong className="text-white text-sm">{currencySymbol}{tradeValue.toLocaleString()}</strong>
                  </div>

                  <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Target 1 Return P&L</span>
                    <strong className="text-emerald-400 text-sm">+{currencySymbol}{expectedProfitT1.toLocaleString()}</strong>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed bg-slate-900/50 p-2.5 rounded-lg">
                  🛡 <strong>Discipline Guarantee:</strong> Even if Stoploss ({fmtCurr(result.strictStopLoss.price)}) is hit, your maximum loss will be capped precisely at {currencySymbol}{maxRiskAmount.toLocaleString()} ({riskPct}% of account).
                </p>
              </div>
            </div>
          )}

        </div>

        {/* Action Footer */}
        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            {onOpenPaperTrading && (
              <button
                onClick={onOpenPaperTrading}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Execute in Paper Trading</span>
              </button>
            )}

            {onOpenAlerts && (
              <button
                onClick={onOpenAlerts}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs flex items-center gap-1.5 border border-slate-700 transition cursor-pointer"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Set Price Alert</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
