import React, { useState, useRef, useMemo, useEffect } from 'react';
import { 
  TimeSeriesPoint, 
  ForecastPoint, 
  AnomalyItem 
} from '../types';
import { 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  Eye, 
  EyeOff, 
  Download, 
  Maximize2,
  AlertCircle,
  CandlestickChart,
  Newspaper,
  Sparkles,
  TrendingUp,
  TrendingDown
} from 'lucide-react';

interface TimeSeriesChartProps {
  history: TimeSeriesPoint[];
  forecasts: ForecastPoint[];
  anomalies: AnomalyItem[];
  unit?: string;
  title?: string;
  confidenceLevel: number;
  onOpenAdvanceChart?: () => void;
  dataQualityState?: 'LIVE' | 'CACHED' | 'SIMULATED' | 'UNAVAILABLE';
  fetchedAt?: string;
  statusMessage?: string;
  engineName?: string;
}

export const TimeSeriesChart: React.FC<TimeSeriesChartProps> = ({
  history,
  forecasts,
  anomalies,
  unit = 'Value',
  title,
  confidenceLevel,
  onOpenAdvanceChart,
  dataQualityState = 'LIVE',
  fetchedAt,
  statusMessage,
  engineName
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoverIndex, setHoverIndex] = useState<{ isForecast: boolean; index: number } | null>(null);
  const [zoomRange, setZoomRange] = useState<[number, number]>([0, 1]); // 0 to 1 normalized
  const [showConfidence, setShowConfidence] = useState(true);
  const [showAnomalies, setShowAnomalies] = useState(true);
  const [showArea, setShowArea] = useState(true);
  const [showNewsSentiment, setShowNewsSentiment] = useState(true);
  const [showCovariateTrack, setShowCovariateTrack] = useState(false);

  // Calculate sentiment stats across history
  const sentimentStats = useMemo(() => {
    let pos = 0;
    let neg = 0;
    let neu = 0;
    let totalScore = 0;
    let count = 0;
    history.forEach(p => {
      if (p.newsSentiment) {
        count++;
        totalScore += p.newsSentiment.score;
        if (p.newsSentiment.sentiment === 'POSITIVE') pos++;
        else if (p.newsSentiment.sentiment === 'NEGATIVE') neg++;
        else neu++;
      }
    });
    const avg = count > 0 ? Math.round((totalScore / count) * 100) / 100 : 0;
    return { pos, neg, neu, total: count, avg };
  }, [history]);

  // Combine data items for calculation
  const totalPoints = history.length + forecasts.length;
  
  // Calculate Min & Max values
  const { minY, maxY, allTimestamps } = useMemo(() => {
    let min = Infinity;
    let max = -Infinity;
    const timestamps: string[] = [];

    history.forEach(p => {
      if (p.value < min) min = p.value;
      if (p.value > max) max = p.value;
      timestamps.push(p.timestamp);
    });

    forecasts.forEach(p => {
      const pLow = p.p025 ?? p.p10;
      const pHigh = p.p975 ?? p.p90;
      if (pLow < min) min = pLow;
      if (pHigh > max) max = pHigh;
      if (p.mean < min) min = p.mean;
      if (p.mean > max) max = p.mean;
      timestamps.push(p.timestamp);
    });

    if (min === Infinity) { min = 0; max = 100; }
    // Add 8% vertical padding
    const range = max - min || 1;
    return {
      minY: min - range * 0.08,
      maxY: max + range * 0.08,
      allTimestamps: timestamps
    };
  }, [history, forecasts]);

  // Dimensions
  const svgWidth = 1000;
  const svgHeight = 440;
  const padding = { top: 25, right: 35, bottom: 45, left: 65 };
  const plotWidth = svgWidth - padding.left - padding.right;
  const plotHeight = svgHeight - padding.top - padding.bottom;

  // Zoomed slice indices
  const startIndex = Math.floor(zoomRange[0] * (totalPoints - 1));
  const endIndex = Math.min(totalPoints - 1, Math.ceil(zoomRange[1] * (totalPoints - 1)));
  const visibleCount = Math.max(2, endIndex - startIndex + 1);

  // Coordinate scales
  const getX = (globalIdx: number) => {
    if (globalIdx < startIndex || globalIdx > endIndex) return -9999;
    const norm = (globalIdx - startIndex) / (visibleCount - 1);
    return padding.left + norm * plotWidth;
  };

  const getY = (val: number) => {
    const norm = (val - minY) / (maxY - minY || 1);
    return padding.top + (1 - norm) * plotHeight;
  };

  // SVG Paths
  const historyPath = useMemo(() => {
    let d = '';
    history.forEach((pt, i) => {
      const x = getX(i);
      const y = getY(pt.value);
      if (x >= padding.left - 5 && x <= padding.left + plotWidth + 5) {
        d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
      }
    });
    return d;
  }, [history, startIndex, endIndex, visibleCount, minY, maxY]);

  const historyAreaPath = useMemo(() => {
    if (history.length === 0) return '';
    let d = '';
    let firstX = 0;
    let lastX = 0;
    const baseZeroY = Math.min(padding.top + plotHeight, Math.max(padding.top, getY(0)));

    history.forEach((pt, i) => {
      const x = getX(i);
      const y = getY(pt.value);
      if (x >= padding.left - 5 && x <= padding.left + plotWidth + 5) {
        if (d === '') {
          firstX = x;
          d = `M ${x} ${baseZeroY} L ${x} ${y}`;
        } else {
          d += ` L ${x} ${y}`;
          lastX = x;
        }
      }
    });
    if (d !== '') {
      d += ` L ${lastX} ${baseZeroY} Z`;
    }
    return d;
  }, [history, startIndex, endIndex, visibleCount, minY, maxY]);

  // Forecast path (connects with last history point)
  const forecastMedianPath = useMemo(() => {
    let d = '';
    // Start at last history point
    if (history.length > 0) {
      const lastHistIdx = history.length - 1;
      d = `M ${getX(lastHistIdx)} ${getY(history[lastHistIdx].value)}`;
    }
    forecasts.forEach((pt, i) => {
      const idx = history.length + i;
      const x = getX(idx);
      const y = getY(pt.p50);
      d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
    });
    return d;
  }, [history, forecasts, startIndex, endIndex, visibleCount, minY, maxY]);

  // Confidence ribbon paths (95% Cone p025-p975, 80% Cone p10-p90, 50% Cone p25-p75)
  const cone95BandPath = useMemo(() => {
    if (forecasts.length === 0) return '';
    let topPath = '';
    let bottomPath = '';

    // Connect from last history
    const lastHistIdx = history.length - 1;
    if (history.length > 0) {
      const startX = getX(lastHistIdx);
      const startY = getY(history[lastHistIdx].value);
      topPath = `M ${startX} ${startY}`;
      bottomPath = `L ${startX} ${startY}`;
    }

    // Forward for upper p975 (or fallback)
    forecasts.forEach((pt, i) => {
      const idx = history.length + i;
      const x = getX(idx);
      const yUpper = getY(pt.p975 ?? pt.p90);
      topPath += ` L ${x} ${yUpper}`;
    });

    // Backward for lower p025 (or fallback)
    for (let i = forecasts.length - 1; i >= 0; i--) {
      const idx = history.length + i;
      const x = getX(idx);
      const yLower = getY(forecasts[i].p025 ?? forecasts[i].p10);
      bottomPath += ` L ${x} ${yLower}`;
    }

    return `${topPath} ${bottomPath} Z`;
  }, [history, forecasts, startIndex, endIndex, visibleCount, minY, maxY]);

  const outerBandPath = useMemo(() => {
    if (forecasts.length === 0) return '';
    let topPath = '';
    let bottomPath = '';

    // Connect from last history
    const lastHistIdx = history.length - 1;
    if (history.length > 0) {
      const startX = getX(lastHistIdx);
      const startY = getY(history[lastHistIdx].value);
      topPath = `M ${startX} ${startY}`;
      bottomPath = `L ${startX} ${startY}`;
    }

    // Forward for upper p90
    forecasts.forEach((pt, i) => {
      const idx = history.length + i;
      const x = getX(idx);
      const yUpper = getY(pt.p90);
      topPath += ` L ${x} ${yUpper}`;
    });

    // Backward for lower p10
    for (let i = forecasts.length - 1; i >= 0; i--) {
      const idx = history.length + i;
      const x = getX(idx);
      const yLower = getY(forecasts[i].p10);
      bottomPath += ` L ${x} ${yLower}`;
    }

    return `${topPath} ${bottomPath} Z`;
  }, [history, forecasts, startIndex, endIndex, visibleCount, minY, maxY]);

  const innerBandPath = useMemo(() => {
    if (forecasts.length === 0) return '';
    let topPath = '';
    let bottomPath = '';

    const lastHistIdx = history.length - 1;
    if (history.length > 0) {
      const startX = getX(lastHistIdx);
      const startY = getY(history[lastHistIdx].value);
      topPath = `M ${startX} ${startY}`;
      bottomPath = `L ${startX} ${startY}`;
    }

    forecasts.forEach((pt, i) => {
      const idx = history.length + i;
      const x = getX(idx);
      const yUpper = getY(pt.p75);
      topPath += ` L ${x} ${yUpper}`;
    });

    for (let i = forecasts.length - 1; i >= 0; i--) {
      const idx = history.length + i;
      const x = getX(idx);
      const yLower = getY(forecasts[i].p25);
      bottomPath += ` L ${x} ${yLower}`;
    }

    return `${topPath} ${bottomPath} Z`;
  }, [history, forecasts, startIndex, endIndex, visibleCount, minY, maxY]);

  // Forecast Origin Divider Line
  const originLineX = history.length > 0 ? getX(history.length - 1) : null;

  // Grid Ticks
  const yTicks = useMemo(() => {
    const count = 5;
    const ticks = [];
    for (let i = 0; i <= count; i++) {
      const val = minY + (i / count) * (maxY - minY);
      ticks.push({
        val: Math.round(val * 100) / 100,
        y: getY(val)
      });
    }
    return ticks;
  }, [minY, maxY]);

  const xTicks = useMemo(() => {
    const count = Math.min(8, visibleCount);
    const step = Math.max(1, Math.floor(visibleCount / count));
    const ticks = [];
    for (let i = startIndex; i <= endIndex; i += step) {
      ticks.push({
        label: allTimestamps[i] || '',
        x: getX(i)
      });
    }
    return ticks;
  }, [startIndex, endIndex, visibleCount, allTimestamps]);

  // Handle Mouse Move for Hover Crosshairs
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mouseX = ((e.clientX - rect.left) / rect.width) * svgWidth;
    if (mouseX < padding.left || mouseX > padding.left + plotWidth) {
      setHoverIndex(null);
      return;
    }

    const norm = (mouseX - padding.left) / plotWidth;
    const targetIdx = Math.round(startIndex + norm * (visibleCount - 1));

    if (targetIdx < history.length) {
      setHoverIndex({ isForecast: false, index: targetIdx });
    } else if (targetIdx < totalPoints) {
      setHoverIndex({ isForecast: true, index: targetIdx - history.length });
    } else {
      setHoverIndex(null);
    }
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
  };

  // Zoom controls
  const handleZoom = (direction: 'in' | 'out') => {
    const currentSpan = zoomRange[1] - zoomRange[0];
    const factor = direction === 'in' ? 0.7 : 1.35;
    const newSpan = Math.min(1.0, Math.max(0.15, currentSpan * factor));
    const center = (zoomRange[0] + zoomRange[1]) / 2;
    const newStart = Math.max(0, Math.min(1 - newSpan, center - newSpan / 2));
    setZoomRange([newStart, newStart + newSpan]);
  };

  const handleResetZoom = () => {
    setZoomRange([0, 1]);
  };

  // Export CSV
  const handleExportCSV = () => {
    let csv = 'Timestamp,Type,Value,p10,p25,p50,p75,p90,Covariates\n';
    history.forEach(p => {
      csv += `${p.timestamp},Historical,${p.value},,,,,${JSON.stringify(p.covariates || {}).replace(/"/g, '""')}\n`;
    });
    forecasts.forEach(p => {
      csv += `${p.timestamp},Forecast,${p.mean},${p.p10},${p.p25},${p.p50},${p.p75},${p.p90},${JSON.stringify(p.covariates || {}).replace(/"/g, '""')}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `timesfm_forecast_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Hover item info
  const hoverPoint = hoverIndex ? (
    hoverIndex.isForecast
      ? forecasts[hoverIndex.index]
      : history[hoverIndex.index]
  ) : null;

  return (
    <div ref={containerRef} className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col">
      {/* Chart Top Controls Bar */}
      <div className="px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-900/60">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${
              dataQualityState === 'LIVE' ? 'bg-emerald-400 animate-pulse' :
              dataQualityState === 'CACHED' ? 'bg-blue-400' :
              dataQualityState === 'SIMULATED' ? 'bg-amber-400' :
              'bg-rose-500'
            }`} />
            <span className="text-sm font-semibold text-white">
              {title || 'Local Forecast Timeline'}
            </span>
            <span className="text-xs text-slate-400">({unit})</span>

            {/* Truthful Data State Badge */}
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold flex items-center gap-1 ${
              dataQualityState === 'LIVE' ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300' :
              dataQualityState === 'CACHED' ? 'bg-blue-950/80 border-blue-500/50 text-blue-300' :
              dataQualityState === 'SIMULATED' ? 'bg-amber-950/80 border-amber-500/50 text-amber-300' :
              'bg-rose-950/80 border-rose-500/50 text-rose-300'
            }`}>
              {dataQualityState === 'LIVE' && '🟢 LIVE FEED'}
              {dataQualityState === 'CACHED' && '🔵 CACHED'}
              {dataQualityState === 'SIMULATED' && '🟠 SIMULATED BENCHMARK'}
              {dataQualityState === 'UNAVAILABLE' && '🔴 UNAVAILABLE'}
            </span>
          </div>

          {/* Horizon & History count badge */}
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700/60 font-mono">
            <span>Context: <strong className="text-slate-200">{history.length}</strong></span>
            <span>•</span>
            <span>Forecast: <strong className="text-cyan-400">{forecasts.length}</strong> steps</span>
            {engineName && (
              <>
                <span>•</span>
                <span className="text-[10px] text-slate-400">{engineName}</span>
              </>
            )}
          </div>
        </div>

        {/* Legend & Interactive Toggles */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Historical Legend */}
          <div className="flex items-center gap-1.5 text-slate-300 px-2 py-1 bg-slate-800/50 rounded-md border border-slate-700/50">
            <div className="w-3 h-0.5 bg-blue-400" />
            <span>History</span>
          </div>

          {/* Median Legend */}
          <div className="flex items-center gap-1.5 text-cyan-300 px-2 py-1 bg-cyan-950/40 rounded-md border border-cyan-800/50">
            <div className="w-3 h-1 bg-cyan-400 rounded-full" />
            <span>Forecast Median (approx.)</span>
          </div>

          {/* Approximate, uncalibrated interval toggle */}
          <button
            id="toggle-confidence-band"
            onClick={() => setShowConfidence(!showConfidence)}
            className={`flex items-center gap-1 px-2 py-1 rounded-md border transition-all ${
              showConfidence 
                ? 'bg-cyan-950/60 text-cyan-300 border-cyan-700' 
                : 'bg-slate-800 text-slate-400 border-slate-700 opacity-60'
            }`}
            title="Toggle approximate forecast interval; historical coverage is not calibrated."
          >
            <div className="w-2.5 h-2.5 rounded bg-cyan-500/30 border border-cyan-400/80" />
            <span>Approx. {confidenceLevel}% range</span>
          </button>

          {/* News Sentiment Toggle */}
          {sentimentStats.total > 0 && (
            <button
              id="toggle-news-sentiment"
              onClick={() => setShowNewsSentiment(!showNewsSentiment)}
              className={`flex items-center gap-1.5 px-2 py-1 rounded-md border transition-all ${
                showNewsSentiment
                  ? 'bg-slate-800/90 text-white border-cyan-600/80 shadow-sm'
                  : 'bg-slate-800/40 text-slate-400 border-slate-700 opacity-60'
              }`}
              title="Toggle News Sentiment Catalyst Markers"
            >
              <Newspaper className="w-3.5 h-3.5 text-cyan-400" />
              <span>News Sentiment</span>
              <div className="flex items-center gap-1 text-[10px] font-mono ml-0.5">
                <span className="text-emerald-400 font-bold">+{sentimentStats.pos}</span>
                <span className="text-rose-400 font-bold">-{sentimentStats.neg}</span>
                <span className="text-slate-400">={sentimentStats.neu}</span>
              </div>
            </button>
          )}

          {/* Anomalies Toggle */}
          {anomalies.length > 0 && (
            <button
              id="toggle-anomalies"
              onClick={() => setShowAnomalies(!showAnomalies)}
              className={`flex items-center gap-1 px-2 py-1 rounded-md border transition-all ${
                showAnomalies 
                  ? 'bg-red-950/60 text-red-300 border-red-700' 
                  : 'bg-slate-800 text-slate-400 border-slate-700 opacity-60'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-red-400" />
              <span>Anomalies ({anomalies.length})</span>
            </button>
          )}

          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg border border-slate-700">
            <button
              id="btn-zoom-in"
              onClick={() => handleZoom('in')}
              className="p-1 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              id="btn-zoom-out"
              onClick={() => handleZoom('out')}
              className="p-1 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              id="btn-reset-zoom"
              onClick={handleResetZoom}
              className="p-1 text-slate-300 hover:text-white hover:bg-slate-700 rounded transition-colors"
              title="Reset Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Export Button */}
          <button
            id="btn-export-csv"
            onClick={handleExportCSV}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
            title="Download CSV"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">CSV</span>
          </button>

          {/* Advance Chart Button */}
          {onOpenAdvanceChart && (
            <button
              id="btn-open-advance-chart"
              onClick={onOpenAdvanceChart}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-gradient-to-r from-purple-900/70 to-indigo-900/70 hover:from-purple-800 hover:to-indigo-800 text-purple-200 border border-purple-500/50 hover:border-purple-400 font-semibold shadow-sm transition-all cursor-pointer"
              title="Open Dedicated Advance Chart (TimesFM Base + VWAP, Bollinger, Pivots, Supertrend, Volume & Imp. Levels)"
            >
              <CandlestickChart className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden sm:inline">Advance Chart</span>
              <span className="sm:hidden">Adv</span>
            </button>
          )}
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative w-full aspect-[16/7] min-h-[360px] max-h-[500px] select-none">
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-full cursor-crosshair overflow-visible"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          preserveAspectRatio="none"
        >
          <defs>
            {/* History gradient */}
            <linearGradient id="historyGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
            </linearGradient>

            {/* 95% Confidence Cone Gradient (Outermost) */}
            <linearGradient id="confidenceGradient95" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.14" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.14" />
            </linearGradient>

            {/* Forecast Confidence Band Gradient (80% / p10-p90) */}
            <linearGradient id="confidenceGradientOuter" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.22" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.14" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.22" />
            </linearGradient>

            <linearGradient id="confidenceGradientInner" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.32" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.32" />
            </linearGradient>

            {/* Subtle Grid Pattern */}
            <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.5" strokeOpacity="0.5" />
            </pattern>
          </defs>

          {/* Background Grid Lines */}
          <rect x={padding.left} y={padding.top} width={plotWidth} height={plotHeight} fill="url(#gridPattern)" />

          {/* Horizontal Grid lines and labels */}
          {yTicks.map((t, idx) => (
            <g key={idx}>
              <line
                x1={padding.left}
                y1={t.y}
                x2={padding.left + plotWidth}
                y2={t.y}
                stroke="#334155"
                strokeWidth="1"
                strokeDasharray="4 4"
                strokeOpacity="0.4"
              />
              <text
                x={padding.left - 10}
                y={t.y + 4}
                fill="#94a3b8"
                fontSize="11"
                textAnchor="end"
                fontFamily="monospace"
              >
                {t.val}
              </text>
            </g>
          ))}

          {/* Vertical X-axis ticks */}
          {xTicks.map((t, idx) => (
            <g key={idx}>
              <line
                x1={t.x}
                y1={padding.top}
                x2={t.x}
                y2={padding.top + plotHeight}
                stroke="#334155"
                strokeWidth="0.5"
                strokeOpacity="0.25"
              />
              <text
                x={t.x}
                y={padding.top + plotHeight + 20}
                fill="#94a3b8"
                fontSize="10"
                textAnchor="middle"
                fontFamily="monospace"
              >
                {t.label}
              </text>
            </g>
          ))}

          {/* Approximate quantile-style intervals; coverage is not calibrated. */}
          {showConfidence && confidenceLevel === 95 && cone95BandPath && (
            <path
              d={cone95BandPath}
              fill="url(#confidenceGradient95)"
              stroke="#06b6d4"
              strokeWidth="0.5"
              strokeDasharray="2 2"
              strokeOpacity="0.4"
            />
          )}

          {/* 80% / p10-p90 Confidence Ribbon */}
          {showConfidence && confidenceLevel === 80 && outerBandPath && (
            <path
              d={outerBandPath}
              fill="url(#confidenceGradientOuter)"
              stroke="#0891b2"
              strokeWidth="0.75"
              strokeDasharray="3 3"
              strokeOpacity="0.5"
            />
          )}

          {/* Inner Confidence Uncertainty Ribbon (p25 - p75) */}
          {showConfidence && confidenceLevel === 50 && innerBandPath && (
            <path
              d={innerBandPath}
              fill="url(#confidenceGradientInner)"
              stroke="#06b6d4"
              strokeWidth="0.5"
              strokeOpacity="0.6"
            />
          )}

          {/* Historical Series Area */}
          {showArea && historyAreaPath && (
            <path d={historyAreaPath} fill="url(#historyGradient)" />
          )}

          {/* Historical Line */}
          {historyPath && (
            <path
              d={historyPath}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Forecast Line (TimesFM Point Forecast) */}
          {forecastMedianPath && (
            <path
              d={forecastMedianPath}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Forecast Points Dots */}
          {forecasts.map((pt, i) => {
            const idx = history.length + i;
            const x = getX(idx);
            const y = getY(pt.p50);
            if (x < padding.left || x > padding.left + plotWidth) return null;
            return (
              <circle
                key={`fc-${i}`}
                cx={x}
                cy={y}
                r="3"
                fill="#0891b2"
                stroke="#ecfeff"
                strokeWidth="1.5"
              />
            );
          })}

          {/* Forecast Origin Indicator */}
          {originLineX !== null && originLineX >= padding.left && originLineX <= padding.left + plotWidth && (
            <g>
              <line
                x1={originLineX}
                y1={padding.top}
                x2={originLineX}
                y2={padding.top + plotHeight}
                stroke="#06b6d4"
                strokeWidth="1.5"
                strokeDasharray="4 4"
                strokeOpacity="0.8"
              />
              <rect
                x={originLineX - 44}
                y={padding.top - 18}
                width="88"
                height="18"
                rx="4"
                fill="#0f172a"
                stroke="#06b6d4"
                strokeWidth="1"
              />
              <text
                x={originLineX}
                y={padding.top - 6}
                fill="#22d3ee"
                fontSize="10"
                fontWeight="600"
                textAnchor="middle"
              >
                Forecast Origin
              </text>
            </g>
          )}

          {/* News Sentiment Markers (Positive: Emerald, Negative: Rose/Red, Neutral: Amber) */}
          {showNewsSentiment && history.map((pt, i) => {
            if (!pt.newsSentiment) return null;
            const x = getX(i);
            const y = getY(pt.value);
            if (x < padding.left || x > padding.left + plotWidth) return null;

            const { sentiment } = pt.newsSentiment;
            const isPos = sentiment === 'POSITIVE';
            const isNeg = sentiment === 'NEGATIVE';
            const fillColor = isPos ? '#10b981' : isNeg ? '#f43f5e' : '#f59e0b';
            const strokeColor = isPos ? '#ecfdf5' : isNeg ? '#fff1f2' : '#fef3c7';
            const badgeText = isPos ? '+' : isNeg ? '−' : '•';
            const markerY = Math.max(padding.top + 16, y - 13);

            return (
              <g key={`sentiment-marker-${i}`} className="cursor-pointer group">
                {/* Connector Pin Line */}
                <line
                  x1={x}
                  y1={y}
                  x2={x}
                  y2={markerY + 6}
                  stroke={fillColor}
                  strokeWidth="1.2"
                  strokeDasharray="2 2"
                  strokeOpacity="0.7"
                />
                {/* Glow Ring */}
                <circle
                  cx={x}
                  cy={markerY}
                  r="9"
                  fill={fillColor}
                  fillOpacity="0.22"
                />
                {/* Main Sentiment Badge Circle */}
                <circle
                  cx={x}
                  cy={markerY}
                  r="6.5"
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth="1.5"
                  className="transition-transform group-hover:scale-125"
                />
                {/* Sentiment Marker Symbol */}
                <text
                  x={x}
                  y={markerY + 3}
                  fill="#ffffff"
                  fontSize="10"
                  fontWeight="bold"
                  textAnchor="middle"
                  fontFamily="monospace"
                >
                  {badgeText}
                </text>
              </g>
            );
          })}

          {/* Anomalies Points on Historical Line */}
          {showAnomalies && anomalies.map((anom, i) => {
            const x = getX(anom.index);
            const y = getY(anom.actual);
            if (x < padding.left || x > padding.left + plotWidth) return null;
            
            const isCritical = anom.severity === 'critical';
            const isHigh = anom.severity === 'high';
            const color = isCritical ? '#ef4444' : isHigh ? '#f97316' : '#eab308';

            return (
              <g key={`anom-${i}`} className="cursor-pointer">
                {/* Glowing pulse ring */}
                <circle
                  cx={x}
                  cy={y}
                  r="9"
                  fill={color}
                  fillOpacity="0.25"
                  className="animate-ping"
                />
                <circle
                  cx={x}
                  cy={y}
                  r="5"
                  fill={color}
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
              </g>
            );
          })}

          {/* Interactive Crosshair & Hover Tooltip Marker */}
          {hoverIndex && hoverPoint && (() => {
            const globalIdx = hoverIndex.isForecast
              ? history.length + hoverIndex.index
              : hoverIndex.index;
            const x = getX(globalIdx);
            const val = 'p50' in hoverPoint ? hoverPoint.p50 : (hoverPoint as TimeSeriesPoint).value;
            const y = getY(val);

            if (x < padding.left || x > padding.left + plotWidth) return null;

            return (
              <g>
                {/* Vertical tracker */}
                <line
                  x1={x}
                  y1={padding.top}
                  x2={x}
                  y2={padding.top + plotHeight}
                  stroke="#94a3b8"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                  strokeOpacity="0.6"
                />
                {/* Horizontal tracker */}
                <line
                  x1={padding.left}
                  y1={y}
                  x2={padding.left + plotWidth}
                  y2={y}
                  stroke="#94a3b8"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                  strokeOpacity="0.3"
                />
                {/* Active marker dot */}
                <circle
                  cx={x}
                  cy={y}
                  r="6"
                  fill={hoverIndex.isForecast ? "#06b6d4" : "#3b82f6"}
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="shadow-md"
                />
              </g>
            );
          })()}
        </svg>

        {/* Floating Tooltip HTML Overlay */}
        {hoverIndex && hoverPoint && (() => {
          const globalIdx = hoverIndex.isForecast
            ? history.length + hoverIndex.index
            : hoverIndex.index;
          const x = getX(globalIdx);
          const val = 'p50' in hoverPoint ? hoverPoint.p50 : (hoverPoint as TimeSeriesPoint).value;
          const y = getY(val);

          if (x < padding.left || x > padding.left + plotWidth) return null;

          // Align tooltip left or right depending on screen edge
          const isRightHalf = (x - padding.left) / plotWidth > 0.65;

          return (
            <div
              className="absolute pointer-events-none z-20 transition-transform duration-75"
              style={{
                left: `${(x / svgWidth) * 100}%`,
                top: `${(y / svgHeight) * 100}%`,
                transform: `translate(${isRightHalf ? '-108%' : '8%'}, -50%)`
              }}
            >
              <div className="bg-slate-900/95 border border-slate-700 text-white px-3 py-2 rounded-xl shadow-2xl backdrop-blur-md min-w-[200px] text-xs">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1.5">
                  <span className="font-semibold text-slate-300 font-mono">
                    {hoverPoint.timestamp}
                  </span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    hoverIndex.isForecast
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                      : 'bg-blue-950 text-blue-300 border border-blue-800'
                  }`}>
                    {hoverIndex.isForecast ? 'Local forecast estimate' : 'Historical'}
                  </span>
                </div>

                {/* Values */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">
                      {hoverIndex.isForecast ? 'Median (p50):' : 'Observed Value:'}
                    </span>
                    <span className="font-bold text-white font-mono text-sm">
                      {val.toLocaleString()} <span className="text-slate-500 text-[10px]">{unit}</span>
                    </span>
                  </div>

                  {hoverIndex.isForecast && 'p10' in hoverPoint && (
                    <>
                      {(hoverPoint.p025 !== undefined && hoverPoint.p975 !== undefined) && (
                        <div className="flex items-center justify-between text-[11px] text-slate-400 bg-cyan-950/40 px-1.5 py-0.5 rounded border border-cyan-800/40">
                          <span className="text-cyan-300 font-semibold">95% Cone:</span>
                          <span className="font-mono text-cyan-200">
                            {hoverPoint.p025.toLocaleString()} → {hoverPoint.p975.toLocaleString()}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>p10 - p90 Range:</span>
                        <span className="font-mono text-cyan-300">
                          {hoverPoint.p10.toLocaleString()} → {hoverPoint.p90.toLocaleString()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>p25 - p75 Interquartile:</span>
                        <span className="font-mono text-cyan-400/80">
                          {hoverPoint.p25.toLocaleString()} → {hoverPoint.p75.toLocaleString()}
                        </span>
                      </div>
                    </>
                  )}

                  {/* News Sentiment Callout if point has news catalyst */}
                  {!(hoverIndex.isForecast) && (hoverPoint as TimeSeriesPoint).newsSentiment && (
                    <div className={`mt-2 pt-2 border-t rounded-lg p-2 border ${
                      (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'POSITIVE'
                        ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-200'
                        : (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'NEGATIVE'
                          ? 'bg-rose-950/60 border-rose-800/60 text-rose-200'
                          : 'bg-amber-950/60 border-amber-800/60 text-amber-200'
                    }`}>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${
                            (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'POSITIVE'
                              ? 'bg-emerald-400 animate-pulse'
                              : (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'NEGATIVE'
                                ? 'bg-rose-400 animate-pulse'
                                : 'bg-amber-400'
                          }`} />
                          <span className="font-bold text-[11px] text-white">
                            {(hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment} News Catalyst
                          </span>
                        </div>
                        <span className={`px-1.5 py-0.2 rounded font-mono font-bold text-[10px] ${
                          (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'POSITIVE'
                            ? 'bg-emerald-900 text-emerald-200'
                            : (hoverPoint as TimeSeriesPoint).newsSentiment?.sentiment === 'NEGATIVE'
                              ? 'bg-rose-900 text-rose-200'
                              : 'bg-amber-900 text-amber-200'
                        }`}>
                          {((hoverPoint as TimeSeriesPoint).newsSentiment?.score ?? 0) > 0 ? `+${(hoverPoint as TimeSeriesPoint).newsSentiment?.score}` : (hoverPoint as TimeSeriesPoint).newsSentiment?.score}
                        </span>
                      </div>
                      
                      {(hoverPoint as TimeSeriesPoint).newsSentiment?.headline && (
                        <p className="text-[11px] text-slate-200 leading-snug font-medium">
                          "{(hoverPoint as TimeSeriesPoint).newsSentiment?.headline}"
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between text-[9px] text-slate-400 mt-1 pt-1 border-t border-slate-800/60">
                        <span>Category: {(hoverPoint as TimeSeriesPoint).newsSentiment?.category || 'General'}</span>
                        <span>{(hoverPoint as TimeSeriesPoint).newsSentiment?.source}</span>
                      </div>
                    </div>
                  )}

                  {/* Anomaly Callout if point was flagged */}
                  {!(hoverIndex.isForecast) && (hoverPoint as TimeSeriesPoint).isAnomaly && (
                    <div className="mt-1.5 pt-1.5 border-t border-slate-800/80 flex items-center gap-1 text-red-400 font-medium">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>Anomaly detected ({(hoverPoint as TimeSeriesPoint).anomalySeverity || 'breach'})</span>
                    </div>
                  )}

                  {/* Covariates list */}
                  {hoverPoint.covariates && Object.keys(hoverPoint.covariates).length > 0 && (
                    <div className="mt-1.5 pt-1.5 border-t border-slate-800 text-[10px] text-slate-400">
                      <span className="font-semibold text-slate-300 block mb-0.5">Covariates:</span>
                      <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                        {Object.entries(hoverPoint.covariates).map(([k, v]) => (
                          <div key={k} className="flex justify-between">
                            <span className="truncate text-slate-400">{k}:</span>
                            <span className="font-mono text-slate-200">{v}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })()}
      </div>

      {/* Mini Range Slider Brush bar at bottom */}
      <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800/80 flex items-center justify-between gap-4 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span>Range:</span>
          <span className="font-mono text-slate-300">
            {allTimestamps[startIndex]}
          </span>
          <span>→</span>
          <span className="font-mono text-cyan-400">
            {allTimestamps[endIndex]}
          </span>
        </div>

        {/* Dual slider track */}
        <div className="flex-1 max-w-xs flex items-center gap-2">
          <input
            id="slider-zoom-start"
            type="range"
            min="0"
            max="0.8"
            step="0.02"
            value={zoomRange[0]}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              if (val < zoomRange[1] - 0.1) {
                setZoomRange([val, zoomRange[1]]);
              }
            }}
            className="w-full accent-cyan-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
            title="Adjust start window"
          />
          <input
            id="slider-zoom-end"
            type="range"
            min="0.2"
            max="1"
            step="0.02"
            value={zoomRange[1]}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              if (val > zoomRange[0] + 0.1) {
                setZoomRange([zoomRange[0], val]);
              }
            }}
            className="w-full accent-cyan-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
            title="Adjust end window"
          />
        </div>

        <div className="text-[11px] text-slate-500">
          Showing {visibleCount} of {totalPoints} total steps
        </div>
      </div>
    </div>
  );
};
