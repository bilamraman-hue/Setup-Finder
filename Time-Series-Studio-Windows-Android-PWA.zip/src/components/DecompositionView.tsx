import React from 'react';
import { DecompositionResult } from '../types';
import { Layers, Info } from 'lucide-react';

interface DecompositionViewProps {
  decomposition?: DecompositionResult;
  unit?: string;
}

export const DecompositionView: React.FC<DecompositionViewProps> = ({
  decomposition,
  unit = 'Value'
}) => {
  if (!decomposition) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
        <Layers className="w-8 h-8 text-slate-500 mx-auto mb-2" />
        <p className="text-sm">Run a forecast to view Seasonal-Trend STL decomposition.</p>
      </div>
    );
  }

  const { timestamps, observed, trend, seasonal, residual, period } = decomposition;

  // Mini SVG Line Chart Generator
  const renderMiniChart = (data: number[], strokeColor: string, label: string, desc: string) => {
    let min = Math.min(...data);
    let max = Math.max(...data);
    const range = max - min || 1;
    min -= range * 0.05;
    max += range * 0.05;

    const width = 800;
    const height = 120;
    const pad = { top: 12, right: 15, bottom: 20, left: 55 };
    const pw = width - pad.left - pad.right;
    const ph = height - pad.top - pad.bottom;

    let pathD = '';
    data.forEach((val, i) => {
      const x = pad.left + (i / (data.length - 1)) * pw;
      const norm = (val - min) / (max - min || 1);
      const y = pad.top + (1 - norm) * ph;
      pathD += (pathD === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
    });

    return (
      <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white">{label}</span>
            <span className="text-slate-400 text-[11px]">({desc})</span>
          </div>
          <div className="font-mono text-slate-400 text-[11px] space-x-2">
            <span>Min: <strong className="text-slate-200">{Math.round(min * 10) / 10}</strong></span>
            <span>Max: <strong className="text-slate-200">{Math.round(max * 10) / 10}</strong></span>
          </div>
        </div>

        <div className="w-full h-28">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full" preserveAspectRatio="none">
            {/* Horizontal zero reference */}
            <line
              x1={pad.left}
              y1={pad.top + ph / 2}
              x2={pad.left + pw}
              y2={pad.top + ph / 2}
              stroke="#334155"
              strokeWidth="0.5"
              strokeDasharray="4 4"
            />
            {/* Data line */}
            <path
              d={pathD}
              fill="none"
              stroke={strokeColor}
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-5 h-5 text-indigo-400" />
          <div>
            <h3 className="text-sm font-semibold text-white">
              TimesFM Seasonal-Trend & Residual Decomposition
            </h3>
            <p className="text-xs text-slate-400">
              Additive decomposition isolating the underlying structural trajectory, periodic seasonality (period = {period}), and anomalous noise.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {renderMiniChart(observed, '#38bdf8', '1. Observed Raw Series (Y_t)', 'Context inputs to foundation model')}
        {renderMiniChart(trend, '#818cf8', '2. Trend Component (T_t)', 'Long-term structural drift & inertia')}
        {renderMiniChart(seasonal, '#34d399', '3. Seasonal Cyclic Component (S_t)', `Repeating pattern (period = ${period} steps)`)}
        {renderMiniChart(residual, '#f87171', '4. Residual Variance & Shock Component (R_t)', 'Residual error inspected for anomalies')}
      </div>
    </div>
  );
};
