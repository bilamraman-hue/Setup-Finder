import React from 'react';
import { AIAnalysisReport } from '../types';
import { Sparkles, X, TrendingUp, AlertTriangle, ShieldCheck, Lightbulb, Activity, CheckCircle2 } from 'lucide-react';

interface AIAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: AIAnalysisReport | null;
  isLoading: boolean;
  onRegenerate: () => void;
  datasetTitle: string;
}

export const AIAnalysisModal: React.FC<AIAnalysisModalProps> = ({
  isOpen,
  onClose,
  report,
  isLoading,
  onRegenerate,
  datasetTitle
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-indigo-950/40 via-purple-950/40 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-900/60 border border-purple-700/50 flex items-center justify-center text-purple-300 shadow">
              <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Market Analysis Report
              </h2>
              <p className="text-xs text-slate-400">
                Synthesis for {datasetTitle}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto text-xs sm:text-sm">
          {isLoading ? (
            <div className="py-16 text-center space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-purple-950 border border-purple-700/60 flex items-center justify-center mx-auto text-purple-400 animate-bounce">
                <Sparkles className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-white">Synthesizing Foundation Model Forecast...</p>
                <p className="text-xs text-slate-400">
                  Analyzing trend trajectories, quantile bounds, and covariate impacts with Gemini AI.
                </p>
              </div>
            </div>
          ) : report ? (
            <div className="space-y-5">
              {/* Executive Summary Card */}
              <div className="bg-purple-950/30 border border-purple-800/50 rounded-xl p-4 space-y-1.5 shadow-sm">
                <div className="flex items-center gap-2 text-purple-400 font-semibold text-xs uppercase tracking-wider">
                  <Activity className="w-4 h-4" />
                  Executive Summary
                </div>
                <p className="text-slate-200 leading-relaxed text-sm">
                  {report.summary}
                </p>
              </div>

              {/* Tactical Trading Recommendation & Targets if present */}
              {report.tradingRecommendation && (
                <div className="bg-cyan-950/30 border border-cyan-800/50 rounded-xl p-4 space-y-2 shadow-sm">
                  <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    Tactical Trade Strategy & Target Summary
                  </div>
                  <p className="text-slate-200 leading-relaxed text-xs sm:text-sm whitespace-pre-line">
                    {report.tradingRecommendation}
                  </p>
                </div>
              )}

              {/* Grid: Trend Analysis & Outlook */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4" />
                    Structural Drift & Trend
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {report.trendAnalysis}
                  </p>
                </div>

                <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-2">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4" />
                    Predictive Horizon Outlook
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {report.forecastOutlook}
                  </p>
                </div>
              </div>

              {/* Seasonality & Cycles */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-1.5">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Seasonality & Pattern Synchronization
                </h4>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {report.seasonalityAndPatterns}
                </p>
              </div>

              {/* Covariate Drivers */}
              {report.covariateImpacts && report.covariateImpacts.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Covariate Elasticity & Influencing Factors
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {report.covariateImpacts.map((impact, idx) => (
                      <div key={idx} className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg text-xs text-slate-300 flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                        <span>{impact}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Risk Signals & Recommendations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Risks */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    Key Risk Signals & Anomalies
                  </h4>
                  <div className="space-y-2">
                    {report.riskSignals.map((risk, idx) => (
                      <div key={idx} className="bg-red-950/20 border border-red-900/40 p-3 rounded-lg text-xs text-red-200 flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
                        <span>{risk}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recommendations */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4" />
                    Strategic Tactical Actions
                  </h4>
                  <div className="space-y-2">
                    {report.recommendations.map((rec, idx) => (
                      <div key={idx} className="bg-amber-950/20 border border-amber-900/40 p-3 rounded-lg text-xs text-amber-200 flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1.5 shrink-0" />
                        <span>{rec}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-8 text-center text-slate-400">
              No report generated yet. Click "Generate Report" below.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/60">
          <span className="text-[11px] text-slate-500 font-mono">
            Model: Gemini + local statistical forecast baseline
          </span>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-slate-400 hover:text-white text-xs"
            >
              Close
            </button>
            <button
              id="btn-regenerate-ai-report"
              onClick={onRegenerate}
              disabled={isLoading}
              className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md shadow-purple-950/50 border border-purple-400/30 transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-4 h-4 text-white" />
              {report ? 'Re-Analyze' : 'Generate Report'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
