import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Clock3, RefreshCw, Search, ShieldCheck, Trash2, X } from 'lucide-react';
import {
  clearAllSetups,
  formatRemainingTime,
  getActiveSetups,
  formatTimeAgo,
  removeSetup,
  subscribeToSetups,
  type MySetupItem
} from '../lib/mySetupsStore';

interface MySetupsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStock: (symbol: string) => void;
  onOpenFinalVerdict?: (item: MySetupItem) => void;
  onFindSetups?: (reportProgress: (message: string) => void) => Promise<void>;
}

export const MySetupsModal: React.FC<MySetupsModalProps> = ({ isOpen, onClose, onSelectStock, onOpenFinalVerdict, onFindSetups }) => {
  const [setups, setSetups] = useState<MySetupItem[]>([]);
  const [search, setSearch] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [isFinding, setIsFinding] = useState(false);
  const [scanProgress, setScanProgress] = useState('');
  const [scanError, setScanError] = useState('');
  const [expandedSymbol, setExpandedSymbol] = useState<string | null>(null);

  const findSetups = async () => {
    if (!onFindSetups || isFinding) return;
    setIsFinding(true); setScanError(''); setScanProgress('Preparing watchlists…');
    try { await onFindSetups(setScanProgress); refresh(); }
    catch (error) { console.error('Find Setups failed:', error); setScanError('Scan stopped unexpectedly. Check the data connection and retry.'); }
    finally { setIsFinding(false); }
  };

  const refresh = useCallback(() => setSetups(getActiveSetups()), []);
  useEffect(() => {
    if (!isOpen) return;
    refresh();
    const unsubscribe = subscribeToSetups(refresh);
    const timer = window.setInterval(refresh, 30_000);
    return () => { unsubscribe(); window.clearInterval(timer); };
  }, [isOpen, refresh]);

  const filtered = useMemo(() => {
    const q = search.trim().toUpperCase();
    return setups.filter(item => !q || item.symbol.includes(q) || item.name.toUpperCase().includes(q));
  }, [setups, search]);

  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-slate-950/80 p-0 backdrop-blur-sm sm:items-center sm:p-3" role="dialog" aria-modal="true" aria-labelledby="my-setups-title">
      <section className="flex max-h-[92dvh] w-full max-w-4xl flex-col overflow-hidden rounded-t-2xl border border-slate-700 bg-slate-900 shadow-2xl sm:max-h-[90vh] sm:rounded-2xl">
        <header className="flex items-center justify-between gap-3 border-b border-slate-800 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-6 w-6 text-cyan-400" />
            <div>
              <h2 id="my-setups-title" className="font-bold text-white">My Setups <span className="ml-1 rounded-full bg-cyan-950 px-2 py-0.5 text-xs text-cyan-300">{setups.length}</span></h2>
              <p className="text-xs text-slate-400">Grade A/A+ · directional verdict · confluence ≥ 65% · saved on this device</p>
            </div>
          </div>
          <button onClick={onClose} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white" aria-label="Close My Setups"><X className="h-5 w-5" /></button>
        </header>
        <div className="space-y-2 border-b border-slate-800 px-4 py-3 sm:px-6">
          <div className="relative"><Search className="absolute left-3 top-3 h-4 w-4 text-slate-500" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search symbol or name" className="min-h-11 w-full rounded-xl border border-slate-700 bg-slate-950 py-2 pl-9 pr-3 text-sm text-white outline-none focus:border-cyan-600" /></div>
          <div className="flex flex-wrap gap-2">
            {onFindSetups && <button onClick={findSetups} disabled={isFinding} className="min-h-11 flex-1 rounded-xl bg-cyan-700 px-3 py-2 text-xs font-bold text-white hover:bg-cyan-600 disabled:opacity-60"><RefreshCw className={`mr-1 inline h-4 w-4 ${isFinding ? 'animate-spin' : ''}`} />{isFinding ? 'Scanning…' : 'Find Setups'}</button>}
            <button onClick={refresh} disabled={isFinding} className="min-h-11 rounded-xl border border-cyan-800 bg-cyan-950/50 px-3 py-2 text-xs font-semibold text-cyan-300 hover:bg-cyan-900/50 disabled:opacity-50"><RefreshCw className="mr-1 inline h-4 w-4" />Refresh</button>
            {setups.length > 0 && (confirmClear ? <><button disabled={isFinding} onClick={() => { clearAllSetups(); refresh(); setConfirmClear(false); }} className="min-h-11 rounded-xl bg-rose-900 px-3 py-2 text-xs text-white disabled:opacity-50">Confirm</button><button disabled={isFinding} onClick={() => setConfirmClear(false)} className="min-h-11 rounded-xl border border-slate-700 px-3 py-2 text-xs text-slate-300 disabled:opacity-50">Cancel</button></> : <button disabled={isFinding} onClick={() => setConfirmClear(true)} className="flex min-h-11 min-w-11 items-center justify-center rounded-xl border border-slate-700 px-3 text-slate-400 hover:text-rose-300 disabled:opacity-50" title="Clear all setups"><Trash2 className="h-4 w-4" /></button>)}
          </div>
        </div>
        {(scanProgress || scanError) && <div className={`border-b border-slate-800 px-4 py-2 text-xs ${scanError ? 'text-rose-300' : 'text-cyan-300'}`} aria-live="polite">{scanError || scanProgress}</div>}
        <div className="min-h-0 overflow-y-auto p-3 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:p-6">
          {filtered.length === 0 ? <div className="rounded-xl border border-dashed border-slate-700 p-8 text-center text-sm text-slate-400">{setups.length ? 'No setups match this search.' : 'No saved A/A+ setups yet. Tap Find Setups to scan every watchlist with fresh timeframe data.'}</div> : <div className="grid gap-3 sm:grid-cols-2">
            {filtered.map(item => {
              const expiry = formatRemainingTime(item.expiresAt);
              return <article key={item.id} className="rounded-xl border border-slate-700 bg-slate-950/70 p-4">
                <div className="flex items-start justify-between gap-3">
                  <button className="min-w-0 text-left" onClick={() => { onSelectStock(item.symbol); onClose(); }}><div className="truncate font-bold text-white">{item.symbol} <span className="text-xs text-slate-400">{item.exchange}</span></div><div className="truncate text-xs text-slate-400">{item.name}</div></button>
                  <span className={`shrink-0 rounded-md border px-2 py-1 text-[10px] font-bold ${item.direction === 'LONG' ? 'border-emerald-800 bg-emerald-950 text-emerald-300' : 'border-rose-800 bg-rose-950 text-rose-300'}`}>{item.gradeBadge || item.setupGrade}</span>
                </div>
                <div className="mt-3 space-y-2">
                  <h3 className="text-[11px] font-bold uppercase tracking-wide text-slate-500">Separate timeframe setups</h3>
                  {item.activeTimeframeList.map(tf => {
                    const q = item.timeframes?.[tf];
                    if (!q) return null;
                    const bullish = q.direction === 'LONG';
                    const analysis = q.analysis;
                    const flow = analysis?.marketFlow;
                    return <section key={tf} className="rounded-lg border border-slate-800 bg-slate-900/80 p-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-2"><span className="rounded bg-cyan-950 px-2 py-1 text-xs font-bold text-cyan-200">{tf}</span><span className={`text-xs font-bold ${bullish ? 'text-emerald-300' : 'text-rose-300'}`}>{q.direction} · {q.finalVerdict}</span></div>
                        <span className="text-xs font-bold text-white">{q.gradeBadge || q.setupGrade} · Setup {Math.round(q.scorePct)}% · Confluence {Math.round(q.confluenceScorePct)}%</span>
                      </div>
                      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-slate-400 sm:grid-cols-3">
                        <span>Entry <b className="text-slate-200">{q.entryRange.text}</b></span>
                        <span>Stop <b className="text-rose-200">₹{q.stopLoss.price.toFixed(2)}</b></span>
                        <span>Target 1 <b className="text-emerald-200">₹{q.target1.price.toFixed(2)}</b></span>
                        <span>Target 2 <b className="text-emerald-200">₹{q.target2.price.toFixed(2)}</b></span>
                        <span>Risk/reward <b className="text-slate-200">{q.riskRewardText}</b></span>
                        <span>Qualified <b className="text-slate-200">{formatTimeAgo(q.qualifiedAt)}</b></span>
                      </div>
                      {(analysis?.coreDriver || analysis?.actionTrigger) && <p className="mt-2 text-[11px] text-slate-400">Setup: <b className="text-slate-200">{analysis.coreDriver || 'Price action'}</b>{analysis.actionTrigger ? ` · Trigger: ${analysis.actionTrigger}` : ''}</p>}
                      {expandedSymbol === item.symbol && <div className="mt-3 space-y-2 border-t border-slate-800 pt-3 text-[11px]">
                        <div className="grid grid-cols-2 gap-2 text-slate-400"><span>CMP <b className="text-slate-200">₹{Number(analysis?.cmp ?? item.cmp).toFixed(2)}</b></span><span>Status <b className="text-slate-200">{q.status}</b></span><span>Entry range <b className="text-slate-200">₹{q.entryRange.min.toFixed(2)}–₹{q.entryRange.max.toFixed(2)}</b></span><span>Stop distance <b className="text-slate-200">{q.stopLoss.pct.toFixed(2)}%</b></span><span>Target 1 move <b className="text-slate-200">{q.target1.pct.toFixed(2)}%</b></span><span>Target 2 move <b className="text-slate-200">{q.target2.pct.toFixed(2)}%</b></span></div>
                        <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-cyan-300">Price/volume buildup:</b> {flow?.syntheticBuildup?.detail || 'Unavailable for this timeframe scan.'}</div>
                        <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-amber-300">Trap check:</b> {flow?.trapRisk?.detail || 'Unavailable for this timeframe scan.'}</div>
                        <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-indigo-300">Volume:</b> {flow?.volumeSpike?.detail || analysis?.volumeSpike?.detail || 'Volume spike data unavailable.'}</div>
                        <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-purple-300">Live OI:</b> {flow?.optionChainOi?.available ? flow.optionChainOi.detail : flow?.futuresOi?.available ? flow.futuresOi.detail : 'No verified live OI signal was available; OI was not inferred from price/volume.'}</div>
                        {analysis?.quantEngineResult && <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-cyan-300">Quant:</b> {analysis.quantEngineResult.signalSummary} · CPR {analysis.quantEngineResult.cprRelation} (pivot {analysis.quantEngineResult.cprPivot.toFixed(2)}, top {analysis.quantEngineResult.cprTop.toFixed(2)}, bottom {analysis.quantEngineResult.cprBottom.toFixed(2)}) · RSI {analysis.quantEngineResult.rsi14} · ATR {analysis.quantEngineResult.atrValue?.toFixed(2) ?? 'n/a'} · Volume POC/VAH/VAL {analysis.quantEngineResult.volumeProfilePoc.toFixed(2)}/{analysis.quantEngineResult.volumeProfileVah.toFixed(2)}/{analysis.quantEngineResult.volumeProfileVal.toFixed(2)}</div>}
                        {analysis?.smcIctResult && <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-cyan-300">Structure:</b> {analysis.smcIctResult.signalSummary} · {analysis.smcIctResult.marketStructure} · FVG {analysis.smcIctResult.fvgStatus} [{analysis.smcIctResult.fvgZone[0].toFixed(2)}–{analysis.smcIctResult.fvgZone[1].toFixed(2)}] · Bullish/Bearish OB {analysis.smcIctResult.bullishOrderBlock.toFixed(2)}/{analysis.smcIctResult.bearishOrderBlock.toFixed(2)} · SSL/BSL swept {analysis.smcIctResult.sslSwept ? 'yes' : 'no'}/{analysis.smcIctResult.bslSwept ? 'yes' : 'no'}</div>}
                        {analysis?.timesfmResult && <div className="rounded-md bg-slate-950 p-2 text-slate-300"><b className="text-cyan-300">Forecast context:</b> {analysis.timesfmResult.signalSummary}</div>}
                        <p className="text-slate-500">Timeframe weight: {analysis?.verdictWeights ? `PA ${analysis.verdictWeights.priceAction} · Volume ${analysis.verdictWeights.volume} · buildup ${analysis.verdictWeights.syntheticMatrix} · OI ${analysis.verdictWeights.liveOi}` : 'not stored for this older setup'} · {formatRemainingTime(q.expiresAt).text}</p>
                      </div>}
                    </section>;
                  })}
                </div>
                {item.scanChanges?.length ? <div className="mt-2 rounded-lg border border-amber-900/60 bg-amber-950/30 p-2 text-[10px] text-amber-200"><b>Recent scan changes:</b> {item.scanChanges.slice(0, 3).map(change => `${change.timeframe}: ${change.description} (${formatTimeAgo(change.detectedAt)})`).join(' · ')}</div> : null}
                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800 pt-2"><span className="flex items-center gap-1 text-[11px] text-slate-500"><Clock3 className="h-3.5 w-3.5" />Expires {expiry.text}</span><div className="flex gap-2"><button onClick={() => setExpandedSymbol(expandedSymbol === item.symbol ? null : item.symbol)} className="min-h-10 rounded-lg border border-cyan-800 px-3 py-1 text-[11px] text-cyan-300 hover:bg-cyan-950/50">{expandedSymbol === item.symbol ? 'Hide report' : 'Open report'}</button><button onClick={() => { onSelectStock(item.symbol); onClose(); }} className="min-h-10 rounded-lg border border-slate-700 px-3 py-1 text-[11px] text-slate-300 hover:bg-slate-800">Chart</button>{onOpenFinalVerdict && <button onClick={() => onOpenFinalVerdict(item)} className="min-h-10 rounded-lg border border-cyan-800 px-3 py-1 text-[11px] text-cyan-300 hover:bg-cyan-950/50">Verdict</button>}<button onClick={() => { removeSetup(item.symbol); refresh(); }} className="flex min-h-10 min-w-10 items-center justify-center rounded-lg text-slate-500 hover:text-rose-300" title="Remove"><Trash2 className="h-4 w-4" /></button></div></div>
              </article>;
            })}
          </div>}
        </div>
      </section>
    </div>
  );
};
