import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  ArrowUpRight, 
  ArrowDownRight, 
  CheckCircle2, 
  AlertCircle, 
  RotateCcw, 
  Play, 
  Clock, 
  ShieldCheck, 
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { 
  PaperPortfolio, 
  VirtualPosition, 
  getPaperPortfolio, 
  openVirtualTrade, 
  closeVirtualTrade, 
  resetPaperPortfolio 
} from '../lib/paperTradingStore';
import { QuantSetupReport } from '../lib/quantSetupEngine';

interface PaperTradingModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSetup?: QuantSetupReport | null;
  currencySymbol?: string;
}

export const PaperTradingModal: React.FC<PaperTradingModalProps> = ({
  isOpen,
  onClose,
  activeSetup,
  currencySymbol = '₹'
}) => {
  const [portfolio, setPortfolio] = useState<PaperPortfolio>(() => getPaperPortfolio());
  const [tradeQuantity, setTradeQuantity] = useState<number>(() => {
    return activeSetup?.positionSizing?.recommendedQuantity || 50;
  });
  const [orderExecutedBanner, setOrderExecutedBanner] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setPortfolio(getPaperPortfolio());
      if (activeSetup?.positionSizing?.recommendedQuantity) {
        setTradeQuantity(activeSetup.positionSizing.recommendedQuantity);
      }
    }
  }, [isOpen, activeSetup]);

  if (!isOpen) return null;

  // Portfolio KPIs
  const investedAmount = portfolio.positions.reduce((acc, p) => acc + p.entryPrice * p.quantity, 0);
  const totalUnrealizedPnl = portfolio.positions.reduce((acc, p) => acc + p.pnl, 0);
  const totalRealizedPnl = portfolio.closedTrades.reduce((acc, p) => acc + p.pnl, 0);
  const portfolioEquity = portfolio.virtualCash + investedAmount + totalUnrealizedPnl;
  const totalPnl = portfolioEquity - portfolio.initialCash;
  const totalPnlPct = (totalPnl / portfolio.initialCash) * 100;

  const totalTradesCount = portfolio.closedTrades.length;
  const winningTrades = portfolio.closedTrades.filter(t => t.pnl > 0).length;
  const winRatePct = totalTradesCount > 0 ? Math.round((winningTrades / totalTradesCount) * 100) : 0;

  const handleExecuteActiveSetup = () => {
    if (!activeSetup) return;

    const isLong = activeSetup.direction === 'LONG' || activeSetup.direction === 'REVERSAL (Bounceback)';
    const pos = openVirtualTrade({
      symbol: activeSetup.symbol,
      name: activeSetup.name,
      direction: isLong ? 'LONG' : 'SHORT',
      entryPrice: activeSetup.cmp,
      quantity: Math.max(1, tradeQuantity),
      stopLoss: activeSetup.stopLoss.price,
      target1: activeSetup.target1.price,
      target2: activeSetup.target2.price,
      score: activeSetup.scorePct
    });

    if (pos) {
      setPortfolio(getPaperPortfolio());
      setOrderExecutedBanner(`Order executed! Bought ${pos.quantity} qty of ${pos.symbol} at ${currencySymbol}${pos.entryPrice}`);
      setTimeout(() => setOrderExecutedBanner(null), 4000);
    } else {
      alert('Insufficient virtual cash to execute this order.');
    }
  };

  const handleCloseTrade = (id: string) => {
    const updated = closeVirtualTrade(id);
    setPortfolio(updated);
  };

  const handleReset = () => {
    if (confirm('Reset paper portfolio back to initial ₹10,00,000 cash balance?')) {
      const fresh = resetPaperPortfolio();
      setPortfolio(fresh);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-b border-slate-700/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                Institutional Virtual Paper Trading Simulator
              </h3>
              <p className="text-[11px] text-slate-400">
                1-Click Execution • Real-Time P&L • Zero-Risk Prop Desk Practice
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer text-xs flex items-center gap-1"
              title="Reset Portfolio"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Reset</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs sm:text-sm">
          
          {/* Banner notification */}
          {orderExecutedBanner && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-200 rounded-xl flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="text-xs font-semibold">{orderExecutedBanner}</span>
            </div>
          )}

          {/* Portfolio Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl">
              <div className="text-[11px] text-slate-400 font-mono">Portfolio Equity</div>
              <div className="text-base sm:text-lg font-black text-white mt-0.5">
                {currencySymbol}{Math.round(portfolioEquity).toLocaleString()}
              </div>
              <div className={`text-[10px] font-mono mt-0.5 flex items-center gap-0.5 ${totalPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {totalPnl >= 0 ? '+' : ''}{currencySymbol}{Math.round(totalPnl).toLocaleString()} ({totalPnlPct.toFixed(2)}%)
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl">
              <div className="text-[11px] text-slate-400 font-mono">Available Cash</div>
              <div className="text-base sm:text-lg font-black text-cyan-400 mt-0.5">
                {currencySymbol}{Math.round(portfolio.virtualCash).toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                Invested: {currencySymbol}{Math.round(investedAmount).toLocaleString()}
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl">
              <div className="text-[11px] text-slate-400 font-mono">Unrealized P&L</div>
              <div className={`text-base sm:text-lg font-black mt-0.5 ${totalUnrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {totalUnrealizedPnl >= 0 ? '+' : ''}{currencySymbol}{Math.round(totalUnrealizedPnl).toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                Open Trades: {portfolio.positions.length}
              </div>
            </div>

            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl">
              <div className="text-[11px] text-slate-400 font-mono">Win Rate (Realized)</div>
              <div className="text-base sm:text-lg font-black text-indigo-300 mt-0.5">
                {winRatePct}%
              </div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                {winningTrades}/{totalTradesCount} Profitable Trades
              </div>
            </div>
          </div>

          {/* Active Setup Execution Bar */}
          {activeSetup && (
            <div className="p-4 bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/50 border border-indigo-500/40 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Execute Active Setup: {activeSetup.symbol} ({activeSetup.direction})
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                    Score: {activeSetup.scorePct}%
                  </span>
                </div>
                <span className="text-xs font-mono font-bold text-white">
                  CMP: {currencySymbol}{activeSetup.cmp}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono text-slate-300 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                <div>Entry: <strong className="text-white">{currencySymbol}{activeSetup.cmp}</strong></div>
                <div>SL: <strong className="text-rose-400">{currencySymbol}{activeSetup.stopLoss.price}</strong></div>
                <div>T1: <strong className="text-emerald-400">{currencySymbol}{activeSetup.target1.price}</strong></div>
                <div>T2: <strong className="text-emerald-300">{currencySymbol}{activeSetup.target2.price}</strong></div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-slate-400">Quantity:</label>
                  <input
                    type="number"
                    min="1"
                    value={tradeQuantity}
                    onChange={(e) => setTradeQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-24 px-2 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-white text-center focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <button
                  onClick={handleExecuteActiveSetup}
                  className="flex-1 py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs transition shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Execute Virtual Trade ({currencySymbol}{(activeSetup.cmp * tradeQuantity).toLocaleString()})</span>
                </button>
              </div>
            </div>
          )}

          {/* Open Positions Section */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <span>Active Virtual Positions ({portfolio.positions.length})</span>
            </h4>

            {portfolio.positions.length === 0 ? (
              <div className="p-6 bg-slate-950/50 border border-slate-800/80 rounded-xl text-center text-slate-500 text-xs">
                No open positions. Click "Execute Virtual Trade" above or from any quant setup to simulate a position.
              </div>
            ) : (
              <div className="space-y-2">
                {portfolio.positions.map((pos) => {
                  const isPositive = pos.pnl >= 0;
                  return (
                    <div 
                      key={pos.id} 
                      className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <span className={`px-2 py-1 rounded text-[10px] font-mono font-bold ${
                          pos.direction === 'LONG' 
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        }`}>
                          {pos.direction}
                        </span>
                        <div>
                          <div className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
                            <span>{pos.symbol}</span>
                            <span className="text-[11px] font-normal text-slate-400">({pos.quantity} Qty)</span>
                          </div>
                          <div className="text-[10px] font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                            <span>Entry: {currencySymbol}{pos.entryPrice}</span>
                            <span>•</span>
                            <span>CMP: {currencySymbol}{pos.currentPrice}</span>
                            <span>•</span>
                            <span>SL: {currencySymbol}{pos.stopLoss}</span>
                            <span>•</span>
                            <span>T1: {currencySymbol}{pos.target1}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-4">
                        <div className="text-right">
                          <div className={`font-mono font-bold text-xs sm:text-sm ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isPositive ? '+' : ''}{currencySymbol}{Math.round(pos.pnl).toLocaleString()}
                          </div>
                          <div className={`text-[10px] font-mono ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {isPositive ? '+' : ''}{pos.pnlPct.toFixed(2)}%
                          </div>
                        </div>

                        <button
                          onClick={() => handleCloseTrade(pos.id)}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition cursor-pointer"
                        >
                          Exit Trade
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Closed Trades History */}
          {portfolio.closedTrades.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Closed Trades History ({portfolio.closedTrades.length})
              </h4>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {portfolio.closedTrades.slice(0, 8).map((trade) => {
                  const isProfit = trade.pnl > 0;
                  return (
                    <div 
                      key={trade.id} 
                      className="p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-lg flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span className={`w-1.5 h-1.5 rounded-full ${isProfit ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                        <span className="font-bold text-white">{trade.symbol}</span>
                        <span className="text-[10px] text-slate-400 font-mono">({trade.direction})</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                          {trade.status.replace('_', ' ')}
                        </span>
                      </div>
                      <div className={`font-mono font-bold ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isProfit ? '+' : ''}{currencySymbol}{Math.round(trade.pnl).toLocaleString()} ({trade.pnlPct.toFixed(2)}%)
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
