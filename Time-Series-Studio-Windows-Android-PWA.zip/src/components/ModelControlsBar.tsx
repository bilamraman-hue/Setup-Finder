import React from 'react';
import { ModelConfig, FrequencyType, StrategyHorizon, BaseTimeframe } from '../types';
import { Sliders, Cpu, Gauge, Zap, CheckCircle2, ShieldAlert, Layers, Clock, Sparkles } from 'lucide-react';

interface ModelControlsBarProps {
  config: ModelConfig;
  onChange: (updates: Partial<ModelConfig>) => void;
  hasCovariates: boolean;
  historyLength: number;
  onOpenPreprocessor?: () => void;
}

export const ModelControlsBar: React.FC<ModelControlsBarProps> = ({
  config,
  onChange,
  hasCovariates,
  historyLength,
  onOpenPreprocessor
}) => {
  const currentStrategy = config.strategyHorizon || 'Intraday (1D)';
  const currentTimeframe = config.baseTimeframe || '5m';

  const handleStrategySelect = (strat: StrategyHorizon) => {
    let tf: BaseTimeframe = '5m';
    let h = 32;
    let l = Math.max(512, historyLength);

    if (strat === 'Intraday (1D)') {
      tf = '15m';
      h = 32;
      l = Math.max(512, historyLength);
    } else if (strat === 'Swing (3-5D)') {
      tf = '1h';
      h = 32;
      l = Math.max(512, historyLength);
    } else if (strat === 'Positional (1-2M)') {
      tf = '1D';
      h = 32;
      l = Math.max(512, historyLength);
    }

    onChange({
      strategyHorizon: strat,
      baseTimeframe: tf,
      horizon: h,
      contextLength: l,
      patchLength: 32,
      confidenceLevel: 95
    });
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg space-y-4">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-semibold text-white">
            Forecast settings & input data
          </h2>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <Cpu className="w-3.5 h-3.5 text-indigo-400" />
            <strong className="text-slate-200">
              Local statistical baseline
            </strong>
          </span>
          <span>•</span>
          <span className="flex items-center gap-1 text-emerald-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" />
            RevIN Active
          </span>
          <span>•</span>
          {onOpenPreprocessor && (
            <button
              onClick={onOpenPreprocessor}
              className="px-2.5 py-1 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-700/60 font-semibold text-[11px] flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              title="Open Preprocessing & Tensor Alignment Inspector (L mod 32 == 0, Gap Removal, 5*ATR Outlier Smoothing, RevIN)"
            >
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              <span>Data Alignment & Tensor</span>
              <span className="bg-cyan-500/20 text-cyan-200 px-1 rounded text-[9px] font-mono">
                L={config.contextLength}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* Input Parameters Quick Row: Strategy Horizon & Base Timeframe */}
      <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span className="text-slate-400 font-semibold">Strategy Horizon:</span>
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            {(['Intraday (1D)', 'Swing (3-5D)', 'Positional (1-2M)'] as StrategyHorizon[]).map((strat) => (
              <button
                key={strat}
                onClick={() => handleStrategySelect(strat)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all cursor-pointer ${
                  currentStrategy === strat
                    ? 'bg-cyan-600 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {strat}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-semibold">Base Timeframe:</span>
          <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            {(['5m', '15m', '1h', '1D'] as BaseTimeframe[]).map((tf) => (
              <button
                key={tf}
                onClick={() => onChange({ baseTimeframe: tf })}
                className={`px-2 py-1 rounded-md text-[11px] font-mono font-medium transition-all cursor-pointer ${
                  currentTimeframe === tf
                    ? 'bg-indigo-600 text-white font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
          <span className="text-[10px] text-slate-500 font-mono hidden md:inline">
            Patch Size: 32 (L mod 32 == 0)
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        {/* 1. Forecast Horizon Slider */}
        <div className="space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
          <div className="flex justify-between items-center">
            <label htmlFor="input-horizon" className="text-slate-300 font-medium flex items-center gap-1">
              <span>Forecast Horizon</span>
            </label>
            <span className="font-mono text-cyan-400 font-bold bg-cyan-950/70 border border-cyan-800/50 px-2 py-0.5 rounded">
              {config.horizon} steps
            </span>
          </div>
          <input
            id="input-horizon"
            type="range"
            min="6"
            max="128"
            step="2"
            value={config.horizon}
            onChange={(e) => onChange({ horizon: parseInt(e.target.value, 10) })}
            className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>6 steps</span>
            <span>64 steps</span>
            <span>128 steps</span>
          </div>
        </div>

        {/* 2. Context Window (History Length) aligned with Patch Size = 32 */}
        <div className="space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
          <div className="flex justify-between items-center">
            <label htmlFor="input-context" className="text-slate-300 font-medium">
              Context Length (Max Input)
            </label>
            <span className="font-mono text-indigo-400 font-bold bg-indigo-950/70 border border-indigo-800/50 px-2 py-0.5 rounded text-[11px]">
              {Math.min(config.contextLength, historyLength || config.contextLength)} pts ({Math.floor(Math.min(config.contextLength, historyLength || config.contextLength) / 32)} patches)
            </span>
          </div>
          <input
            id="input-context"
            type="range"
            min="32"
            max="1024"
            step="32"
            value={config.contextLength}
            onChange={(e) => {
              const val = parseInt(e.target.value, 10);
              const aligned = val - (val % 32);
              onChange({ contextLength: Math.max(32, aligned) });
            }}
            className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>32</span>
            <span>256</span>
            <span>512</span>
            <span className="text-indigo-400 font-semibold">1024 (Max)</span>
          </div>
        </div>

        {/* 3. Frequency & Confidence Level */}
        <div className="space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
          <div className="flex justify-between items-center">
            <label htmlFor="select-frequency" className="text-slate-300 font-medium">
              Input time frequency
            </label>
            <span className="text-cyan-400 font-mono text-[10px] font-bold">
              {config.frequencyToken !== undefined ? `Category ${config.frequencyToken}` : (config.frequency === 'hourly' ? 'Hourly' : config.frequency === 'daily' ? 'Daily' : 'Auto')}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <select
              id="select-frequency"
              value={config.frequency}
              onChange={(e) => onChange({ frequency: e.target.value as FrequencyType })}
              className="bg-slate-900 text-slate-200 border border-slate-700 rounded-lg px-2 py-1.5 text-xs focus:ring-1 focus:ring-cyan-500"
            >
              <option value="auto">Auto-detect interval</option>
              <option value="hourly">Hourly / intraday</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>

            <select
              id="select-confidence"
              value={config.confidenceLevel}
              onChange={(e) => onChange({ confidenceLevel: parseInt(e.target.value, 10) as 50 | 80 | 95 })}
              className="bg-slate-900 text-slate-200 border border-slate-700 rounded-lg px-2 py-1.5 text-xs focus:ring-1 focus:ring-cyan-500 font-semibold text-cyan-300"
              title="Select an approximate forecast interval; coverage is not calibrated."
            >
              <option value={95}>Approx. p2.5–p97.5 range</option>
              <option value={80}>Approx. p10–p90 range</option>
              <option value={50}>Approx. p25–p75 range</option>
            </select>
          </div>
        </div>

        {/* 4. CPM Covariates & Anomaly Sensitivity */}
        <div className="space-y-1.5 bg-slate-950/40 p-3 rounded-xl border border-slate-800/80">
          <div className="flex justify-between items-center">
            <label htmlFor="input-anomaly-threshold" className="text-slate-300 font-medium flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>Anomaly Sensitivity</span>
            </label>
            <span className="font-mono text-amber-400 font-bold bg-amber-950/70 border border-amber-800/50 px-2 py-0.5 rounded">
              {config.anomalyThreshold} σ
            </span>
          </div>
          <input
            id="input-anomaly-threshold"
            type="range"
            min="1.5"
            max="4.5"
            step="0.1"
            value={config.anomalyThreshold}
            onChange={(e) => onChange({ anomalyThreshold: parseFloat(e.target.value) })}
            className="w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                id="checkbox-cpm-covariates"
                type="checkbox"
                checked={config.useCovariates && hasCovariates}
                disabled={!hasCovariates}
                onChange={(e) => onChange({ useCovariates: e.target.checked })}
                className="w-3.5 h-3.5 rounded border-slate-700 bg-slate-900 text-cyan-600 focus:ring-cyan-500 disabled:opacity-40"
              />
              <span className={`text-[11px] font-medium ${hasCovariates ? 'text-cyan-300' : 'text-slate-500'}`}>
                Covariates (CPM)
              </span>
            </label>
            <span className="text-[10px] text-slate-500">
              Patch: {config.patchLength}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
