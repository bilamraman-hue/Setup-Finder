import React, { useState, useEffect, useRef } from 'react';
import { StockSummaryReportData, TimeSeriesPoint } from '../types';
import { downloadStockSummaryHtmlReport } from '../lib/htmlReportGenerator';
import { BacktestAccuracyOverlay } from './BacktestAccuracyOverlay';
import { 
  Target, 
  ShieldAlert, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  CheckCircle2, 
  Copy, 
  Check, 
  Flame, 
  Crosshair, 
  Sparkles, 
  ArrowRight, 
  Info, 
  Download, 
  BarChart2, 
  Zap, 
  AlertTriangle, 
  Calendar, 
  Layers, 
  Compass, 
  Lock, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';
import { SeparateReportWindow } from './SeparateReportWindow';
import { VoiceCopilotButton } from './VoiceCopilotButton';

interface StockSummaryReportProps {
  report: StockSummaryReportData;
  onToggleDirection?: (dir: 'BULLISH' | 'BEARISH') => void;
  history?: TimeSeriesPoint[];
  confidenceLevel?: number;
}

export const StockSummaryReport: React.FC<StockSummaryReportProps> = ({
  report,
  onToggleDirection,
  history = [],
  confidenceLevel = 90
}) => {
  const [copied, setCopied] = useState(false);
  const [showBacktest, setShowBacktest] = useState(false);
  const [isSeparateWindowOpen, setIsSeparateWindowOpen] = useState(false);
  const [separateWindowTab, setSeparateWindowTab] = useState<'targets' | 'backtest' | 'split'>('split');
  const [activePlan, setActivePlan] = useState<'BULLISH' | 'BEARISH'>(report.direction === 'BEARISH' ? 'BEARISH' : 'BULLISH');
  
  // High confidence detection
  const isHighConfidence = report.targetOne.probabilityPct !== undefined && report.targetOne.probabilityPct >= 65;

  // Visual notification flashing state
  const [isFlashing, setIsFlashing] = useState(true);
  const [flashKey, setFlashKey] = useState(0);

  useEffect(() => {
    if (isHighConfidence) {
      setIsFlashing(true);
      setFlashKey(k => k + 1);

      const timer = setTimeout(() => {
        setIsFlashing(false);
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [report.lastUpdated, report.currentMarketPrice, confidenceLevel, isHighConfidence]);

  const {
    symbol,
    name,
    currencySymbol,
    currentMarketPrice,
    changePct = 0,
    changeAmount = 0,
    actionRecommendation,
    actionBadgeText,
    actionReason,
    historicalSpan,
    entryGuide,
    targetOne,
    targetTwo,
    targetThree,
    strictStoploss,
    frequency,
    lastUpdated
  } = report;

  const isPositive = changePct >= 0;
  const isBullish = activePlan === 'BULLISH';

  // Format currency with commas in Indian numbering style
  const fmtCurr = (val: number) => {
    return `${currencySymbol}${val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  // Copy full trade plan to clipboard
  const handleCopyPlan = () => {
    const text = `📊 **TIMESFM 3.0 STOCK SUMMARY & TRADE PLAN — ${symbol}** (${name})
📅 Generated: ${new Date().toLocaleDateString('en-IN')} ${lastUpdated}
📈 **Historical Data Used**: ${historicalSpan.durationText} (${historicalSpan.startDate} to ${historicalSpan.endDate}) | ${historicalSpan.frequency}

🎯 **ACTION VERDICT**: ${actionBadgeText}
💡 **Reasoning**: ${actionReason}

1️⃣ **Current Market Price (CMP)**: ${fmtCurr(currentMarketPrice)} (${changePct >= 0 ? '+' : ''}${changePct}%)
2️⃣ **Ideal Entry Range**: ${entryGuide.idealEntryRange} (Aggressive CMP: ${fmtCurr(entryGuide.aggressiveEntry)} | Conservative Dip: ${fmtCurr(entryGuide.conservativePullbackEntry)})
3️⃣ **Target 1 (T1)**: ${fmtCurr(targetOne.targetPrice)} (${targetOne.returnPct >= 0 ? '+' : ''}${targetOne.returnPct}%) ⏱ ${targetOne.timeframeText} | Exit: ${targetOne.exitStrategy || 'Book 50% & SL to Cost'}
4️⃣ **Target 2 (T2)**: ${fmtCurr(targetTwo.targetPrice)} (${targetTwo.returnPct >= 0 ? '+' : ''}${targetTwo.returnPct}%) ⏱ ${targetTwo.timeframeText} | Exit: ${targetTwo.exitStrategy || 'Book 30% & Trail 20 EMA'}
5️⃣ **Target 3 (T3)**: ${fmtCurr(targetThree.targetPrice)} (${targetThree.returnPct >= 0 ? '+' : ''}${targetThree.returnPct}%) ⏱ ${targetThree.timeframeText} | Exit: ${targetThree.exitStrategy || 'Full exit or 1.5 ATR trail'}
🛡 **Strict Stoploss**: ${fmtCurr(strictStoploss.stoplossPrice)} (Risk ${fmtCurr(strictStoploss.riskAmount)} / ${strictStoploss.riskPct}%) | Risk:Reward 1:${strictStoploss.riskRewardRatio}

📋 **Trailing & Discipline**: ${strictStoploss.trailingRule}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handlePlanChange = (dir: 'BULLISH' | 'BEARISH') => {
    setActivePlan(dir);
    if (onToggleDirection) {
      onToggleDirection(dir);
    }
  };

  // Action verdict styles
  const getActionVerdictStyle = () => {
    switch (actionRecommendation) {
      case 'TRADE_NOW':
        return {
          bg: 'bg-emerald-950/90',
          border: 'border-emerald-500/70',
          text: 'text-emerald-300',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/50',
          icon: Zap,
          glow: 'ring-emerald-500/30'
        };
      case 'WAIT_FOR_DIP':
        return {
          bg: 'bg-amber-950/90',
          border: 'border-amber-500/70',
          text: 'text-amber-300',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-400/50',
          icon: Clock,
          glow: 'ring-amber-500/30'
        };
      case 'WAIT_FOR_BREAKOUT':
        return {
          bg: 'bg-cyan-950/90',
          border: 'border-cyan-500/70',
          text: 'text-cyan-300',
          badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50',
          icon: Compass,
          glow: 'ring-cyan-500/30'
        };
      case 'AVOID_HIGH_RISK':
      default:
        return {
          bg: 'bg-rose-950/90',
          border: 'border-rose-500/70',
          text: 'text-rose-300',
          badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-400/50',
          icon: AlertTriangle,
          glow: 'ring-rose-500/30'
        };
    }
  };

  const actionStyle = getActionVerdictStyle();
  const ActionIcon = actionStyle.icon;

  // Calculate visual progress along the ladder
  const minVal = Math.min(strictStoploss.stoplossPrice, currentMarketPrice * 0.9);
  const maxVal = Math.max(targetThree.targetPrice, currentMarketPrice * 1.2);
  const range = Math.max(1, maxVal - minVal);
  const cmpPct = Math.min(95, Math.max(5, ((currentMarketPrice - minVal) / range) * 100));
  const slPct = Math.min(95, Math.max(5, ((strictStoploss.stoplossPrice - minVal) / range) * 100));

  return (
    <div id="stock-summary-report-card" className="bg-slate-900/95 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-5 relative overflow-hidden backdrop-blur-md">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800 relative z-10">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700/60 text-cyan-400 text-[11px] font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              Quantitative Forecast Summary & Price Targets
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              Updated {lastUpdated}
            </span>
          </div>

          <div className="mt-1.5 flex items-center gap-2.5 flex-wrap">
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{name}</span>
              <span className="text-sm px-2.5 py-0.5 rounded-md bg-slate-950 text-cyan-300 font-mono border border-slate-700">
                {symbol}
              </span>
            </h2>
          </div>
        </div>

        {/* Action buttons: Plan switch & Copy button */}
        <div className="flex items-center gap-2 self-start md:self-auto flex-wrap">
          {/* Plan direction toggle */}
          <div className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              type="button"
              onClick={() => handlePlanChange('BULLISH')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                activePlan === 'BULLISH'
                  ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span>Bullish Long</span>
            </button>
            <button
              type="button"
              onClick={() => handlePlanChange('BEARISH')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                activePlan === 'BEARISH'
                  ? 'bg-rose-600/30 text-rose-300 border border-rose-500/50 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
              <span>Bearish Short</span>
            </button>
          </div>

          {/* Voice Copilot Audio Briefing */}
          <VoiceCopilotButton
            symbol={report.symbol}
            name={report.name}
            cmp={report.currentMarketPrice}
            direction={activePlan}
            grade="Grade A+"
            confluenceScore={88}
            entryZoneMin={report.entryGuide.idealEntryMin || report.currentMarketPrice * 0.995}
            entryZoneMax={report.entryGuide.idealEntryMax || report.currentMarketPrice * 1.003}
            target1={report.targetOne.targetPrice}
            stopLoss={report.strictStoploss.stoplossPrice}
            currencySymbol={report.currencySymbol}
          />

          {/* Copy Report Button */}
          <button
            type="button"
            onClick={handleCopyPlan}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-700 shadow-sm transition active:scale-95"
            title="Copy formatted summary and price targets"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300 font-mono">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-300" />
                <span>Copy</span>
              </>
            )}
          </button>

          {/* View Backtest Accuracy Button */}
          <button
            type="button"
            onClick={() => setShowBacktest(!showBacktest)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border shadow-sm transition active:scale-95 cursor-pointer ${
              showBacktest
                ? 'bg-gradient-to-r from-emerald-600 to-cyan-600 text-white border-emerald-400 shadow-md shadow-emerald-950/60'
                : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-slate-700'
            }`}
            title="Toggle previous trade signals and backtest accuracy chart"
          >
            <BarChart2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showBacktest ? 'Hide Backtest' : 'Backtest'}</span>
          </button>

          {/* Separate Window Button */}
          <button
            type="button"
            onClick={() => {
              setSeparateWindowTab(showBacktest ? 'backtest' : 'split');
              setIsSeparateWindowOpen(true);
            }}
            className="px-3 py-2 bg-gradient-to-r from-cyan-950 via-slate-800 to-indigo-950 hover:from-cyan-900 hover:to-indigo-900 text-cyan-300 font-semibold rounded-xl text-xs flex items-center gap-1.5 border border-cyan-500/50 shadow-sm transition active:scale-95 cursor-pointer hover:text-white"
            title="Pop out Targets & Backtest into a separate floating window"
          >
            <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
            <span>Pop Out</span>
          </button>

          {/* Download HTML Report File Button */}
          <button
            type="button"
            onClick={() => downloadStockSummaryHtmlReport(report)}
            className="px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-cyan-900/30 transition active:scale-95 cursor-pointer"
            title="Download complete standalone HTML report file"
          >
            <Download className="w-3.5 h-3.5" />
            <span>HTML Report</span>
          </button>
        </div>
      </div>

      {/* 1. HISTORICAL DATA USED FOR CALCULATION (Months / Years / Candles Span) */}
      <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-3 sm:p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-cyan-950/80 border border-cyan-800/80 text-cyan-400 shrink-0">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider font-semibold">
              Historical Calculation Dataset Scope
            </div>
            <div className="text-sm font-bold text-white font-mono flex items-center gap-2 mt-0.5">
              <span>{historicalSpan.durationText}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-normal">
                {historicalSpan.frequency}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-slate-300 font-mono text-[11px] border-t md:border-t-0 pt-2 md:pt-0 border-slate-800 flex-wrap">
          <div>
            <span className="text-slate-500">Date Range: </span>
            <strong className="text-slate-200">{historicalSpan.startDate} → {historicalSpan.endDate}</strong>
          </div>
          <div className="h-3 w-px bg-slate-800 hidden sm:block" />
          <div>
            <span className="text-slate-500">Sample Count: </span>
            <strong className="text-cyan-400">{historicalSpan.totalCandles} Candles</strong>
          </div>
        </div>
      </div>

      {/* 5. ACTION VERDICT: TRADE NOW / WAIT FOR DIP / WAIT FOR BREAKOUT / AVOID */}
      <div className={`p-4 rounded-xl border ${actionStyle.border} ${actionStyle.bg} shadow-lg relative z-10 ring-1 ${actionStyle.glow}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-lg bg-black/40 border border-white/10 ${actionStyle.text}`}>
              <ActionIcon className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">
                Trade Timing & Execution Verdict
              </span>
              <span className={`text-base sm:text-lg font-black tracking-tight font-mono ${actionStyle.text}`}>
                {actionBadgeText}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto font-mono text-xs">
            <span className="px-2.5 py-1 rounded-md bg-black/50 border border-white/10 text-white font-bold">
              Risk:Reward = 1 : {strictStoploss.riskRewardRatio}
            </span>
            <span className="px-2.5 py-1 rounded-md bg-black/50 border border-white/10 text-cyan-300 font-bold">
              {targetOne.probabilityPct !== undefined ? `${targetOne.probabilityPct}% Probability` : 'Probability not calibrated'}
            </span>
          </div>
        </div>

        <div className="mt-2.5 text-xs text-slate-200 leading-relaxed font-sans">
          <strong className="text-white">Quantitative Verdict: </strong>
          {actionReason}
        </div>
      </div>

      {/* 3. PERFECT ENTRY LEVELS CARD */}
      <div className="bg-slate-950/90 border border-cyan-500/30 rounded-xl p-4 space-y-3 relative z-10 shadow-lg">
        <div className="flex items-center justify-between text-xs text-cyan-400 font-bold uppercase tracking-wider">
          <span className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            3. Recommended Entry Levels & Buying Zones
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-300 font-mono">
            Optimized Execution
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* Ideal Buy Range */}
          <div className="bg-slate-900/90 p-3 rounded-lg border border-cyan-500/40">
            <div className="text-[10px] text-cyan-300 font-mono uppercase font-semibold">
              🎯 Ideal Entry Zone (Accumulation)
            </div>
            <div className="text-base sm:text-lg font-black font-mono text-cyan-400 mt-1">
              {entryGuide.idealEntryRange}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Optimal risk-mitigated entry corridor.
            </div>
          </div>

          {/* Aggressive Entry */}
          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-[10px] text-emerald-400 font-mono uppercase font-semibold">
              ⚡ Aggressive Entry (CMP Market)
            </div>
            <div className="text-base sm:text-lg font-black font-mono text-white mt-1">
              {fmtCurr(entryGuide.aggressiveEntry)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Execute immediate market buy / short order.
            </div>
          </div>

          {/* Conservative Dip Entry */}
          <div className="bg-slate-900/90 p-3 rounded-lg border border-slate-800">
            <div className="text-[10px] text-amber-400 font-mono uppercase font-semibold">
              🛡 Conservative Pullback Dip
            </div>
            <div className="text-base sm:text-lg font-black font-mono text-amber-300 mt-1">
              {fmtCurr(entryGuide.conservativePullbackEntry)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Limit order placed at technical support floor.
            </div>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-800/80 text-xs text-slate-300 flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span>{entryGuide.entryStrategyText}</span>
        </div>
      </div>

      {/* Backtest Accuracy & Previous Trade Signals Chart Overlay */}
      {showBacktest && (
        <div className="relative z-20">
          <BacktestAccuracyOverlay
            symbol={symbol}
            name={name}
            currencySymbol={currencySymbol}
            history={history}
            onClose={() => setShowBacktest(false)}
            onPopout={() => {
              setShowBacktest(false);
              setSeparateWindowTab('backtest');
              setIsSeparateWindowOpen(true);
            }}
          />
        </div>
      )}

      {/* Separate Pop-out Window Modal */}
      <SeparateReportWindow
        report={report}
        history={history}
        confidenceLevel={confidenceLevel}
        isOpen={isSeparateWindowOpen}
        onClose={() => setIsSeparateWindowOpen(false)}
        initialTab={separateWindowTab}
      />

      {/* 2 & 4. 5 CORE METRICS GRID: CMP, TARGET 1, TARGET 2, TARGET 3, STRICT STOPLOSS */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3.5 relative z-10">
        {/* 1. CURRENT MARKET PRICE (CMP) */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-cyan-500/30 shadow-lg relative overflow-hidden flex flex-col justify-between group hover:border-cyan-500/60 transition">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-cyan-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                1. Current Price (CMP)
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-mono">
                LIVE
              </span>
            </div>
            
            <div className="pt-2">
              <div className="text-2xl sm:text-3xl font-black font-mono text-white tracking-tight">
                {fmtCurr(currentMarketPrice)}
              </div>
              
              <div className="flex items-center gap-2 mt-1.5 text-xs font-mono">
                <span className={`px-2 py-0.5 rounded-md font-bold flex items-center gap-1 ${
                  isPositive ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                }`}>
                  {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {isPositive ? '+' : ''}{changePct}%
                </span>
                <span className="text-slate-400">
                  ({isPositive ? '+' : ''}{fmtCurr(changeAmount)})
                </span>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-[11px] text-slate-400">
            Real-time close benchmark in {currencySymbol}.
          </div>
        </div>

        {/* 2. TARGET ONE (1-3 Trading Days Momentum Hurdle) */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-amber-500/30 shadow-lg relative overflow-hidden flex flex-col justify-between group hover:border-amber-500/60 transition">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-amber-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-amber-400" />
                2. Target 1 (T1)
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950/80 border border-amber-500/70 text-amber-300 font-mono font-bold flex items-center gap-1">
                ⏱ {targetOne.estimatedSteps} Steps
              </span>
            </div>

            <div className="pt-2">
              <div className="text-2xl sm:text-3xl font-black font-mono text-amber-400 tracking-tight">
                {fmtCurr(targetOne.targetPrice)}
              </div>

              <div className="flex items-center gap-1.5 mt-1.5 text-xs font-mono font-bold text-amber-300">
                <span>{targetOne.returnPct >= 0 ? '+' : ''}{targetOne.returnPct}% Gain</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 text-[11px]">{targetOne.probabilityPct !== undefined ? `${targetOne.probabilityPct}%` : 'Not calibrated'}</span>
              </div>
            </div>
          </div>

          {/* Timeframe & Exit Strategy */}
          <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-amber-300 font-semibold bg-amber-950/60 px-2 py-1 rounded border border-amber-800/60">
              <Clock className="w-3 h-3 text-amber-400 shrink-0" />
              <span>⏱ {targetOne.timeframeText}</span>
            </div>
            <p className="text-[10px] text-amber-200/80 leading-tight">
              🚪 <strong>Exit:</strong> {targetOne.exitStrategy || 'Book 50% & SL to Cost.'}
            </p>
          </div>
        </div>

        {/* 3. TARGET TWO (Core Median Target) */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-emerald-500/30 shadow-lg relative overflow-hidden flex flex-col justify-between group hover:border-emerald-500/60 transition">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-emerald-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <Crosshair className="w-3.5 h-3.5 text-emerald-400" />
                3. Target 2 (T2)
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-300 font-mono">
                📅 TimesFM p50
              </span>
            </div>

            <div className="pt-2">
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400 tracking-tight">
                {fmtCurr(targetTwo.targetPrice)}
              </div>

              <div className="flex items-center gap-1.5 mt-1.5 text-xs font-mono font-bold text-emerald-300">
                <span>{targetTwo.returnPct >= 0 ? '+' : ''}{targetTwo.returnPct}% Gain</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 text-[11px]">{targetTwo.probabilityPct !== undefined ? `${targetTwo.probabilityPct}%` : 'Not calibrated'}</span>
              </div>
            </div>
          </div>

          {/* Timeframe & Exit Strategy */}
          <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-300 font-semibold bg-emerald-950/60 px-2 py-1 rounded border border-emerald-800/60">
              <Clock className="w-3 h-3 text-emerald-400 shrink-0" />
              <span>⏱ {targetTwo.timeframeText}</span>
            </div>
            <p className="text-[10px] text-emerald-200/80 leading-tight">
              🚪 <strong>Exit:</strong> {targetTwo.exitStrategy || 'Book 30% & Trail with 20 EMA.'}
            </p>
          </div>
        </div>

        {/* 4. TARGET THREE (Upper Quantile Swing Extension) */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-purple-500/30 shadow-lg relative overflow-hidden flex flex-col justify-between group hover:border-purple-500/60 transition">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-purple-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-purple-400" />
                4. Target 3 (T3)
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-950/80 border border-purple-800 text-purple-300 font-mono">
                🚀 Swing Ext.
              </span>
            </div>

            <div className="pt-2">
              <div className="text-2xl sm:text-3xl font-black font-mono text-purple-300 tracking-tight">
                {fmtCurr(targetThree.targetPrice)}
              </div>

              <div className="flex items-center gap-1.5 mt-1.5 text-xs font-mono font-bold text-purple-300">
                <span>{targetThree.returnPct >= 0 ? '+' : ''}{targetThree.returnPct}% Gain</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 text-[11px]">{targetThree.probabilityPct !== undefined ? `${targetThree.probabilityPct}%` : 'Not calibrated'}</span>
              </div>
            </div>
          </div>

          {/* Timeframe & Exit Strategy */}
          <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-purple-300 font-semibold bg-purple-950/60 px-2 py-1 rounded border border-purple-800/60">
              <Clock className="w-3 h-3 text-purple-400 shrink-0" />
              <span>⏱ {targetThree.timeframeText}</span>
            </div>
            <p className="text-[10px] text-purple-200/80 leading-tight">
              🚪 <strong>Exit:</strong> {targetThree.exitStrategy || 'Final target exit / 1.5 ATR trail.'}
            </p>
          </div>
        </div>

        {/* 5. STRICT STOPLOSS */}
        <div className="bg-slate-950/80 p-4 rounded-xl border border-rose-500/40 shadow-lg relative overflow-hidden flex flex-col justify-between group hover:border-rose-500/70 transition">
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-rose-400 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                5. Strict Stoploss
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-950 border border-rose-800 text-rose-300 font-mono font-bold">
                1:{strictStoploss.riskRewardRatio} RRR
              </span>
            </div>

            <div className="pt-2">
              <div className="text-2xl sm:text-3xl font-black font-mono text-rose-400 tracking-tight">
                {fmtCurr(strictStoploss.stoplossPrice)}
              </div>

              <div className="flex items-center gap-1.5 mt-1.5 text-xs font-mono font-bold text-rose-400">
                <span>{strictStoploss.riskPct}% Max Risk</span>
                <span className="text-slate-500">•</span>
                <span className="text-slate-400 text-[11px]">{fmtCurr(strictStoploss.riskAmount)}</span>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1">
            <div className="text-[11px] font-mono text-rose-300 bg-rose-950/60 px-2 py-1 rounded border border-rose-900/60 font-medium">
              🛡 Daily Closing Invalidation
            </div>
            <p className="text-[10px] text-slate-400 leading-tight">
              {strictStoploss.supportBasis}
            </p>
          </div>
        </div>
      </div>

      {/* Visual Price Corridor & Trailing Strategy Bar */}
      <div className="bg-slate-950/70 p-4 rounded-xl border border-slate-800 space-y-3 relative z-10">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-300 flex-wrap gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400">Execution Corridor:</span>
            <span className="font-mono text-rose-400">SL: {fmtCurr(strictStoploss.stoplossPrice)}</span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className="font-mono text-cyan-300 font-bold">CMP: {fmtCurr(currentMarketPrice)}</span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className="font-mono text-amber-400">T1: {fmtCurr(targetOne.targetPrice)}</span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className="font-mono text-emerald-400">T2: {fmtCurr(targetTwo.targetPrice)}</span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className="font-mono text-purple-400">T3: {fmtCurr(targetThree.targetPrice)}</span>
          </div>

          <div className="text-[11px] font-mono text-slate-400">
            Risk-Reward Profile: <strong className="text-cyan-400">1 : {strictStoploss.riskRewardRatio}</strong>
          </div>
        </div>

        {/* Visual Ladder Bar */}
        <div className="h-3 w-full bg-slate-900 rounded-full relative overflow-hidden border border-slate-800">
          {/* Stoploss Zone (Red) */}
          <div 
            className="absolute top-0 bottom-0 left-0 bg-rose-500/40 rounded-l-full"
            style={{ width: `${Math.min(cmpPct, slPct)}%` }}
          />
          {/* Target Zone (Green to Cyan) */}
          <div 
            className="absolute top-0 bottom-0 bg-gradient-to-r from-cyan-500/50 via-emerald-500/50 to-purple-500/50 rounded-r-full"
            style={{ left: `${Math.min(cmpPct, slPct)}%`, width: `${Math.max(0, 100 - Math.min(cmpPct, slPct))}%` }}
          />
        </div>

        {/* Strategy Guidance Callout */}
        <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-300 border-t border-slate-800/60">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              <strong className="text-white">Strict Trailing Rule:</strong> {strictStoploss.trailingRule}
            </span>
          </div>
          <div className="text-[11px] font-mono text-amber-400/90 font-medium shrink-0">
            ⚠️ Limit position risk to max {strictStoploss.maxCapitalRiskPct}% of total portfolio capital.
          </div>
        </div>
      </div>
    </div>
  );
};
