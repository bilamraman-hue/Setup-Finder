import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  ShieldCheck, 
  Percent, 
  Activity, 
  CheckCircle2, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Sliders,
  Download,
  Copy,
  Check,
  Play,
  RotateCcw,
  Sparkles,
  Layers,
  Filter
} from 'lucide-react';
import { TimeSeriesPoint } from '../types';
import { 
  runBacktestSimulation, 
  BacktestResult, 
  BacktestStrategyType,
  BacktestSignal
} from '../lib/backtestEngine';
import { BACKTEST_LOOKBACK_BARS, MIN_BACKTEST_TRADES_FOR_RELIABLE_SAMPLE } from '../lib/backtestEngine';
import type { SyntheticBuildupTimeframe } from '../lib/syntheticBuildupMatrix';
import { fetchCandlesForTimeframe } from '../lib/watchlistAnalysisEngine';

interface WalkForwardBacktestModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  history: TimeSeriesPoint[];
  currencySymbol?: string;
  onOpenPaperTrading?: () => void;
  timeframe?: SyntheticBuildupTimeframe;
}

export const WalkForwardBacktestModal: React.FC<WalkForwardBacktestModalProps> = ({
  isOpen,
  onClose,
  symbol,
  history,
  currencySymbol = '₹',
  onOpenPaperTrading,
  timeframe: initialTimeframe = '1h'
}) => {
  const [strategy, setStrategy] = useState<BacktestStrategyType>('timesfm_momentum');
  const [timeframe, setTimeframe] = useState<SyntheticBuildupTimeframe>(initialTimeframe);
  const [lookbackBars, setLookbackBars] = useState<number>(BACKTEST_LOOKBACK_BARS[initialTimeframe]);
  const [backtestHistory, setBacktestHistory] = useState<TimeSeriesPoint[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [riskRewardRatio, setRiskRewardRatio] = useState<number>(2.0);
  const [useTrailingStop, setUseTrailingStop] = useState<boolean>(true);
  const [initialCapital, setInitialCapital] = useState<number>(1000000);
  const [tradeFilter, setTradeFilter] = useState<'ALL' | 'WINS' | 'LOSSES' | 'BUY' | 'SELL'>('ALL');
  const [selectedSignal, setSelectedSignal] = useState<BacktestSignal | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) return;
    setTimeframe(initialTimeframe);
    setLookbackBars(BACKTEST_LOOKBACK_BARS[initialTimeframe]);
  }, [isOpen, initialTimeframe]);

  useEffect(() => {
    if (!isOpen) return;
    let active = true;
    setIsLoadingHistory(true); setBacktestHistory([]);
    void fetchCandlesForTimeframe(symbol, timeframe).then(points => {
      if (active) setBacktestHistory(points);
    }).catch(error => console.warn(`Walk-forward history fetch failed for ${symbol} @ ${timeframe}`, error)).finally(() => {
      if (active) setIsLoadingHistory(false);
    });
    return () => { active = false; };
  }, [isOpen, symbol, timeframe]);

  // Compute full backtest result
  const backtest: BacktestResult = useMemo(() => {
    return runBacktestSimulation(backtestHistory, symbol, {
      lookbackBars,
      timeframe,
      strategy,
      riskRewardRatio,
      useTrailingStop,
      initialCapital,
      riskPerTradePct: 1.0
    });
  }, [backtestHistory, symbol, lookbackBars, timeframe, strategy, riskRewardRatio, useTrailingStop, initialCapital]);

  if (!isOpen) return null;

  const {
    winRatePct,
    wins,
    losses,
    profitFactor,
    sharpeRatio,
    sortinoRatio,
    expectancyPct,
    maxDrawdownPct,
    recoveryFactor,
    consecutiveWins,
    consecutiveLosses,
    netProfitAmount,
    netReturnPct,
    buyAndHoldReturnPct,
    avgWinPct,
    avgLossPct,
    signals,
    equityCurve
  } = backtest;
  const { isSampleSufficient, statusMessage } = backtest;

  // Filter signals for journal
  const filteredSignals = signals.filter(s => {
    if (tradeFilter === 'WINS') return s.outcome === 'TARGET_HIT' || s.returnPct > 0;
    if (tradeFilter === 'LOSSES') return s.returnPct <= 0;
    if (tradeFilter === 'BUY') return s.type === 'BUY';
    if (tradeFilter === 'SELL') return s.type === 'SELL';
    return true;
  });

  // Export Backtest Report as CSV
  const handleExportCsv = () => {
    const headers = ['Date,Type,Entry Price,Target Price,Exit Price,Outcome,Return %,PnL Amount,Bars Held,Reason'];
    const rows = signals.map(s => 
      `"${s.timestamp}","${s.type}",${s.entryPrice},${s.targetPrice},${s.exitPrice},"${s.outcome}",${s.returnPct}%,${s.pnlAmount},${s.barsHeld},"${s.reason}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `backtest_${symbol}_${strategy}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Copy Summary Report to Clipboard
  const handleCopyReport = () => {
    const text = `📊 QUANTITATIVE BACKTEST REPORT: ${symbol}
Strategy: ${backtest.strategyName}
Lookback Window: ${lookbackBars} Bars
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Win Rate: ${winRatePct}% (${wins} Wins / ${losses} Losses)
• Net Return: +${netReturnPct}% (${currencySymbol}${netProfitAmount.toLocaleString()})
• Buy & Hold Benchmark: ${buyAndHoldReturnPct >= 0 ? '+' : ''}${buyAndHoldReturnPct}%
• Profit Factor: ${profitFactor}x
• Sharpe Ratio: ${sharpeRatio} | Sortino: ${sortinoRatio}
• Expectancy / Trade: +${expectancyPct}%
• Max Drawdown: -${maxDrawdownPct}%
• Max Consecutive Wins: ${consecutiveWins} | Losses: ${consecutiveLosses}
• Risk:Reward Setup: 1:${riskRewardRatio} | Trailing SL: ${useTrailingStop ? 'ON' : 'OFF'}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // SVG Equity Curve Calculation
  const svgWidth = 800;
  const svgHeight = 180;
  const paddingX = 40;
  const paddingY = 20;

  const equities = equityCurve.map(e => e.equity);
  const minEq = Math.min(...equities, initialCapital * 0.95);
  const maxEq = Math.max(...equities, initialCapital * 1.05);
  const eqRange = Math.max(1, maxEq - minEq);

  const getEqX = (idx: number) => {
    if (equityCurve.length <= 1) return paddingX;
    return paddingX + (idx / (equityCurve.length - 1)) * (svgWidth - paddingX * 2);
  };

  const getEqY = (val: number) => {
    return svgHeight - paddingY - ((val - minEq) / eqRange) * (svgHeight - paddingY * 2);
  };

  const eqPath = equityCurve.reduce((acc, pt, idx) => {
    const x = getEqX(idx);
    const y = getEqY(pt.equity);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  const benchmarkPath = equityCurve.reduce((acc, pt, idx) => {
    const x = getEqX(idx);
    const y = getEqY(pt.benchmarkEquity);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-t-2xl sm:rounded-2xl shadow-2xl flex flex-col max-h-[96dvh] sm:max-h-[92vh] overflow-hidden text-slate-100 ring-1 ring-cyan-500/20">
        
        {/* Header Modal Bar */}
        <div className="px-5 py-3.5 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-cyan-500/20">
              <BarChart3 className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-wide flex items-center gap-1.5">
                  Historical Strategy Backtest — {symbol}
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {winRatePct}% Win Rate
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                  {profitFactor}x PF
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Historical simulation • fees and slippage assumptions apply • not out-of-sample validated
              </p>
              <p className="text-[10px] text-cyan-300">{isLoadingHistory ? `Loading actual ${timeframe} candles…` : `${backtestHistory.length} fetched ${timeframe} candles${backtestHistory.length ? '' : ' · unavailable'}`}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyReport}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer text-xs flex items-center gap-1"
              title="Copy Summary Report"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? 'Copied!' : 'Copy'}</span>
            </button>
            <button
              onClick={handleExportCsv}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white transition cursor-pointer text-xs flex items-center gap-1"
              title="Download Trades CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CSV</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">

          {statusMessage && <div className={`rounded-xl border p-3 text-xs leading-relaxed ${isSampleSufficient ? 'border-cyan-800 bg-cyan-950/50 text-cyan-200' : 'border-amber-700 bg-amber-950/50 text-amber-200'}`} role="status">{statusMessage}{!isSampleSufficient && signals.length > 0 ? ` A basic reporting flag uses ${MIN_BACKTEST_TRADES_FOR_RELIABLE_SAMPLE} trades; it does not establish a profitable edge.` : ''}</div>}
          
          {/* Strategy & Parameter Control Bar */}
          <div className="p-3.5 bg-slate-950/90 border border-slate-800 rounded-xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              
              {/* Strategy Selector */}
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                <span className="text-slate-400 font-semibold text-xs flex items-center gap-1 shrink-0">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                  Strategy:
                </span>
                {[
                  { id: 'timesfm_momentum', label: 'TimesFM Momentum' },
                  { id: 'smc_fvg_retest', label: 'SMC FVG Retest' },
                  { id: 'cpr_orb_breakout', label: 'CPR Breakout' },
                  { id: 'rsi_mean_reversion', label: 'RSI Mean-Reversion' },
                  { id: 'timeframe_weighted_setup', label: 'Weighted PA + Volume' }
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStrategy(s.id as BacktestStrategyType)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                      strategy === s.id
                        ? 'bg-cyan-600 text-white shadow-sm'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {/* Lookback Selector */}
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <span className="text-slate-400 font-semibold text-xs shrink-0">Lookback:</span>
                <div className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-800 text-xs">
                  {[60, 180, 500, BACKTEST_LOOKBACK_BARS[timeframe]].filter((v, i, a) => a.indexOf(v) === i).map((bars) => (
                    <button
                      key={bars}
                      onClick={() => setLookbackBars(bars)}
                      className={`px-2 py-0.8 rounded-md font-mono text-[11px] font-semibold transition cursor-pointer ${
                        lookbackBars === bars
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {bars}b
                    </button>
                  ))}
                </div>
              </div>
              <label className="flex items-center gap-1 text-xs text-slate-400">Timeframe
                <select value={timeframe} onChange={event => { const tf = event.target.value as SyntheticBuildupTimeframe; setTimeframe(tf); setLookbackBars(BACKTEST_LOOKBACK_BARS[tf]); }} className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-1 text-cyan-200">
                  {(['5m', '15m', '1h', '1d'] as const).map(tf => <option key={tf} value={tf}>{tf} · {BACKTEST_LOOKBACK_BARS[tf]} bars</option>)}
                </select>
              </label>
            </div>

            {/* Risk & Execution Filters */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-850 text-xs">
              <div className="flex items-center gap-3 flex-wrap">
                {/* Risk-Reward Picker */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 font-mono text-[11px]">R:R Ratio:</span>
                  {[1.5, 2.0, 2.5, 3.0].map((r) => (
                    <button
                      key={r}
                      onClick={() => setRiskRewardRatio(r)}
                      className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                        riskRewardRatio === r
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      1:{r}
                    </button>
                  ))}
                </div>

                {/* Trailing Stop Loss Toggle */}
                <button
                  onClick={() => setUseTrailingStop(!useTrailingStop)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 border transition cursor-pointer ${
                    useTrailingStop
                      ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Trailing SL: <strong>{useTrailingStop ? 'ON (1.5× ATR)' : 'OFF'}</strong></span>
                </button>
              </div>

              {onOpenPaperTrading && (
                <button
                  onClick={onOpenPaperTrading}
                  className="px-3 py-1 rounded-lg bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-[11px] flex items-center gap-1 shadow-md cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-white" />
                  <span>Run Live in Paper Trading</span>
                </button>
              )}
            </div>
          </div>

          {/* Top Performance Statistics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5">
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Win Rate %</span>
              <div className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                {winRatePct}%
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {wins}W / {losses}L ({signals.length} Signals)
              </span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Net Return</span>
              <div className={`text-lg font-black font-mono mt-0.5 ${netReturnPct >= 0 ? 'text-cyan-400' : 'text-rose-400'}`}>
                {netReturnPct > 0 ? '+' : ''}{netReturnPct}%
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {currencySymbol}{netProfitAmount.toLocaleString()} P&L
              </span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Profit Factor</span>
              <div className="text-lg font-black text-indigo-300 font-mono mt-0.5">
                {profitFactor}x
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                Expectancy: {expectancyPct > 0 ? '+' : ''}{expectancyPct}%
              </span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Per-trade Sharpe / Sortino</span>
              <div className="text-lg font-black text-purple-300 font-mono mt-0.5">
                {sharpeRatio} / {sortinoRatio}
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                Unannualized trade returns
              </span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Max Drawdown</span>
              <div className="text-lg font-black text-amber-400 font-mono mt-0.5">
                -{maxDrawdownPct}%
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                Recovery: {recoveryFactor}x
              </span>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl">
              <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">Benchmark Alpha</span>
              <div className="text-lg font-black text-emerald-300 font-mono mt-0.5">
                +{(netReturnPct - buyAndHoldReturnPct).toFixed(1)}%
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                vs Buy & Hold ({buyAndHoldReturnPct >= 0 ? '+' : ''}{buyAndHoldReturnPct}%)
              </span>
            </div>
          </div>

          {/* Cumulative Equity Curve Visualization */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Compounded Equity Curve vs Buy & Hold Benchmark
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  Base: {currencySymbol}{initialCapital.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] font-mono">
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  Strategy ({currencySymbol}{backtest.finalEquity.toLocaleString()})
                </span>
                <span className="flex items-center gap-1.5 text-slate-500">
                  <span className="w-2.5 h-0.5 bg-slate-500" />
                  Buy & Hold ({currencySymbol}{Math.round(initialCapital * (1 + buyAndHoldReturnPct / 100)).toLocaleString()})
                </span>
              </div>
            </div>

            {/* SVG Visual Graph */}
            <div className="relative bg-slate-900/60 rounded-xl border border-slate-850 p-2 overflow-hidden">
              <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-40 sm:h-48 overflow-visible select-none">
                <defs>
                  <linearGradient id="eqFillGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid guidelines */}
                {[0.25, 0.5, 0.75].map((pct, idx) => {
                  const y = paddingY + pct * (svgHeight - paddingY * 2);
                  const eqVal = maxEq - pct * eqRange;
                  return (
                    <g key={idx}>
                      <line x1={paddingX} y1={y} x2={svgWidth - paddingX} y2={y} stroke="#334155" strokeDasharray="3 3" strokeOpacity="0.5" />
                      <text x={paddingX - 6} y={y + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                        {currencySymbol}{Math.round(eqVal / 1000)}k
                      </text>
                    </g>
                  );
                })}

                {/* Benchmark Buy & Hold Line */}
                <path d={benchmarkPath} fill="none" stroke="#64748b" strokeWidth="1.5" strokeDasharray="4 4" />

                {/* Strategy Equity Area & Line */}
                <path
                  d={`${eqPath} L ${getEqX(equityCurve.length - 1)} ${svgHeight - paddingY} L ${getEqX(0)} ${svgHeight - paddingY} Z`}
                  fill="url(#eqFillGrad)"
                />
                <path d={eqPath} fill="none" stroke="#06b6d4" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </div>
            
            <div className="flex justify-between text-[10px] font-mono text-slate-500 px-1">
              <span>Start: {equityCurve[0]?.timestamp || 'Inception'}</span>
              <span>End: {equityCurve[equityCurve.length - 1]?.timestamp || 'Current'}</span>
            </div>
          </div>

          {/* Trade Details Callout if Selected */}
          {selectedSignal && (
            <div className="p-3.5 bg-slate-950 border border-cyan-500/50 rounded-xl space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                    selectedSignal.type === 'BUY' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  }`}>
                    {selectedSignal.type}
                  </span>
                  <span>Signal on {selectedSignal.timestamp}</span>
                </span>
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                  selectedSignal.returnPct >= 0 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                }`}>
                  {selectedSignal.outcome.replace(/_/g, ' ')}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                <div>Entry: <strong className="text-white">{currencySymbol}{selectedSignal.entryPrice}</strong></div>
                <div>Target: <strong className="text-emerald-400">{currencySymbol}{selectedSignal.targetPrice}</strong></div>
                <div>Exit: <strong className={selectedSignal.returnPct >= 0 ? 'text-emerald-300' : 'text-rose-400'}>{currencySymbol}{selectedSignal.exitPrice}</strong></div>
                <div>Return: <strong className={selectedSignal.returnPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>{selectedSignal.returnPct >= 0 ? '+' : ''}{selectedSignal.returnPct}%</strong></div>
                <div>Duration: <strong className="text-cyan-300">{selectedSignal.barsHeld} bars</strong></div>
              </div>
              <p className="text-[11px] text-slate-400">
                <strong className="text-slate-300">Strategy Setup Trigger:</strong> {selectedSignal.reason}
              </p>
            </div>
          )}

          {/* Trade Signals History Journal */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-cyan-400" />
                Verified Signal Journal ({filteredSignals.length} Trades)
              </span>

              {/* Journal Filter Buttons */}
              <div className="inline-flex rounded-lg p-0.5 bg-slate-950 border border-slate-800 text-[11px]">
                {(['ALL', 'WINS', 'LOSSES', 'BUY', 'SELL'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setTradeFilter(filter)}
                    className={`px-2 py-0.5 rounded font-mono font-semibold transition cursor-pointer ${
                      tradeFilter === filter
                        ? 'bg-slate-800 text-cyan-400'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            <div className="max-h-52 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950/70 scrollbar-thin">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-slate-400 text-[10px] font-mono uppercase tracking-wider border-b border-slate-800 sticky top-0">
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-2.5">Type</th>
                    <th className="py-2 px-2.5 text-right">Entry</th>
                    <th className="py-2 px-2.5 text-right">Target</th>
                    <th className="py-2 px-2.5 text-right">Exit</th>
                    <th className="py-2 px-2.5 text-right">Return %</th>
                    <th className="py-2 px-2.5 text-right">PnL ({currencySymbol})</th>
                    <th className="py-2 px-2.5 text-center">Outcome</th>
                    <th className="py-2 px-2.5 text-center">Bars</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {filteredSignals.map((s) => {
                    const isWin = s.returnPct > 0;
                    return (
                      <tr
                        key={s.id}
                        className="hover:bg-slate-850/60 cursor-pointer transition-colors"
                        onClick={() => setSelectedSignal(s)}
                      >
                        <td className="py-2 px-3 text-slate-300 font-sans">{s.timestamp}</td>
                        <td className="py-2 px-2.5">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            s.type === 'BUY' ? 'text-emerald-400 bg-emerald-950/80 border border-emerald-800' : 'text-rose-400 bg-rose-950/80 border border-rose-800'
                          }`}>
                            {s.type}
                          </span>
                        </td>
                        <td className="py-2 px-2.5 text-right text-white">
                          {currencySymbol}{s.entryPrice.toLocaleString()}
                        </td>
                        <td className="py-2 px-2.5 text-right text-emerald-400">
                          {currencySymbol}{s.targetPrice.toLocaleString()}
                        </td>
                        <td className="py-2 px-2.5 text-right text-slate-200">
                          {currencySymbol}{s.exitPrice.toLocaleString()}
                        </td>
                        <td className={`py-2 px-2.5 text-right font-bold ${
                          isWin ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {s.returnPct >= 0 ? '+' : ''}{s.returnPct}%
                        </td>
                        <td className={`py-2 px-2.5 text-right font-bold ${
                          s.pnlAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {s.pnlAmount >= 0 ? '+' : ''}{currencySymbol}{s.pnlAmount.toLocaleString()}
                        </td>
                        <td className="py-2 px-2.5 text-center">
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                            isWin ? 'text-emerald-300 bg-emerald-950 border border-emerald-900' : 'text-rose-300 bg-rose-950 border border-rose-900'
                          }`}>
                            {s.outcome.replace('_HIT', '')}
                          </span>
                        </td>
                        <td className="py-2 px-2.5 text-center text-slate-400">
                          {s.barsHeld}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
