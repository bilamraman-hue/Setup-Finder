import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { 
  X, 
  CandlestickChart, 
  LineChart as LineChartIcon, 
  SlidersHorizontal, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  Download, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Layers, 
  Eye, 
  EyeOff, 
  Info, 
  RotateCw, 
  Camera, 
  Minus, 
  Crosshair as CrosshairIcon, 
  ZoomIn, 
  ZoomOut, 
  AlertTriangle, 
  Smartphone, 
  Monitor,
  Target,
  ShieldAlert,
  Sliders,
  Check,
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { TimeSeriesPoint, ForecastPoint, AnomalyItem, StockSummaryReportData } from '../types';
import { evaluateQuantSetup, QuantHorizon, QuantSetupReport } from '../lib/quantSetupEngine';
import { 
  buildCandleSeries, 
  calculateVWAP, 
  calculateBollingerBands, 
  calculatePivotLevels, 
  calculateSupertrend, 
  calculateVolumeSMA,
  calculateSMA,
  calculateEMA,
  calculateRSI,
  resampleCandlesForTimeframe,
  CandlePoint
} from '../lib/technicalIndicators';

interface AdvanceChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  name: string;
  history: TimeSeriesPoint[];
  forecasts: ForecastPoint[];
  anomalies?: AnomalyItem[];
  confidenceLevel?: number;
  unit?: string;
  currencySymbol?: string;
  stockSummaryReport?: StockSummaryReportData | null;
}

type Timeframe = '1m' | '5m' | '15m' | '1H' | '1D' | '1W';
type ChartStyle = 'candles' | 'line' | 'area';
type ActiveTool = 'crosshair' | 'horizontal';

export const AdvanceChartModal: React.FC<AdvanceChartModalProps> = ({
  isOpen,
  onClose,
  symbol,
  name,
  history,
  forecasts,
  anomalies = [],
  confidenceLevel = 90,
  unit = '₹',
  currencySymbol = '₹',
  stockSummaryReport = null
}) => {
  // Chart Display Settings
  const [timeframe, setTimeframe] = useState<Timeframe>('15m');
  const [chartStyle, setChartStyle] = useState<ChartStyle>('candles');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isForcedLandscape, setIsForcedLandscape] = useState(false);
  const [activeTool, setActiveTool] = useState<ActiveTool>('crosshair');
  const [isIndicatorsModalOpen, setIsIndicatorsModalOpen] = useState(false);

  // Dynamic Zoom & Pan State (like TimesFM Chart)
  const [zoomRange, setZoomRange] = useState<[number, number]>([0, 1]);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [isDraggingPan, setIsDraggingPan] = useState(false);
  const [dragStartX, setDragStartX] = useState<number | null>(null);
  const [dragStartRange, setDragStartRange] = useState<[number, number]>([0, 1]);

  // Mini-map Brush Slider State
  const [isBrushDragging, setIsBrushDragging] = useState<'left' | 'right' | 'window' | null>(null);
  const [brushStartX, setBrushStartX] = useState<number | null>(null);
  const [brushStartRange, setBrushStartRange] = useState<[number, number]>([0, 1]);

  // Indicators State & Parameters
  const [showTimesFmCorridor, setShowTimesFmCorridor] = useState(true);
  const [showTimesFmConfidence, setShowTimesFmConfidence] = useState(true);
  const [showTimesFmTargets, setShowTimesFmTargets] = useState(true);
  const [showAnomalies, setShowAnomalies] = useState(true);

  const [showSMA, setShowSMA] = useState(true);
  const [smaPeriod, setSmaPeriod] = useState<number>(20);

  const [showEMA, setShowEMA] = useState(true);
  const [emaPeriod, setEmaPeriod] = useState<number>(20);

  const [showRSI, setShowRSI] = useState(true);
  const [showVWAP, setShowVWAP] = useState(true);
  const [showBollinger, setShowBollinger] = useState(true);
  const [showPivotPoints, setShowPivotPoints] = useState(true);
  const [showSupertrend, setShowSupertrend] = useState(true);
  const [showVolume, setShowVolume] = useState(true);
  const [showKeyLevels, setShowKeyLevels] = useState(true);

  // Institutional Quantitative Trade Setup State (Targets, Stoploss, Entry Zone)
  const [showQuantSetup, setShowQuantSetup] = useState(true);
  const [quantHorizon, setQuantHorizon] = useState<QuantHorizon>('Swing (3–4 Days)');
  const [showQuantShading, setShowQuantShading] = useState(true);
  const [showQuantHud, setShowQuantHud] = useState(true);
  const [isQuantHudMinimized, setIsQuantHudMinimized] = useState(false);

  // Auto-sync quantHorizon when timeframe changes
  useEffect(() => {
    if (timeframe === '1m' || timeframe === '5m' || timeframe === '15m') {
      setQuantHorizon('Intraday (5m/15m)');
    } else if (timeframe === '1H' || timeframe === '1D') {
      setQuantHorizon('Swing (3–4 Days)');
    } else if (timeframe === '1W') {
      setQuantHorizon('Positional (1–2 Months)');
    }
  }, [timeframe]);

  // User Placed Custom Horizontal Ray Levels
  const [userLevels, setUserLevels] = useState<number[]>([]);

  const modalRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  // Detect physical device orientation
  const [deviceOrientation, setDeviceOrientation] = useState<'portrait' | 'landscape'>('portrait');

  useEffect(() => {
    const handleOrientation = () => {
      if (typeof window !== 'undefined') {
        const isLandscape = window.innerWidth > window.innerHeight;
        setDeviceOrientation(isLandscape ? 'landscape' : 'portrait');
      }
    };
    handleOrientation();
    window.addEventListener('resize', handleOrientation);
    window.addEventListener('orientationchange', handleOrientation);
    return () => {
      window.removeEventListener('resize', handleOrientation);
      window.removeEventListener('orientationchange', handleOrientation);
    };
  }, []);

  // 1. Build Base Candle Series & Resample
  const rawCandles = useMemo(() => {
    return buildCandleSeries(history, forecasts);
  }, [history, forecasts]);

  const allCandles = useMemo(() => {
    return resampleCandlesForTimeframe(rawCandles, timeframe);
  }, [rawCandles, timeframe]);

  const totalPoints = allCandles.length;

  // Initial Auto-zoom to show last 40-50 candles comfortably if series is very long
  useEffect(() => {
    if (totalPoints > 45) {
      const startRatio = Math.max(0, (totalPoints - 45) / totalPoints);
      setZoomRange([startRatio, 1]);
    } else {
      setZoomRange([0, 1]);
    }
  }, [totalPoints, timeframe]);

  // 2. Visible Sliced Candles based on Zoom Window
  const startIndex = Math.max(0, Math.floor(zoomRange[0] * (totalPoints - 1)));
  const endIndex = Math.min(totalPoints - 1, Math.ceil(zoomRange[1] * (totalPoints - 1)));
  const visibleCount = Math.max(2, endIndex - startIndex + 1);

  // 3. Technical Indicators on full candle series
  const vwapSeries = useMemo(() => calculateVWAP(allCandles), [allCandles]);
  const bollingerSeries = useMemo(() => calculateBollingerBands(allCandles, 20, 2), [allCandles]);
  const pivotLevels = useMemo(() => calculatePivotLevels(allCandles), [allCandles]);
  const supertrendSeries = useMemo(() => calculateSupertrend(allCandles, 10, 3), [allCandles]);
  const volumeSmaSeries = useMemo(() => calculateVolumeSMA(allCandles, 20), [allCandles]);
  const smaSeries = useMemo(() => calculateSMA(allCandles, smaPeriod), [allCandles, smaPeriod]);
  const emaSeries = useMemo(() => calculateEMA(allCandles, emaPeriod), [allCandles, emaPeriod]);
  const rsiSeries = useMemo(() => calculateRSI(allCandles, 14), [allCandles]);

  // Current Latest Stats
  const latestCandle = allCandles[allCandles.length - 1] || { close: 0, open: 0, high: 0, low: 0, volume: 0, timestamp: '' };
  const prevCandle = allCandles[allCandles.length - 2] || latestCandle;
  const cmp = latestCandle.close || 0;
  const changeVal = cmp - prevCandle.close;
  const changePct = prevCandle.close ? (changeVal / prevCandle.close) * 100 : 0;
  const isPositive = changeVal >= 0;

  const latestVWAP = vwapSeries[vwapSeries.length - 1] || cmp;
  const latestBollinger = bollingerSeries[bollingerSeries.length - 1];
  const latestSupertrend = supertrendSeries[supertrendSeries.length - 1] || { supertrend: cmp, direction: 'UP' };
  const latestSMA = smaSeries[smaSeries.length - 1] || cmp;
  const latestEMA = emaSeries[emaSeries.length - 1] || cmp;
  const latestRSI = rsiSeries[rsiSeries.length - 1] ?? 50;

  // First Forecast Index (Forecast Origin)
  const firstForecastIndex = useMemo(() => {
    const idx = allCandles.findIndex(c => c.isForecast);
    return idx >= 0 ? idx : null;
  }, [allCandles]);

  // Forecast Targets & Risk Floor from TimesFM
  const timesFmTargets = useMemo(() => {
    const fcCandles = allCandles.filter(c => c.isForecast);
    if (fcCandles.length === 0) return null;
    const p90s = fcCandles.map(c => c.forecastP90 || c.high).filter(Boolean);
    const p75s = fcCandles.map(c => c.forecastP75 || c.close).filter(Boolean);
    const p10s = fcCandles.map(c => c.forecastP10 || c.low).filter(Boolean);
    const p50s = fcCandles.map(c => c.forecastP50 || c.forecastMean || c.close).filter(Boolean);

    return {
      targetP90: Math.max(...p90s),
      targetP75: Math.max(...p75s),
      medianP50: p50s[p50s.length - 1] || cmp,
      floorP10: Math.min(...p10s)
    };
  }, [allCandles, cmp]);

  // Institutional Quantitative Trade Setup Evaluation (Entry, Targets, Stoploss)
  const quantReport = useMemo(() => {
    return evaluateQuantSetup(symbol, name, history, quantHorizon, currencySymbol, true, false, forecasts);
  }, [symbol, name, history, quantHorizon, currencySymbol, forecasts]);

  const quantSetupData = useMemo(() => {
    if (!quantReport) return null;

    const entryMin = quantReport.entryRange.min;
    const entryMax = quantReport.entryRange.max;
    const entryAvg = Math.round(((entryMin + entryMax) / 2) * 100) / 100;
    
    // Stop Loss (Strict SL)
    const slPrice = stockSummaryReport?.strictStoploss?.stoplossPrice ?? quantReport.stopLoss.price;
    const slPct = stockSummaryReport?.strictStoploss?.riskPct ?? quantReport.stopLoss.pct;
    const slBasis = stockSummaryReport?.strictStoploss?.supportBasis || quantReport.stopLoss.basis;
    
    // Target 1
    const t1Price = stockSummaryReport?.targetOne?.targetPrice ?? quantReport.target1.price;
    const t1Pct = stockSummaryReport?.targetOne?.returnPct ?? quantReport.target1.pct;
    const t1Label = stockSummaryReport?.targetOne?.timeframeText || quantReport.target1.horizonLabel;
    
    // Target 2
    const t2Price = stockSummaryReport?.targetTwo?.targetPrice ?? quantReport.target2.price;
    const t2Pct = stockSummaryReport?.targetTwo?.returnPct ?? quantReport.target2.pct;
    const t2Label = stockSummaryReport?.targetTwo?.timeframeText || quantReport.target2.horizonLabel;
    
    // Target 3 (Extended Target)
    const t3Price = stockSummaryReport?.targetThree?.targetPrice;
    const t3Pct = stockSummaryReport?.targetThree?.returnPct;

    const isLong = quantReport.direction === 'LONG' || quantReport.direction === 'REVERSAL (Bounceback)';

    return {
      direction: quantReport.direction,
      isLong,
      status: quantReport.status,
      statusReason: quantReport.statusReason,
      scorePct: quantReport.scorePct,
      riskRewardRatio: quantReport.riskRewardRatio,
      riskRewardText: quantReport.riskRewardText,
      entryMin,
      entryMax,
      entryAvg,
      slPrice,
      slPct,
      slBasis,
      t1Price,
      t1Pct,
      t1Label,
      t2Price,
      t2Pct,
      t2Label,
      t3Price,
      t3Pct,
      directNichod: quantReport.directNichod,
      levels: quantReport.levels
    };
  }, [quantReport, stockSummaryReport]);

  // SVG Canvas Dimensions
  const svgWidth = 1000;
  const volumeHeight = showVolume ? 58 : 0;
  const rsiHeight = showRSI ? 65 : 0;
  const subPanesHeight = volumeHeight + rsiHeight + (showVolume && showRSI ? 14 : (showVolume || showRSI ? 10 : 0));
  
  const svgHeight = 440 + subPanesHeight;
  const padding = { top: 28, right: 85, bottom: 25, left: 16 };
  const mainPlotHeight = svgHeight - padding.top - padding.bottom - subPanesHeight;
  const plotWidth = svgWidth - padding.left - padding.right;

  // Dynamic Min & Max Y in visible zoom slice
  const { minY, maxY, maxVolume } = useMemo(() => {
    if (allCandles.length === 0) return { minY: 0, maxY: 100, maxVolume: 1000 };

    let min = Infinity;
    let max = -Infinity;
    let maxVol = 0;

    const visibleSlice = allCandles.slice(startIndex, endIndex + 1);

    visibleSlice.forEach((c, idx) => {
      const globalIdx = startIndex + idx;
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
      if (c.volume > maxVol) maxVol = c.volume;

      if (showTimesFmCorridor && c.isForecast) {
        if (c.forecastP10 !== undefined && c.forecastP10 < min) min = c.forecastP10;
        if (c.forecastP90 !== undefined && c.forecastP90 > max) max = c.forecastP90;
      }

      if (showBollinger) {
        const bb = bollingerSeries[globalIdx];
        if (bb) {
          if (bb.lower < min) min = bb.lower;
          if (bb.upper > max) max = bb.upper;
        }
      }

      if (showSupertrend) {
        const st = supertrendSeries[globalIdx];
        if (st) {
          if (st.supertrend < min) min = st.supertrend;
          if (st.supertrend > max) max = st.supertrend;
        }
      }

      if (showSMA) {
        const val = smaSeries[globalIdx];
        if (val !== null && val !== undefined) {
          if (val < min) min = val;
          if (val > max) max = val;
        }
      }

      if (showEMA) {
        const val = emaSeries[globalIdx];
        if (val !== null && val !== undefined) {
          if (val < min) min = val;
          if (val > max) max = val;
        }
      }
    });

    if (showPivotPoints) {
      if (pivotLevels.r1 > max) max = pivotLevels.r1;
      if (pivotLevels.s1 < min) min = pivotLevels.s1;
    }

    if (showTimesFmTargets && timesFmTargets) {
      if (timesFmTargets.targetP90 > max) max = timesFmTargets.targetP90;
      if (timesFmTargets.floorP10 < min) min = timesFmTargets.floorP10;
    }

    if (showQuantSetup && quantSetupData) {
      if (quantSetupData.entryMin < min) min = quantSetupData.entryMin;
      if (quantSetupData.entryMax > max) max = quantSetupData.entryMax;
      if (quantSetupData.slPrice < min) min = quantSetupData.slPrice;
      if (quantSetupData.slPrice > max) max = quantSetupData.slPrice;
      if (quantSetupData.t1Price < min) min = quantSetupData.t1Price;
      if (quantSetupData.t1Price > max) max = quantSetupData.t1Price;
      if (quantSetupData.t2Price < min) min = quantSetupData.t2Price;
      if (quantSetupData.t2Price > max) max = quantSetupData.t2Price;
      if (quantSetupData.t3Price) {
        if (quantSetupData.t3Price < min) min = quantSetupData.t3Price;
        if (quantSetupData.t3Price > max) max = quantSetupData.t3Price;
      }
    }

    userLevels.forEach(lvl => {
      if (lvl < min) min = lvl;
      if (lvl > max) max = lvl;
    });

    if (min === Infinity) { min = 0; max = 100; }
    const span = max - min || 1;
    return {
      minY: min - span * 0.05,
      maxY: max + span * 0.05,
      maxVolume: Math.max(1, maxVol * 1.3)
    };
  }, [allCandles, startIndex, endIndex, bollingerSeries, supertrendSeries, smaSeries, emaSeries, pivotLevels, userLevels, timesFmTargets, quantSetupData, showTimesFmCorridor, showBollinger, showSupertrend, showSMA, showEMA, showPivotPoints, showTimesFmTargets, showQuantSetup]);

  // Scaled Coordinate Converters for Zoomed View
  const getX = useCallback((globalIdx: number) => {
    if (globalIdx < startIndex || globalIdx > endIndex) return -9999;
    if (visibleCount <= 1) return padding.left;
    const ratio = (globalIdx - startIndex) / (visibleCount - 1);
    return padding.left + ratio * plotWidth;
  }, [startIndex, endIndex, visibleCount, padding.left, plotWidth]);

  const getY = useCallback((val: number) => {
    const ratio = (val - minY) / (maxY - minY || 1);
    return padding.top + (1 - ratio) * mainPlotHeight;
  }, [minY, maxY, padding.top, mainPlotHeight]);

  // Sub-pane Y origins
  const volumeBaseY = padding.top + mainPlotHeight + 10;
  const getVolY = (vol: number) => {
    const ratio = vol / (maxVolume || 1);
    return volumeBaseY + (1 - ratio) * volumeHeight;
  };

  const rsiBaseY = volumeBaseY + volumeHeight + (showVolume ? 12 : 0);
  const getRsiY = (rsiVal: number) => {
    const clamped = Math.max(0, Math.min(100, rsiVal));
    const ratio = clamped / 100;
    return rsiBaseY + (1 - ratio) * rsiHeight;
  };

  // Convert screen pointer coordinates to SVG coordinate space
  // Perfectly handles Rotated Landscape Mode (90deg) without glitching!
  const getSvgPoint = (clientX: number, clientY: number): { x: number; y: number } | null => {
    const svg = svgRef.current;
    if (!svg) return null;
    const rect = svg.getBoundingClientRect();

    if (isForcedLandscape && deviceOrientation === 'portrait') {
      // 90deg Clockwise CSS rotation coordinate transformation
      const relX = ((clientY - rect.top) / rect.height) * svgWidth;
      const relY = ((rect.right - clientX) / rect.width) * svgHeight;
      return { x: relX, y: relY };
    } else {
      const relX = ((clientX - rect.left) / rect.width) * svgWidth;
      const relY = ((clientY - rect.top) / rect.height) * svgHeight;
      return { x: relX, y: relY };
    }
  };

  // Pointer interactions: Zoom with mouse wheel
  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const pt = getSvgPoint(e.clientX, e.clientY);
    if (!pt) return;

    const plotX = pt.x - padding.left;
    const cursorRatio = Math.max(0, Math.min(1, plotX / plotWidth));
    const currentSpan = zoomRange[1] - zoomRange[0];
    const zoomFactor = e.deltaY > 0 ? 1.15 : 0.85;
    const nextSpan = Math.max(0.08, Math.min(1.0, currentSpan * zoomFactor));

    const cursorCenter = zoomRange[0] + cursorRatio * currentSpan;
    let nextStart = cursorCenter - cursorRatio * nextSpan;
    let nextEnd = nextStart + nextSpan;

    if (nextStart < 0) {
      nextStart = 0;
      nextEnd = Math.min(1, nextSpan);
    }
    if (nextEnd > 1) {
      nextEnd = 1;
      nextStart = Math.max(0, 1 - nextSpan);
    }

    setZoomRange([nextStart, nextEnd]);
  };

  // Drag-to-Pan on chart canvas
  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    if (activeTool === 'crosshair') {
      setIsDraggingPan(true);
      setDragStartX(e.clientX);
      setDragStartRange([...zoomRange]);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const pt = getSvgPoint(e.clientX, e.clientY);
    if (!pt) return;

    if (isDraggingPan && dragStartX !== null) {
      const deltaScreen = e.clientX - dragStartX;
      const span = dragStartRange[1] - dragStartRange[0];
      const deltaRatio = -(deltaScreen / (plotWidth * 1.2)) * span;
      let nextStart = Math.max(0, dragStartRange[0] + deltaRatio);
      let nextEnd = Math.min(1, dragStartRange[1] + deltaRatio);
      if (nextStart === 0) nextEnd = span;
      if (nextEnd === 1) nextStart = 1 - span;
      setZoomRange([nextStart, nextEnd]);
    }

    // Update crosshair hover index
    const plotX = pt.x - padding.left;
    if (plotX >= 0 && plotX <= plotWidth && visibleCount > 1) {
      const localNorm = plotX / plotWidth;
      const globalIdx = Math.round(startIndex + localNorm * (visibleCount - 1));
      setHoverIndex(Math.max(startIndex, Math.min(endIndex, globalIdx)));
    } else {
      setHoverIndex(null);
    }
  };

  const handleMouseUp = () => {
    setIsDraggingPan(false);
    setDragStartX(null);
  };

  // Click on chart to place custom horizontal levels
  const handleChartClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (activeTool === 'horizontal') {
      const pt = getSvgPoint(e.clientX, e.clientY);
      if (pt && pt.y >= padding.top && pt.y <= padding.top + mainPlotHeight) {
        const priceRatio = 1 - (pt.y - padding.top) / mainPlotHeight;
        const price = minY + priceRatio * (maxY - minY);
        setUserLevels(prev => [...prev, Number(price.toFixed(2))]);
      }
    }
  };

  // Zoom control buttons
  const handleZoomIn = () => {
    const span = zoomRange[1] - zoomRange[0];
    const nextSpan = Math.max(0.08, span * 0.7);
    const center = (zoomRange[0] + zoomRange[1]) / 2;
    setZoomRange([Math.max(0, center - nextSpan / 2), Math.min(1, center + nextSpan / 2)]);
  };

  const handleZoomOut = () => {
    const span = zoomRange[1] - zoomRange[0];
    const nextSpan = Math.min(1.0, span * 1.4);
    const center = (zoomRange[0] + zoomRange[1]) / 2;
    setZoomRange([Math.max(0, center - nextSpan / 2), Math.min(1, center + nextSpan / 2)]);
  };

  const handleResetZoom = () => {
    if (totalPoints > 45) {
      const startRatio = Math.max(0, (totalPoints - 45) / totalPoints);
      setZoomRange([startRatio, 1]);
    } else {
      setZoomRange([0, 1]);
    }
  };

  // Landscape Mode Handler (Native Fullscreen + Virtual Rotation)
  const handleToggleLandscape = async () => {
    const willBeLandscape = !isForcedLandscape;
    setIsForcedLandscape(willBeLandscape);

    try {
      if (willBeLandscape) {
        if (modalRef.current?.requestFullscreen) {
          await modalRef.current.requestFullscreen().catch(() => {});
        }
        if (screen?.orientation?.lock) {
          await screen.orientation.lock('landscape').catch(() => {});
        }
      } else {
        if (document.fullscreenElement && document.exitFullscreen) {
          await document.exitFullscreen().catch(() => {});
        }
        if (screen?.orientation?.unlock) {
          screen.orientation.unlock();
        }
      }
    } catch {
      // Graceful fallback to virtual CSS rotation
    }
  };

  // Export SVG Snapshot
  const handleDownloadSnapshot = () => {
    const svgElement = svgRef.current;
    if (!svgElement) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgElement);
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${symbol}_TimesFM_AdvanceChart_${timeframe}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // ----------------- SVG PATH BUILDERS -----------------

  // 1. VWAP Path
  const vwapPath = useMemo(() => {
    if (!showVWAP || allCandles.length === 0) return '';
    let d = '';
    for (let i = startIndex; i <= endIndex; i++) {
      const v = vwapSeries[i];
      if (v !== undefined) {
        const x = getX(i);
        const y = getY(v);
        d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
      }
    }
    return d;
  }, [showVWAP, vwapSeries, allCandles, startIndex, endIndex, getX, getY]);

  // 2. SMA Path
  const smaPath = useMemo(() => {
    if (!showSMA || allCandles.length === 0) return '';
    let d = '';
    for (let i = startIndex; i <= endIndex; i++) {
      const v = smaSeries[i];
      if (v !== null && v !== undefined) {
        const x = getX(i);
        const y = getY(v);
        d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
      }
    }
    return d;
  }, [showSMA, smaSeries, allCandles, startIndex, endIndex, getX, getY]);

  // 3. EMA Path
  const emaPath = useMemo(() => {
    if (!showEMA || allCandles.length === 0) return '';
    let d = '';
    for (let i = startIndex; i <= endIndex; i++) {
      const v = emaSeries[i];
      if (v !== null && v !== undefined) {
        const x = getX(i);
        const y = getY(v);
        d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
      }
    }
    return d;
  }, [showEMA, emaSeries, allCandles, startIndex, endIndex, getX, getY]);

  // 4. RSI Path
  const rsiPath = useMemo(() => {
    if (!showRSI || allCandles.length === 0) return '';
    let d = '';
    for (let i = startIndex; i <= endIndex; i++) {
      const v = rsiSeries[i];
      if (v !== null && v !== undefined) {
        const x = getX(i);
        const y = getRsiY(v);
        d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
      }
    }
    return d;
  }, [showRSI, rsiSeries, allCandles, startIndex, endIndex, getX, getRsiY]);

  // 5. Bollinger Bands (Cloud + Bands)
  const bollingerPaths = useMemo(() => {
    if (!showBollinger || allCandles.length === 0) return { upper: '', lower: '', middle: '', cloud: '' };

    let upperD = '';
    let lowerD = '';
    let middleD = '';
    const upperPts: [number, number][] = [];
    const lowerPts: [number, number][] = [];

    for (let i = startIndex; i <= endIndex; i++) {
      const bb = bollingerSeries[i];
      if (!bb) continue;
      const x = getX(i);
      const uy = getY(bb.upper);
      const my = getY(bb.middle);
      const ly = getY(bb.lower);

      upperD += (upperD === '' ? `M ${x} ${uy}` : ` L ${x} ${uy}`);
      middleD += (middleD === '' ? `M ${x} ${my}` : ` L ${x} ${my}`);
      lowerD += (lowerD === '' ? `M ${x} ${ly}` : ` L ${x} ${ly}`);

      upperPts.push([x, uy]);
      lowerPts.push([x, ly]);
    }

    let cloudD = '';
    if (upperPts.length > 0) {
      cloudD = `M ${upperPts[0][0]} ${upperPts[0][1]} ` +
        upperPts.slice(1).map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' ' +
        lowerPts.slice().reverse().map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' Z';
    }

    return { upper: upperD, lower: lowerD, middle: middleD, cloud: cloudD };
  }, [showBollinger, bollingerSeries, allCandles, startIndex, endIndex, getX, getY]);

  // 6. Local baseline AI Prediction Corridor (Dual Confidence Bands: P10-P90 & P25-P75 + Median Line)
  const timesFmCorridorPaths = useMemo(() => {
    if (!showTimesFmCorridor || allCandles.length === 0) return { outerCloud: '', innerCloud: '', medianLine: '' };

    const fcIndices: number[] = [];
    for (let i = startIndex; i <= endIndex; i++) {
      if (allCandles[i]?.isForecast) fcIndices.push(i);
    }
    if (fcIndices.length === 0) return { outerCloud: '', innerCloud: '', medianLine: '' };

    // Anchor to the last actual historical candle
    const lastActualIdx = Math.max(0, fcIndices[0] - 1);
    const lastActual = allCandles[lastActualIdx];

    const outerTop: [number, number][] = [];
    const outerBottom: [number, number][] = [];
    const innerTop: [number, number][] = [];
    const innerBottom: [number, number][] = [];
    const medianPts: [number, number][] = [];

    // Anchor point
    const anchorX = getX(lastActualIdx);
    const anchorY = getY(lastActual.close);
    outerTop.push([anchorX, anchorY]);
    outerBottom.push([anchorX, anchorY]);
    innerTop.push([anchorX, anchorY]);
    innerBottom.push([anchorX, anchorY]);
    medianPts.push([anchorX, anchorY]);

    fcIndices.forEach(i => {
      const c = allCandles[i];
      const x = getX(i);
      const p10Y = getY(c.forecastP10 ?? c.low);
      const p25Y = getY(c.forecastP25 ?? c.low);
      const p50Y = getY(c.forecastP50 ?? c.forecastMean ?? c.close);
      const p75Y = getY(c.forecastP75 ?? c.high);
      const p90Y = getY(c.forecastP90 ?? c.high);

      outerTop.push([x, p90Y]);
      outerBottom.push([x, p10Y]);
      innerTop.push([x, p75Y]);
      innerBottom.push([x, p25Y]);
      medianPts.push([x, p50Y]);
    });

    const outerCloud = `M ${outerTop[0][0]} ${outerTop[0][1]} ` +
      outerTop.slice(1).map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' ' +
      outerBottom.slice().reverse().map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' Z';

    const innerCloud = `M ${innerTop[0][0]} ${innerTop[0][1]} ` +
      innerTop.slice(1).map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' ' +
      innerBottom.slice().reverse().map(p => `L ${p[0]} ${p[1]}`).join(' ') + ' Z';

    const medianLine = medianPts.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p[0]} ${p[1]}`).join(' ');

    return { outerCloud, innerCloud, medianLine };
  }, [showTimesFmCorridor, allCandles, startIndex, endIndex, getX, getY]);

  // 7. Line & Area Chart Paths
  const lineChartPath = useMemo(() => {
    let d = '';
    for (let i = startIndex; i <= endIndex; i++) {
      const c = allCandles[i];
      if (!c) continue;
      const x = getX(i);
      const y = getY(c.close);
      d += (d === '' ? `M ${x} ${y}` : ` L ${x} ${y}`);
    }
    return d;
  }, [allCandles, startIndex, endIndex, getX, getY]);

  const areaChartPath = useMemo(() => {
    if (!lineChartPath) return '';
    const firstX = getX(startIndex);
    const lastX = getX(endIndex);
    const baseY = padding.top + mainPlotHeight;
    return `${lineChartPath} L ${lastX} ${baseY} L ${firstX} ${baseY} Z`;
  }, [lineChartPath, startIndex, endIndex, getX, padding.top, mainPlotHeight]);

  // Active Hovered Candle & Metrics
  const activeCandle = hoverIndex !== null && allCandles[hoverIndex] ? allCandles[hoverIndex] : latestCandle;
  const activeVWAP = hoverIndex !== null && vwapSeries[hoverIndex] !== undefined ? vwapSeries[hoverIndex] : latestVWAP;
  const activeBB = hoverIndex !== null && bollingerSeries[hoverIndex] ? bollingerSeries[hoverIndex] : latestBollinger;
  const activeST = hoverIndex !== null && supertrendSeries[hoverIndex] ? supertrendSeries[hoverIndex] : latestSupertrend;
  const activeSMA = hoverIndex !== null && smaSeries[hoverIndex] !== undefined && smaSeries[hoverIndex] !== null ? smaSeries[hoverIndex] : latestSMA;
  const activeEMA = hoverIndex !== null && emaSeries[hoverIndex] !== undefined && emaSeries[hoverIndex] !== null ? emaSeries[hoverIndex] : latestEMA;
  const activeRSI = hoverIndex !== null && rsiSeries[hoverIndex] !== undefined && rsiSeries[hoverIndex] !== null ? rsiSeries[hoverIndex] : latestRSI;

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-0 bg-black/90 backdrop-blur-md animate-fade-in select-none"
      onClick={onClose}
    >
      <div 
        ref={modalRef}
        style={
          isForcedLandscape && deviceOrientation === 'portrait'
            ? {
                position: 'fixed',
                top: 0,
                left: '100vw',
                width: '100vh',
                height: '100vw',
                transform: 'rotate(90deg)',
                transformOrigin: 'top left',
                zIndex: 99999
              }
            : undefined
        }
        className={`bg-[#131722] border border-[#2a2e39] w-full flex flex-col shadow-2xl overflow-hidden text-[#d1d4dc] font-sans ${
          isFullscreen || (isForcedLandscape && deviceOrientation === 'portrait')
            ? 'fixed inset-0 rounded-none h-screen w-screen'
            : 'rounded-xl max-w-7xl max-h-[96vh] h-[94vh]'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* ===================== TOP BAR (TRADINGVIEW LOOK & FEEL) ===================== */}
        <div className="px-3 py-1.5 sm:px-4 sm:py-2 bg-[#1e222d] border-b border-[#2a2e39] flex flex-wrap items-center justify-between gap-2 shrink-0">
          {/* Symbol, Name & Live Price */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-7 h-7 rounded bg-[#2962ff] flex items-center justify-center text-white font-black text-xs shadow-md">
              TV
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-sm sm:text-base text-white tracking-tight">{symbol}</span>
                <span className="text-[10px] px-1 py-0.2 rounded bg-[#2a2e39] text-[#787b86] font-mono">NSE</span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/50 hidden xs:inline-flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
                  Local Forecast Baseline
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 text-xs border-l border-[#2a2e39] pl-2.5 font-mono">
              <span className="font-bold text-white">
                {currencySymbol}{cmp.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={`text-[11px] font-bold flex items-center ${isPositive ? 'text-[#089981]' : 'text-[#f23645]'}`}>
                {isPositive ? '+' : ''}{changeVal.toFixed(2)} ({isPositive ? '+' : ''}{changePct.toFixed(2)}%)
              </span>
            </div>
          </div>

          {/* Timeframe & Chart Style Pickers */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {/* Timeframe pills */}
            <div className="inline-flex rounded bg-[#131722] border border-[#2a2e39] p-0.5 text-xs">
              {(['1m', '5m', '15m', '1H', '1D', '1W'] as Timeframe[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono font-medium transition cursor-pointer ${
                    timeframe === tf 
                      ? 'bg-[#2962ff] text-white font-bold shadow-sm' 
                      : 'text-[#787b86] hover:text-[#d1d4dc] hover:bg-[#2a2e39]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>

            {/* Chart Type (Candle, Line, Area) */}
            <div className="inline-flex rounded bg-[#131722] border border-[#2a2e39] p-0.5 text-xs">
              <button
                onClick={() => setChartStyle('candles')}
                className={`p-1 rounded transition cursor-pointer ${
                  chartStyle === 'candles' ? 'bg-[#2a2e39] text-[#2962ff]' : 'text-[#787b86] hover:text-white'
                }`}
                title="Candlestick Chart"
              >
                <CandlestickChart className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setChartStyle('line')}
                className={`p-1 rounded transition cursor-pointer ${
                  chartStyle === 'line' ? 'bg-[#2a2e39] text-[#2962ff]' : 'text-[#787b86] hover:text-white'
                }`}
                title="Line Chart"
              >
                <LineChartIcon className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setChartStyle('area')}
                className={`p-1 rounded transition cursor-pointer ${
                  chartStyle === 'area' ? 'bg-[#2a2e39] text-[#2962ff]' : 'text-[#787b86] hover:text-white'
                }`}
                title="Mountain / Area Chart"
              >
                <TrendingUp className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* fx Indicators Manager Button */}
            <button
              onClick={() => setIsIndicatorsModalOpen(!isIndicatorsModalOpen)}
              className="px-2.5 py-1 rounded bg-[#131722] hover:bg-[#2a2e39] border border-[#2a2e39] hover:border-[#2962ff] text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-sm"
              title="Add / Configure Technical Indicators & TimesFM Overlays"
            >
              <span className="text-[#2962ff] font-serif font-black italic text-sm">fx</span>
              <span className="hidden sm:inline">Indicators</span>
              <span className="w-4 h-4 rounded-full bg-[#2962ff] text-[10px] font-bold flex items-center justify-center text-white">
                {[showSMA, showEMA, showRSI, showVWAP, showBollinger, showSupertrend, showPivotPoints, showVolume, showTimesFmCorridor, showQuantSetup].filter(Boolean).length}
              </span>
            </button>

            {/* Institutional Quant Setup Quick Button */}
            <div className="inline-flex items-center rounded bg-[#131722] border border-[#2a2e39] p-0.5 text-xs shadow-sm">
              <button
                onClick={() => setShowQuantSetup(!showQuantSetup)}
                className={`px-2 py-1 rounded text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                  showQuantSetup 
                    ? (quantSetupData?.isLong 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/40')
                    : 'text-[#787b86] hover:text-white hover:bg-[#2a2e39]'
                }`}
                title="Toggle Institutional Quant Trade Setup (Entry, Targets, SL)"
              >
                <Zap className={`w-3.5 h-3.5 ${showQuantSetup ? (quantSetupData?.isLong ? 'text-emerald-400 fill-emerald-400' : 'text-rose-400 fill-rose-400') : 'text-[#787b86]'}`} />
                <span className="hidden xs:inline">Quant Setup</span>
                {showQuantSetup && quantSetupData && (
                  <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-black uppercase ${
                    quantSetupData.status === 'TRADE NOW' 
                      ? 'bg-emerald-500 text-black' 
                      : quantSetupData.status === 'WAIT FOR LEVEL' 
                        ? 'bg-amber-500 text-black' 
                        : 'bg-rose-500 text-white'
                  }`}>
                    {quantSetupData.direction.includes('LONG') ? 'LONG' : 'SHORT'} • {quantSetupData.scorePct}%
                  </span>
                )}
              </button>
              
              {showQuantSetup && (
                <button
                  onClick={() => setShowQuantHud(!showQuantHud)}
                  className={`p-1 rounded transition cursor-pointer ${
                    showQuantHud ? 'text-cyan-400 hover:bg-[#2a2e39]' : 'text-[#787b86] hover:text-white'
                  }`}
                  title={showQuantHud ? 'Hide On-Chart Trade HUD' : 'Show On-Chart Trade HUD'}
                >
                  {showQuantHud ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          </div>

          {/* Right Action Controls: Zoom, Landscape/Portrait, Fullscreen, Close */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {/* Zoom Controls (+, -, Reset) */}
            <div className="inline-flex rounded bg-[#131722] border border-[#2a2e39] p-0.5 text-xs">
              <button
                onClick={handleZoomIn}
                className="p-1 rounded text-[#787b86] hover:text-white hover:bg-[#2a2e39] transition cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleZoomOut}
                className="p-1 rounded text-[#787b86] hover:text-white hover:bg-[#2a2e39] transition cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={handleResetZoom}
                className="p-1 rounded text-[#787b86] hover:text-white hover:bg-[#2a2e39] transition cursor-pointer"
                title="Reset Zoom to Recent Range"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Orientation: Landscape / Portrait Toggle */}
            <button
              onClick={handleToggleLandscape}
              className={`px-2 py-1 rounded border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm ${
                isForcedLandscape || deviceOrientation === 'landscape'
                  ? 'bg-[#2962ff] border-[#2962ff] text-white ring-2 ring-[#2962ff]/30' 
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-white hover:bg-[#2a2e39]'
              }`}
              title="Toggle Landscape / Widescreen Mode"
            >
              <RotateCw className="w-3.5 h-3.5 animate-pulse" />
              <span className="hidden xs:inline">
                {isForcedLandscape || deviceOrientation === 'landscape' ? 'Landscape (Active)' : 'Landscape'}
              </span>
            </button>

            {/* Snapshot */}
            <button
              onClick={handleDownloadSnapshot}
              className="p-1.5 rounded bg-[#131722] hover:bg-[#2a2e39] border border-[#2a2e39] text-[#787b86] hover:text-white transition cursor-pointer"
              title="Download SVG Chart Snapshot"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>

            {/* Fullscreen */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1.5 rounded bg-[#131722] hover:bg-[#2a2e39] border border-[#2a2e39] text-[#787b86] hover:text-white transition cursor-pointer"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 rounded bg-[#131722] hover:bg-[#f23645]/20 hover:text-[#f23645] border border-[#2a2e39] text-[#787b86] transition cursor-pointer"
              title="Close Advance Chart"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ===================== QUICK OVERLAY TOGGLE RIBBON ===================== */}
        <div className="px-3 py-1.5 bg-[#171b26] border-b border-[#2a2e39] flex items-center justify-between gap-2 overflow-x-auto scrollbar-none text-[11px]">
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            {/* Approximate forecast estimate toggle */}
            <button
              onClick={() => setShowTimesFmCorridor(!showTimesFmCorridor)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showTimesFmCorridor
                  ? 'bg-cyan-950/80 border-cyan-500/60 text-cyan-300 ring-1 ring-cyan-500/30'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              Approx. forecast corridor
            </button>

            {/* Forecast targets and floor */}
            {timesFmTargets && (
              <button
                onClick={() => setShowTimesFmTargets(!showTimesFmTargets)}
                className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                  showTimesFmTargets
                    ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-300 ring-1 ring-emerald-500/30'
                    : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
                }`}
              >
                <Target className="w-3 h-3 text-emerald-400" />
                Targets & Floor
              </button>
            )}

            {/* SMA 20/50 Toggle */}
            <div className="inline-flex rounded border border-[#2a2e39] bg-[#131722] overflow-hidden">
              <button
                onClick={() => setShowSMA(!showSMA)}
                className={`px-2 py-0.5 font-bold transition flex items-center gap-1 cursor-pointer ${
                  showSMA ? 'bg-[#eab308]/20 text-[#eab308]' : 'text-[#787b86] hover:text-[#d1d4dc]'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-[#eab308]" />
                SMA {smaPeriod}
              </button>
              {showSMA && (
                <button
                  onClick={() => setSmaPeriod(smaPeriod === 20 ? 50 : smaPeriod === 50 ? 200 : 20)}
                  className="px-1.5 py-0.5 border-l border-[#2a2e39] text-[9px] font-mono text-[#eab308] hover:bg-[#2a2e39] cursor-pointer"
                  title="Switch SMA Period (20, 50, 200)"
                >
                  {smaPeriod === 20 ? '50' : smaPeriod === 50 ? '200' : '20'}
                </button>
              )}
            </div>

            {/* EMA 20/50 Toggle */}
            <div className="inline-flex rounded border border-[#2a2e39] bg-[#131722] overflow-hidden">
              <button
                onClick={() => setShowEMA(!showEMA)}
                className={`px-2 py-0.5 font-bold transition flex items-center gap-1 cursor-pointer ${
                  showEMA ? 'bg-[#06b6d4]/20 text-[#06b6d4]' : 'text-[#787b86] hover:text-[#d1d4dc]'
                }`}
              >
                <span className="w-1.5 h-1.5 rounded-full bg-[#06b6d4]" />
                EMA {emaPeriod}
              </button>
              {showEMA && (
                <button
                  onClick={() => setEmaPeriod(emaPeriod === 20 ? 50 : emaPeriod === 50 ? 9 : 20)}
                  className="px-1.5 py-0.5 border-l border-[#2a2e39] text-[9px] font-mono text-[#06b6d4] hover:bg-[#2a2e39] cursor-pointer"
                  title="Switch EMA Period (9, 20, 50)"
                >
                  {emaPeriod === 20 ? '50' : emaPeriod === 50 ? '9' : '20'}
                </button>
              )}
            </div>

            {/* RSI (14) */}
            <button
              onClick={() => setShowRSI(!showRSI)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showRSI
                  ? 'bg-[#a855f7]/20 border-[#a855f7]/60 text-[#c084fc]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#a855f7]" />
              RSI (14)
            </button>

            {/* VWAP */}
            <button
              onClick={() => setShowVWAP(!showVWAP)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showVWAP
                  ? 'bg-[#f59e0b]/20 border-[#f59e0b]/60 text-[#fbbf24]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#f59e0b]" />
              VWAP
            </button>

            {/* Bollinger Bands */}
            <button
              onClick={() => setShowBollinger(!showBollinger)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showBollinger
                  ? 'bg-[#38bdf8]/20 border-[#38bdf8]/60 text-[#38bdf8]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8]" />
              BB (20,2)
            </button>

            {/* Supertrend (10, 3) */}
            <button
              onClick={() => setShowSupertrend(!showSupertrend)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showSupertrend
                  ? latestSupertrend.direction === 'UP'
                    ? 'bg-[#089981]/20 border-[#089981]/60 text-[#089981]'
                    : 'bg-[#f23645]/20 border-[#f23645]/60 text-[#f23645]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${latestSupertrend.direction === 'UP' ? 'bg-[#089981]' : 'bg-[#f23645]'}`} />
              Supertrend
            </button>

            {/* Pivots & CPR */}
            <button
              onClick={() => setShowPivotPoints(!showPivotPoints)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showPivotPoints
                  ? 'bg-[#818cf8]/20 border-[#818cf8]/60 text-[#818cf8]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#818cf8]" />
              Pivots & CPR
            </button>

            {/* Volume */}
            <button
              onClick={() => setShowVolume(!showVolume)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showVolume
                  ? 'bg-[#2962ff]/20 border-[#2962ff]/60 text-[#2962ff]'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#2962ff]" />
              Volume
            </button>

            {/* Anomalies */}
            <button
              onClick={() => setShowAnomalies(!showAnomalies)}
              className={`px-2 py-0.5 rounded border transition flex items-center gap-1 cursor-pointer font-bold ${
                showAnomalies
                  ? 'bg-amber-950/80 border-amber-500/60 text-amber-300'
                  : 'bg-[#131722] border-[#2a2e39] text-[#787b86] hover:text-[#d1d4dc]'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-amber-400" />
              Anomalies
            </button>
          </div>

          {/* Quick Stats: Zoom Range & Points visible */}
          <div className="hidden lg:flex items-center gap-2 font-mono text-[11px] text-[#787b86]">
            <span>Bars: <strong className="text-white">{visibleCount}</strong>/{totalPoints}</span>
            <span>•</span>
            <span>Zoom: <strong className="text-cyan-400">{Math.round((1 / (zoomRange[1] - zoomRange[0])) * 100)}%</strong></span>
          </div>
        </div>

        {/* ===================== HOVER VALUES STRIP ===================== */}
        <div className="px-3 py-1 bg-[#131722] border-b border-[#2a2e39] text-[11px] font-mono flex items-center justify-between gap-3 overflow-x-auto text-[#787b86]">
          <div className="flex items-center gap-3">
            <span>Date: <strong className="text-white">{activeCandle.timestamp || 'Latest'}</strong></span>
            {activeCandle.isForecast && (
              <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 text-[10px] font-bold">
                Local Forecast
              </span>
            )}
            <span>O: <strong className="text-[#d1d4dc]">{currencySymbol}{activeCandle.open.toFixed(2)}</strong></span>
            <span>H: <strong className="text-[#089981]">{currencySymbol}{activeCandle.high.toFixed(2)}</strong></span>
            <span>L: <strong className="text-[#f23645]">{currencySymbol}{activeCandle.low.toFixed(2)}</strong></span>
            <span>C: <strong className="text-white">{currencySymbol}{activeCandle.close.toFixed(2)}</strong></span>
            {showVolume && <span>Vol: <strong className="text-[#2962ff]">{activeCandle.volume.toLocaleString()}</strong></span>}
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {activeCandle.isForecast && activeCandle.forecastP50 && (
              <span>P50: <strong className="text-cyan-400">{currencySymbol}{activeCandle.forecastP50.toFixed(2)}</strong></span>
            )}
            {activeCandle.isForecast && activeCandle.forecastP90 && (
              <span>Target (P90): <strong className="text-emerald-400">{currencySymbol}{activeCandle.forecastP90.toFixed(2)}</strong></span>
            )}
            {showSMA && activeSMA !== null && <span>SMA({smaPeriod}): <strong className="text-[#eab308]">{currencySymbol}{activeSMA.toFixed(2)}</strong></span>}
            {showEMA && activeEMA !== null && <span>EMA({emaPeriod}): <strong className="text-[#06b6d4]">{currencySymbol}{activeEMA.toFixed(2)}</strong></span>}
            {showRSI && activeRSI !== null && <span>RSI(14): <strong className="text-[#c084fc]">{activeRSI.toFixed(1)}</strong></span>}
            {showVWAP && <span>VWAP: <strong className="text-[#fbbf24]">{currencySymbol}{activeVWAP.toFixed(2)}</strong></span>}
          </div>
        </div>

        {/* ===================== MAIN WORKSPACE (TOOLS + SVG VIEWPORT) ===================== */}
        <div className="flex-1 relative flex overflow-hidden bg-[#131722]">
          {/* Left Drawing Sidebar */}
          <div className="w-10 bg-[#1e222d] border-r border-[#2a2e39] flex flex-col items-center py-2 gap-1.5 shrink-0 select-none">
            <button
              onClick={() => setActiveTool('crosshair')}
              className={`p-2 rounded transition cursor-pointer ${
                activeTool === 'crosshair' ? 'bg-[#2962ff] text-white shadow-sm' : 'text-[#787b86] hover:text-white hover:bg-[#2a2e39]'
              }`}
              title="Crosshair Tool"
            >
              <CrosshairIcon className="w-4 h-4" />
            </button>

            <button
              onClick={() => setActiveTool('horizontal')}
              className={`p-2 rounded transition cursor-pointer ${
                activeTool === 'horizontal' ? 'bg-[#2962ff] text-white shadow-sm' : 'text-[#787b86] hover:text-white hover:bg-[#2a2e39]'
              }`}
              title="Place Horizontal Support/Resistance Level"
            >
              <Minus className="w-4 h-4" />
            </button>

            {userLevels.length > 0 && (
              <button
                onClick={() => setUserLevels([])}
                className="p-2 rounded text-[#f23645] hover:bg-[#2a2e39] transition cursor-pointer"
                title="Clear All Custom Drawn Levels"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            <div className="w-5 h-px bg-[#2a2e39] my-1" />

            <button
              onClick={() => setIsIndicatorsModalOpen(true)}
              className="p-2 rounded text-[#787b86] hover:text-[#2962ff] hover:bg-[#2a2e39] transition cursor-pointer"
              title="Indicators & Strategy Parameters"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>

          {/* SVG Canvas Container */}
          <div className="flex-1 relative overflow-hidden bg-[#131722] select-none flex flex-col">
            <svg
              ref={svgRef}
              className="w-full h-full cursor-crosshair"
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              preserveAspectRatio="none"
              onWheel={handleWheel}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onClick={handleChartClick}
            >
              <defs>
                {/* TimesFM Outer Corridor Gradient (P10 to P90) */}
                <linearGradient id="timesfmOuterCorridorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.22" />
                  <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.10" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.03" />
                </linearGradient>

                {/* TimesFM Inner Corridor Gradient (P25 to P75) */}
                <linearGradient id="timesfmInnerCorridorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0.12" />
                </linearGradient>

                {/* Bollinger Bands Shaded Cloud Gradient */}
                <linearGradient id="bollingerCloudGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.12" />
                  <stop offset="100%" stopColor="#818cf8" stopOpacity="0.04" />
                </linearGradient>

                {/* Mountain Area Gradient */}
                <linearGradient id="chartAreaGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2962ff" stopOpacity="0.32" />
                  <stop offset="100%" stopColor="#2962ff" stopOpacity="0.0" />
                </linearGradient>

                {/* RSI Shaded Band Gradient */}
                <linearGradient id="rsiBandGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a855f7" stopOpacity="0.18" />
                  <stop offset="100%" stopColor="#a855f7" stopOpacity="0.06" />
                </linearGradient>

                {/* Institutional Quant Entry Zone Gradient */}
                <linearGradient id="quantEntryGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0284c7" stopOpacity="0.25" />
                  <stop offset="50%" stopColor="#0ea5e9" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0.25" />
                </linearGradient>

                {/* Institutional Quant Risk Corridor Gradient (Entry to SL) */}
                <linearGradient id="quantRiskGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="0.30" />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity="0.06" />
                </linearGradient>

                {/* Institutional Quant Profit Corridor Gradient (Entry to T1) */}
                <linearGradient id="quantRewardGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.30" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="0.06" />
                </linearGradient>
              </defs>

              {/* Horizontal Gridlines & Price Scale Markers */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                const y = padding.top + ratio * mainPlotHeight;
                const val = maxY - ratio * (maxY - minY);
                return (
                  <g key={`grid_${ratio}`}>
                    <line
                      x1={padding.left}
                      y1={y}
                      x2={padding.left + plotWidth}
                      y2={y}
                      stroke="#1e222d"
                      strokeWidth="1"
                    />
                    <text
                      x={padding.left + plotWidth + 6}
                      y={y + 3.5}
                      fill="#787b86"
                      fontSize="10"
                      fontFamily="monospace"
                    >
                      {val.toFixed(2)}
                    </text>
                  </g>
                );
              })}

              {/* User Placed Custom Horizontal Lines */}
              {userLevels.map((lvl, idx) => (
                <g key={`user_lvl_${idx}`}>
                  <line
                    x1={padding.left}
                    y1={getY(lvl)}
                    x2={padding.left + plotWidth}
                    y2={getY(lvl)}
                    stroke="#f59e0b"
                    strokeWidth="1.5"
                    strokeDasharray="4 2"
                  />
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(lvl) - 8}
                    width="65"
                    height="16"
                    fill="#f59e0b"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(lvl) + 3.5}
                    fill="#000000"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    {lvl.toFixed(2)}
                  </text>
                </g>
              ))}

              {/* Bollinger Bands Cloud & Lines */}
              {showBollinger && bollingerPaths.cloud && (
                <path d={bollingerPaths.cloud} fill="url(#bollingerCloudGradient)" />
              )}
              {showBollinger && (
                <>
                  <path d={bollingerPaths.upper} fill="none" stroke="#38bdf8" strokeWidth="1.2" strokeOpacity="0.8" />
                  <path d={bollingerPaths.middle} fill="none" stroke="#818cf8" strokeWidth="1" strokeDasharray="3 3" strokeOpacity="0.6" />
                  <path d={bollingerPaths.lower} fill="none" stroke="#38bdf8" strokeWidth="1.2" strokeOpacity="0.8" />
                </>
              )}

              {/* ===================== TIMESFM BASE AI CORRIDOR LAYER ===================== */}
              {showTimesFmCorridor && timesFmCorridorPaths.outerCloud && (
                <g id="timesfm-ai-corridor">
                  {/* Outer Confidence Band (P10 - P90) */}
                  <path d={timesFmCorridorPaths.outerCloud} fill="url(#timesfmOuterCorridorGradient)" />

                  {/* Inner Confidence Band (P25 - P75) */}
                  {showTimesFmConfidence && timesFmCorridorPaths.innerCloud && (
                    <path d={timesFmCorridorPaths.innerCloud} fill="url(#timesfmInnerCorridorGradient)" />
                  )}

                  {/* Median Forecast Trajectory Line (P50) */}
                  <path 
                    d={timesFmCorridorPaths.medianLine} 
                    fill="none" 
                    stroke="#06b6d4" 
                    strokeWidth="2.5" 
                    strokeDasharray="5 3" 
                  />
                </g>
              )}

              {/* Forecast Origin Indicator (Vertical Divider between Historical & AI Predictions) */}
              {firstForecastIndex !== null && firstForecastIndex >= startIndex && firstForecastIndex <= endIndex && (
                <g id="forecast-origin">
                  <line
                    x1={getX(firstForecastIndex)}
                    y1={padding.top}
                    x2={getX(firstForecastIndex)}
                    y2={padding.top + mainPlotHeight}
                    stroke="#06b6d4"
                    strokeWidth="1.8"
                    strokeDasharray="4 4"
                  />
                  <rect
                    x={getX(firstForecastIndex) - 48}
                    y={padding.top - 18}
                    width="96"
                    height="18"
                    rx="4"
                    fill="#0f172a"
                    stroke="#06b6d4"
                    strokeWidth="1.2"
                  />
                  <text
                    x={getX(firstForecastIndex)}
                    y={padding.top - 6}
                    fill="#22d3ee"
                    fontSize="9.5"
                    fontWeight="bold"
                    textAnchor="middle"
                    fontFamily="monospace"
                  >
                    ✦ Forecast origin
                  </text>
                </g>
              )}

              {/* TimesFM Target 1, Target 2 and Floor Beacons */}
              {showTimesFmTargets && timesFmTargets && (
                <g id="timesfm-targets">
                  {/* Target 2 (P90) */}
                  <line
                    x1={padding.left}
                    y1={getY(timesFmTargets.targetP90)}
                    x2={padding.left + plotWidth}
                    y2={getY(timesFmTargets.targetP90)}
                    stroke="#10b981"
                    strokeWidth="1.2"
                    strokeDasharray="5 3"
                  />
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(timesFmTargets.targetP90) - 8}
                    width="75"
                    height="16"
                    fill="#059669"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(timesFmTargets.targetP90) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    T2: {timesFmTargets.targetP90.toFixed(1)}
                  </text>

                  {/* Target 1 (P75) */}
                  <line
                    x1={padding.left}
                    y1={getY(timesFmTargets.targetP75)}
                    x2={padding.left + plotWidth}
                    y2={getY(timesFmTargets.targetP75)}
                    stroke="#34d399"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                  />
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(timesFmTargets.targetP75) - 8}
                    width="75"
                    height="16"
                    fill="#10b981"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(timesFmTargets.targetP75) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    T1: {timesFmTargets.targetP75.toFixed(1)}
                  </text>

                  {/* Risk Floor (P10) */}
                  <line
                    x1={padding.left}
                    y1={getY(timesFmTargets.floorP10)}
                    x2={padding.left + plotWidth}
                    y2={getY(timesFmTargets.floorP10)}
                    stroke="#f43f5e"
                    strokeWidth="1.2"
                    strokeDasharray="4 3"
                  />
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(timesFmTargets.floorP10) - 8}
                    width="75"
                    height="16"
                    fill="#e11d48"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(timesFmTargets.floorP10) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    Floor: {timesFmTargets.floorP10.toFixed(1)}
                  </text>
                </g>
              )}

              {/* ===================== INSTITUTIONAL QUANTITATIVE TRADE SETUP (ENTRY, TARGETS, SL) ===================== */}
              {showQuantSetup && quantSetupData && (
                <g id="institutional-quant-setup">
                  {/* 1. Stoploss Risk Corridor Shading (between Entry and SL) */}
                  {showQuantShading && (
                    <rect
                      x={padding.left}
                      y={Math.min(getY(quantSetupData.entryAvg), getY(quantSetupData.slPrice))}
                      width={plotWidth}
                      height={Math.max(2, Math.abs(getY(quantSetupData.slPrice) - getY(quantSetupData.entryAvg)))}
                      fill="url(#quantRiskGradient)"
                    />
                  )}

                  {/* 2. Profit Corridor Shading (between Entry and Target 1) */}
                  {showQuantShading && (
                    <rect
                      x={padding.left}
                      y={Math.min(getY(quantSetupData.entryAvg), getY(quantSetupData.t1Price))}
                      width={plotWidth}
                      height={Math.max(2, Math.abs(getY(quantSetupData.t1Price) - getY(quantSetupData.entryAvg)))}
                      fill="url(#quantRewardGradient)"
                    />
                  )}

                  {/* 3. Entry Zone Band (between EntryMin and EntryMax) */}
                  {showQuantShading && (
                    <rect
                      x={padding.left}
                      y={Math.min(getY(quantSetupData.entryMin), getY(quantSetupData.entryMax))}
                      width={plotWidth}
                      height={Math.max(2, Math.abs(getY(quantSetupData.entryMax) - getY(quantSetupData.entryMin)))}
                      fill="url(#quantEntryGradient)"
                    />
                  )}

                  {/* Entry Zone Border Guidelines */}
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.entryMax)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.entryMax)}
                    stroke="#38bdf8"
                    strokeWidth="1.2"
                    strokeDasharray="4 3"
                    strokeOpacity="0.8"
                  />
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.entryMin)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.entryMin)}
                    stroke="#38bdf8"
                    strokeWidth="1.2"
                    strokeDasharray="4 3"
                    strokeOpacity="0.8"
                  />

                  {/* Central Entry Ray */}
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.entryAvg)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.entryAvg)}
                    stroke="#0284c7"
                    strokeWidth="1.8"
                    strokeDasharray="6 3"
                  />
                  {/* Left In-Chart Entry Zone Badge */}
                  <g transform={`translate(${padding.left + 8}, ${getY(quantSetupData.entryAvg) - 9})`}>
                    <rect x="0" y="0" width="146" height="18" rx="3" fill="#082f49" stroke="#38bdf8" strokeWidth="1" />
                    <text x="6" y="12.5" fill="#bae6fd" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      ⚡ ENTRY: {currencySymbol}{quantSetupData.entryMin} - {quantSetupData.entryMax}
                    </text>
                  </g>
                  {/* Right Axis Entry Tag */}
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(quantSetupData.entryAvg) - 9}
                    width="80"
                    height="18"
                    fill="#0284c7"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(quantSetupData.entryAvg) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    ENTRY {quantSetupData.entryAvg.toFixed(1)}
                  </text>

                  {/* 4. Strict Stoploss Ray */}
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.slPrice)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.slPrice)}
                    stroke="#ef4444"
                    strokeWidth="2"
                    strokeDasharray="6 3"
                  />
                  {/* Left In-Chart SL Badge */}
                  <g transform={`translate(${padding.left + 8}, ${getY(quantSetupData.slPrice) + (quantSetupData.isLong ? 5 : -23)})`}>
                    <rect x="0" y="0" width="168" height="18" rx="3" fill="#450a0a" stroke="#ef4444" strokeWidth="1" />
                    <text x="6" y="12.5" fill="#fca5a5" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      🛑 STRICT SL: {currencySymbol}{quantSetupData.slPrice.toFixed(1)} ({quantSetupData.slPct > 0 ? `-${quantSetupData.slPct}%` : `${quantSetupData.slPct}%`})
                    </text>
                  </g>
                  {/* Right Axis SL Tag */}
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(quantSetupData.slPrice) - 9}
                    width="80"
                    height="18"
                    fill="#dc2626"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(quantSetupData.slPrice) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    SL: {quantSetupData.slPrice.toFixed(1)}
                  </text>

                  {/* 5. Target 1 (T1) Ray */}
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.t1Price)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.t1Price)}
                    stroke="#10b981"
                    strokeWidth="2"
                    strokeDasharray="5 3"
                  />
                  {/* Left In-Chart T1 Badge */}
                  <g transform={`translate(${padding.left + 8}, ${getY(quantSetupData.t1Price) + (quantSetupData.isLong ? -23 : 5)})`}>
                    <rect x="0" y="0" width="175" height="18" rx="3" fill="#064e3b" stroke="#10b981" strokeWidth="1" />
                    <text x="6" y="12.5" fill="#a7f3d0" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      🎯 T1: {currencySymbol}{quantSetupData.t1Price.toFixed(1)} (+{Math.abs(quantSetupData.t1Pct)}%) • R:R 1:1.8
                    </text>
                  </g>
                  {/* Right Axis T1 Tag */}
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(quantSetupData.t1Price) - 9}
                    width="80"
                    height="18"
                    fill="#059669"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(quantSetupData.t1Price) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    T1: {quantSetupData.t1Price.toFixed(1)}
                  </text>

                  {/* 6. Target 2 (T2) Ray */}
                  <line
                    x1={padding.left}
                    y1={getY(quantSetupData.t2Price)}
                    x2={padding.left + plotWidth}
                    y2={getY(quantSetupData.t2Price)}
                    stroke="#059669"
                    strokeWidth="1.8"
                    strokeDasharray="6 3"
                  />
                  {/* Left In-Chart T2 Badge */}
                  <g transform={`translate(${padding.left + 8}, ${getY(quantSetupData.t2Price) + (quantSetupData.isLong ? -23 : 5)})`}>
                    <rect x="0" y="0" width="175" height="18" rx="3" fill="#064e3b" stroke="#059669" strokeWidth="1" />
                    <text x="6" y="12.5" fill="#6ee7b7" fontSize="9" fontWeight="bold" fontFamily="monospace">
                      🚀 T2: {currencySymbol}{quantSetupData.t2Price.toFixed(1)} (+{Math.abs(quantSetupData.t2Pct)}%) • R:R 1:2.8
                    </text>
                  </g>
                  {/* Right Axis T2 Tag */}
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(quantSetupData.t2Price) - 9}
                    width="80"
                    height="18"
                    fill="#047857"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 4}
                    y={getY(quantSetupData.t2Price) + 3.5}
                    fill="#ffffff"
                    fontSize="9"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    T2: {quantSetupData.t2Price.toFixed(1)}
                  </text>

                  {/* 7. Optional Target 3 (T3) Ray */}
                  {quantSetupData.t3Price && (
                    <g id="quant-target-3">
                      <line
                        x1={padding.left}
                        y1={getY(quantSetupData.t3Price)}
                        x2={padding.left + plotWidth}
                        y2={getY(quantSetupData.t3Price)}
                        stroke="#8b5cf6"
                        strokeWidth="1.5"
                        strokeDasharray="4 4"
                      />
                      <g transform={`translate(${padding.left + 8}, ${getY(quantSetupData.t3Price) + (quantSetupData.isLong ? -23 : 5)})`}>
                        <rect x="0" y="0" width="150" height="18" rx="3" fill="#2e1065" stroke="#8b5cf6" strokeWidth="1" />
                        <text x="6" y="12.5" fill="#ddd6fe" fontSize="9" fontWeight="bold" fontFamily="monospace">
                          ✦ T3: {currencySymbol}{quantSetupData.t3Price.toFixed(1)} (+{quantSetupData.t3Pct}%)
                        </text>
                      </g>
                      <rect
                        x={padding.left + plotWidth}
                        y={getY(quantSetupData.t3Price) - 9}
                        width="80"
                        height="18"
                        fill="#7c3aed"
                        rx="2"
                      />
                      <text
                        x={padding.left + plotWidth + 4}
                        y={getY(quantSetupData.t3Price) + 3.5}
                        fill="#ffffff"
                        fontSize="9"
                        fontFamily="monospace"
                        fontWeight="bold"
                      >
                        T3: {quantSetupData.t3Price.toFixed(1)}
                      </text>
                    </g>
                  )}
                </g>
              )}

              {/* Pivot Points & CPR Horizontal Lines */}
              {showPivotPoints && (
                <g id="pivot-lines">
                  <line x1={padding.left} y1={getY(pivotLevels.tc)} x2={padding.left + plotWidth} y2={getY(pivotLevels.tc)} stroke="#a855f7" strokeWidth="1" strokeDasharray="3 3" />
                  <text x={padding.left + plotWidth + 4} y={getY(pivotLevels.tc) + 3} fill="#c084fc" fontSize="9" fontFamily="monospace">TC {pivotLevels.tc}</text>

                  <line x1={padding.left} y1={getY(pivotLevels.pivot)} x2={padding.left + plotWidth} y2={getY(pivotLevels.pivot)} stroke="#d946ef" strokeWidth="1.5" />
                  <text x={padding.left + plotWidth + 4} y={getY(pivotLevels.pivot) + 3} fill="#e879f9" fontSize="9" fontFamily="monospace" fontWeight="bold">P {pivotLevels.pivot}</text>

                  <line x1={padding.left} y1={getY(pivotLevels.bc)} x2={padding.left + plotWidth} y2={getY(pivotLevels.bc)} stroke="#a855f7" strokeWidth="1" strokeDasharray="3 3" />
                  <text x={padding.left + plotWidth + 4} y={getY(pivotLevels.bc) + 3} fill="#c084fc" fontSize="9" fontFamily="monospace">BC {pivotLevels.bc}</text>

                  <line x1={padding.left} y1={getY(pivotLevels.r1)} x2={padding.left + plotWidth} y2={getY(pivotLevels.r1)} stroke="#f23645" strokeWidth="1" strokeDasharray="2 2" />
                  <text x={padding.left + plotWidth + 4} y={getY(pivotLevels.r1) + 3} fill="#f87171" fontSize="9" fontFamily="monospace">R1 {pivotLevels.r1}</text>

                  <line x1={padding.left} y1={getY(pivotLevels.s1)} x2={padding.left + plotWidth} y2={getY(pivotLevels.s1)} stroke="#089981" strokeWidth="1" strokeDasharray="2 2" />
                  <text x={padding.left + plotWidth + 4} y={getY(pivotLevels.s1) + 3} fill="#34d399" fontSize="9" fontFamily="monospace">S1 {pivotLevels.s1}</text>
                </g>
              )}

              {/* Key Levels: Day High, Day Low */}
              {showKeyLevels && (
                <g id="key-levels">
                  <line x1={padding.left} y1={getY(pivotLevels.dayHigh)} x2={padding.left + plotWidth} y2={getY(pivotLevels.dayHigh)} stroke="#38bdf8" strokeWidth="1" strokeDasharray="6 3" />
                  <text x={padding.left + 5} y={getY(pivotLevels.dayHigh) - 4} fill="#38bdf8" fontSize="9" fontFamily="monospace" fontWeight="bold">Day High: {currencySymbol}{pivotLevels.dayHigh}</text>

                  <line x1={padding.left} y1={getY(pivotLevels.dayLow)} x2={padding.left + plotWidth} y2={getY(pivotLevels.dayLow)} stroke="#fb7185" strokeWidth="1" strokeDasharray="6 3" />
                  <text x={padding.left + 5} y={getY(pivotLevels.dayLow) + 11} fill="#fb7185" fontSize="9" fontFamily="monospace" fontWeight="bold">Day Low: {currencySymbol}{pivotLevels.dayLow}</text>
                </g>
              )}

              {/* Area Chart Mode */}
              {chartStyle === 'area' && (
                <>
                  <path d={areaChartPath} fill="url(#chartAreaGradient)" />
                  <path d={lineChartPath} fill="none" stroke="#2962ff" strokeWidth="2.2" />
                </>
              )}

              {/* Line Chart Mode */}
              {chartStyle === 'line' && (
                <path d={lineChartPath} fill="none" stroke="#2962ff" strokeWidth="2.2" />
              )}

              {/* Candlesticks Mode */}
              {chartStyle === 'candles' && (
                <g id="candlesticks">
                  {allCandles.slice(startIndex, endIndex + 1).map((c, idx) => {
                    const i = startIndex + idx;
                    const x = getX(i);
                    const isUp = c.close >= c.open;
                    const candleColor = c.isForecast 
                      ? (isUp ? '#06b6d4' : '#ec4899') 
                      : (isUp ? '#089981' : '#f23645');

                    const wickTop = getY(c.high);
                    const wickBottom = getY(c.low);
                    const bodyTop = getY(Math.max(c.open, c.close));
                    const bodyBottom = getY(Math.min(c.open, c.close));
                    const bodyHeight = Math.max(1.8, bodyBottom - bodyTop);
                    const candleWidth = Math.max(3.5, Math.min(14, (plotWidth / visibleCount) * 0.72));

                    return (
                      <g key={`candle_${i}`}>
                        <line x1={x} y1={wickTop} x2={x} y2={wickBottom} stroke={candleColor} strokeWidth="1.2" />
                        <rect
                          x={x - candleWidth / 2}
                          y={bodyTop}
                          width={candleWidth}
                          height={bodyHeight}
                          fill={c.isForecast ? 'none' : candleColor}
                          stroke={candleColor}
                          strokeWidth="1.2"
                          strokeDasharray={c.isForecast ? '2 2' : undefined}
                          rx="0.5"
                        />

                        {/* Forecast point dot marker on median */}
                        {c.isForecast && (
                          <circle
                            cx={x}
                            cy={getY(c.forecastP50 ?? c.forecastMean ?? c.close)}
                            r="2.5"
                            fill="#06b6d4"
                            stroke="#ecfeff"
                            strokeWidth="1"
                          />
                        )}

                        {/* Anomaly Beacon Ring */}
                        {showAnomalies && c.isAnomaly && (
                          <g>
                            <circle
                              cx={x}
                              cy={getY(c.high) - 8}
                              r="5"
                              fill="#ef4444"
                              fillOpacity="0.8"
                              className="animate-ping"
                            />
                            <circle
                              cx={x}
                              cy={getY(c.high) - 8}
                              r="3.5"
                              fill="#ef4444"
                              stroke="#ffffff"
                              strokeWidth="1"
                            />
                          </g>
                        )}
                      </g>
                    );
                  })}
                </g>
              )}

              {/* SMA Line */}
              {showSMA && smaPath && (
                <path d={smaPath} fill="none" stroke="#eab308" strokeWidth="2.2" />
              )}

              {/* EMA Line */}
              {showEMA && emaPath && (
                <path d={emaPath} fill="none" stroke="#06b6d4" strokeWidth="2.2" />
              )}

              {/* Supertrend Line & Signals */}
              {showSupertrend && (
                <g id="supertrend-line">
                  {supertrendSeries.slice(startIndex, endIndex + 1).map((st, idx) => {
                    const i = startIndex + idx;
                    if (i === 0) return null;
                    const prev = supertrendSeries[i - 1];
                    const x1 = getX(i - 1);
                    const y1 = getY(prev.supertrend);
                    const x2 = getX(i);
                    const y2 = getY(st.supertrend);
                    const strokeColor = st.direction === 'UP' ? '#089981' : '#f23645';

                    return (
                      <g key={`st_${i}`}>
                        <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={strokeColor} strokeWidth="2.2" />
                        {st.signal === 'BUY' && <circle cx={x2} cy={y2 + 8} r="3.5" fill="#089981" />}
                        {st.signal === 'SELL' && <circle cx={x2} cy={y2 - 8} r="3.5" fill="#f23645" />}
                      </g>
                    );
                  })}
                </g>
              )}

              {/* VWAP Overlay Line */}
              {showVWAP && vwapPath && (
                <path d={vwapPath} fill="none" stroke="#f59e0b" strokeWidth="2.2" />
              )}

              {/* Current Close Price Tag on Right Axis */}
              <g id="cmp-tag">
                <line
                  x1={padding.left}
                  y1={getY(cmp)}
                  x2={padding.left + plotWidth}
                  y2={getY(cmp)}
                  stroke={isPositive ? '#089981' : '#f23645'}
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                <rect
                  x={padding.left + plotWidth}
                  y={getY(cmp) - 9}
                  width="75"
                  height="18"
                  fill={isPositive ? '#089981' : '#f23645'}
                  rx="2"
                />
                <text
                  x={padding.left + plotWidth + 6}
                  y={getY(cmp) + 3.5}
                  fill="#ffffff"
                  fontSize="10"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {cmp.toFixed(2)}
                </text>
              </g>

              {/* ===================== VOLUME SUB-PANE ===================== */}
              {showVolume && (
                <g id="volume-pane">
                  <line x1={padding.left} y1={volumeBaseY} x2={padding.left + plotWidth} y2={volumeBaseY} stroke="#2a2e39" strokeWidth="1" />
                  <text x={padding.left + 4} y={volumeBaseY + 12} fill="#787b86" fontSize="9" fontFamily="monospace" fontWeight="bold">
                    Vol 20 SMA
                  </text>

                  {allCandles.slice(startIndex, endIndex + 1).map((c, idx) => {
                    const i = startIndex + idx;
                    const x = getX(i);
                    const isUp = c.close >= c.open;
                    const barTop = getVolY(c.volume);
                    const barBottom = volumeBaseY + volumeHeight;
                    const barHeight = Math.max(1.5, barBottom - barTop);
                    const barWidth = Math.max(2.5, Math.min(10, (plotWidth / visibleCount) * 0.65));

                    return (
                      <rect
                        key={`vol_${i}`}
                        x={x - barWidth / 2}
                        y={barTop}
                        width={barWidth}
                        height={barHeight}
                        fill={isUp ? '#089981' : '#f23645'}
                        fillOpacity="0.55"
                      />
                    );
                  })}

                  {volumeSmaSeries.slice(startIndex, endIndex + 1).map((vma, idx) => {
                    const i = startIndex + idx;
                    if (i === 0) return null;
                    const x1 = getX(i - 1);
                    const y1 = getVolY(volumeSmaSeries[i - 1]);
                    const x2 = getX(i);
                    const y2 = getVolY(vma);
                    return <line key={`vma_${i}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#fbbf24" strokeWidth="1" />;
                  })}
                </g>
              )}

              {/* ===================== RSI (14) OSCILLATOR SUB-PANE ===================== */}
              {showRSI && (
                <g id="rsi-pane">
                  <line x1={padding.left} y1={rsiBaseY} x2={padding.left + plotWidth} y2={rsiBaseY} stroke="#2a2e39" strokeWidth="1" />
                  <text x={padding.left + 4} y={rsiBaseY + 12} fill="#c084fc" fontSize="9" fontFamily="monospace" fontWeight="bold">
                    RSI (14): {activeRSI.toFixed(1)}
                  </text>

                  {/* 70-30 Shaded Band */}
                  <rect
                    x={padding.left}
                    y={getRsiY(70)}
                    width={plotWidth}
                    height={Math.max(1, getRsiY(30) - getRsiY(70))}
                    fill="url(#rsiBandGradient)"
                  />

                  {/* 70 Overbought */}
                  <line x1={padding.left} y1={getRsiY(70)} x2={padding.left + plotWidth} y2={getRsiY(70)} stroke="#f23645" strokeWidth="1" strokeDasharray="3 3" strokeOpacity="0.7" />
                  <text x={padding.left + plotWidth + 4} y={getRsiY(70) + 3} fill="#f23645" fontSize="8" fontFamily="monospace">70</text>

                  {/* 50 Center */}
                  <line x1={padding.left} y1={getRsiY(50)} x2={padding.left + plotWidth} y2={getRsiY(50)} stroke="#475569" strokeWidth="1" strokeDasharray="2 2" />

                  {/* 30 Oversold */}
                  <line x1={padding.left} y1={getRsiY(30)} x2={padding.left + plotWidth} y2={getRsiY(30)} stroke="#089981" strokeWidth="1" strokeDasharray="3 3" strokeOpacity="0.7" />
                  <text x={padding.left + plotWidth + 4} y={getRsiY(30) + 3} fill="#089981" fontSize="8" fontFamily="monospace">30</text>

                  {/* RSI Line */}
                  {rsiPath && <path d={rsiPath} fill="none" stroke="#a855f7" strokeWidth="2" />}

                  {/* RSI Right Axis Badge */}
                  <rect x={padding.left + plotWidth} y={getRsiY(latestRSI) - 7} width="45" height="14" fill="#a855f7" rx="2" />
                  <text x={padding.left + plotWidth + 4} y={getRsiY(latestRSI) + 3} fill="#ffffff" fontSize="9" fontFamily="monospace" fontWeight="bold">
                    {latestRSI.toFixed(1)}
                  </text>
                </g>
              )}

              {/* ===================== CROSSHAIR & HOVER CURSOR ===================== */}
              {hoverIndex !== null && allCandles[hoverIndex] && (
                <g id="crosshair">
                  <line
                    x1={getX(hoverIndex)}
                    y1={padding.top}
                    x2={getX(hoverIndex)}
                    y2={svgHeight - padding.bottom}
                    stroke="#2962ff"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                  />
                  <line
                    x1={padding.left}
                    y1={getY(allCandles[hoverIndex].close)}
                    x2={padding.left + plotWidth}
                    y2={getY(allCandles[hoverIndex].close)}
                    stroke="#2962ff"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                  />
                  <rect
                    x={padding.left + plotWidth}
                    y={getY(allCandles[hoverIndex].close) - 9}
                    width="75"
                    height="18"
                    fill="#2962ff"
                    rx="2"
                  />
                  <text
                    x={padding.left + plotWidth + 6}
                    y={getY(allCandles[hoverIndex].close) + 3.5}
                    fill="#ffffff"
                    fontSize="10"
                    fontFamily="monospace"
                    fontWeight="bold"
                  >
                    {allCandles[hoverIndex].close.toFixed(2)}
                  </text>
                </g>
              )}
            </svg>

            {/* ===================== FLOATING INSTITUTIONAL QUANT SETUP HUD CARD ===================== */}
            {showQuantSetup && quantSetupData && showQuantHud && (
              <div className="absolute top-3 left-3 z-20 pointer-events-auto transition-all max-w-[320px] sm:max-w-xs shadow-2xl">
                <div className="bg-[#181d28]/95 backdrop-blur-md rounded-xl border border-slate-700/80 p-3 text-white space-y-2.5 shadow-2xl">
                  {/* Header with Direction, Status, and Controls */}
                  <div className="flex items-center justify-between gap-1 border-b border-slate-700/60 pb-2">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <div className={`p-1 rounded-md ${quantSetupData.isLong ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                        <Zap className="w-3.5 h-3.5 fill-current" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-black text-xs tracking-wide">QUANT SETUP</span>
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                            quantSetupData.isLong ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/30 text-rose-300 border border-rose-500/40'
                          }`}>
                            {quantSetupData.direction}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          Score: <strong className="text-cyan-400">{quantSetupData.scorePct}%</strong> • R:R: <strong className="text-emerald-400">{quantSetupData.riskRewardText}</strong>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => setIsQuantHudMinimized(!isQuantHudMinimized)}
                        className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
                        title={isQuantHudMinimized ? "Expand Details" : "Minimize Card"}
                      >
                        {isQuantHudMinimized ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => setShowQuantHud(false)}
                        className="p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer"
                        title="Close Card Overlay"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Horizon selector pills */}
                  <div className="grid grid-cols-3 gap-1 bg-[#10141e] p-1 rounded-lg border border-slate-800 text-[10px]">
                    {(['Intraday (5m/15m)', 'Swing (3–4 Days)', 'Positional (1–2 Months)'] as QuantHorizon[]).map((hz) => (
                      <button
                        key={hz}
                        onClick={() => setQuantHorizon(hz)}
                        className={`py-0.5 px-1 rounded text-center truncate font-semibold transition cursor-pointer ${
                          quantHorizon === hz
                            ? 'bg-[#2962ff] text-white shadow-sm'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800'
                        }`}
                        title={hz}
                      >
                        {hz.split(' ')[0]}
                      </button>
                    ))}
                  </div>

                  {/* Main Trade Targets & Stoploss Grid */}
                  {!isQuantHudMinimized && (
                    <div className="space-y-2 pt-0.5 text-xs">
                      {/* Status Badge */}
                      <div className="flex items-center justify-between bg-slate-900/80 px-2.5 py-1.5 rounded-lg border border-slate-800">
                        <span className="text-[11px] text-slate-400">Execution Call</span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                          quantSetupData.status === 'TRADE NOW'
                            ? 'bg-emerald-500 text-black shadow-sm shadow-emerald-500/20'
                            : quantSetupData.status === 'WAIT FOR LEVEL'
                              ? 'bg-amber-500 text-black'
                              : 'bg-rose-500 text-white'
                        }`}>
                          {quantSetupData.status}
                        </span>
                      </div>

                      {/* Entry Range */}
                      <div className="p-2 rounded-lg bg-sky-950/30 border border-sky-800/40 flex items-center justify-between">
                        <div>
                          <div className="text-[10px] uppercase font-bold text-sky-400 flex items-center gap-1">
                            <CrosshairIcon className="w-3 h-3" />
                            <span>Entry Zone</span>
                          </div>
                          <div className="text-[10px] text-slate-400">Optimal fill bracket</div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-black text-sm text-sky-300">
                            {currencySymbol}{quantSetupData.entryMin} – {quantSetupData.entryMax}
                          </div>
                          <div className="text-[10px] text-sky-400/80 font-mono">
                            Avg: {currencySymbol}{quantSetupData.entryAvg}
                          </div>
                        </div>
                      </div>

                      {/* Strict Stoploss */}
                      <div className="p-2 rounded-lg bg-rose-950/30 border border-rose-800/40 flex items-center justify-between">
                        <div>
                          <div className="text-[10px] uppercase font-bold text-rose-400 flex items-center gap-1">
                            <ShieldAlert className="w-3 h-3" />
                            <span>Strict Stoploss</span>
                          </div>
                          <div className="text-[9px] text-slate-400 truncate max-w-[120px]" title={quantSetupData.slBasis}>
                            {quantSetupData.slBasis}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-black text-sm text-rose-400">
                            {currencySymbol}{quantSetupData.slPrice.toFixed(1)}
                          </div>
                          <div className="text-[10px] text-rose-400 font-mono font-bold">
                            {quantSetupData.slPct > 0 ? `-${quantSetupData.slPct}%` : `${quantSetupData.slPct}%`}
                          </div>
                        </div>
                      </div>

                      {/* Targets: T1 & T2 */}
                      <div className="grid grid-cols-2 gap-1.5">
                        {/* Target 1 */}
                        <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
                          <div className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                            <Target className="w-3 h-3" />
                            <span>Target 1 (T1)</span>
                          </div>
                          <div className="font-mono font-black text-sm text-emerald-300 mt-0.5">
                            {currencySymbol}{quantSetupData.t1Price.toFixed(1)}
                          </div>
                          <div className="text-[10px] text-emerald-400 font-mono font-semibold">
                            +{Math.abs(quantSetupData.t1Pct)}% • R:R 1:1.8
                          </div>
                        </div>

                        {/* Target 2 */}
                        <div className="p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/40">
                          <div className="text-[10px] uppercase font-bold text-emerald-300 flex items-center gap-1">
                            <TrendingUp className="w-3 h-3" />
                            <span>Target 2 (T2)</span>
                          </div>
                          <div className="font-mono font-black text-sm text-emerald-200 mt-0.5">
                            {currencySymbol}{quantSetupData.t2Price.toFixed(1)}
                          </div>
                          <div className="text-[10px] text-emerald-300 font-mono font-semibold">
                            +{Math.abs(quantSetupData.t2Pct)}% • R:R 1:2.8
                          </div>
                        </div>
                      </div>

                      {/* Action Trigger / Core Driver */}
                      <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800 text-[10px] text-slate-300 leading-relaxed">
                        <span className="font-bold text-amber-400">Trigger: </span>
                        {quantSetupData.directNichod.actionTrigger}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ===================== MINI-MAP BRUSH TIMELINE SLIDER (LIKE TIMESFM CHART) ===================== */}
        <div className="px-3 py-1.5 bg-[#171b26] border-t border-[#2a2e39] flex flex-col gap-1 shrink-0 select-none">
          <div className="flex items-center justify-between text-[10px] font-mono text-[#787b86]">
            <span>{allCandles[0]?.timestamp || ''}</span>
            <span className="text-white font-bold">Timeline Mini-Map & Drag Window</span>
            <span>{allCandles[allCandles.length - 1]?.timestamp || ''}</span>
          </div>

          <div className="relative w-full h-7 bg-[#131722] rounded border border-[#2a2e39] overflow-hidden">
            {/* Background SVG Sparkline Thumbnail */}
            <svg className="w-full h-full" preserveAspectRatio="none" viewBox={`0 0 ${totalPoints} 100`}>
              <path
                d={allCandles.map((c, i) => `${i === 0 ? 'M' : 'L'} ${i} ${100 - ((c.close - minY) / (maxY - minY || 1)) * 100}`).join(' ')}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="1.5"
                strokeOpacity="0.4"
              />
            </svg>

            {/* Draggable Active Viewport Window */}
            <div
              style={{
                left: `${zoomRange[0] * 100}%`,
                width: `${(zoomRange[1] - zoomRange[0]) * 100}%`
              }}
              className="absolute inset-y-0 bg-[#2962ff]/20 border-x-2 border-[#2962ff] flex items-center justify-between cursor-grab active:cursor-grabbing"
              onMouseDown={(e) => {
                setIsBrushDragging('window');
                setBrushStartX(e.clientX);
                setBrushStartRange([...zoomRange]);
              }}
            >
              <div className="w-1.5 h-full bg-[#2962ff] cursor-ew-resize opacity-80 hover:opacity-100" />
              <div className="w-1.5 h-full bg-[#2962ff] cursor-ew-resize opacity-80 hover:opacity-100" />
            </div>
          </div>
        </div>

        {/* ===================== INDICATORS MODAL / PARAMETER SETTINGS DRAWER ===================== */}
        {isIndicatorsModalOpen && (
          <div 
            className="absolute inset-0 bg-black/75 backdrop-blur-md z-40 flex items-center justify-center p-4 animate-fade-in"
            onClick={() => setIsIndicatorsModalOpen(false)}
          >
            <div 
              className="bg-[#1e222d] border border-[#2a2e39] rounded-xl max-w-lg w-full p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex items-center justify-between border-b border-[#2a2e39] pb-3 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-[#2962ff] font-serif font-black italic text-xl">fx</span>
                  <h3 className="font-extrabold text-white text-base">Indicators & Forecast Overlays</h3>
                </div>
                <button
                  onClick={() => setIsIndicatorsModalOpen(false)}
                  className="p-1 rounded text-[#787b86] hover:text-white hover:bg-[#2a2e39] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-3 overflow-y-auto pr-1 flex-1">
                {/* 0. Institutional Quantitative Trade Setup (Entry, Targets, Stoploss) */}
                <div className="p-3 rounded-lg bg-[#131722] border border-emerald-500/50 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-emerald-400 fill-emerald-400" />
                      <div>
                        <div className="font-bold text-white text-sm flex items-center gap-1.5">
                          <span>Institutional Quant Trade Setup</span>
                          {quantSetupData && (
                            <span className={`px-1.5 py-0.2 text-[10px] rounded font-black uppercase ${
                              quantSetupData.status === 'TRADE NOW' ? 'bg-emerald-500 text-black' : 'bg-amber-500 text-black'
                            }`}>
                              {quantSetupData.status}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#787b86]">
                          Entry Bracket, Strict Stoploss & Targets (T1/T2) with Risk-Reward Engine
                        </div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={showQuantSetup}
                      onChange={e => setShowQuantSetup(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-500 cursor-pointer"
                    />
                  </div>

                  {showQuantSetup && (
                    <div className="pt-2 border-t border-[#2a2e39] space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-[#787b86]">Trade Horizon:</span>
                        <div className="flex items-center gap-1">
                          {(['Intraday (5m/15m)', 'Swing (3–4 Days)', 'Positional (1–2 Months)'] as QuantHorizon[]).map((hz) => (
                            <button
                              key={hz}
                              onClick={() => setQuantHorizon(hz)}
                              className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold cursor-pointer transition ${
                                quantHorizon === hz ? 'bg-emerald-500 text-black' : 'bg-[#2a2e39] text-white hover:bg-slate-700'
                              }`}
                            >
                              {hz.split(' ')[0]}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[#787b86]">Risk / Reward Corridor Shading</span>
                        <input
                          type="checkbox"
                          checked={showQuantShading}
                          onChange={e => setShowQuantShading(e.target.checked)}
                          className="w-3.5 h-3.5 rounded text-emerald-500 cursor-pointer"
                        />
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <span className="text-[#787b86]">Show Floating On-Chart HUD Card</span>
                        <input
                          type="checkbox"
                          checked={showQuantHud}
                          onChange={e => setShowQuantHud(e.target.checked)}
                          className="w-3.5 h-3.5 rounded text-emerald-500 cursor-pointer"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* 1. Local baseline AI Corridor */}
                <div className="p-3 rounded-lg bg-[#131722] border border-cyan-800/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <div>
                        <div className="font-bold text-white text-sm">Local Forecast Corridor</div>
                        <div className="text-[11px] text-[#787b86]">P10, P50 Median, and P90 Trajectory Envelope</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={showTimesFmCorridor}
                      onChange={e => setShowTimesFmCorridor(e.target.checked)}
                      className="w-4 h-4 rounded text-cyan-500 cursor-pointer"
                    />
                  </div>
                </div>

                {/* 2. SMA (Simple Moving Average) */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-[#eab308]" />
                      <div>
                        <div className="font-bold text-white text-sm">SMA (Simple Moving Average)</div>
                        <div className="text-[11px] text-[#787b86]">Classic trend line (Yellow)</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={showSMA}
                      onChange={e => setShowSMA(e.target.checked)}
                      className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                    />
                  </div>
                  {showSMA && (
                    <div className="flex items-center gap-2 pt-1 border-t border-[#2a2e39] text-xs">
                      <span className="text-[#787b86]">Period:</span>
                      {[20, 50, 100, 200].map(p => (
                        <button
                          key={p}
                          onClick={() => setSmaPeriod(p)}
                          className={`px-2 py-0.5 rounded text-xs font-mono font-bold cursor-pointer ${
                            smaPeriod === p ? 'bg-[#eab308] text-black' : 'bg-[#2a2e39] text-white hover:bg-slate-700'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 3. EMA (Exponential Moving Average) */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full bg-[#06b6d4]" />
                      <div>
                        <div className="font-bold text-white text-sm">EMA (Exponential Moving Average)</div>
                        <div className="text-[11px] text-[#787b86]">Responsive momentum average (Cyan)</div>
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={showEMA}
                      onChange={e => setShowEMA(e.target.checked)}
                      className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                    />
                  </div>
                  {showEMA && (
                    <div className="flex items-center gap-2 pt-1 border-t border-[#2a2e39] text-xs">
                      <span className="text-[#787b86]">Period:</span>
                      {[9, 20, 50, 200].map(p => (
                        <button
                          key={p}
                          onClick={() => setEmaPeriod(p)}
                          className={`px-2 py-0.5 rounded text-xs font-mono font-bold cursor-pointer ${
                            emaPeriod === p ? 'bg-[#06b6d4] text-black' : 'bg-[#2a2e39] text-white hover:bg-slate-700'
                          }`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 4. RSI (14) Oscillator */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#a855f7]" />
                    <div>
                      <div className="font-bold text-white text-sm">RSI (Relative Strength Index)</div>
                      <div className="text-[11px] text-[#787b86]">14-period momentum pane with 70/30 thresholds</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showRSI}
                    onChange={e => setShowRSI(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>

                {/* 5. VWAP */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#f59e0b]" />
                    <div>
                      <div className="font-bold text-white text-sm">VWAP (Volume Weighted Average Price)</div>
                      <div className="text-[11px] text-[#787b86]">Institutional benchmark ray</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showVWAP}
                    onChange={e => setShowVWAP(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>

                {/* 6. Bollinger Bands */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#38bdf8]" />
                    <div>
                      <div className="font-bold text-white text-sm">Bollinger Bands (20, 2)</div>
                      <div className="text-[11px] text-[#787b86]">Volatility envelope & reversion cloud</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showBollinger}
                    onChange={e => setShowBollinger(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>

                {/* 7. Supertrend (10, 3) */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#089981]" />
                    <div>
                      <div className="font-bold text-white text-sm">Supertrend (10, 3)</div>
                      <div className="text-[11px] text-[#787b86]">Trailing trend stop with Buy/Sell markers</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showSupertrend}
                    onChange={e => setShowSupertrend(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>

                {/* 8. Pivot Points & CPR */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#818cf8]" />
                    <div>
                      <div className="font-bold text-white text-sm">Pivot Points & CPR</div>
                      <div className="text-[11px] text-[#787b86]">Floor Pivots (TC, Pivot, BC, R1-R2, S1-S2)</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showPivotPoints}
                    onChange={e => setShowPivotPoints(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>

                {/* 9. Volume Histogram */}
                <div className="p-3 rounded-lg bg-[#131722] border border-[#2a2e39] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-[#2962ff]" />
                    <div>
                      <div className="font-bold text-white text-sm">Volume Sub-Pane</div>
                      <div className="text-[11px] text-[#787b86]">Volume bars + 20-period SMA line</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={showVolume}
                    onChange={e => setShowVolume(e.target.checked)}
                    className="w-4 h-4 rounded text-[#2962ff] cursor-pointer"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2a2e39] shrink-0">
                <button
                  onClick={() => setIsIndicatorsModalOpen(false)}
                  className="px-5 py-2 rounded-lg bg-[#2962ff] hover:bg-[#1e53e5] text-white font-bold text-xs shadow-md transition cursor-pointer"
                >
                  Apply & Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===================== FOOTER BAR ===================== */}
        <div className="px-3 py-1.5 bg-[#1e222d] border-t border-[#2a2e39] flex flex-wrap items-center justify-between gap-2 text-xs shrink-0 font-mono">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-[11px] text-[#787b86]">
            <span className="text-white font-semibold">
              Model: <strong className="text-cyan-400">local statistical baseline</strong>
            </span>
            <span>•</span>
            <span>CPR: <strong className="text-purple-300">{pivotLevels.cprTrendBias} ({pivotLevels.cprWidth})</strong></span>
            <span>•</span>
            <span>Supertrend: <strong className={latestSupertrend.direction === 'UP' ? 'text-[#089981]' : 'text-[#f23645]'}>{latestSupertrend.direction}</strong></span>
            {timesFmTargets && (
              <>
                <span>•</span>
                <span>T1: <strong className="text-emerald-400">{currencySymbol}{timesFmTargets.targetP75.toFixed(1)}</strong></span>
                <span>•</span>
                <span>T2: <strong className="text-emerald-400">{currencySymbol}{timesFmTargets.targetP90.toFixed(1)}</strong></span>
              </>
            )}
            {showQuantSetup && quantSetupData && (
              <>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Zap className="w-3 h-3 text-emerald-400 fill-emerald-400 inline" />
                  <span>Setup: <strong className={quantSetupData.isLong ? "text-emerald-400" : "text-rose-400"}>{quantSetupData.direction}</strong></span>
                </span>
                <span>•</span>
                <span>Entry: <strong className="text-sky-300">{currencySymbol}{quantSetupData.entryMin}-{quantSetupData.entryMax}</strong></span>
                <span>•</span>
                <span>SL: <strong className="text-rose-400">{currencySymbol}{quantSetupData.slPrice.toFixed(1)} ({quantSetupData.slPct > 0 ? `-${quantSetupData.slPct}%` : `${quantSetupData.slPct}%`})</strong></span>
                <span>•</span>
                <span>T1: <strong className="text-emerald-400">{currencySymbol}{quantSetupData.t1Price.toFixed(1)} (+{Math.abs(quantSetupData.t1Pct)}%)</strong></span>
                <span>•</span>
                <span>T2: <strong className="text-emerald-300">{currencySymbol}{quantSetupData.t2Price.toFixed(1)} (+{Math.abs(quantSetupData.t2Pct)}%)</strong></span>
              </>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetZoom}
              className="px-2.5 py-0.5 rounded bg-[#131722] hover:bg-[#2a2e39] border border-[#2a2e39] text-[#787b86] hover:text-white text-[11px] flex items-center gap-1 transition cursor-pointer"
              title="Reset Zoom to Recent Bars"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Zoom</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1 rounded bg-[#2962ff] hover:bg-[#1e53e5] text-white font-bold text-xs shadow-md transition cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
