import React, { useState } from 'react';
import { CovariateDefinition } from '../types';
import { Wand2, RefreshCw, Sliders, TrendingUp, Info, RotateCcw } from 'lucide-react';

interface CovariatesScenarioEditorProps {
  covariates: CovariateDefinition[];
  futureCovariates: Record<string, number>[];
  onUpdateFutureCovariates: (updated: Record<string, number>[]) => void;
  onSimulate: () => void;
  horizon: number;
  isLoading: boolean;
}

export const CovariatesScenarioEditor: React.FC<CovariatesScenarioEditorProps> = ({
  covariates,
  futureCovariates,
  onUpdateFutureCovariates,
  onSimulate,
  horizon,
  isLoading
}) => {
  // Global scenario overrides
  const [globalOverrides, setGlobalOverrides] = useState<Record<string, number>>({});

  // Apply a scenario to all future horizon steps
  const handleApplyOverride = (covName: string, value: number) => {
    const newOverrides = { ...globalOverrides, [covName]: value };
    setGlobalOverrides(newOverrides);

    const updated = Array.from({ length: horizon }, (_, i) => {
      const current = futureCovariates[i] || {};
      return {
        ...current,
        [covName]: value
      };
    });

    onUpdateFutureCovariates(updated);
  };

  // Reset to original preset defaults
  const handleReset = () => {
    setGlobalOverrides({});
    // Reset to neutral
    const resetList = Array.from({ length: horizon }, () => {
      const obj: Record<string, number> = {};
      covariates.forEach(c => {
        obj[c.name] = c.defaultValue ?? 0;
      });
      return obj;
    });
    onUpdateFutureCovariates(resetList);
  };

  if (covariates.length === 0) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
        <Info className="w-8 h-8 text-slate-500 mx-auto mb-2" />
        <p className="text-sm">This dataset does not define dynamic numerical covariates.</p>
        <p className="text-xs text-slate-500 mt-1">
          Switch to <strong className="text-cyan-400">Omnichannel Retail Sales</strong> or <strong className="text-cyan-400">Power Grid Load</strong> to experiment with TimesFM CPM Covariates!
        </p>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h3 className="text-base font-semibold text-white flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-amber-400" />
            TimesFM Covariate Projection Module (CPM) Scenario Sandbox
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Test "What-If" hypotheses by altering future external regressors across the {horizon}-step horizon.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-reset-covariates"
            onClick={handleReset}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset Defaults
          </button>
          <button
            id="btn-apply-simulate"
            onClick={onSimulate}
            disabled={isLoading}
            className="flex items-center gap-2 px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-900/40 border border-cyan-400/30 transition-all disabled:opacity-50"
          >
            {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <TrendingUp className="w-3.5 h-3.5" />}
            Simulate TimesFM Impact
          </button>
        </div>
      </div>

      {/* Covariate Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {covariates.map((cov) => {
          const currentVal = globalOverrides[cov.name] ?? (futureCovariates[0]?.[cov.name] ?? 0);
          const isPercent = cov.name.includes('pct') || cov.name.includes('discount');
          const isBinary = cov.type === 'binary' || cov.name.includes('flag') || cov.name.includes('is_');

          return (
            <div key={cov.name} className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-xs font-bold text-white font-mono">{cov.name}</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">{cov.description || 'External regressor'}</p>
                </div>
                <span className="font-mono text-cyan-400 text-xs font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/60">
                  {currentVal}{isPercent ? '%' : ''}
                </span>
              </div>

              {isBinary ? (
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => handleApplyOverride(cov.name, 0)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      currentVal === 0
                        ? 'bg-slate-800 text-white border-slate-600'
                        : 'bg-slate-900/50 text-slate-500 border-slate-800'
                    }`}
                  >
                    Off (0)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyOverride(cov.name, 1)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                      currentVal === 1
                        ? 'bg-cyan-600 text-white border-cyan-400'
                        : 'bg-slate-900/50 text-slate-500 border-slate-800'
                    }`}
                  >
                    Active (1)
                  </button>
                </div>
              ) : (
                <div className="space-y-1">
                  <input
                    type="range"
                    min={cov.min ?? 0}
                    max={cov.max ?? (isPercent ? 50 : 10000)}
                    step={isPercent ? 1 : 50}
                    value={currentVal}
                    onChange={(e) => handleApplyOverride(cov.name, parseFloat(e.target.value))}
                    className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>{cov.min ?? 0}{isPercent ? '%' : ''}</span>
                    <span>{cov.max ?? (isPercent ? '50%' : '10,000')}</span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Info notice */}
      <div className="bg-slate-950/40 rounded-xl p-3 border border-slate-800/60 text-xs text-slate-400 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200">How TimesFM handles Covariates:</strong> Unlike traditional ARIMAX models that suffer from multicollinearity, TimesFM utilizes a deep Covariate Projection Module (CPM) with residual refinement to learn the nonlinear interaction between univariate foundations and future intervention scenarios.
        </div>
      </div>
    </div>
  );
};
