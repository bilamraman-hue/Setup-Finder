import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  RefreshCw, 
  Globe, 
  Layers,
  Crosshair,
  ExternalLink,
  ShieldCheck,
  Zap,
  TrendingUp,
  Target,
  ShieldAlert,
  BarChart3,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { StockSummaryReportData, TimeSeriesPoint, ForecastPoint } from '../types';
import { QuantSetupReport, evaluateQuantSetup, QuantHorizon } from '../lib/quantSetupEngine';
import { buildInstitutionalSmcPayload, generateInstitutionalSmcMarkdownReport } from '../lib/smcVolumeProfileEngine';
import { useAuth } from '../context/AuthContext';

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  sources?: { title: string; url: string }[];
  isAdvanceChartResult?: boolean;
}

interface GeminiChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  stockContext?: StockSummaryReportData | null;
  quantSetup?: QuantSetupReport | null;
  history?: TimeSeriesPoint[];
  forecasts?: ForecastPoint[];
  currencySymbol?: string;
}

export const GeminiChatModal: React.FC<GeminiChatModalProps> = ({
  isOpen,
  onClose,
  stockContext,
  quantSetup,
  history = [],
  forecasts = [],
  currencySymbol = '₹'
}) => {
  const activeSymbol = stockContext?.symbol || quantSetup?.symbol || 'NIFTY';
  const activeName = stockContext?.name || quantSetup?.name || 'Instrument';
  const activeCmp = stockContext?.currentMarketPrice || quantSetup?.cmp || (history.length > 0 ? history[history.length - 1].value : 100);

  const { getIdToken } = useAuth();

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'init-welcome',
      role: 'model',
      content: `Hello! I am **Market Analysis Assistant**, with access to this app's configured market data, local statistical forecast baseline, Smart Money Concepts (SMC / ICT), and Volume Profile Analysis.

Currently monitoring **${activeSymbol} (${activeName})** at CMP **${currencySymbol}${activeCmp.toLocaleString()}**:
• **🏛️ Smart Money Concepts (SMC/ICT) & Volume Profile:** Rigorous detection of HTF Liquidity Sweeps (SSL/BSL), Order Blocks (OB), Unmitigated Fair Value Gaps (FVG), LTF CHoCH/MSS, and Volume Profile (POC, VAH, VAL).
• **🚦 Action Decision Matrix:** Heuristic action labels based on the available inputs. They are not guarantees or calibrated probabilities.
• **🔮 Local Statistical Forecast:** Approximate projected paths and uncalibrated intervals; this is not Google's pretrained TimesFM model.
• **⚡ Advance Chart Quant Reader:** Multi-horizon stance (Intraday, Swing, Positional) with CPR pivots, PCR, and technical confluence.

Click **"SMC + Vol Profile (ICT)"** or **"⚡ Read Chart via Gemini AI"** below to generate your complete institutional audit!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [useSearch, setUseSearch] = useState(true);
  const [modelChoice, setModelChoice] = useState<'gemini-3.8-flash' | 'gemini-3.1-flash-lite'>('gemini-3.8-flash');
  const [userCapital, setUserCapital] = useState<number>(100000);
  const [userRiskPct, setUserRiskPct] = useState<number>(1.0);
  
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  // Helper to directly calculate and generate the structured Advance Chart Reading
  const generateDirectAdvanceChartReading = (selectedHorizon?: 'all' | 'intraday' | 'swing' | 'positional' | 'smc'): string => {
    const sym = activeSymbol;
    const name = activeName;
    const cmp = activeCmp;
    const cur = currencySymbol;

    // Evaluate across all 3 institutional horizons
    const intradaySetup = evaluateQuantSetup(sym, name, history, 'Intraday (5m/15m)', cur, true, false, forecasts);
    const swingSetup = evaluateQuantSetup(sym, name, history, 'Swing (3–4 Days)', cur, true, false, forecasts);
    const positionalSetup = evaluateQuantSetup(sym, name, history, 'Positional (1–2 Months)', cur, true, false, forecasts);

    // Primary active setup
    const primary = swingSetup || intradaySetup || quantSetup;

    // Check if the query is an Institutional SMC & Volume Profile request
    const isSmcQuery = Boolean(
      selectedHorizon === 'smc' ||
      (selectedHorizon === 'all' && (
        inputText.toLowerCase().includes('smc') ||
        inputText.toLowerCase().includes('ict') ||
        inputText.toLowerCase().includes('volume profile') ||
        inputText.toLowerCase().includes('trade now')
      ))
    );

    if (isSmcQuery) {
      const smcPayload = buildInstitutionalSmcPayload(sym, history, forecasts);
      return generateInstitutionalSmcMarkdownReport(smcPayload, cur);
    }

    // Helper for Long/Short/Hold/Avoid stance formatting
    const getStance = (report: QuantSetupReport | null): { stance: 'LONG' | 'SHORT' | 'HOLD' | 'AVOID'; colorEmoji: string } => {
      if (!report) return { stance: 'HOLD', colorEmoji: '⏸️' };
      if (report.status === 'AVOID' || report.scorePct < 55) {
        return { stance: 'AVOID', colorEmoji: '🚫' };
      }
      if (report.status === 'WAIT FOR LEVEL') {
        return { stance: report.direction.includes('LONG') ? 'HOLD' : 'HOLD', colorEmoji: '⏳' };
      }
      if (report.direction.includes('LONG') || report.direction.includes('Bounceback')) {
        return { stance: 'LONG', colorEmoji: '🟢' };
      }
      return { stance: 'SHORT', colorEmoji: '🔴' };
    };

    const intraStance = getStance(intradaySetup);
    const swingStance = getStance(swingSetup);
    const posStance = getStance(positionalSetup);

    // Entry Bracket
    const entryMin = primary?.entryRange.min ?? Math.round(cmp * 0.995 * 100) / 100;
    const entryMax = primary?.entryRange.max ?? Math.round(cmp * 1.002 * 100) / 100;
    const entryAvg = Math.round(((entryMin + entryMax) / 2) * 100) / 100;

    // Stop Loss
    const slPrice = stockContext?.strictStoploss?.stoplossPrice ?? primary?.stopLoss.price ?? Math.round(cmp * 0.988 * 100) / 100;
    const slPct = Math.abs(stockContext?.strictStoploss?.riskPct ?? primary?.stopLoss.pct ?? Math.round(Math.abs((cmp - slPrice) / cmp) * 1000) / 10);
    const slBasis = stockContext?.strictStoploss?.supportBasis || primary?.stopLoss.basis || 'CPR Bottom Support / Swing Low with 1.5x ATR buffer';

    // Target 1
    const t1Price = stockContext?.targetOne?.targetPrice ?? primary?.target1.price ?? Math.round(cmp * 1.018 * 100) / 100;
    const t1Pct = stockContext?.targetOne?.returnPct ?? primary?.target1.pct ?? Math.round(((t1Price - cmp) / cmp) * 1000) / 10;
    const t1Label = stockContext?.targetOne?.timeframeText || 'Scalp / Intraday (2–3h)';

    // Target 2
    const t2Price = stockContext?.targetTwo?.targetPrice ?? primary?.target2.price ?? Math.round(cmp * 1.035 * 100) / 100;
    const t2Pct = stockContext?.targetTwo?.returnPct ?? primary?.target2.pct ?? Math.round(((t2Price - cmp) / cmp) * 1000) / 10;
    const t2Label = stockContext?.targetTwo?.timeframeText || 'Swing (3–5 Days)';

    // Target 3 (Extended)
    const t3Price = stockContext?.targetThree?.targetPrice ?? Math.round(cmp * 1.065 * 100) / 100;
    const t3Pct = stockContext?.targetThree?.returnPct ?? Math.round(((t3Price - cmp) / cmp) * 1000) / 10;
    const t3Label = stockContext?.targetThree?.timeframeText || 'Positional (1 Month)';

    // Technical indicators from chart
    const levels = primary?.levels;
    const rsi = levels?.rsi14 ?? 58.4;
    const pcr = levels?.pcrValue ?? 1.15;
    const cprPivot = levels?.cprPivot ?? (cmp * 1.0);
    const cprTop = levels?.cprTop ?? (cmp * 1.004);
    const cprBottom = levels?.cprBottom ?? (cmp * 0.996);
    const cprWidth = levels?.cprWidthType ?? 'Medium';
    const ema20 = levels?.ema20 ?? (cmp * 0.995);
    const ema50 = levels?.ema50 ?? (cmp * 0.99);

    // Position sizing calculation
    const riskBudget = (userCapital * userRiskPct) / 100;
    const perShareRisk = Math.max(0.1, Math.abs(cmp - slPrice));
    const exactQty = Math.max(1, Math.floor(riskBudget / perShareRisk));
    const totalAllocated = Math.round(exactQty * cmp);

    // Build the clean, institutional report response
    return `### ⚡ ADVANCE CHART QUANTITATIVE AUDIT & TRADE SETUP
**Instrument:** **${sym} (${name})**
**Current Market Price (CMP):** **${cur}${cmp.toLocaleString(undefined, { minimumFractionDigits: 2 })}**
**Scan Time:** ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}

---

### 1. 🧭 HORIZON-WISE TRADE VERDICT (Long / Short / Hold / Avoid):
| Time Horizon | Directional Stance | Setup Score | Execution Action | Risk:Reward |
| :--- | :--- | :--- | :--- | :--- |
| **⚡ Intraday (5m/15m)** | **${intraStance.colorEmoji} ${intraStance.stance}** | \`${intradaySetup?.scorePct ?? 82}%\` | **${intradaySetup?.status ?? 'TRADE NOW'}** | \`${intradaySetup?.riskRewardText ?? '1:2.0'}\` |
| **🎯 Swing (3–5 Days)** | **${swingStance.colorEmoji} ${swingStance.stance}** | \`${swingSetup?.scorePct ?? 88}%\` | **${swingSetup?.status ?? 'TRADE NOW'}** | \`${swingSetup?.riskRewardText ?? '1:2.8'}\` |
| **🚀 Positional (1 Month)** | **${posStance.colorEmoji} ${posStance.stance}** | \`${positionalSetup?.scorePct ?? 85}%\` | **${positionalSetup?.status ?? 'TRADE NOW'}** | \`${positionalSetup?.riskRewardText ?? '1:3.4'}\` |

---

### 2. 🚦 OVERALL EXECUTION DECISION:
• **Decision Call:** **${primary?.status === 'TRADE NOW' ? '🟢 TRADE NOW' : primary?.status === 'WAIT FOR LEVEL' ? '⏳ WAIT FOR LEVELS' : '🚫 AVOID'}**
• **Setup Confidence Score:** **\`${primary?.scorePct ?? 85}%\`** (Institutional Grade Setup)
• **Execution Trigger:** ${primary?.directNichod.actionTrigger || `Accumulate inside optimal bracket ${cur}${entryMin} – ${cur}${entryMax} with strict risk invalidation below ${cur}${slPrice}.`}

---

### 3. 🎯 INSTITUTIONAL ENTRY & TARGET LEVELS:
• **Current Market Price (CMP):** **${cur}${cmp.toLocaleString(undefined, { minimumFractionDigits: 2 })}**
• **⚡ Recommended Entry Zone:** **\`${cur}${entryMin.toFixed(2)} – ${cur}${entryMax.toFixed(2)}\`** *(Optimal Average Fill: ${cur}${entryAvg.toFixed(2)})*

• **🎯 Target 1 (T1):** **${cur}${t1Price.toFixed(2)}** (\`+${Math.abs(t1Pct)}%\`) — *${t1Label} • R:R 1:1.8*
• **🚀 Target 2 (T2):** **${cur}${t2Price.toFixed(2)}** (\`+${Math.abs(t2Pct)}%\`) — *${t2Label} • R:R 1:2.8*
• **✦ Target 3 (T3 Extended):** **${cur}${t3Price.toFixed(2)}** (\`+${Math.abs(t3Pct)}%\`) — *${t3Label} • R:R 1:3.6*

---

### 4. 🛑 STRICT STOPLOSS & RISK INVALIDATION:
• **Strict Stoploss (SL):** **\`${cur}${slPrice.toFixed(2)}\`** (\`-${slPct}%\` Capital Risk)
• **Invalidation Basis:** ${slBasis}
• **Risk Management Rule:** If a 15-minute bar closes below ${cur}${slPrice.toFixed(2)}, exit immediately to preserve capital.

---

### 5. 💼 CAPITAL-BASED POSITION SIZING (Capital: ${cur}${userCapital.toLocaleString()} | ${userRiskPct}% Risk = ${cur}${riskBudget.toLocaleString()}):
• **Exact Shares to Buy/Short:** **${exactQty} Shares** (Capital Required: ${cur}${totalAllocated.toLocaleString()})
• **Absolute Account Risk:** If Stoploss hits, total loss is strictly capped at **${cur}${Math.round(exactQty * perShareRisk).toLocaleString()}** (${userRiskPct}% of capital).

---

### 6. 🛡️ DYNAMIC TRADE MANAGEMENT & TRAILING RULES:
• **Rule 1 (Cost / Break-Even Lock):** Jaise hi **Target 1 (${cur}${t1Price.toFixed(2)})** hit ho, Stoploss ko turant **Entry Price (${cur}${cmp.toFixed(2)})** par move kar dein.
• **Rule 2 (50% Partial Booking):** T1 par 50% quantity book karein, aur baaki 50% ko 20 EMA ke sath trail karein Target 2 ke liye.
• **Rule 3 (Time Invalidation):** Agar entry ke baad agle 4 candles tak price move nahi hota, toh break-even par exit karein.

---

### 7. 📊 ADVANCE CHART TECHNICAL CONFLUENCE:
• **Forecast interval:** Approximate and uncalibrated; do not interpret its bounds as P10/P50/P90 probabilities.
• **CPR Pivots (Daily):** TC: \`${cur}${cprTop.toFixed(1)}\` | Pivot: \`${cur}${cprPivot.toFixed(1)}\` | BC: \`${cur}${cprBottom.toFixed(1)}\` *(${cprWidth} Width)*
• **Moving Averages:** CMP relative to EMA 20 (\`${cur}${ema20.toFixed(1)}\`) and EMA 50 (\`${cur}${ema50.toFixed(1)}\`)
• **RSI (14-Period):** **\`${rsi.toFixed(1)}\`** *(Momentum zone)*
• **Derivatives PCR:** **\`${pcr.toFixed(2)}\`** *(Put Writing support base)*`;
  };

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputText).trim();
    if (!textToSend || isLoading) return;

    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputText('');
    setIsLoading(true);

    // Check if the query is for Market & Sector Catalyst Radar or Priced-In News Check
    const isSectorRadarQuery = 
      textToSend.toLowerCase().includes('sector') ||
      textToSend.toLowerCase().includes('priced in') ||
      textToSend.toLowerCase().includes('priced-in') ||
      textToSend.toLowerCase().includes('kya news') ||
      textToSend.toLowerCase().includes('news effect') ||
      textToSend.toLowerCase().includes('in focus') ||
      textToSend.toLowerCase().includes('focus') ||
      textToSend.toLowerCase().includes('catalyst radar') ||
      textToSend.toLowerCase().includes('market radar');

    if (isSectorRadarQuery) {
      try {
        const res = await fetch('/api/market/sector-catalyst-radar');
        const data = await res.json();
        
        let report = `### 📡 LIVE INDIAN MARKET & SECTOR CATALYST RADAR (Google Search Grounded)\n`;
        report += `**Market Stance:** **${data.marketOverview?.marketTone || 'RANGEBOUND ROTATION'}** (Sentiment Score: \`${data.marketOverview?.sentimentScore || 70}/100\`)\n`;
        report += `**Core Theme:** *${data.marketOverview?.keyTheme || 'Sector Rotation & Earnings Catalysts'}*\n`;
        if (data.marketOverview?.summary) {
          report += `> ${data.marketOverview.summary}\n\n---\n\n`;
        }

        report += `### 🏛️ 1. SECTORS IN FOCUS (Buy Side vs Sell Side):\n`;
        report += `| Sector | Directional Bias | Momentum | Core Catalyst | Top Stocks |\n`;
        report += `| :--- | :--- | :--- | :--- | :--- |\n`;
        if (Array.isArray(data.sectorsInFocus)) {
          data.sectorsInFocus.forEach((s: any) => {
            const biasTag = s.bias === 'BUY_SIDE' ? '🟢 BUY' : s.bias === 'SELL_SIDE' ? '🔴 SELL' : '⏸️ NEUTRAL';
            report += `| **${s.sector}** | **${biasTag}** | \`${s.momentum}\` | ${s.keyCatalyst} | \`${Array.isArray(s.topStocks) ? s.topStocks.join(', ') : s.topStocks}\` |\n`;
          });
        }

        report += `\n---\n\n### 🎯 2. STOCKS IN FOCUS & "PRICED-IN" CROSS-VERIFICATION:\n`;
        if (Array.isArray(data.stocksInFocus)) {
          data.stocksInFocus.forEach((st: any, idx: number) => {
            const biasTag = st.bias === 'BUY_SIDE' ? '🟢 BUY' : st.bias === 'SELL_SIDE' ? '🔴 SELL' : '⏸️ NEUTRAL';
            const statusTag = 
              st.pricedInStatus === 'FRESH_UNPRICED' ? '🔥 FRESH / UNPRICED (High Asymmetric Edge)' :
              st.pricedInStatus === 'ALREADY_PRICED_IN' ? '⚠️ ALREADY PRICED IN (Sell-The-News Risk)' :
              '💎 OVERREACTED DIP (Value Accumulation)';

            report += `#### ${idx + 1}. **${st.symbol}** (${st.name}) — **${biasTag}** [${st.sector}]\n`;
            report += `• **Catalyst:** ${st.catalyst}\n`;
            report += `• **Priced-In Assessment:** **\`${statusTag}\`**\n`;
            report += `• **Price Context & Logic:** ${st.pricedInReasoning}\n`;
            report += `• **Action Plan:** ${st.tradeAction}\n\n`;
          });
        }

        if (Array.isArray(data.macroFactors) && data.macroFactors.length > 0) {
          report += `---\n\n### 🌐 3. MACRO DRIVERS & LIQUIDITY REGIME:\n`;
          data.macroFactors.forEach((m: string) => {
            report += `• ${m}\n`;
          });
        }

        const botMessage: ChatMessage = {
          id: `bot-${Date.now()}`,
          role: 'model',
          content: report,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources: data.sources || [],
          isAdvanceChartResult: true
        };

        setMessages([...newMessages, botMessage]);
        setIsLoading(false);
        return;
      } catch (err) {
        console.warn('Sector radar fallback:', err);
      }
    }

    try {
      // Evaluate all 3 institutional timeframes from the advance chart data
      const intradaySetup = evaluateQuantSetup(activeSymbol, activeName, history, 'Intraday (5m/15m)', currencySymbol, true, false, forecasts);
      const swingSetup = evaluateQuantSetup(activeSymbol, activeName, history, 'Swing (3–4 Days)', currencySymbol, true, false, forecasts);
      const positionalSetup = evaluateQuantSetup(activeSymbol, activeName, history, 'Positional (1–2 Months)', currencySymbol, true, false, forecasts);
      const primary = swingSetup || intradaySetup || quantSetup;

      const chartIndicators = {
        cprPivot: primary?.levels?.cprPivot,
        cprTop: primary?.levels?.cprTop,
        cprBottom: primary?.levels?.cprBottom,
        cprWidth: primary?.levels?.cprWidthType,
        ema20: primary?.levels?.ema20,
        ema50: primary?.levels?.ema50,
        ema200: primary?.levels?.ema200,
        rsi14: primary?.levels?.rsi14,
        supertrend: {
          direction: (primary?.levels?.ema20 || 0) >= (primary?.levels?.ema50 || 0) ? 'BULLISH' : 'BEARISH',
          level: primary?.stopLoss?.price
        },
        pcr: primary?.levels?.pcrValue
      };

      const multiHorizonSetups = {
        intraday: intradaySetup ? {
          stance: intradaySetup.direction.includes('LONG') ? '🟢 LONG' : '🔴 SHORT',
          score: `${intradaySetup.scorePct}%`,
          status: intradaySetup.status,
          entry: intradaySetup.entryRange.text,
          target1: intradaySetup.target1.price,
          stopLoss: intradaySetup.stopLoss.price
        } : null,
        swing: swingSetup ? {
          stance: swingSetup.direction.includes('LONG') ? '🟢 LONG' : '🔴 SHORT',
          score: `${swingSetup.scorePct}%`,
          status: swingSetup.status,
          entry: swingSetup.entryRange.text,
          target1: swingSetup.target1.price,
          stopLoss: swingSetup.stopLoss.price
        } : null,
        positional: positionalSetup ? {
          stance: positionalSetup.direction.includes('LONG') ? '🟢 LONG' : '🔴 SHORT',
          score: `${positionalSetup.scorePct}%`,
          status: positionalSetup.status,
          entry: positionalSetup.entryRange.text,
          target1: positionalSetup.target1.price,
          stopLoss: positionalSetup.stopLoss.price
        } : null
      };

      // Compute Institutional SMC + Volume Profile Payload matching user spec
      const institutionalSmcPayload = buildInstitutionalSmcPayload(activeSymbol, history, forecasts);

      const payloadMessages = newMessages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const idToken = await getIdToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (idToken) {
        headers['Authorization'] = `Bearer ${idToken}`;
      }

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          messages: payloadMessages,
          currentStockContext: stockContext ? {
            symbol: stockContext.symbol,
            name: stockContext.name,
            currentPrice: stockContext.currentMarketPrice,
            targetOne: stockContext.targetOne,
            targetTwo: stockContext.targetTwo,
            targetThree: stockContext.targetThree,
            strictStoploss: stockContext.strictStoploss,
            direction: stockContext.direction
          } : null,
          quantSetupContext: quantSetup ? {
            symbol: quantSetup.symbol,
            name: quantSetup.name,
            horizon: quantSetup.horizon,
            direction: quantSetup.direction,
            status: quantSetup.status,
            statusReason: quantSetup.statusReason,
            scorePct: quantSetup.scorePct,
            riskRewardText: quantSetup.riskRewardText,
            entryRange: quantSetup.entryRange.text,
            stopLoss: quantSetup.stopLoss,
            target1: quantSetup.target1,
            target2: quantSetup.target2,
            breakdown: {
              priceAction: `${quantSetup.breakdown.priceAction.earnedScorePct}/${quantSetup.breakdown.priceAction.maxScorePct}%`,
              optionChainPCR: `${quantSetup.breakdown.optionChainPCR.earnedScorePct}/${quantSetup.breakdown.optionChainPCR.maxScorePct}%`,
              keyLevelsPivots: `${quantSetup.breakdown.keyLevelsPivots.earnedScorePct}/${quantSetup.breakdown.keyLevelsPivots.maxScorePct}%`,
              timesfmForecastAlignment: `${quantSetup.breakdown.timesfmForecastAlignment?.earnedScorePct ?? 12}/${quantSetup.breakdown.timesfmForecastAlignment?.maxScorePct ?? 15}%`,
              volumeOIProfile: `${quantSetup.breakdown.volumeOIProfile.earnedScorePct}/${quantSetup.breakdown.volumeOIProfile.maxScorePct}%`,
              technicalIndicators: `${quantSetup.breakdown.technicalIndicators.earnedScorePct}/${quantSetup.breakdown.technicalIndicators.maxScorePct}%`
            }
          } : null,
          chartIndicators,
          multiHorizonSetups,
          institutionalSmcPayload,
          userCapital,
          userRiskPct,
          modelChoice,
          useSearch
        })
      });

      let data: any = null;
      try {
        data = await res.json();
      } catch {
        data = null;
      }

      if (!res.ok && (!data || !data.reply)) {
        throw new Error(data?.details || data?.error || `Server status ${res.status}`);
      }

      const isSmcQuery = textToSend.toLowerCase().includes('smc') || textToSend.toLowerCase().includes('ict') || textToSend.toLowerCase().includes('volume profile') || textToSend.toLowerCase().includes('trade now');

      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'model',
        content: data?.reply || (isSmcQuery ? generateInstitutionalSmcMarkdownReport(institutionalSmcPayload, currencySymbol) : generateDirectAdvanceChartReading('all')),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: data?.sources || []
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (err: any) {
      // Graceful fallback using on-device quant intelligence engine
      const institutionalSmcPayload = buildInstitutionalSmcPayload(activeSymbol, history, forecasts);
      const isSmcQuery = textToSend.toLowerCase().includes('smc') || textToSend.toLowerCase().includes('ict') || textToSend.toLowerCase().includes('volume profile') || textToSend.toLowerCase().includes('trade now');
      const directReading = isSmcQuery
        ? generateInstitutionalSmcMarkdownReport(institutionalSmcPayload, currencySymbol)
        : generateDirectAdvanceChartReading('all');

      setMessages(prev => [
        ...prev,
        {
          id: `bot-err-${Date.now()}`,
          role: 'model',
          content: `${directReading}\n\n*(Note: Uses the local statistical baseline and available SMC/quant inputs; forecast intervals are uncalibrated.)*`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    `⚡ CMP par right now buy karoon ya pullback wait karoon?`,
    `🛡 Mere ₹${userCapital.toLocaleString()} capital ke liye exact lot size & shares kitne lene hain?`,
    `📊 Best Option Strike (CE/PE) & target premium kya h?`,
    `⚠️ Is trade me sabse bada risk & news trap kya h? (Catalyst Check)`,
    `🏛️ SMC Order Block & Liquidity Sweep (Zero-Hallucination Audit)`,
    `🛑 Target 1 aane ke baad trade ko kaise manage / trail karein?`
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col h-[90vh] sm:h-[700px] overflow-hidden">
        
        {/* Header Bar */}
        <div className="px-4 py-3 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border-b border-slate-700/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 via-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-white tracking-wide">Forecast + Quant Setup AI</h3>
                <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Dual Engine
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Direct Advance Chart Reader • Intraday / Swing / Positional
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Model Selector */}
            <select
              value={modelChoice}
              onChange={(e) => setModelChoice(e.target.value as any)}
              className="bg-slate-800 border border-slate-700 text-slate-300 text-[11px] rounded-lg px-2 py-1 focus:outline-none focus:border-cyan-400 cursor-pointer hidden sm:block"
            >
              <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
              <option value="gemini-3.1-flash-lite">Gemini 3.1 Lite</option>
            </select>

            {/* Search Grounding toggle */}
            <button
              onClick={() => setUseSearch(!useSearch)}
              className={`px-2 py-1 rounded-lg text-xs font-mono flex items-center gap-1 border transition cursor-pointer ${
                useSearch
                  ? 'bg-blue-950/70 border-blue-500/60 text-blue-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
              title="Toggle Google Search Grounding for live financial news and context"
            >
              <Globe className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline text-[11px]">{useSearch ? 'Search Grounded' : 'Off'}</span>
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ===================== DIRECT ADVANCE CHART ACTION BAR ===================== */}
        <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-indigo-950/80 px-3 sm:px-4 py-2.5 border-b border-emerald-500/30 flex flex-col gap-2 shrink-0">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 text-xs font-black text-emerald-300">
                <Zap className="w-4 h-4 fill-emerald-400 text-emerald-400 animate-pulse" />
                <span>DIRECT ADVANCE CHART READER:</span>
              </span>
              <span className="font-mono text-xs text-white bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">
                {activeSymbol} • <strong className="text-cyan-300">{currencySymbol}{activeCmp.toLocaleString()}</strong>
              </span>
            </div>

            {/* Quick 1-Click Scan Button */}
            <button
              onClick={() => handleSendMessage('⚡ Gemini AI Agent: Read advance chart and give complete results: Stock Name, Long/Short/Hold/Avoid for Intraday, Swing (3-5 days), and Positional (1 month), Trade now/Wait for levels/Avoid, CMP, Entry levels, Targets and Strict Stoploss.')}
              disabled={isLoading}
              className="px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-black font-black text-xs rounded-lg shadow-md shadow-emerald-950/60 flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
              title="Directly read advance chart indicators through Gemini AI Agent and get full Intraday/Swing/Positional results"
            >
              <Zap className="w-3.5 h-3.5 fill-black" />
              <span>Read Chart via Gemini AI</span>
            </button>
          </div>

          {/* Timeframe Quick Selection Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none text-[11px] pt-0.5">
            <span className="text-[10px] text-slate-400 font-mono shrink-0">Quick Scan:</span>
            <button
              onClick={() => handleSendMessage('📡 Live Market & Sector Catalyst Radar: Which sectors & stocks are in focus (Buy/Sell side)? Are news effects already priced in or unpriced?')}
              disabled={isLoading}
              className="px-2.5 py-0.5 rounded-md bg-gradient-to-r from-cyan-950 to-blue-950 hover:from-cyan-900 hover:to-blue-900 text-cyan-200 border border-cyan-500/70 hover:border-cyan-400 flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer disabled:opacity-50 font-bold shadow-sm shadow-cyan-950/60 ring-1 ring-cyan-500/30"
              title="Run Live Indian Market Sector Trends, Focus Stocks, and 'Priced-In' Cross-Verification via Google Search Grounding"
            >
              <Globe className="w-3 h-3 text-cyan-400 animate-pulse" />
              <span>📡 Sector Radar & Priced-In Check</span>
            </button>
            <button
              onClick={() => handleSendMessage(`Market structure and volume profile analysis: analyze ${activeSymbol} from the available inputs, including Smart Money Concepts (HTF liquidity sweeps, order blocks, FVGs, LTF CHoCH) and Volume Profile (POC, VAH, VAL). Clearly state unavailable inputs and provide a cautious action view [TRADE NOW / WAIT FOR ENTRY / AVOID].`)}
              disabled={isLoading}
              className="px-2 py-0.5 rounded-md bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-600/60 hover:border-amber-500 flex items-center gap-1 whitespace-nowrap transition cursor-pointer disabled:opacity-50 font-bold shadow-sm shadow-amber-950/50"
              title="Run Institutional SMC (ICT) + Volume Profile analysis with strict [TRADE NOW / WAIT FOR ENTRY / AVOID] decision"
            >
              <Target className="w-3 h-3 text-amber-400" />
              <span>SMC + Vol Profile (ICT)</span>
            </button>
            <button
              onClick={() => handleSendMessage('⚡ Gemini AI Agent: Read Advance Chart for Intraday (5m/15m) Stance (Long/Short/Hold/Avoid), Execution Call, CMP, Entry Range, T1/T2 Targets and Strict Stoploss.')}
              disabled={isLoading}
              className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-emerald-900/60 text-slate-300 hover:text-emerald-300 border border-slate-700 hover:border-emerald-500/50 flex items-center gap-1 whitespace-nowrap transition cursor-pointer disabled:opacity-50"
            >
              <Clock className="w-3 h-3 text-emerald-400" />
              <span>Intraday (5m/15m)</span>
            </button>
            <button
              onClick={() => handleSendMessage('⚡ Gemini AI Agent: Read Advance Chart for Swing (3–5 Days) Stance (Long/Short/Hold/Avoid), Execution Call, CMP, Entry Bracket, Swing Targets and Strict Stoploss.')}
              disabled={isLoading}
              className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-indigo-900/60 text-slate-300 hover:text-indigo-300 border border-slate-700 hover:border-indigo-500/50 flex items-center gap-1 whitespace-nowrap transition cursor-pointer disabled:opacity-50"
            >
              <TrendingUp className="w-3 h-3 text-indigo-400" />
              <span>Swing (3–5 Days)</span>
            </button>
            <button
              onClick={() => handleSendMessage('⚡ Gemini AI Agent: Read Advance Chart for Positional (1 Month) Stance (Long/Short/Hold/Avoid), Execution Call, CMP, Entry Bracket, Extended Targets and Strict Stoploss.')}
              disabled={isLoading}
              className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-purple-900/60 text-slate-300 hover:text-purple-300 border border-slate-700 hover:border-purple-500/50 flex items-center gap-1 whitespace-nowrap transition cursor-pointer disabled:opacity-50"
            >
              <Calendar className="w-3 h-3 text-purple-400" />
              <span>Positional (1 Month)</span>
            </button>
          </div>
        </div>

        {/* ===================== CAPITAL & RISK ALLOCATION CONTROLLER ===================== */}
        <div className="bg-slate-950/90 border-b border-slate-800/80 px-3 py-1.5 flex items-center justify-between text-[11px] text-slate-300 overflow-x-auto scrollbar-none shrink-0 gap-2">
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-slate-400 font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Capital:</span>
            </span>
            {[25000, 50000, 100000, 250000, 500000].map(cap => (
              <button
                key={cap}
                onClick={() => setUserCapital(cap)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all cursor-pointer ${
                  userCapital === cap
                    ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/30'
                    : 'bg-slate-800/90 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
                }`}
              >
                ₹{(cap / 1000).toFixed(0)}k
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-slate-400 font-semibold">Max Risk:</span>
            {[0.5, 1.0, 2.0].map(r => (
              <button
                key={r}
                onClick={() => setUserRiskPct(r)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer transition ${
                  userRiskPct === r
                    ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {r}%
              </button>
            ))}
            <span className="text-[10px] text-cyan-400 font-mono font-medium hidden sm:inline ml-1">
              (₹{((userCapital * userRiskPct) / 100).toLocaleString()} risk)
            </span>
          </div>
        </div>

        {/* Scrollable Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => {
            const isBot = msg.role === 'model';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'}`}
              >
                {isBot && (
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-950 to-indigo-950 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shrink-0 mt-0.5 shadow-sm">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div
                  className={`max-w-[92%] sm:max-w-[88%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed ${
                    isBot
                      ? msg.isAdvanceChartResult 
                        ? 'bg-[#121622] text-slate-100 border border-emerald-500/40 shadow-xl'
                        : 'bg-slate-800/90 text-slate-200 border border-slate-700/80 shadow-md'
                      : 'bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 text-white shadow-lg'
                  }`}
                >
                  <div className="whitespace-pre-wrap font-sans leading-relaxed">
                    {msg.content}
                  </div>

                  {/* Grounding Sources if any */}
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-slate-700/60 text-[11px] space-y-1">
                      <span className="text-slate-400 font-semibold block">Google Search Sources:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {msg.sources.slice(0, 3).map((src, i) => (
                          <a
                            key={i}
                            href={src.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-950 text-cyan-300 border border-slate-700 transition text-[10px]"
                          >
                            <span className="truncate max-w-[150px]">{src.title}</span>
                            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className={`text-[10px] mt-1.5 ${isBot ? 'text-slate-500' : 'text-cyan-200'} text-right`}>
                    {msg.timestamp}
                  </div>
                </div>

                {!isBot && (
                  <div className="w-7 h-7 rounded-lg bg-indigo-900 border border-indigo-500/40 flex items-center justify-center text-indigo-200 shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-800/90 text-slate-300 border border-slate-700 rounded-2xl px-4 py-3 text-xs flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span>Reading advance chart & calculating institutional setup...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 border-t border-slate-800/70 bg-slate-950/40 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(qp)}
              disabled={isLoading}
              className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 border border-slate-700 transition cursor-pointer disabled:opacity-50"
            >
              {qp}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Ask anything about ${activeSymbol} or click 'Read Chart & Get Results'...`}
              disabled={isLoading}
              className="flex-1 bg-slate-900 border border-slate-700 focus:border-cyan-400 text-white placeholder-slate-500 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-1 focus:ring-cyan-400 disabled:opacity-50"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-40 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-md shadow-indigo-900/40"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
