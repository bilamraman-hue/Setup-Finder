import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  Layers, 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  Check, 
  Activity, 
  RefreshCw,
  Play,
  Filter,
  Search,
  AlertTriangle,
  HelpCircle,
  ShieldCheck, 
  ArrowUpRight, 
  ArrowDownRight,
  Info,
  BarChart3,
  SlidersHorizontal,
  DollarSign,
  Gauge,
  Anchor,
  Waves,
  PieChart,
  ShieldAlert,
  Key
} from 'lucide-react';
import { 
  buildInstitutionalOptionChain, 
  isFnoStock, 
  NSE_FNO_REGISTRY,
  OptionChainPayload,
  OptionChainRow,
  OptionExpiryInfo
} from '../lib/indianOptionsEngine';
import { openVirtualTrade } from '../lib/paperTradingStore';

interface LiveOptionChainModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  name: string;
  cmp: number;
  currencySymbol?: string;
  onExecuteTrade?: (details: any) => void;
  onSelectStockSymbol?: (symbol: string) => void;
}

const POPULAR_FNO_TICKERS = [
  'NIFTY',
  'BANKNIFTY',
  'RELIANCE',
  'TCS',
  'INFY',
  'HDFCBANK',
  'TATAMOTORS',
  'SBIN',
  'BAJFINANCE',
  'ITC',
  'ICICIBANK'
];

// Format Indian Open Interest and Volume figures (e.g. 15.50L, 1.25Cr, 85k)
export function formatIndianNumber(num: number): string {
  if (!num || isNaN(num)) return '0';
  const sign = num < 0 ? '-' : '';
  const abs = Math.abs(num);
  if (abs >= 10000000) return `${sign}${(abs / 10000000).toFixed(2)}Cr`;
  if (abs >= 100000) return `${sign}${(abs / 100000).toFixed(2)}L`;
  if (abs >= 1000) return `${sign}${(abs / 1000).toFixed(1)}k`;
  return `${sign}${abs.toLocaleString()}`;
}

export const LiveOptionChainModal: React.FC<LiveOptionChainModalProps> = ({
  isOpen,
  onClose,
  symbol,
  name,
  cmp,
  currencySymbol = '₹',
  onExecuteTrade,
  onSelectStockSymbol
}) => {
  const [activeSymbol, setActiveSymbol] = useState<string>(symbol);
  const [activeName, setActiveName] = useState<string>(name);
  const [activeCmp, setActiveCmp] = useState<number>(cmp);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Mobile / Desktop Tabs: 'TABLE' (Full Chain), 'GEX' (Gamma Exposure), 'IV_MATRIX' (Volatility), 'ORDER_FLOW' (CVD Flow), 'MATRIX' (Mobile Ladder), 'PAYOFF' (P&L Diagram)
  const [activeViewTab, setActiveViewTab] = useState<'TABLE' | 'GEX' | 'IV_MATRIX' | 'ORDER_FLOW' | 'MATRIX' | 'PAYOFF'>('TABLE');

  const [selectedExpiryIndex, setSelectedExpiryIndex] = useState<number>(0);
  const [selectedStrike, setSelectedStrike] = useState<number | null>(null);
  const [selectedContractType, setSelectedContractType] = useState<'CE' | 'PE'>('CE');
  const [strikeFilter, setStrikeFilter] = useState<'ALL' | 'NEAR_ATM' | 'ITM_ONLY' | 'OTM_ONLY'>('NEAR_ATM');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isAutoRefresh, setIsAutoRefresh] = useState<boolean>(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<Date | null>(new Date());
  const [timeAgo, setTimeAgo] = useState<string>('Just now');
  const [orderNotification, setOrderNotification] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Initialize with exact instant calculation from current market spot
  const [chainPayload, setChainPayload] = useState<OptionChainPayload | null>(() => 
    buildInstitutionalOptionChain(symbol, name, cmp || 1000, 0)
  );
  const [lotSize, setLotSize] = useState<number>(() => chainPayload?.lotSize || 50);

  // Sync state when props change
  useEffect(() => {
    if (isOpen) {
      setActiveSymbol(symbol);
      setActiveName(name);
      setActiveCmp(cmp);
      const initial = buildInstitutionalOptionChain(symbol, name, cmp || 1000, 0);
      setChainPayload(initial);
      setLotSize(initial.lotSize);
      setSelectedStrike(initial.atmStrike);
      setErrorMsg(null);
      setSelectedExpiryIndex(0);
      setLastSyncedTime(new Date());
      fetchLiveOptionsFromServer(symbol, 0, cmp);
    }
  }, [isOpen, symbol, name, cmp]);

  // Live Auto-Refresh poller (5s interval when toggled on)
  useEffect(() => {
    let intervalId: NodeJS.Timeout | null = null;
    if (isOpen && isAutoRefresh) {
      intervalId = setInterval(() => {
        fetchLiveOptionsFromServer(activeSymbol, selectedExpiryIndex, activeCmp);
      }, 5000);
    }
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isOpen, isAutoRefresh, activeSymbol, selectedExpiryIndex, activeCmp]);

  // Update Data Age indicator string every second
  useEffect(() => {
    const updateAge = () => {
      if (!lastSyncedTime) {
        setTimeAgo('Syncing...');
        return;
      }
      const diffSec = Math.max(0, Math.floor((Date.now() - lastSyncedTime.getTime()) / 1000));
      if (diffSec < 2) {
        setTimeAgo('Just now');
      } else if (diffSec < 60) {
        setTimeAgo(`${diffSec}s ago`);
      } else {
        const mins = Math.floor(diffSec / 60);
        const remSec = diffSec % 60;
        setTimeAgo(`${mins}m ${remSec}s ago`);
      }
    };

    updateAge();
    const interval = setInterval(updateAge, 1000);
    return () => clearInterval(interval);
  }, [lastSyncedTime]);

  // Fetch live spot & option chain directly from connected Broker API without synthetic fabrication
  const fetchLiveOptionsFromServer = async (sym: string, expiryIdx: number = 0, explicitCmp?: number) => {
    try {
      setIsLoading(true);
      setErrorMsg(null);
      const targetCmp = explicitCmp !== undefined && explicitCmp > 0 ? explicitCmp : (sym === symbol ? cmp : undefined);
      const cmpParam = targetCmp ? `&cmp=${targetCmp}` : '';
      
      const savedConfigStr = typeof window !== 'undefined' ? localStorage.getItem('timesfm_custom_api_config') : null;
      const headers: Record<string, string> = {};
      if (savedConfigStr) {
        headers['x-custom-api-config'] = encodeURIComponent(savedConfigStr);
      }

      const res = await fetch(`/api/market/options?symbol=${encodeURIComponent(sym)}&expiryIndex=${expiryIdx}${cmpParam}`, { headers });
      if (res.ok) {
        const data: OptionChainPayload = await res.json();
        if (data && data.options && data.options.length > 0) {
          setChainPayload(data);
          setErrorMsg(null);
          setActiveCmp(data.underlyingPrice);
          setLotSize(data.lotSize);
          setLastSyncedTime(new Date());
          setSelectedStrike(data.atmStrike);
        } else {
          setChainPayload(null);
          setErrorMsg(`No option chain contracts returned from broker API for ${sym}.`);
        }
      } else {
        const errJson = await res.json().catch(() => ({}));
        setChainPayload(null);
        setErrorMsg(errJson.error || `No live option chain data available from connected broker API for ${sym}.`);
      }
    } catch (e: any) {
      setChainPayload(null);
      setErrorMsg(`Failed to connect to Broker API: ${e?.message || 'Network error'}. Please check your Broker API Token.`);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Expiry Change
  const handleExpiryChange = (idx: number) => {
    setSelectedExpiryIndex(idx);
    fetchLiveOptionsFromServer(activeSymbol, idx, activeCmp);
  };

  // Handle Switch Symbol
  const handleSwitchSymbol = (newSym: string) => {
    setActiveSymbol(newSym);
    setActiveName(newSym);
    setSearchQuery('');
    setSelectedExpiryIndex(0);
    // When switching symbol, fetch fresh real-time/last closing price from server (do not carry over old stock's cmp)
    fetchLiveOptionsFromServer(newSym, 0, undefined);
    onSelectStockSymbol?.(newSym);
  };

  // Filter strikes
  const filteredRows = useMemo(() => {
    if (!chainPayload || !chainPayload.options || !chainPayload.options.length) return [];
    const rows = chainPayload.options;
    if (strikeFilter === 'ALL') return rows;
    if (strikeFilter === 'NEAR_ATM') {
      const atmIdx = rows.findIndex(r => r.strike === chainPayload.atmStrike || r.isAtm);
      if (atmIdx === -1) return rows.slice(0, 16);
      const start = Math.max(0, atmIdx - 7);
      const end = Math.min(rows.length, atmIdx + 8);
      return rows.slice(start, end);
    }
    if (strikeFilter === 'ITM_ONLY') {
      return rows.filter(r => r.strike <= chainPayload.underlyingPrice);
    }
    if (strikeFilter === 'OTM_ONLY') {
      return rows.filter(r => r.strike >= chainPayload.underlyingPrice);
    }
    return rows;
  }, [chainPayload, strikeFilter]);

  // Selected Option Details for Payoff Calculation
  const activeSelectedStrike = selectedStrike || chainPayload?.atmStrike || 0;
  const activeRow = chainPayload?.options?.find(r => r.strike === activeSelectedStrike);
  const activeOption = selectedContractType === 'CE' ? activeRow?.call : activeRow?.put;
  const activePremium = activeOption?.lastPrice || 1.0;
  const breakevenPoint = selectedContractType === 'CE' 
    ? activeSelectedStrike + activePremium 
    : activeSelectedStrike - activePremium;
  const maxRiskCapital = Math.round(activePremium * lotSize);

  // Virtual Trade Execution
  const handleExecuteOptionTrade = () => {
    try {
      const tradeSym = `${activeSymbol.toUpperCase()} ${activeSelectedStrike} ${selectedContractType}`;
      const slPrice = Math.max(0.1, Math.round((activePremium * 0.65) * 10) / 10);
      const t1Price = Math.round((activePremium * 1.5) * 10) / 10;
      const t2Price = Math.round((activePremium * 2.2) * 10) / 10;

      openVirtualTrade({
        symbol: tradeSym,
        name: `${activeSymbol} ${activeSelectedStrike} ${selectedContractType} Option`,
        direction: 'LONG',
        entryPrice: activePremium,
        quantity: lotSize,
        stopLoss: slPrice,
        target1: t1Price,
        target2: t2Price,
        score: 88
      });

      setOrderNotification(`Executed Virtual Order: ${lotSize} Qty of ${tradeSym} @ ₹${activePremium}`);
      setTimeout(() => setOrderNotification(null), 4000);
      onExecuteTrade?.({ symbol: tradeSym, price: activePremium, lotSize });
    } catch (e) {
      alert('Could not execute paper trade');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-6xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[96vh] sm:max-h-[94vh] text-slate-100 ring-1 ring-cyan-500/20">
        
        {/* Header */}
        <div className="px-3 sm:px-4 py-2.5 sm:py-3 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-cyan-500/20 shrink-0">
              <Layers className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-wide truncate">
                  F&O Option Chain & Greeks
                </h3>
                <span className="px-1.5 sm:px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shrink-0">
                  {activeSymbol} {chainPayload ? `• ${currencySymbol}${chainPayload.underlyingPrice.toLocaleString()}` : ''}
                </span>
                {chainPayload && (
                  <span className={`px-1.5 sm:px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${
                    chainPayload.isFnoEnabled
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                      : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                  }`}>
                    {chainPayload.isFnoEnabled ? '🟢 F&O Active' : '⚠️ Cash Only'}
                  </span>
                )}
                {chainPayload?.provider && (
                  <span className={`px-1.5 sm:px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 flex items-center gap-1 shadow-sm ${
                    chainPayload.sourceState === 'LIVE'
                      ? 'bg-emerald-950/90 text-emerald-200 border-emerald-400/60 shadow-emerald-950'
                      : chainPayload.sourceState === 'CACHED'
                      ? 'bg-blue-950/90 text-blue-200 border-blue-400/60 shadow-blue-950'
                      : chainPayload.sourceState === 'SIMULATED'
                      ? 'bg-amber-950/90 text-amber-200 border-amber-400/60 shadow-amber-950'
                      : 'bg-rose-950/90 text-rose-200 border-rose-400/60 shadow-rose-950'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      chainPayload.sourceState === 'LIVE' ? 'bg-emerald-400 animate-pulse' :
                      chainPayload.sourceState === 'CACHED' ? 'bg-blue-400' :
                      chainPayload.sourceState === 'SIMULATED' ? 'bg-amber-400' : 'bg-rose-400'
                    }`} />
                    <span>
                      {chainPayload.sourceState === 'LIVE' ? `🟢 ${chainPayload.provider}` :
                       chainPayload.sourceState === 'SIMULATED' ? `🟠 ${chainPayload.provider}` :
                       chainPayload.sourceState === 'CACHED' ? `🔵 Cached Options` : `🔴 Feed Unavailable`}
                    </span>
                  </span>
                )}
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate mt-0.5">
                {chainPayload 
                  ? `${chainPayload.contractTypeLabel} • Lot: ${chainPayload.lotSize} • Step: ${chainPayload.strikeInterval}`
                  : `Connecting to Broker API Feed for ${activeSymbol}...`}
              </p>
              {chainPayload?.sourceState === 'LIVE' && /angel one/i.test(chainPayload.provider) && (
                <p className="text-[9px] text-cyan-300/80 mt-0.5">
                  OI buildup compares with the previous app snapshot; first refresh establishes the baseline.
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Live Data Age & Sync Indicator */}
            <div 
              className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-slate-950 border border-slate-800 text-[10px] sm:text-xs font-mono"
              title={lastSyncedTime ? `Last Synced: ${lastSyncedTime.toLocaleTimeString()}` : 'Syncing...'}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${
                isLoading 
                  ? 'bg-amber-400 animate-pulse' 
                  : isAutoRefresh 
                  ? 'bg-emerald-400 animate-pulse' 
                  : chainPayload ? 'bg-cyan-400' : 'bg-rose-400'
              }`} />
              <span className="text-slate-400 hidden sm:inline">Synced:</span>
              <strong className={isLoading ? 'text-amber-300' : chainPayload ? 'text-cyan-300' : 'text-rose-400'}>
                {isLoading ? 'Syncing...' : timeAgo}
              </strong>
            </div>

            {/* Expiry Selector */}
            {chainPayload && chainPayload.expirationDates && chainPayload.expirationDates.length > 0 && (
              <div className="flex items-center gap-1 bg-slate-950 px-2 py-1 rounded-xl border border-slate-800 text-xs">
                <span className="text-slate-400 text-[10px] sm:text-[11px] hidden xs:inline">Expiry:</span>
                <select
                  value={selectedExpiryIndex}
                  onChange={(e) => handleExpiryChange(Number(e.target.value))}
                  className="bg-transparent text-cyan-300 font-semibold focus:outline-none cursor-pointer text-xs"
                >
                  {chainPayload.expirationDates.map((exp, idx) => (
                    <option key={exp.timestamp} value={idx} className="bg-slate-900 text-white">
                      {exp.label} ({exp.daysToExpiry}D)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Auto Stream Toggle */}
            <button
              onClick={() => setIsAutoRefresh(!isAutoRefresh)}
              className={`px-2 py-1 rounded-xl text-[10px] sm:text-xs font-bold transition flex items-center gap-1 cursor-pointer border ${
                isAutoRefresh 
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/60 shadow-sm shadow-emerald-950' 
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
              title={isAutoRefresh ? 'Auto Live Refresh is ON (every 5s)' : 'Click to enable 5s Auto-Refresh'}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${isAutoRefresh ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
              <span className="hidden xs:inline">{isAutoRefresh ? 'Live (5s)' : 'Stream'}</span>
            </button>

            {/* Broker Settings Quick Trigger */}
            <button
              onClick={() => {
                const currentConfigStr = localStorage.getItem('timesfm_custom_api_config');
                let currentConfig: any = null;
                try {
                  currentConfig = currentConfigStr ? JSON.parse(currentConfigStr) : null;
                } catch {}
                const newKey = prompt('🔑 Connect Direct Broker Option Chain Feed:\nEnter your Broker API Key / JWT Token (Angel One SmartAPI, Upstox, Dhan, or Custom Bridge):', currentConfig?.apiKey || '');
                if (newKey !== null) {
                  const updated = {
                    ...(currentConfig || {}),
                    provider: 'custom_api',
                    customApiName: currentConfig?.customApiName || 'AngelOne SmartAPI',
                    url: currentConfig?.url || 'https://apiconnect.angelone.in/rest/secure/angelbroking/market/v1/quote',
                    apiKey: newKey.trim(),
                    authType: 'Bearer',
                    authHeader: 'Authorization',
                    isConnected: Boolean(newKey.trim())
                  };
                  localStorage.setItem('timesfm_custom_api_config', JSON.stringify(updated));
                  fetchLiveOptionsFromServer(activeSymbol, selectedExpiryIndex, activeCmp);
                }
              }}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 transition cursor-pointer"
              title="Configure Broker API Key / SmartAPI Token for Direct Live Market Option Chain"
            >
              <Key className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
            </button>

            {/* Manual Refresh Button */}
            <button
              onClick={() => fetchLiveOptionsFromServer(activeSymbol, selectedExpiryIndex)}
              disabled={isLoading}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
              title="Refresh live option prices"
            >
              <RefreshCw className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </div>
        </div>

        {/* Quick Ticker Switcher Bar */}
        <div className="px-3 py-1.5 bg-slate-950 border-b border-slate-850 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none text-xs shrink-0">
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Quick F&O:</span>
            {POPULAR_FNO_TICKERS.map((sym) => (
              <button
                key={sym}
                onClick={() => handleSwitchSymbol(sym)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border transition cursor-pointer ${
                  activeSymbol.toUpperCase() === sym
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
                }`}
              >
                {sym}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <input
              type="text"
              placeholder="Search Symbol..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value.toUpperCase())}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchQuery.trim()) {
                  handleSwitchSymbol(searchQuery.trim());
                }
              }}
              className="w-28 sm:w-36 px-2 py-0.5 rounded bg-slate-900 border border-slate-750 text-[11px] text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            {searchQuery && (
              <button
                onClick={() => handleSwitchSymbol(searchQuery.trim())}
                className="px-2 py-0.5 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-[10px] font-bold"
              >
                Go
              </button>
            )}
          </div>
        </div>

        {/* Order notification */}
        {orderNotification && (
          <div className="bg-emerald-950/90 border-b border-emerald-500/50 px-4 py-2 text-xs font-semibold text-emerald-200 flex items-center justify-between animate-in fade-in shrink-0">
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>{orderNotification}</span>
            </span>
            <span className="text-[10px] text-emerald-300 font-mono">Recorded in Virtual Portfolio</span>
          </div>
        )}

        {/* Market Status & Metrics Bar (Only rendered when Real Broker Data is received) */}
        {chainPayload && (
          <div className="p-2 sm:p-3 bg-slate-950/90 border-b border-slate-800 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs shrink-0">
            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Put-Call Ratio (PCR)</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <strong className="text-xs sm:text-sm font-black text-cyan-300 font-mono">{chainPayload.pcr}</strong>
                <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded truncate ${
                  chainPayload.pcr > 1.25 ? 'bg-emerald-950 text-emerald-300' : chainPayload.pcr < 0.75 ? 'bg-rose-950 text-rose-300' : 'bg-slate-800 text-slate-300'
                }`}>
                  {chainPayload.pcr > 1.25 ? 'Bullish' : chainPayload.pcr < 0.75 ? 'Bearish' : 'Neutral'}
                </span>
              </div>
            </div>

            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">ATM Strike</span>
              <div className="flex items-center gap-1.5 mt-0.5 font-mono">
                <strong className="text-xs sm:text-sm font-black text-white">{currencySymbol}{chainPayload.atmStrike.toLocaleString()}</strong>
                <span className="text-[9px] text-slate-400">Step: {chainPayload.strikeInterval}</span>
              </div>
            </div>

            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Max Pain Level</span>
              <div className="flex items-center gap-1.5 mt-0.5 font-mono">
                <strong className="text-xs sm:text-sm font-black text-amber-300">{currencySymbol}{chainPayload.maxPain.toLocaleString()}</strong>
                <span className="text-[9px] text-slate-400">Magnet</span>
              </div>
            </div>

            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Net Gamma (GEX)</span>
              <div className="flex items-center gap-1.5 mt-0.5 font-mono">
                <strong className={`text-xs sm:text-sm font-black ${chainPayload.gexMetrics?.totalNetGexCr >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {chainPayload.gexMetrics?.totalNetGexCr >= 0 ? `+₹${chainPayload.gexMetrics?.totalNetGexCr}` : `-₹${Math.abs(chainPayload.gexMetrics?.totalNetGexCr || 0)}`}Cr
                </strong>
                <span className={`text-[8px] font-bold px-1 rounded truncate ${chainPayload.gexMetrics?.gexRegime === 'POSITIVE_GAMMA' ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                  {chainPayload.gexMetrics?.gexRegime === 'POSITIVE_GAMMA' ? '+Gamma' : '-Gamma'}
                </span>
              </div>
            </div>

            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">IV Rank (IVR)</span>
              <div className="flex items-center gap-1.5 mt-0.5 font-mono">
                <strong className="text-xs sm:text-sm font-black text-purple-300">{chainPayload.ivMetrics?.ivRank != null ? `${chainPayload.ivMetrics.ivRank}%` : 'N/A'}</strong>
                <span className="text-[9px] text-slate-400">IV: {chainPayload.atmIv}%</span>
              </div>
            </div>

            <div className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Order Flow Bias</span>
              <div className="flex items-center gap-1.5 mt-0.5 font-mono">
                <strong className={`text-xs font-black truncate ${
                  chainPayload.orderFlowMetrics?.orderFlowBias === 'INSTITUTIONAL_BULLISH_FLOW' ? 'text-emerald-400' :
                  chainPayload.orderFlowMetrics?.orderFlowBias === 'INSTITUTIONAL_BEARISH_FLOW' ? 'text-rose-400' : 'text-slate-300'
                }`}>
                  {chainPayload.sourceState === 'LIVE' ? 'N/A · trade ticks missing' : `${(chainPayload.orderFlowMetrics?.netOptionsCvd / 1000).toFixed(1)}k simulated CVD`}
                </strong>
              </div>
            </div>
          </div>
        )}

        {/* View Mode Tabs & Filter Bar (Only rendered when Real Broker Data is received) */}
        {chainPayload && (
          <div className="px-3 py-1.5 bg-slate-950 border-b border-slate-800/80 flex items-center justify-between gap-2 flex-wrap shrink-0">
            {/* Switch Tabs */}
            <div className="flex items-center gap-1 bg-slate-900 p-0.5 rounded-xl border border-slate-800 overflow-x-auto max-w-full">
              {[
                { id: 'TABLE', label: 'Full Chain', icon: Layers },
                { id: 'GEX', label: 'Gamma (GEX)', icon: Anchor, highlight: true },
                { id: 'IV_MATRIX', label: 'IV Matrix', icon: Gauge, highlight: true },
                { id: 'ORDER_FLOW', label: 'Order Flow', icon: Waves, highlight: true },
                { id: 'MATRIX', label: 'Mobile Ladder', icon: Zap },
                { id: 'PAYOFF', label: 'Payoff & Greeks', icon: Activity }
              ].map(tab => {
                const Icon = tab.icon;
                const isActive = activeViewTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveViewTab(tab.id as any)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                      isActive
                        ? 'bg-cyan-600 text-white shadow-sm font-bold'
                        : tab.highlight
                        ? 'text-cyan-300 hover:text-white hover:bg-slate-800/60'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : tab.highlight ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Filter Bar */}
            <div className="flex items-center gap-1 text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-400 hidden xs:inline" />
              {[
                { id: 'NEAR_ATM', label: 'ATM (±7)' },
                { id: 'ALL', label: 'All' },
                { id: 'ITM_ONLY', label: 'ITM' },
                { id: 'OTM_ONLY', label: 'OTM' }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setStrikeFilter(f.id as any)}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition cursor-pointer ${
                    strikeFilter === f.id
                      ? 'bg-slate-750 text-cyan-300 font-bold border border-cyan-500/40'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-3 space-y-3">
          {isLoading && (
            <div className="p-16 text-center text-slate-400 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
              <p className="text-sm font-semibold text-white">Streaming live option chain from Broker API for {activeSymbol}...</p>
              <p className="text-xs text-slate-500">Connecting to matching engine order depth feed</p>
            </div>
          )}

          {!isLoading && !chainPayload && errorMsg && (
            <div className="p-6 sm:p-8 rounded-2xl bg-slate-900/90 border border-slate-800 text-center max-w-xl mx-auto my-8 space-y-4 shadow-2xl">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Real Broker API Data Required</h4>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  {errorMsg}
                </p>
                <div className="mt-3 p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-cyan-300 text-left font-mono">
                  <strong className="text-white block mb-0.5">Strict Real-Data Policy Active:</strong>
                  No synthetic mathematical data is generated. We only display 100% verified real exchange quotes from your connected Broker API.
                </div>
              </div>
              <div className="flex items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => {
                    const currentConfigStr = localStorage.getItem('timesfm_custom_api_config');
                    let currentConfig: any = null;
                    try { currentConfig = currentConfigStr ? JSON.parse(currentConfigStr) : null; } catch {}
                    const newKey = prompt('🔑 Connect Direct Broker Option Chain Feed:\nEnter your Broker API Key / JWT Token (Angel One SmartAPI, Upstox, Dhan, or Custom Bridge):', currentConfig?.apiKey || '');
                    if (newKey !== null) {
                      const updated = {
                        ...(currentConfig || {}),
                        provider: 'custom_api',
                        customApiName: currentConfig?.customApiName || 'AngelOne SmartAPI',
                        url: currentConfig?.url || 'https://apiconnect.angelone.in/rest/secure/angelbroking/market/v1/quote',
                        apiKey: newKey.trim(),
                        authType: 'Bearer',
                        authHeader: 'Authorization',
                        isConnected: Boolean(newKey.trim())
                      };
                      localStorage.setItem('timesfm_custom_api_config', JSON.stringify(updated));
                      fetchLiveOptionsFromServer(activeSymbol, selectedExpiryIndex, activeCmp);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-600/30"
                >
                  <Key className="w-4 h-4" />
                  <span>Enter Broker API Token</span>
                </button>
                <button
                  onClick={() => fetchLiveOptionsFromServer(activeSymbol, selectedExpiryIndex, activeCmp)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition cursor-pointer"
                >
                  Retry Fetch
                </button>
              </div>
            </div>
          )}

          {/* Tabs and Payoff Execution Bar (Only when real broker chain data is present) */}
          {!isLoading && chainPayload && (
            <>
              {/* TAB 1: Institutional Full Table (with Sensibull-style visual OI bars & Greeks) */}
              {activeViewTab === 'TABLE' && (
            <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950/70 shadow-lg">
              <div className="overflow-x-auto">
                <table className="w-full text-center text-xs font-mono border-collapse min-w-[760px]">
                  <thead>
                    <tr className="bg-slate-900/90 text-[10px] text-slate-400 uppercase tracking-wider border-b border-slate-800 sticky top-0 z-10">
                      <th colSpan={6} className="py-2 px-2 bg-emerald-950/30 text-emerald-300 border-r border-slate-800 font-sans font-bold">
                        CALL OPTIONS (CE)
                      </th>
                      <th className="py-2 px-3 bg-slate-900 text-white font-sans font-black">
                        STRIKE
                      </th>
                      <th colSpan={6} className="py-2 px-2 bg-rose-950/30 text-rose-300 border-l border-slate-800 font-sans font-bold">
                        PUT OPTIONS (PE)
                      </th>
                    </tr>
                    <tr className="bg-slate-900/60 text-[9px] text-slate-400 border-b border-slate-800 font-sans">
                      <th className="py-1.5 px-2">OI (Visual)</th>
                      <th className="py-1.5 px-2">Chg OI</th>
                      <th className="py-1.5 px-2">IV (%)</th>
                      <th className="py-1.5 px-2">Delta</th>
                      <th className="py-1.5 px-2">Theta</th>
                      <th className="py-1.5 px-2 border-r border-slate-800 text-right">LTP (₹)</th>
                      <th className="py-1.5 px-3 bg-slate-900 text-white">Strike</th>
                      <th className="py-1.5 px-2 border-l border-slate-800 text-left">LTP (₹)</th>
                      <th className="py-1.5 px-2">Delta</th>
                      <th className="py-1.5 px-2">Theta</th>
                      <th className="py-1.5 px-2">IV (%)</th>
                      <th className="py-1.5 px-2">Chg OI</th>
                      <th className="py-1.5 px-2">OI (Visual)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-[11px]">
                    {filteredRows.map((row) => {
                      const isSelected = selectedStrike === row.strike;
                      const isItmCall = row.strike < chainPayload.underlyingPrice;
                      const isItmPut = row.strike > chainPayload.underlyingPrice;

                      return (
                        <tr
                          key={row.strike}
                          onClick={() => setSelectedStrike(row.strike)}
                          className={`transition cursor-pointer ${
                            row.isAtm
                              ? 'bg-amber-950/30 font-bold'
                              : isSelected
                              ? 'bg-indigo-950/40'
                              : 'hover:bg-slate-850/50'
                          }`}
                        >
                          {/* CALL OI Visual Bar */}
                          <td 
                            title={`Call OI: ${row.call.openInterest.toLocaleString()} shares (${Math.round(row.call.openInterest / lotSize)} lots)`}
                            className={`py-2 px-2 text-slate-300 relative overflow-hidden font-mono text-center ${isItmCall ? 'bg-emerald-950/20' : ''}`}
                          >
                            <div 
                              className="absolute top-0 right-0 bottom-0 bg-rose-500/20 pointer-events-none transition-all"
                              style={{ width: `${row.call.oiPercent || 15}%` }}
                            />
                            <span className="relative z-1 font-semibold">{formatIndianNumber(row.call.openInterest)}</span>
                          </td>

                          {/* CALL CHG OI */}
                          <td 
                            title={`Change in OI: ${row.call.changeInOi >= 0 ? '+' : ''}${row.call.changeInOi.toLocaleString()} shares (${row.call.changeInOiPct >= 0 ? '+' : ''}${row.call.changeInOiPct}%) - ${row.call.buildup || ''}`}
                            className={`py-1 px-1.5 text-[10px] leading-tight text-center ${row.call.changeInOi >= 0 ? 'text-emerald-400' : 'text-rose-400'} ${isItmCall ? 'bg-emerald-950/20' : ''}`}
                          >
                            <div className="font-semibold font-mono">
                              {row.call.changeInOi >= 0 ? `+${formatIndianNumber(row.call.changeInOi)}` : formatIndianNumber(row.call.changeInOi)}
                            </div>
                            <div className="text-[9px] opacity-80 font-mono">
                              {row.call.changeInOiPct >= 0 ? `+${row.call.changeInOiPct}%` : `${row.call.changeInOiPct}%`}
                            </div>
                            {row.call.buildup && (
                              <span className={`inline-block text-[7px] px-1 rounded font-sans font-bold uppercase ${
                                row.call.buildup === 'Long Buildup' ? 'bg-emerald-500/20 text-emerald-300' :
                                row.call.buildup === 'Short Buildup' ? 'bg-rose-500/20 text-rose-300' :
                                row.call.buildup === 'Short Covering' ? 'bg-cyan-500/20 text-cyan-300' :
                                'bg-amber-500/20 text-amber-300'
                              }`}>
                                {row.call.buildup === 'Long Buildup' ? 'LB' : row.call.buildup === 'Short Buildup' ? 'SB' : row.call.buildup === 'Short Covering' ? 'SC' : 'LU'}
                              </span>
                            )}
                          </td>

                          {/* CALL IV */}
                          <td className={`py-2 px-1 text-slate-400 font-mono ${isItmCall ? 'bg-emerald-950/20' : ''}`}>
                            {row.call.impliedVolatility.toFixed(1)}%
                          </td>

                          {/* CALL DELTA */}
                          <td className={`py-2 px-1 text-emerald-400 font-semibold font-mono ${isItmCall ? 'bg-emerald-950/20' : ''}`}>
                            +{row.call.delta.toFixed(3)}
                          </td>

                          {/* CALL THETA */}
                          <td 
                            title={`Daily Time Decay: -₹${row.call.theta.toFixed(2)} / share (-₹${(row.call.thetaLot || row.call.theta * lotSize).toFixed(2)} / lot)`}
                            className={`py-2 px-1 text-slate-400 font-mono ${isItmCall ? 'bg-emerald-950/20' : ''}`}
                          >
                            -₹{row.call.theta.toFixed(2)}
                          </td>

                          {/* CALL LTP */}
                          <td className={`py-2 px-2 border-r border-slate-800 text-right font-bold text-white ${isItmCall ? 'bg-emerald-950/25' : ''}`}>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedStrike(row.strike);
                                setSelectedContractType('CE');
                              }}
                              className={`px-2 py-0.5 rounded text-xs transition cursor-pointer font-mono ${
                                isSelected && selectedContractType === 'CE'
                                  ? 'bg-emerald-600 text-white shadow ring-2 ring-emerald-400/50'
                                  : 'hover:bg-emerald-900/60 text-emerald-300'
                              }`}
                            >
                              ₹{row.call.lastPrice.toFixed(2)}
                            </button>
                          </td>

                          {/* STRIKE PRICE */}
                          <td className={`py-2 px-3 font-bold text-center ${
                            row.isAtm
                              ? 'bg-amber-500/20 text-amber-300 border-x border-amber-500/50 font-black'
                              : 'bg-slate-900 text-white'
                          }`}>
                            {row.strike}
                            {row.isAtm && <span className="block text-[8px] font-sans text-amber-300 font-bold">ATM</span>}
                          </td>

                          {/* PUT LTP */}
                          <td className={`py-2 px-2 border-l border-slate-800 text-left font-bold text-white ${isItmPut ? 'bg-rose-950/25' : ''}`}>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedStrike(row.strike);
                                setSelectedContractType('PE');
                              }}
                              className={`px-2 py-0.5 rounded text-xs transition cursor-pointer font-mono ${
                                isSelected && selectedContractType === 'PE'
                                  ? 'bg-rose-600 text-white shadow ring-2 ring-rose-400/50'
                                  : 'hover:bg-rose-950/60 text-rose-300'
                              }`}
                            >
                              ₹{row.put.lastPrice.toFixed(2)}
                            </button>
                          </td>

                          {/* PUT DELTA */}
                          <td className={`py-2 px-1 text-rose-400 font-semibold font-mono ${isItmPut ? 'bg-rose-950/20' : ''}`}>
                            {row.put.delta.toFixed(3)}
                          </td>

                          {/* PUT THETA */}
                          <td 
                            title={`Daily Time Decay: -₹${row.put.theta.toFixed(2)} / share (-₹${(row.put.thetaLot || row.put.theta * lotSize).toFixed(2)} / lot)`}
                            className={`py-2 px-1 text-slate-400 font-mono ${isItmPut ? 'bg-rose-950/20' : ''}`}
                          >
                            -₹{row.put.theta.toFixed(2)}
                          </td>

                          {/* PUT IV */}
                          <td className={`py-2 px-1 text-slate-400 font-mono ${isItmPut ? 'bg-rose-950/20' : ''}`}>
                            {row.put.impliedVolatility.toFixed(1)}%
                          </td>

                          {/* PUT CHG OI */}
                          <td 
                            title={`Change in OI: ${row.put.changeInOi >= 0 ? '+' : ''}${row.put.changeInOi.toLocaleString()} shares (${row.put.changeInOiPct >= 0 ? '+' : ''}${row.put.changeInOiPct}%) - ${row.put.buildup || ''}`}
                            className={`py-1 px-1.5 text-[10px] leading-tight text-center ${row.put.changeInOi >= 0 ? 'text-emerald-400' : 'text-rose-400'} ${isItmPut ? 'bg-rose-950/20' : ''}`}
                          >
                            <div className="font-semibold font-mono">
                              {row.put.changeInOi >= 0 ? `+${formatIndianNumber(row.put.changeInOi)}` : formatIndianNumber(row.put.changeInOi)}
                            </div>
                            <div className="text-[9px] opacity-80 font-mono">
                              {row.put.changeInOiPct >= 0 ? `+${row.put.changeInOiPct}%` : `${row.put.changeInOiPct}%`}
                            </div>
                            {row.put.buildup && (
                              <span className={`inline-block text-[7px] px-1 rounded font-sans font-bold uppercase ${
                                row.put.buildup === 'Long Buildup' ? 'bg-emerald-500/20 text-emerald-300' :
                                row.put.buildup === 'Short Buildup' ? 'bg-rose-500/20 text-rose-300' :
                                row.put.buildup === 'Short Covering' ? 'bg-cyan-500/20 text-cyan-300' :
                                'bg-amber-500/20 text-amber-300'
                              }`}>
                                {row.put.buildup === 'Long Buildup' ? 'LB' : row.put.buildup === 'Short Buildup' ? 'SB' : row.put.buildup === 'Short Covering' ? 'SC' : 'LU'}
                              </span>
                            )}
                          </td>

                          {/* PUT OI Visual Bar */}
                          <td 
                            title={`Put OI: ${row.put.openInterest.toLocaleString()} shares (${Math.round(row.put.openInterest / lotSize)} lots)`}
                            className={`py-2 px-2 text-slate-300 relative overflow-hidden font-mono text-center ${isItmPut ? 'bg-rose-950/20' : ''}`}
                          >
                            <div 
                              className="absolute top-0 left-0 bottom-0 bg-emerald-500/20 pointer-events-none transition-all"
                              style={{ width: `${row.put.oiPercent || 15}%` }}
                            />
                            <span className="relative z-1 font-semibold">{formatIndianNumber(row.put.openInterest)}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: Gamma Exposure (GEX) Quantitative Dashboard */}
          {activeViewTab === 'GEX' && (
            <div className="space-y-3">
              {/* GEX Quantitative KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Net Gamma Exposure (GEX)</span>
                  <div className="flex items-baseline gap-1.5 mt-1 font-mono">
                    <strong className={`text-base font-black ${chainPayload.gexMetrics.totalNetGexCr >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {chainPayload.gexMetrics.totalNetGexCr >= 0 ? `+₹${chainPayload.gexMetrics.totalNetGexCr}` : `-₹${Math.abs(chainPayload.gexMetrics.totalNetGexCr)}`} Cr
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">Dealer Δ per 1% spot move</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Dealer Gamma Regime</span>
                  <div className="flex items-center gap-1.5 mt-1 font-mono">
                    <strong className={`text-xs font-bold px-2 py-0.5 rounded uppercase ${
                      chainPayload.gexMetrics.gexRegime === 'POSITIVE_GAMMA' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' : 'bg-rose-950 text-rose-300 border border-rose-500/40'
                    }`}>
                      {chainPayload.gexMetrics.gexRegime === 'POSITIVE_GAMMA' ? '+Gamma (Volatility Low)' : '-Gamma (Vol Breakout)'}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">
                    {chainPayload.gexMetrics.gexRegime === 'POSITIVE_GAMMA' ? 'Mean-Reverting & Pinning' : 'Momentum Acceleration'}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Zero Gamma Flip Strike</span>
                  <div className="flex items-baseline gap-1.5 mt-1 font-mono">
                    <strong className="text-base font-black text-amber-300">
                      ₹{(chainPayload.gexMetrics.zeroGammaFlipStrike === null ? 'N/A' : chainPayload.gexMetrics.zeroGammaFlipStrike.toLocaleString())}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">Regime Transition Pivot</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Call GEX Resistance (Pin)</span>
                  <div className="flex items-baseline gap-1.5 mt-1 font-mono">
                    <strong className="text-base font-black text-emerald-400">
                      ₹{chainPayload.gexMetrics.callGexResistanceStrike.toLocaleString()}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">+₹{chainPayload.gexMetrics.totalCallGexCr} Cr Call Wall</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Put GEX Support (Floor)</span>
                  <div className="flex items-baseline gap-1.5 mt-1 font-mono">
                    <strong className="text-base font-black text-rose-400">
                      ₹{chainPayload.gexMetrics.putGexSupportStrike.toLocaleString()}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">-₹{Math.abs(chainPayload.gexMetrics.totalPutGexCr)} Cr Put Floor</span>
                </div>
              </div>

              {/* Dealer Playbook Explanation */}
              <div className="p-3 bg-slate-900/90 border border-slate-800 rounded-xl text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-cyan-300">
                  <Anchor className="w-4 h-4 text-cyan-400" />
                  <span>Institutional Dealer Hedging Dynamics ({chainPayload.symbol})</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  {chainPayload.gexMetrics.regimeDescription}
                </p>
              </div>

              {/* Strike-by-Strike GEX Distribution Ladder */}
              <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950/80 shadow-lg">
                <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs font-bold text-white">
                  <span className="flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-cyan-400" />
                    Strike-Level Gamma Exposure (GEX in ₹ Crores)
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Underlying Spot: ₹{chainPayload.underlyingPrice.toFixed(2)}
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-center text-xs font-mono border-collapse min-w-[700px]">
                    <thead>
                      <tr className="bg-slate-900/60 text-[9px] text-slate-400 border-b border-slate-800">
                        <th className="py-2 px-3 text-right">Call GEX (₹ Cr)</th>
                        <th className="py-2 px-3 text-center">Net GEX Bar</th>
                        <th className="py-2 px-3 text-center bg-slate-900 text-white font-bold">STRIKE</th>
                        <th className="py-2 px-3 text-center">Gamma (Γ)</th>
                        <th className="py-2 px-3 text-left">Put GEX (₹ Cr)</th>
                        <th className="py-2 px-3 text-left">Microstructure Level</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-[11px]">
                      {filteredRows.map((r) => {
                        const isCallWall = r.strike === chainPayload.gexMetrics.callGexResistanceStrike;
                        const isPutWall = r.strike === chainPayload.gexMetrics.putGexSupportStrike;
                        const isFlip = chainPayload.gexMetrics.zeroGammaFlipStrike !== null && Math.abs(r.strike - chainPayload.gexMetrics.zeroGammaFlipStrike) <= chainPayload.strikeInterval / 2;

                        return (
                          <tr 
                            key={r.strike}
                            onClick={() => setSelectedStrike(r.strike)}
                            className={`transition cursor-pointer ${
                              r.isAtm ? 'bg-amber-950/30 font-bold' : isCallWall ? 'bg-emerald-950/20' : isPutWall ? 'bg-rose-950/20' : 'hover:bg-slate-850/50'
                            }`}
                          >
                            <td className="py-2 px-3 text-right font-semibold text-emerald-400">
                              +₹{r.call.gexCr.toFixed(2)} Cr
                            </td>
                            <td className="py-2 px-2">
                              <div className="w-full h-3 bg-slate-900 rounded flex items-center overflow-hidden border border-slate-800">
                                <div 
                                  className="h-full bg-rose-500/70"
                                  style={{ width: `${Math.min(50, Math.abs(r.put.gexCr) * 4)}%` }}
                                />
                                <div 
                                  className="h-full bg-emerald-500/70 ml-auto"
                                  style={{ width: `${Math.min(50, r.call.gexCr * 4)}%` }}
                                />
                              </div>
                            </td>
                            <td className={`py-2 px-3 font-bold text-center ${r.isAtm ? 'bg-amber-500/20 text-amber-300 font-black' : 'text-white'}`}>
                              {r.strike}
                              {r.isAtm && <span className="block text-[8px] text-amber-300 font-sans">ATM</span>}
                            </td>
                            <td className="py-2 px-3 text-slate-400">
                              {r.call.gamma.toFixed(4)}
                            </td>
                            <td className="py-2 px-3 text-left font-semibold text-rose-400">
                              -₹{Math.abs(r.put.gexCr).toFixed(2)} Cr
                            </td>
                            <td className="py-2 px-3 text-left">
                              {isCallWall ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                  📌 Major Call GEX Wall (Ceiling)
                                </span>
                              ) : isPutWall ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                                  🛡️ Major Put GEX Support (Floor)
                                </span>
                              ) : isFlip ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                                  ⚖️ Zero Gamma Flip
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-500 font-sans">
                                  {r.netGexCr >= 0 ? `+Net GEX ₹${r.netGexCr} Cr` : `-Net GEX ₹${Math.abs(r.netGexCr)} Cr`}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Implied Volatility (IV) Matrix & Cone */}
          {activeViewTab === 'IV_MATRIX' && (
            <div className="space-y-3">
              {/* IV Metric Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 font-medium">IV Rank (IVR)</span>
                    <span className="text-xs font-mono font-bold text-purple-300">{chainPayload.ivMetrics.ivRank != null ? `${chainPayload.ivMetrics.ivRank}%` : 'N/A'}</span>
                  </div>
                  {chainPayload.ivMetrics.ivRank != null ? <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all ${
                        chainPayload.ivMetrics.ivRank > 60 ? 'bg-gradient-to-r from-amber-500 to-rose-500' :
                        chainPayload.ivMetrics.ivRank < 30 ? 'bg-gradient-to-r from-cyan-500 to-emerald-500' : 'bg-cyan-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(5, chainPayload.ivMetrics.ivRank))}%` }}
                    />
                  </div> : <span className="text-[9px] text-slate-500">Historical IV observations required</span>}
                  <div className="flex justify-between text-[9px] text-slate-500 font-mono">
                    <span>52w Low: {chainPayload.ivMetrics.iv52wLow != null ? `${chainPayload.ivMetrics.iv52wLow}%` : 'N/A'}</span>
                    <span>52w High: {chainPayload.ivMetrics.iv52wHigh != null ? `${chainPayload.ivMetrics.iv52wHigh}%` : 'N/A'}</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-medium block">IV Percentile (IVP)</span>
                  <div className="flex items-baseline gap-1.5 font-mono">
                    <strong className="text-lg font-black text-cyan-300">{chainPayload.ivMetrics.ivPercentile != null ? `${chainPayload.ivMetrics.ivPercentile}%` : 'N/A'}</strong>
                    <span className="text-[10px] text-slate-400">{chainPayload.ivMetrics.ivPercentile != null ? 'of trading days lower' : 'history required'}</span>
                  </div>
                  <span className="text-[9px] text-slate-500 block">ATM IV: {chainPayload.ivMetrics.atmIv}%</span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-medium block">Expected Expiry Move (1-Sigma)</span>
                  <div className="flex items-baseline gap-1.5 font-mono">
                    <strong className="text-lg font-black text-amber-300">
                      ±₹{chainPayload.ivMetrics.impliedMovePoints}
                    </strong>
                    <span className="text-xs text-amber-400 font-bold">(±{chainPayload.ivMetrics.impliedMovePct}%)</span>
                  </div>
                  <span className="text-[9px] text-slate-500 block font-mono">
                    DTE: {chainPayload.selectedExpiry.daysToExpiry} Days ({chainPayload.selectedExpiry.label})
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-medium block">IV vs 30D HV Spread</span>
                  <div className="flex items-baseline gap-1.5 font-mono">
                    <strong className={`text-lg font-black ${chainPayload.ivMetrics.ivHvPremium != null && chainPayload.ivMetrics.ivHvPremium > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                      {chainPayload.ivMetrics.ivHvPremium != null ? `${chainPayload.ivMetrics.ivHvPremium > 0 ? '+' : ''}${chainPayload.ivMetrics.ivHvPremium}%` : 'N/A'}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block font-mono">
                    HV: {chainPayload.ivMetrics.historicalVol30d != null ? `${chainPayload.ivMetrics.historicalVol30d}%` : 'N/A'}
                  </span>
                </div>
              </div>

              {/* 1-Standard Deviation Expiration Move Cone */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Gauge className="w-4 h-4 text-cyan-400" />
                  Approximate 1-Sigma Expiration Range (normal-model assumption)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 font-mono text-center">
                  <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/40">
                    <span className="text-[10px] text-emerald-300 font-sans block">Upper Expected Move Band</span>
                    <strong className="text-sm font-black text-emerald-400">
                      ₹{(chainPayload.underlyingPrice + chainPayload.ivMetrics.impliedMovePoints).toFixed(2)}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700">
                    <span className="text-[10px] text-slate-400 font-sans block">Current Spot Price</span>
                    <strong className="text-sm font-black text-white">
                      ₹{chainPayload.underlyingPrice.toFixed(2)}
                    </strong>
                  </div>

                  <div className="p-2.5 rounded-lg bg-rose-950/30 border border-rose-500/40">
                    <span className="text-[10px] text-rose-300 font-sans block">Lower Expected Move Band</span>
                    <strong className="text-sm font-black text-rose-400">
                      ₹{(chainPayload.underlyingPrice - chainPayload.ivMetrics.impliedMovePoints).toFixed(2)}
                    </strong>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 text-xs">
                  <span className="font-bold text-cyan-300 block mb-1">Quantitative Strategy Edge:</span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {chainPayload.ivMetrics.quantStrategyRecommendation}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Order Flow & Microstructure (CVD) */}
          {activeViewTab === 'ORDER_FLOW' && (
            <div className="space-y-3">
              {/* Order Flow KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Net Options Cumulative Volume Delta (CVD)</span>
                  <div className="flex items-baseline gap-1.5 mt-1 font-mono">
                    <strong className={`text-base font-black ${chainPayload.sourceState === 'LIVE' ? 'text-slate-300' : chainPayload.orderFlowMetrics.netOptionsCvd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {chainPayload.sourceState === 'LIVE' ? 'N/A' : chainPayload.orderFlowMetrics.netOptionsCvd >= 0 ? `+${chainPayload.orderFlowMetrics.netOptionsCvd.toLocaleString()}` : chainPayload.orderFlowMetrics.netOptionsCvd.toLocaleString()}
                    </strong>
                    <span className="text-[10px] text-slate-400">Contracts</span>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">{chainPayload.sourceState === 'LIVE' ? 'Broker feed did not supply aggressor-side trades' : 'Synthetic illustration only'}</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Order Flow Institutional Bias</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <strong className={`text-xs font-bold px-2 py-0.5 rounded uppercase ${
                      chainPayload.orderFlowMetrics.orderFlowBias === 'INSTITUTIONAL_BULLISH_FLOW' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' :
                      chainPayload.orderFlowMetrics.orderFlowBias === 'INSTITUTIONAL_BEARISH_FLOW' ? 'bg-rose-950 text-rose-300 border border-rose-500/40' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {chainPayload.sourceState === 'LIVE' ? 'UNAVAILABLE' : chainPayload.orderFlowMetrics.orderFlowBias.replace(/_/g, ' ')}
                    </strong>
                  </div>
                  <span className="text-[9px] text-slate-400 block mt-0.5">Delta Directional Momentum</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-medium">Microstructure Trap / Absorption Alert</span>
                  <p className="text-xs font-bold text-amber-300 mt-1 line-clamp-1">
                    {chainPayload.sourceState === 'LIVE' ? 'Trade-tick data unavailable' : chainPayload.orderFlowMetrics.trapSignal}
                  </p>
                  <span className="text-[9px] text-slate-400 block mt-0.5 font-mono">Key Strike: {chainPayload.sourceState === 'LIVE' ? 'N/A' : `₹${chainPayload.orderFlowMetrics.keyTrapStrike}`}</span>
                </div>
              </div>

              {/* Order Flow Microstructure Table */}
              <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950/80 shadow-lg">
                <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs font-bold text-white">
                  <span className="flex items-center gap-1.5">
                    <Waves className="w-4 h-4 text-cyan-400" />
                    Strike Order Flow & Aggressive Volume Delta
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Call CVD vs Put CVD
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-center text-xs font-mono border-collapse min-w-[720px]">
                    <thead>
                      <tr className="bg-slate-900/60 text-[9px] text-slate-400 border-b border-slate-800">
                        <th className="py-2 px-2 text-right text-emerald-400">Call Buys (Ask)</th>
                        <th className="py-2 px-2 text-right">Call Sells (Bid)</th>
                        <th className="py-2 px-2 text-center text-emerald-300">Call CVD</th>
                        <th className="py-2 px-3 text-center bg-slate-900 text-white font-bold">STRIKE</th>
                        <th className="py-2 px-2 text-center text-rose-300">Put CVD</th>
                        <th className="py-2 px-2 text-left">Put Buys (Ask)</th>
                        <th className="py-2 px-2 text-left text-rose-400">Put Sells (Bid)</th>
                        <th className="py-2 px-3 text-left">Microstructure Tag</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-[11px]">
                      {filteredRows.map((r) => (
                        <tr 
                          key={r.strike}
                          onClick={() => setSelectedStrike(r.strike)}
                          className={`transition cursor-pointer ${
                            r.isAtm ? 'bg-amber-950/30 font-bold' : 'hover:bg-slate-850/50'
                          }`}
                        >
                          <td className="py-2 px-2 text-right text-emerald-400">
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : formatIndianNumber(r.call.aggressiveBuyVol)}
                          </td>
                          <td className="py-2 px-2 text-right text-slate-400">
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : formatIndianNumber(r.call.aggressiveSellVol)}
                          </td>
                          <td className={`py-2 px-2 text-center font-bold ${r.call.cvd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : r.call.cvd >= 0 ? `+${formatIndianNumber(r.call.cvd)}` : formatIndianNumber(r.call.cvd)}
                          </td>
                          <td className={`py-2 px-3 font-bold text-center ${r.isAtm ? 'bg-amber-500/20 text-amber-300 font-black' : 'text-white'}`}>
                            {r.strike}
                          </td>
                          <td className={`py-2 px-2 text-center font-bold ${r.put.cvd >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : r.put.cvd >= 0 ? `+${formatIndianNumber(r.put.cvd)}` : formatIndianNumber(r.put.cvd)}
                          </td>
                          <td className="py-2 px-2 text-left text-emerald-400">
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : formatIndianNumber(r.put.aggressiveBuyVol)}
                          </td>
                          <td className="py-2 px-2 text-left text-rose-400">
                            {chainPayload.sourceState === 'LIVE' ? 'N/A' : formatIndianNumber(r.put.aggressiveSellVol)}
                          </td>
                          <td className="py-2 px-3 text-left">
                            <span className="text-[10px] font-sans font-semibold text-slate-300">
                              {r.microstructureSignal}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Mobile Fast Matrix Ladder */}
          {activeViewTab === 'MATRIX' && (
            <div className="space-y-2">
              <div className="text-[11px] text-slate-400 px-1 flex items-center justify-between">
                <span>Call Option (CE)</span>
                <span className="font-bold text-white">STRIKE</span>
                <span>Put Option (PE)</span>
              </div>

              <div className="grid grid-cols-1 gap-1.5">
                {filteredRows.map((row) => {
                  const isSelected = selectedStrike === row.strike;
                  return (
                    <div 
                      key={row.strike}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 transition ${
                        row.isAtm 
                          ? 'bg-amber-950/40 border-amber-500/50 shadow'
                          : isSelected
                          ? 'bg-indigo-950/50 border-indigo-500/50'
                          : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {/* Left: CALL Button */}
                      <button
                        onClick={() => {
                          setSelectedStrike(row.strike);
                          setSelectedContractType('CE');
                        }}
                        className={`flex-1 py-2 px-3 rounded-lg flex flex-col items-start transition cursor-pointer ${
                          isSelected && selectedContractType === 'CE'
                            ? 'bg-emerald-600 text-white shadow ring-2 ring-emerald-400/60'
                            : 'bg-slate-900 border border-slate-800 text-emerald-300 hover:bg-emerald-950/60'
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-[10px] font-bold">BUY CALL</span>
                          <span className="text-xs font-mono font-bold">₹{row.call.lastPrice.toFixed(2)}</span>
                        </div>
                        <div className="text-[9px] opacity-80 mt-0.5 flex items-center gap-1.5 font-mono flex-wrap">
                          <span>Δ {row.call.delta > 0 ? `+${row.call.delta.toFixed(3)}` : row.call.delta.toFixed(3)}</span>
                          <span>OI {formatIndianNumber(row.call.openInterest)}</span>
                          <span className={row.call.changeInOi >= 0 ? 'text-emerald-300' : 'text-rose-300'}>
                            ({row.call.changeInOi >= 0 ? `+${formatIndianNumber(row.call.changeInOi)}` : formatIndianNumber(row.call.changeInOi)})
                          </span>
                        </div>
                      </button>

                      {/* Center: STRIKE */}
                      <div className="px-3 py-1 flex flex-col items-center justify-center font-mono shrink-0">
                        <span className={`text-sm font-black ${row.isAtm ? 'text-amber-300' : 'text-white'}`}>
                          {row.strike}
                        </span>
                        {row.isAtm && (
                          <span className="text-[8px] font-sans font-bold text-amber-300 bg-amber-500/20 px-1 rounded mt-0.5">
                            ATM
                          </span>
                        )}
                      </div>

                      {/* Right: PUT Button */}
                      <button
                        onClick={() => {
                          setSelectedStrike(row.strike);
                          setSelectedContractType('PE');
                        }}
                        className={`flex-1 py-2 px-3 rounded-lg flex flex-col items-end transition cursor-pointer ${
                          isSelected && selectedContractType === 'PE'
                            ? 'bg-rose-600 text-white shadow ring-2 ring-rose-400/60'
                            : 'bg-slate-900 border border-slate-800 text-rose-300 hover:bg-rose-950/60'
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs font-mono font-bold">₹{row.put.lastPrice.toFixed(2)}</span>
                          <span className="text-[10px] font-bold">BUY PUT</span>
                        </div>
                        <div className="text-[9px] opacity-80 mt-0.5 flex items-center gap-1.5 font-mono flex-wrap justify-end">
                          <span className={row.put.changeInOi >= 0 ? 'text-emerald-300' : 'text-rose-300'}>
                            ({row.put.changeInOi >= 0 ? `+${formatIndianNumber(row.put.changeInOi)}` : formatIndianNumber(row.put.changeInOi)})
                          </span>
                          <span>OI {formatIndianNumber(row.put.openInterest)}</span>
                          <span>Δ {row.put.delta.toFixed(3)}</span>
                        </div>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: Payoff & Greeks Diagram */}
          {activeViewTab === 'PAYOFF' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Left Box: Greeks Deep Dive */}
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2.5">
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    Option Greeks Breakdown ({activeSymbol} {activeSelectedStrike} {selectedContractType})
                  </h4>
                  {activeOption?.buildup && (
                    <span className={`text-[10px] px-2 py-0.5 rounded font-sans font-bold uppercase ${
                      activeOption.buildup === 'Long Buildup' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      activeOption.buildup === 'Short Buildup' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' :
                      activeOption.buildup === 'Short Covering' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' :
                      'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}>
                      {activeOption.buildup}
                    </span>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Delta (Δ)</span>
                    <strong className="text-emerald-400 font-mono text-sm">
                      {activeOption ? (activeOption.delta > 0 ? `+${activeOption.delta.toFixed(3)}` : activeOption.delta.toFixed(3)) : '0.000'}
                    </strong>
                    <span className="text-[9px] text-slate-500 block mt-0.5">₹ move per ₹1 underlying change</span>
                  </div>

                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Theta (Θ) Decay</span>
                    <strong className="text-rose-400 font-mono text-sm">-₹{activeOption?.theta?.toFixed(2)} / day</strong>
                    <span className="text-[9px] text-slate-500 block mt-0.5">
                      -₹{((activeOption?.thetaLot || (activeOption?.theta || 0) * lotSize)).toFixed(2)} per lot/day
                    </span>
                  </div>

                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Gamma (Γ)</span>
                    <strong className="text-purple-300 font-mono text-sm">{activeOption?.gamma?.toFixed(4)}</strong>
                    <span className="text-[9px] text-slate-500 block mt-0.5">Delta acceleration rate</span>
                  </div>

                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Vega (ν)</span>
                    <strong className="text-amber-300 font-mono text-sm">₹{activeOption?.vega?.toFixed(2)}</strong>
                    <span className="text-[9px] text-slate-500 block mt-0.5">Price move per 1% IV change</span>
                  </div>
                </div>

                <div className="p-2.5 rounded bg-slate-900/80 border border-slate-800 text-xs space-y-1 font-mono">
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Intrinsic Value:</span>
                    <strong className="text-white font-mono">₹{activeOption?.intrinsicValue?.toFixed(2) || '0.00'}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Time Extrinsic Value:</span>
                    <strong className="text-cyan-300 font-mono">₹{activeOption?.timeValue?.toFixed(2) || activePremium?.toFixed(2)}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Open Interest (OI):</span>
                    <strong className="text-slate-200 font-mono">
                      {formatIndianNumber(activeOption?.openInterest || 0)} shares ({Math.round((activeOption?.openInterest || 0) / lotSize)} lots)
                    </strong>
                  </div>
                  <div className="flex justify-between text-slate-400 text-[11px]">
                    <span>Change in OI:</span>
                    <strong className={`${(activeOption?.changeInOi || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'} font-mono`}>
                      {(activeOption?.changeInOi || 0) >= 0 ? `+${formatIndianNumber(activeOption?.changeInOi || 0)}` : formatIndianNumber(activeOption?.changeInOi || 0)}
                      {' '}({(activeOption?.changeInOiPct || 0) >= 0 ? `+${activeOption?.changeInOiPct}%` : `${activeOption?.changeInOiPct}%`})
                    </strong>
                  </div>
                </div>
              </div>

              {/* Right Box: Target P&L Scenarios */}
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2.5">
                <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                  Estimated Expiry P&L Scenarios ({lotSize} Qty)
                </h4>

                <div className="space-y-1.5 text-xs font-mono">
                  {[
                    { label: '+3% Stock Move', price: chainPayload.underlyingPrice * 1.03 },
                    { label: '+1.5% Stock Move', price: chainPayload.underlyingPrice * 1.015 },
                    { label: 'Spot Unchanged', price: chainPayload.underlyingPrice },
                    { label: '-1.5% Stock Move', price: chainPayload.underlyingPrice * 0.985 },
                    { label: '-3% Stock Move', price: chainPayload.underlyingPrice * 0.97 }
                  ].map((sc, i) => {
                    const expiryOptionValue = selectedContractType === 'CE' 
                      ? Math.max(0, sc.price - activeSelectedStrike)
                      : Math.max(0, activeSelectedStrike - sc.price);
                    const netPnl = Math.round((expiryOptionValue - activePremium) * lotSize);

                    return (
                      <div key={i} className="p-1.5 rounded bg-slate-900 border border-slate-800 flex items-center justify-between text-[11px]">
                        <span className="text-slate-300">{sc.label} ({currencySymbol}{Math.round(sc.price)})</span>
                        <strong className={netPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {netPnl >= 0 ? `+₹${netPnl.toLocaleString()}` : `-₹${Math.abs(netPnl).toLocaleString()}`}
                        </strong>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Interactive Payoff & 1-Click Execution Bar */}
          <div className="p-3 sm:p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-850 pb-2.5">
              <div className="flex items-center gap-2 flex-wrap min-w-0">
                <span className="text-xs font-bold text-white flex items-center gap-1.5 shrink-0">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Selected Setup:
                </span>
                <span className="px-2 py-0.5 rounded font-mono text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 truncate">
                  {activeSymbol} {activeSelectedStrike} {selectedContractType} @ ₹{activePremium}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  IV: {activeOption?.impliedVolatility || 16}% • Δ {activeOption?.delta || 0.5}
                </span>
              </div>

              <div className="flex items-center gap-2 sm:gap-3">
                <div className="flex items-center gap-1.5 font-mono text-xs">
                  <span className="text-slate-400 text-[11px]">Lots:</span>
                  <input
                    type="number"
                    value={lotSize}
                    onChange={(e) => setLotSize(Math.max(1, Number(e.target.value)))}
                    className="w-16 sm:w-20 px-2 py-1 rounded bg-slate-900 border border-slate-700 text-white font-bold text-center text-xs"
                  />
                </div>

                <button
                  onClick={handleExecuteOptionTrade}
                  className="px-3 sm:px-4 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer active:scale-95 shrink-0"
                >
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>Execute Virtual Trade</span>
                </button>
              </div>
            </div>

            {/* Payoff Key Figures */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Total Premium / Max Risk</span>
                <strong className="text-rose-400 font-mono text-xs sm:text-sm block mt-0.5">
                  -₹{maxRiskCapital.toLocaleString()}
                </strong>
                <span className="text-[9px] text-slate-500">100% Capped Buyer Risk</span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Expiry Breakeven Spot</span>
                <strong className="text-cyan-300 font-mono text-xs sm:text-sm block mt-0.5">
                  {currencySymbol}{Math.round(breakevenPoint * 10) / 10}
                </strong>
                <span className="text-[9px] text-slate-500">
                  {selectedContractType === 'CE' 
                    ? `+${Math.round(activePremium / chainPayload.underlyingPrice * 1000) / 10}% Spot Up` 
                    : `-${Math.round(activePremium / chainPayload.underlyingPrice * 1000) / 10}% Spot Down`}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Gain at +2% Spot Move</span>
                <strong className="text-emerald-400 font-mono text-xs sm:text-sm block mt-0.5">
                  {selectedContractType === 'CE' 
                    ? `+₹${Math.round((chainPayload.underlyingPrice * 0.02 * (activeOption?.delta || 0.5)) * lotSize).toLocaleString()}` 
                    : '₹0'}
                </strong>
                <span className="text-[9px] text-slate-500">Delta Leveraged Profit</span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">Daily Theta Decay</span>
                <strong className="text-amber-400 font-mono text-xs sm:text-sm block mt-0.5">
                  -₹{Math.round((activeOption?.theta || 1.2) * lotSize).toLocaleString()} / day
                </strong>
                <span className="text-[9px] text-slate-500">Holding Decay Cost</span>
              </div>
            </div>
          </div>
          </>
        )}
        </div>

        {/* Footer */}
        <div className="px-3 sm:px-4 py-2 sm:py-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <span className="text-slate-500 flex items-center gap-1 text-[10px] sm:text-xs truncate mr-2">
            <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">Black-Scholes-Merton (BSM) closed-form calculation calibrated for NSE Monthly Stock Options & Weekly Indices.</span>
          </span>
          <button
            onClick={onClose}
            className="px-3 sm:px-4 py-1 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition cursor-pointer shrink-0 text-xs"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
