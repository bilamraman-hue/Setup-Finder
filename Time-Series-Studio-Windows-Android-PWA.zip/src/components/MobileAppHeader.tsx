import React from 'react';
import { 
  TrendingUp, 
  Sparkles, 
  Globe, 
  Cpu, 
  Sliders, 
  Crosshair, 
  RefreshCw, 
  Play, 
  ShieldCheck, 
  Search,
  ChevronRight,
  Zap,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  ListFilter,
  Wallet
} from 'lucide-react';
import { DatasetPreset, ModelConfig, ProviderFetchConfig } from '../types';
import { useAuth } from '../context/AuthContext';

interface MobileAppHeaderProps {
  currentPreset: DatasetPreset;
  presets: DatasetPreset[];
  onSelectPreset: (preset: DatasetPreset) => void;
  lastClosePrice?: number;
  currency?: string;
  onOpenSearch: () => void;
  onOpenMarketProvider: () => void;
  onOpenFinalVerdict: () => void;
  onOpenWatchlistScan?: () => void;
  onOpenMySetups?: () => void;
  onOpenDiscrepancyAudit?: () => void;
  watchlistCount?: number;
  onRunForecast: () => void;
  isLoading: boolean;
  isLocalMode: boolean;
  onToggleLocalMode: (val: boolean) => void;
  activeTab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition';
  setActiveTab: (tab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition') => void;
  quantScore?: number;
  selectedApiConfig?: ProviderFetchConfig;
  onOpenAuthModal?: () => void;
  onOpenPaperTrading?: () => void;
}

export const MobileAppHeader: React.FC<MobileAppHeaderProps> = ({
  currentPreset,
  presets,
  onSelectPreset,
  lastClosePrice,
  currency = '₹',
  onOpenSearch,
  onOpenMarketProvider,
  onOpenFinalVerdict,
  onOpenWatchlistScan,
  onOpenMySetups,
  onOpenDiscrepancyAudit,
  watchlistCount,
  onRunForecast,
  isLoading,
  isLocalMode,
  onToggleLocalMode,
  activeTab,
  setActiveTab,
  quantScore = 78,
  selectedApiConfig,
  onOpenAuthModal,
  onOpenPaperTrading
}) => {
  const currSym = currency.includes('INR') || currency.includes('₹') ? '₹' : '$';
  const isCustomConnected = selectedApiConfig?.provider === 'custom_api' && (selectedApiConfig?.isConnected || Boolean(selectedApiConfig?.apiKey));
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-30 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800/90 shadow-md">
      {/* Top Mobile Status & Brand Bar */}
      <div className="px-3.5 pt-2.5 pb-2 flex items-center justify-between gap-2">
        {/* Brand & Market Live Tag */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-950/60 border border-cyan-400/40 shrink-0">
            <TrendingUp className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-black text-white tracking-tight leading-none truncate">
                Time Series Studio
              </h1>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            </div>
            <p className="text-[10px] font-mono text-cyan-400 font-semibold tracking-wider uppercase leading-none mt-0.5">
              NSE • BSE • MCX
            </p>
          </div>
        </div>

        {/* Right Header Action Icons */}
        <div className="flex max-w-[58%] flex-wrap items-center justify-end gap-1 sm:gap-1.5 shrink-0">
          {/* Firebase Auth & Profile Icon */}
          {onOpenAuthModal && (
            <button
              onClick={onOpenAuthModal}
              className={`flex h-10 min-w-10 items-center justify-center rounded-xl border text-[10px] transition active:scale-95 cursor-pointer ${
                user
                  ? 'bg-emerald-950/70 border-emerald-500/60 text-emerald-300'
                  : 'bg-slate-900 border-slate-700 text-slate-300'
              }`}
              title={user ? `Signed in as ${user.email}` : 'Sign In with Google / Firebase'}
            >
              {user && user.photoURL ? (
                <img src={user.photoURL} alt="User" className="w-4 h-4 rounded-full object-cover" />
              ) : (
                <ShieldCheck className={`w-4 h-4 ${user ? 'text-emerald-400' : 'text-cyan-400'}`} />
              )}
            </button>
          )}

          {/* Quick Final Verdict Pill Button */}
          <button
            onClick={onOpenFinalVerdict}
            className="flex min-h-10 items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-amber-600/30 to-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold shadow-sm active:scale-95 transition cursor-pointer"
            title="Open Final Verdict (Buy/Sell/Hold)"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Verdict</span>
          </button>

          {/* Quick Paper Trading Button */}
          {onOpenPaperTrading && (
            <button
              onClick={onOpenPaperTrading}
              className="flex h-10 min-w-10 items-center justify-center rounded-xl border border-emerald-500/40 bg-emerald-950/60 text-emerald-300 active:scale-95 transition cursor-pointer"
              title="Open Virtual Paper Trading Simulator"
            >
              <Wallet className="w-4 h-4 text-emerald-400" />
            </button>
          )}

          {/* Quick Engine Mode Switcher (Local vs Cloud) */}
          <button
            onClick={() => onToggleLocalMode(!isLocalMode)}
            className={`flex h-10 min-w-10 items-center justify-center rounded-xl border text-[10px] font-mono transition active:scale-95 cursor-pointer ${
              isLocalMode 
                ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300' 
                : 'bg-slate-900 border-slate-700 text-slate-300'
            }`}
            title={isLocalMode ? 'Local Engine (Device)' : 'Cloud Proxy'}
          >
            <Cpu className="w-4 h-4" />
          </button>

          {/* Provider API Switcher */}
          <button
            onClick={onOpenMarketProvider}
            className={`relative flex h-10 min-w-10 items-center justify-center rounded-xl border text-[10px] font-medium active:scale-95 transition cursor-pointer ${
              isCustomConnected
                ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/40'
                : 'bg-slate-900 border-slate-700 text-cyan-300'
            }`}
            title={`Market Data API: ${selectedApiConfig?.provider === 'custom_api' ? 'Custom API (Connected)' : 'Configure API'}`}
          >
            <Globe className={`w-4 h-4 ${isCustomConnected ? 'text-emerald-400' : 'text-cyan-400'}`} />
            {isCustomConnected && (
              <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            )}
          </button>

          {/* Run Forecast Prediction Button */}
          <button
            onClick={onRunForecast}
            disabled={isLoading}
            className="flex min-h-10 items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-[11px] font-bold shadow-md shadow-cyan-950 border border-cyan-400/40 active:scale-95 transition disabled:opacity-50 cursor-pointer"
          >
            {isLoading ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
            ) : (
              <Play className="w-3.5 h-3.5 fill-white" />
            )}
            <span className="hidden sm:inline">{isLoading ? 'Wait...' : 'Predict'}</span>
          </button>
        </div>
      </div>

      {/* Active Ticker Card & Quick Switcher Strip */}
      <div className="px-3.5 py-2 bg-slate-900/80 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-mono font-black text-sm text-white tracking-wide">
                {currentPreset.symbol || 'NIFTY'}
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 font-mono border border-cyan-800/60 truncate max-w-[120px]">
                {currentPreset.title}
              </span>
            </div>
            {lastClosePrice !== undefined && (
              <div className="text-xs font-mono font-bold text-slate-200 mt-0.5">
                CMP: <strong className="text-cyan-300">{currSym}{lastClosePrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
              </div>
            )}
          </div>
        </div>

        {/* Search Tap Bar to open search */}
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-700/80 text-slate-400 hover:text-white text-xs transition active:scale-95 cursor-pointer shrink-0"
        >
          <Search className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-medium text-[11px]">Search Ticker</span>
        </button>
      </div>

      {/* Horizontal App Navigation Tabs (Swipeable/Scrollable on mobile) */}
      <div className="flex min-h-12 items-center gap-1 px-3 py-1.5 overflow-x-auto overscroll-x-contain scrollbar-none border-t border-slate-800/60 text-xs">
        <button
          onClick={() => setActiveTab('forecast')}
          className={`min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 ${
            activeTab === 'forecast'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          <span>Chart & Levels</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('quant');
            const el = document.getElementById('quant-setup-card-section') || document.getElementById('institutional-quant-setup-container');
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
          className={`min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 ${
            activeTab === 'quant'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
              : 'text-slate-400 hover:text-indigo-300'
          }`}
        >
          <Crosshair className="w-3.5 h-3.5 text-indigo-400" />
          <span>Quant Setup</span>
          <span className="px-1 py-0.2 rounded bg-indigo-900/60 text-[9px] font-mono text-indigo-300">
            {quantScore}%
          </span>
        </button>

        {onOpenWatchlistScan && (
          <button
            onClick={onOpenWatchlistScan}
            className="min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 bg-indigo-950/80 text-indigo-300 border border-indigo-700/60 shadow-sm"
            title="Open Watchlist Scan (multiple lists, up to 38 unique stocks each)"
          >
            <ListFilter className="w-3.5 h-3.5 text-indigo-400" />
            <span>Watchlist</span>
            {watchlistCount !== undefined && watchlistCount > 0 && (
              <span className="px-1 py-0.2 rounded bg-indigo-900/60 text-[9px] font-mono text-indigo-300">
                {watchlistCount}
              </span>
            )}
          </button>
        )}
        {onOpenMySetups && (
          <button onClick={onOpenMySetups} className="flex items-center gap-1 rounded-lg border border-cyan-800/70 bg-cyan-950/50 px-2 py-1.5 text-[11px] font-semibold text-cyan-300" title="Open saved Grade A setups">
            <Layers className="h-3.5 w-3.5" /><span>My Setups</span>
          </button>
        )}

        {onOpenDiscrepancyAudit && (
          <button
            onClick={onOpenDiscrepancyAudit}
            className="min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 bg-cyan-950/80 text-cyan-300 border border-cyan-700/60 shadow-sm"
            title="Open Algorithm & Quant Discrepancy Auditor"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
            <span>Auditor</span>
            <span className="px-1 py-0.2 rounded bg-emerald-900/60 text-[9px] font-mono text-emerald-300">
              100%
            </span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('scenario')}
          className={`min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 ${
            activeTab === 'scenario'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-amber-400" />
          <span>Indicators & Covariates</span>
        </button>

        <button
          onClick={() => setActiveTab('anomalies')}
          className={`min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 ${
            activeTab === 'anomalies'
              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-rose-400" />
          <span>Anomalies</span>
        </button>

        <button
          onClick={() => setActiveTab('decomposition')}
          className={`min-h-10 px-3 py-2 rounded-lg transition-all font-semibold flex items-center gap-1 whitespace-nowrap cursor-pointer shrink-0 ${
            activeTab === 'decomposition'
              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-purple-400" />
          <span>Cycles</span>
        </button>
      </div>
    </header>
  );
};
