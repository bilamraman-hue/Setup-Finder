import React from 'react';
import { TradingMetrics, TradingSignal, TimeSeriesPoint, ForecastPoint } from '../types';
import { 
  TrendingUp, 
  TrendingDown, 
  ShieldAlert, 
  Target, 
  Crosshair, 
  Gauge, 
  Scale, 
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Sparkles,
  Cpu
} from 'lucide-react';

interface TradingPredictionCardProps {
  tradingMetrics?: TradingMetrics;
  lastClose: number;
  unit?: string;
  isLocalExecution?: boolean;
  symbol: string;
}

export const TradingPredictionCard: React.FC<TradingPredictionCardProps> = ({
  tradingMetrics,
  lastClose,
  unit = 'INR (₹)',
  isLocalExecution = true,
  symbol
}) => {
  if (!tradingMetrics) return null;

  const currSym = unit.includes('INR') || unit.includes('₹') ? '₹' : unit.includes('USD') || unit.includes('$') ? '$' : '₹';

  const {
    signal,
    projectedReturnPct,
    directionalConfidence,
    targetMedianPrice,
    supportFloorP10,
    resistanceCeilingP90,
    valueAtRiskPct,
    riskRewardRatio,
    rsi14,
    sma20,
    atr14
  } = tradingMetrics;

  const isBullish = projectedReturnPct > 0;
  const isNeutral = Math.abs(projectedReturnPct) < 0.7;

  // Signal badges styling
  const getSignalBadge = (sig: TradingSignal) => {
    switch (sig) {
      case 'STRONG_BUY':
        return {
          label: 'STRONG BUY / BULLISH BREAKOUT',
          bgColor: 'bg-emerald-500/20 border-emerald-500 text-emerald-400',
          textColor: 'text-emerald-400',
          indicator: 'bg-emerald-400',
          icon: TrendingUp
        };
      case 'BUY':
        return {
          label: 'BUY / ACCUMULATE',
          bgColor: 'bg-emerald-600/15 border-emerald-600/50 text-emerald-300',
          textColor: 'text-emerald-300',
          indicator: 'bg-emerald-500',
          icon: TrendingUp
        };
      case 'STRONG_SELL':
        return {
          label: 'STRONG SELL / HIGH DOWNSIDE',
          bgColor: 'bg-rose-500/20 border-rose-500 text-rose-400',
          textColor: 'text-rose-400',
          indicator: 'bg-rose-400',
          icon: TrendingDown
        };
      case 'SELL':
        return {
          label: 'SELL / REDUCE EXPOSURE',
          bgColor: 'bg-rose-600/15 border-rose-600/50 text-rose-300',
          textColor: 'text-rose-300',
          indicator: 'bg-rose-500',
          icon: TrendingDown
        };
      default:
        return {
          label: 'NEUTRAL / RANGEBOUND HOLD',
          bgColor: 'bg-amber-500/15 border-amber-500/50 text-amber-300',
          textColor: 'text-amber-300',
          indicator: 'bg-amber-400',
          icon: Minus
        };
    }
  };

  const badge = getSignalBadge(signal);
  const SignalIcon = badge.icon;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl relative overflow-hidden space-y-4">
      {/* Background ambient gradient glow depending on signal */}
      <div 
        className={`absolute -top-16 -right-16 w-60 h-60 rounded-full blur-3xl pointer-events-none opacity-20 ${
          signal.includes('BUY') ? 'bg-emerald-500' : signal.includes('SELL') ? 'bg-rose-500' : 'bg-amber-500'
        }`} 
      />

      {/* Header bar: Symbol, Signal & Execution tag */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pb-3 border-b border-slate-800/80 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 font-mono text-sm font-bold text-white shadow-inner">
            {symbol}
          </div>
          <div className={`px-3 py-1 rounded-lg border text-xs font-bold flex items-center gap-1.5 shadow-sm ${badge.bgColor}`}>
            <span className={`w-2 h-2 rounded-full ${badge.indicator} animate-pulse`} />
            <SignalIcon className="w-3.5 h-3.5" />
            <span>{badge.label}</span>
          </div>
        </div>

        {/* Local on-device execution indicator & link to Stock Summary */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              const el = document.getElementById('stock-summary-report-card');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-700/50 text-[11px] text-cyan-300 font-semibold transition cursor-pointer"
          >
            <Target className="w-3.5 h-3.5 text-cyan-400" />
            <span>View Targets & Stoploss Report ⬇</span>
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-950/70 border border-slate-800 text-[11px] text-slate-300 font-mono">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isLocalExecution ? 'On-Device Local Inference' : 'Cloud Hybrid'}</span>
          </div>
        </div>
      </div>

      {/* Main Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 relative z-10">
        {/* 1. Projected Return */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Forecasted Return</span>
            {isBullish ? (
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
            ) : isNeutral ? (
              <Minus className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
            )}
          </div>
          <div className={`text-xl font-bold font-mono ${
            projectedReturnPct > 0 ? 'text-emerald-400' : projectedReturnPct < 0 ? 'text-rose-400' : 'text-slate-200'
          }`}>
            {projectedReturnPct > 0 ? `+${projectedReturnPct}%` : `${projectedReturnPct}%`}
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
            vs Last Close {currSym}{lastClose.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        {/* 2. Target Median Price */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Target Price (p50)</span>
            <Target className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xl font-bold font-mono text-white">
            {currSym}{targetMedianPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-500 font-mono">
            Local baseline median estimate
          </div>
        </div>

        {/* 3. Support Floor & Resistance Ceiling */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Floor / Ceiling</span>
            <Crosshair className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xs font-mono font-bold space-y-0.5">
            <div className="text-emerald-400 flex items-center justify-between">
              <span className="text-[10px] text-slate-500 font-sans">p90 Ceil:</span>
              <span>{currSym}{resistanceCeilingP90.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="text-rose-400 flex items-center justify-between">
              <span className="text-[10px] text-slate-500 font-sans">p10 Floor:</span>
              <span>{currSym}{supportFloorP10.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        {/* 4. Risk / Reward & VaR */}
        <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80 space-y-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Risk / Reward</span>
            <Scale className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-cyan-300">
            {riskRewardRatio}:1
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            P2.5 downside band: -{valueAtRiskPct}%
          </div>
        </div>
      </div>

      {/* Technical Indicators Strip (RSI, SMA, ATR, Directional Confidence) */}
      <div className="pt-2 border-t border-slate-800/60 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs relative z-10">
        <div className="flex items-center justify-between bg-slate-950/40 px-2.5 py-1.5 rounded-lg border border-slate-800/50">
          <span className="text-[11px] text-slate-400">Directional Conf:</span>
          <span className="font-mono font-bold text-cyan-400">{directionalConfidence !== undefined ? `${directionalConfidence}%` : 'Not calibrated'}</span>
        </div>

        <div className="flex items-center justify-between bg-slate-950/40 px-2.5 py-1.5 rounded-lg border border-slate-800/50">
          <span className="text-[11px] text-slate-400">RSI (14):</span>
          <span className={`font-mono font-bold ${
            (rsi14 ?? 50) < 30 ? 'text-emerald-400' : (rsi14 ?? 50) > 70 ? 'text-rose-400' : 'text-slate-300'
          }`}>
            {rsi14 !== undefined ? rsi14 : 'N/A'}
          </span>
        </div>

        <div className="flex items-center justify-between bg-slate-950/40 px-2.5 py-1.5 rounded-lg border border-slate-800/50">
          <span className="text-[11px] text-slate-400">SMA Trend:</span>
          <span className="font-mono font-bold text-slate-300">
            {sma20 !== undefined ? `$${sma20.toFixed(2)}` : 'N/A'}
          </span>
        </div>

        <div className="flex items-center justify-between bg-slate-950/40 px-2.5 py-1.5 rounded-lg border border-slate-800/50">
          <span className="text-[11px] text-slate-400">ATR (14):</span>
          <span className="font-mono font-bold text-amber-300">
            {atr14 !== undefined ? atr14.toFixed(2) : 'N/A'}
          </span>
        </div>
      </div>
    </div>
  );
};
