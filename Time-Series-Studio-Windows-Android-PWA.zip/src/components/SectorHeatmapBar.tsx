import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Layers, ChevronDown, ChevronUp, Zap, RefreshCw } from 'lucide-react';

export interface SectorItem {
  id: string;
  name: string;
  symbol: string;
  price?: number;
  changePct: number;
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  leadingStocks: string[];
}

const DEFAULT_SECTORS: SectorItem[] = [
  { id: 'nifty', name: 'Nifty 50', symbol: '^NSEI', changePct: 0.65, bias: 'BULLISH', leadingStocks: ['RELIANCE', 'HDFCBANK', 'TCS'] },
  { id: 'bank', name: 'Bank Nifty', symbol: '^NSEBANK', changePct: 0.92, bias: 'BULLISH', leadingStocks: ['HDFCBANK', 'ICICIBANK', 'SBIN'] },
  { id: 'it', name: 'Nifty IT', symbol: '^CNXIT', changePct: 1.45, bias: 'BULLISH', leadingStocks: ['TCS', 'INFY', 'WIPRO'] },
  { id: 'auto', name: 'Nifty Auto', symbol: '^CNXAUTO', changePct: 0.35, bias: 'BULLISH', leadingStocks: ['TATAMOTORS', 'MARUTI', 'M&M'] },
  { id: 'metal', name: 'Nifty Metal', symbol: '^CNXMETAL', changePct: -0.42, bias: 'BEARISH', leadingStocks: ['TATASTEEL', 'JSWSTEEL', 'HINDALCO'] },
  { id: 'pharma', name: 'Nifty Pharma', symbol: '^CNXPHARMA', changePct: 0.18, bias: 'NEUTRAL', leadingStocks: ['SUNPHARMA', 'CIPLA', 'DRREDDY'] },
  { id: 'fmcg', name: 'Nifty FMCG', symbol: '^CNXFMCG', changePct: -0.25, bias: 'BEARISH', leadingStocks: ['ITC', 'HINDUNILVR', 'NESTLEIND'] },
  { id: 'energy', name: 'Nifty Energy', symbol: '^CNXENERGY', changePct: 0.88, bias: 'BULLISH', leadingStocks: ['RELIANCE', 'ONGC', 'NTPC'] }
];

interface SectorHeatmapBarProps {
  currentSymbol?: string;
  onSelectSectorSymbol?: (symbol: string) => void;
}

export const SectorHeatmapBar: React.FC<SectorHeatmapBarProps> = ({
  currentSymbol = 'RELIANCE',
  onSelectSectorSymbol
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [sectors, setSectors] = useState<SectorItem[]>(DEFAULT_SECTORS);
  const [isLoading, setIsLoading] = useState(false);

  const fetchLiveSectors = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/market/sectors');
      if (res.ok) {
        const json = await res.json();
        if (json?.sectors && Array.isArray(json.sectors) && json.sectors.length > 0) {
          setSectors(json.sectors);
        }
      }
    } catch (e) {
      console.warn('Could not fetch live sectors, using local state:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLiveSectors();
    // Refresh every 60 seconds
    const interval = setInterval(fetchLiveSectors, 60000);
    return () => clearInterval(interval);
  }, []);

  const cleanSym = currentSymbol.toUpperCase().replace(/\.NS$|\.BO$/i, '');

  // Detect matching sector for the active stock
  const matchedSector = sectors.find(sec => 
    sec.leadingStocks.some(s => s === cleanSym) || 
    (cleanSym.includes('NIFTY') && sec.id === 'nifty') ||
    (cleanSym.includes('BANK') && sec.id === 'bank') ||
    (cleanSym.includes('IT') && sec.id === 'it') ||
    (cleanSym.includes('TCS') && sec.id === 'it') ||
    (cleanSym.includes('INFY') && sec.id === 'it')
  );

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-950/85 shadow-md overflow-hidden text-xs font-sans">
      {/* Top compact bar */}
      <div className="px-3 py-2 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-slate-300 font-bold">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] tracking-wide">Live Sector Breadth</span>
            {isLoading && <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin ml-0.5" />}
          </div>

          {/* Current Stock Sector Confluence Badge */}
          {matchedSector && (
            <div className={`hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
              matchedSector.changePct >= 0 
                ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300' 
                : 'bg-rose-950/70 border-rose-500/50 text-rose-300'
            }`}>
              <Zap className="w-3 h-3 text-current" />
              <span>
                {cleanSym} belongs to <strong>{matchedSector.name}</strong> ({matchedSector.changePct >= 0 ? '+' : ''}{matchedSector.changePct}%)
                {matchedSector.changePct >= 0 ? ' • Sector Tailwind' : ' • Sector Headwind'}
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5">
          {sectors.map((sec) => {
            const isMatch = matchedSector?.id === sec.id;
            return (
              <button
                key={sec.id}
                onClick={() => onSelectSectorSymbol?.(sec.symbol)}
                className={`px-2 py-1 rounded-lg font-mono text-[10px] font-bold border transition flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                  isMatch
                    ? 'ring-1 ring-cyan-400 bg-slate-900 border-cyan-500 text-white shadow-sm'
                    : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-850'
                }`}
                title={`Click to load ${sec.name} live chart`}
              >
                <span>{sec.name}</span>
                <span className={sec.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {sec.changePct >= 0 ? '+' : ''}{sec.changePct}%
                </span>
              </button>
            );
          })}

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded text-slate-400 hover:text-white transition cursor-pointer"
            title={isExpanded ? 'Collapse' : 'Expand full sector details'}
          >
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Expanded Details Grid */}
      {isExpanded && (
        <div className="p-3 bg-slate-950 border-t border-slate-850 grid grid-cols-2 sm:grid-cols-4 gap-2 animate-in fade-in duration-150">
          {sectors.map((sec) => (
            <div
              key={sec.id}
              onClick={() => onSelectSectorSymbol?.(sec.symbol)}
              className={`p-2 rounded-lg border text-xs cursor-pointer transition hover:scale-[1.02] ${
                sec.changePct >= 0
                  ? 'bg-emerald-950/25 border-emerald-900/50 text-emerald-200 hover:border-emerald-500'
                  : 'bg-rose-950/25 border-rose-900/50 text-rose-200 hover:border-rose-500'
              }`}
            >
              <div className="flex items-center justify-between font-bold">
                <span>{sec.name}</span>
                <span className="font-mono">{sec.changePct >= 0 ? '+' : ''}{sec.changePct}%</span>
              </div>
              {sec.price ? (
                <div className="text-[10px] text-slate-300 font-mono mt-0.5">
                  ₹{sec.price.toLocaleString()}
                </div>
              ) : null}
              <div className="text-[10px] text-slate-400 mt-1 truncate">
                Leaders: {sec.leadingStocks.join(', ')}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
