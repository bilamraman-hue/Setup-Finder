import React, { useState } from 'react';
import { TimeSeriesPoint, CovariateDefinition } from '../types';
import { Upload, X, FileText, Check, AlertCircle, Download } from 'lucide-react';

interface DataUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDatasetLoaded: (data: TimeSeriesPoint[], title: string, covariates: CovariateDefinition[], unit: string) => void;
}

export const DataUploadModal: React.FC<DataUploadModalProps> = ({
  isOpen,
  onClose,
  onDatasetLoaded
}) => {
  const [dragActive, setDragActive] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [headers, setHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<string[][]>([]);
  const [dateCol, setDateCol] = useState<string>('');
  const [valueCol, setValueCol] = useState<string>('');
  const [selectedCovariates, setSelectedCovariates] = useState<string[]>([]);
  const [datasetTitle, setDatasetTitle] = useState('Custom Imported Dataset');
  const [unitLabel, setUnitLabel] = useState('Units');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const parseCSVText = (text: string, filename: string) => {
    try {
      setErrorMessage(null);
      const lines = text.trim().split(/\r?\n/).filter(line => line.trim().length > 0);
      if (lines.length < 5) {
        throw new Error('CSV must contain at least a header row and multiple data rows.');
      }

      // Detect separator (comma or tab or semicolon)
      const firstLine = lines[0];
      let delimiter = ',';
      if (firstLine.includes('\t')) delimiter = '\t';
      else if (firstLine.includes(';') && !firstLine.includes(',')) delimiter = ';';

      const parsedHeaders = firstLine.split(delimiter).map(h => h.trim().replace(/^["']|["']$/g, ''));
      const parsedRows = lines.slice(1).map(line => 
        line.split(delimiter).map(c => c.trim().replace(/^["']|["']$/g, ''))
      );

      setHeaders(parsedHeaders);
      setRawRows(parsedRows);
      setFileName(filename);
      setDatasetTitle(filename.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' '));

      // Auto-detect date column
      const detectedDate = parsedHeaders.find(h => 
        /date|time|timestamp|year|ds|month|day/i.test(h)
      ) || parsedHeaders[0];
      setDateCol(detectedDate);

      // Auto-detect value column
      const detectedVal = parsedHeaders.find(h => 
        /value|target|sales|revenue|load|demand|price|cpu|temp|y/i.test(h) && h !== detectedDate
      ) || parsedHeaders[1] || parsedHeaders[0];
      setValueCol(detectedVal);

      // Auto-detect potential covariates (any remaining columns that are numerical)
      const remainingCols = parsedHeaders.filter(h => h !== detectedDate && h !== detectedVal);
      setSelectedCovariates(remainingCols.slice(0, 3));
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to parse file.');
    }
  };

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      parseCSVText(text, file.name);
    };
    reader.readAsText(file);
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmImport = () => {
    if (!dateCol || !valueCol) {
      setErrorMessage('Please specify both a Timestamp column and a Value column.');
      return;
    }

    const dateIdx = headers.indexOf(dateCol);
    const valueIdx = headers.indexOf(valueCol);

    if (dateIdx === -1 || valueIdx === -1) {
      setErrorMessage('Invalid column selections.');
      return;
    }

    const covariateIndices = selectedCovariates
      .map(name => ({ name, idx: headers.indexOf(name) }))
      .filter(item => item.idx !== -1);

    const points: TimeSeriesPoint[] = [];

    rawRows.forEach((row) => {
      const rawDate = row[dateIdx];
      const rawVal = parseFloat(row[valueIdx]);

      if (rawDate && !isNaN(rawVal)) {
        const covMap: Record<string, number> = {};
        covariateIndices.forEach(({ name, idx }) => {
          const num = parseFloat(row[idx]);
          if (!isNaN(num)) {
            covMap[name] = num;
          }
        });

        points.push({
          timestamp: rawDate,
          value: rawVal,
          covariates: Object.keys(covMap).length > 0 ? covMap : undefined
        });
      }
    });

    if (points.length < 8) {
      setErrorMessage(`Only parsed ${points.length} valid numeric points. At least 8 points are required.`);
      return;
    }

    const covariateDefs: CovariateDefinition[] = selectedCovariates.map(name => ({
      name,
      type: 'numeric',
      description: `Imported covariate ${name}`
    }));

    onDatasetLoaded(points, datasetTitle, covariateDefs, unitLabel);
    onClose();
  };

  const downloadSampleCSV = () => {
    const sample = `date,sales,discount_pct,is_promo,temperature
2024-01-01,1050,0,0,18.5
2024-01-02,1120,0,0,19.1
2024-01-03,1240,10,1,20.4
2024-01-04,1310,15,1,21.0
2024-01-05,1480,20,1,21.8
2024-01-06,1890,20,1,22.5
2024-01-07,1750,15,1,21.9
2024-01-08,1190,0,0,19.2
2024-01-09,1220,0,0,18.8
2024-01-10,1350,10,1,20.1
2024-01-11,1410,15,1,21.2
2024-01-12,1620,20,1,22.0
2024-01-13,1950,25,1,22.8
2024-01-14,1800,20,1,22.1`;

    const blob = new Blob([sample], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'timesfm_sample_template.csv';
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Upload className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-semibold text-white">
              Import Time Series Data (CSV / TSV)
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          {/* Drag and Drop Zone */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
              dragActive 
                ? 'border-cyan-400 bg-cyan-950/20' 
                : 'border-slate-700 hover:border-slate-600 bg-slate-950/40'
            }`}
          >
            <FileText className="w-10 h-10 text-cyan-400/80 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-200">
              Drag and drop your CSV / TSV file here
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Supports daily, hourly, weekly, or custom timestamp series
            </p>

            <div className="mt-4 flex items-center justify-center gap-3">
              <label className="cursor-pointer px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg shadow transition-colors">
                Browse File
                <input
                  type="file"
                  accept=".csv,.tsv,.txt"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleFile(e.target.files[0]);
                  }}
                />
              </label>

              <button
                type="button"
                onClick={downloadSampleCSV}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                Download Sample CSV
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 bg-red-950/70 border border-red-800 rounded-xl text-xs text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Configuration Form if file parsed */}
          {headers.length > 0 && (
            <div className="space-y-4 pt-2 border-t border-slate-800">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Dataset Title */}
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Dataset Name</label>
                  <input
                    type="text"
                    value={datasetTitle}
                    onChange={(e) => setDatasetTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-1 focus:ring-cyan-500"
                  />
                </div>

                {/* Unit label */}
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Units (e.g. $, MW, Units)</label>
                  <input
                    type="text"
                    value={unitLabel}
                    onChange={(e) => setUnitLabel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-1 focus:ring-cyan-500"
                  />
                </div>

                {/* Date column selector */}
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Timestamp / Date Column</label>
                  <select
                    value={dateCol}
                    onChange={(e) => setDateCol(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-1 focus:ring-cyan-500"
                  >
                    {headers.map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>

                {/* Target value column selector */}
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Target Forecast Metric Column</label>
                  <select
                    value={valueCol}
                    onChange={(e) => setValueCol(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-1 focus:ring-cyan-500"
                  >
                    {headers.filter(h => h !== dateCol).map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Covariates Checkboxes */}
              {headers.filter(h => h !== dateCol && h !== valueCol).length > 0 && (
                <div className="text-xs">
                  <label className="block text-slate-300 font-medium mb-1.5">
                    Include External Regressors (CPM Covariates):
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {headers.filter(h => h !== dateCol && h !== valueCol).map(h => {
                      const isChecked = selectedCovariates.includes(h);
                      return (
                        <button
                          key={h}
                          type="button"
                          onClick={() => {
                            if (isChecked) {
                              setSelectedCovariates(selectedCovariates.filter(c => c !== h));
                            } else {
                              setSelectedCovariates([...selectedCovariates, h]);
                            }
                          }}
                          className={`px-3 py-1 rounded-lg border font-mono transition-all ${
                            isChecked
                              ? 'bg-cyan-950 text-cyan-300 border-cyan-700'
                              : 'bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300'
                          }`}
                        >
                          {isChecked ? '✓ ' : '+ '}{h}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Data Preview Table */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-semibold text-slate-400">
                  Preview (First 4 rows of {rawRows.length}):
                </span>
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-[11px] font-mono">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        {headers.map(h => (
                          <th key={h} className={`p-2 ${h === dateCol ? 'text-cyan-400 font-bold' : h === valueCol ? 'text-emerald-400 font-bold' : ''}`}>
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-slate-300">
                      {rawRows.slice(0, 4).map((row, rIdx) => (
                        <tr key={rIdx}>
                          {row.map((val, cIdx) => (
                            <td key={cIdx} className="p-2">
                              {val}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="text-xs text-slate-500">
            {rawRows.length > 0 ? `${rawRows.length} rows loaded` : 'No file selected'}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-import"
              type="button"
              disabled={headers.length === 0}
              onClick={handleConfirmImport}
              className="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-900/40 border border-cyan-400/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Load Data for Analysis
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
