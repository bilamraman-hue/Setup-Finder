import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  LogOut, 
  User as UserIcon, 
  Send, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  KeyRound,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSymbol?: string;
  currentPrice?: number;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentSymbol = 'NIFTY50',
  currentPrice = 24250.00
}) => {
  const { user, loading, signInWithGoogle, logout, getIdToken, sendAnalysisRequest } = useAuth();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isSendingRequest, setIsSendingRequest] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const [tokenPreview, setTokenPreview] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSignIn = async () => {
    setErrorMsg(null);
    setIsSigningIn(true);
    try {
      const u = await signInWithGoogle();
      if (u) {
        const token = await u.getIdToken();
        setTokenPreview(token);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sign in with Google');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setErrorMsg(null);
    try {
      await logout();
      setAnalysisResult(null);
      setTokenPreview(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sign out');
    }
  };

  const handleTestSecureAnalysis = async () => {
    setErrorMsg(null);
    setIsSendingRequest(true);
    try {
      const payload = {
        symbol: currentSymbol,
        timeframe: '15m',
        current_price: currentPrice,
        indicators: {
          rsi14: 61.2,
          supertrend: 'BULLISH',
          cpr_pivot: currentPrice * 0.998
        },
        user_notes: 'Price swept HTF Sell-Side Liquidity followed by strong displacement.'
      };

      const result = await sendAnalysisRequest(payload);
      setAnalysisResult(result);
    } catch (err: any) {
      setErrorMsg(err.message || 'Secure analysis request failed');
    } finally {
      setIsSendingRequest(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border-b border-slate-700/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide flex items-center gap-1.5">
                Firebase Authentication & Secure Proxy
              </h3>
              <p className="text-[11px] text-slate-400">
                Google Sign-In • Bearer Token Auth • Protected Gemini API
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs sm:text-sm">
          
          {/* Error Alert */}
          {errorMsg && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-xl flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="text-xs leading-relaxed">{errorMsg}</div>
            </div>
          )}

          {/* User Logged Out View */}
          {!user ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 shadow-inner">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Sign In to Authenticate API Access</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  The backend proxy requires a verified Firebase ID token (JWT) to access Gemini AI models without exposing the API key to the client.
                </p>
              </div>

              <button
                onClick={handleSignIn}
                disabled={isSigningIn || loading}
                className="inline-flex items-center gap-3 px-5 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs sm:text-sm transition-all shadow-lg shadow-white/10 active:scale-95 cursor-pointer disabled:opacity-50"
              >
                {/* Google Icon */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>{isSigningIn ? 'Connecting to Google...' : 'Sign in with Google'}</span>
              </button>
            </div>
          ) : (
            /* User Logged In View */
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3.5 bg-slate-800/80 border border-slate-700 rounded-xl">
                <div className="flex items-center gap-3">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-10 h-10 rounded-full border border-cyan-400/40 object-cover" />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-cyan-900 border border-cyan-400/40 flex items-center justify-center text-cyan-300 font-bold">
                      {user.displayName?.[0] || 'U'}
                    </div>
                  )}
                  <div>
                    <div className="font-bold text-white text-xs sm:text-sm">{user.displayName || 'Google User'}</div>
                    <div className="text-[11px] text-slate-400 font-mono">{user.email}</div>
                  </div>
                </div>

                <button
                  onClick={handleSignOut}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 hover:text-white border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </div>

              {/* Token Info Pill */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-mono text-cyan-400 flex items-center gap-1 font-bold">
                    <KeyRound className="w-3.5 h-3.5" /> Firebase ID Token (JWT)
                  </span>
                  <span className="text-emerald-400 text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/30">
                    Active & Verified
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  UID: <code className="text-slate-300 font-mono">{user.uid}</code>
                </p>
              </div>

              {/* Action Button: Test Secure Proxy */}
              <div className="space-y-2">
                <button
                  onClick={handleTestSecureAnalysis}
                  disabled={isSendingRequest}
                  className="w-full py-2.5 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow-md shadow-cyan-950/60 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSendingRequest ? 'Verifying Bearer Token & Calling Gemini...' : 'Send Request to Protected /api/analyze Endpoint'}</span>
                </button>
                <p className="text-[10px] text-slate-400 text-center">
                  Sends HTTP POST to <code className="text-cyan-300">/api/analyze</code> with <code className="text-amber-300">Authorization: Bearer &lt;ID_TOKEN&gt;</code>
                </p>
              </div>

              {/* Result Box */}
              {analysisResult && (
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                    <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" /> 200 OK — Authenticated by Firebase & Gemini
                    </span>
                    <span className="font-mono text-[10px]">
                      {new Date(analysisResult.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="text-xs whitespace-pre-wrap font-sans text-slate-200 leading-relaxed max-h-48 overflow-y-auto">
                    {analysisResult.analysis}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
