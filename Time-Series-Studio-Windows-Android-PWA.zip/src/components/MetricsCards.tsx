import React from 'react';
import { ForecastMetrics, ModelConfig } from '../types';
import { Activity, Target, Percent, ShieldCheck, Clock, Layers } from 'lucide-react';

interface MetricsCardsProps {
  metrics?: ForecastMetrics;
  modelConfig: ModelConfig;
  executionTimeMs?: number;
  unit?: string;
}

export const MetricsCards: React.FC<MetricsCardsProps> = ({
  metrics,
  modelConfig,
  executionTimeMs,
  unit = 'units'
}) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
      {/* Metric 1: Backtest MAE */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">Backtest MAE</span>
          <Target className="w-3.5 h-3.5 text-cyan-400" />
        </div>
        <div className="text-base sm:text-lg font-bold text-white font-mono">
          {metrics ? metrics.mae.toLocaleString() : '—'}
        </div>
        <div className="text-[10px] text-slate-500 truncate">
          Mean Absolute Error ({unit})
        </div>
      </div>

      {/* Metric 2: Backtest RMSE */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">RMSE</span>
          <Activity className="w-3.5 h-3.5 text-blue-400" />
        </div>
        <div className="text-base sm:text-lg font-bold text-white font-mono">
          {metrics ? metrics.rmse.toLocaleString() : '—'}
        </div>
        <div className="text-[10px] text-slate-500 truncate">
          Root Mean Squared Error
        </div>
      </div>

      {/* Metric 3: MAPE */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">MAPE</span>
          <Percent className="w-3.5 h-3.5 text-emerald-400" />
        </div>
        <div className="text-base sm:text-lg font-bold text-emerald-400 font-mono">
          {metrics ? `${metrics.mape}%` : '—'}
        </div>
        <div className="text-[10px] text-slate-500 truncate">
          Mean Abs % Error
        </div>
      </div>

      {/* Metric 4: Directional Accuracy (MDA) */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">Directional Acc.</span>
          <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
        </div>
        <div className="text-base sm:text-lg font-bold text-purple-300 font-mono">
          {metrics?.mda !== undefined ? `${metrics.mda}%` : '—'}
        </div>
        <div className="text-[10px] text-slate-400 font-mono truncate">
          {metrics ? `Coverage: ${metrics.coverageRate}%` : 'No out-of-sample evaluation'}
        </div>
      </div>

      {/* Metric 5: Model Patch & Architecture */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">Forecast engine</span>
          <Layers className="w-3.5 h-3.5 text-amber-400" />
        </div>
        <div className="text-xs sm:text-sm font-bold text-slate-200 font-mono truncate">
          Local baseline
        </div>
        <div className="text-[10px] text-slate-500 truncate">
          Heuristic; no pretrained TimesFM weights
        </div>
      </div>

      {/* Metric 6: Execution Latency */}
      <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl shadow-sm">
        <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
          <span className="font-medium">Calculation time</span>
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
        </div>
        <div className="text-base sm:text-lg font-bold text-indigo-300 font-mono">
          {executionTimeMs !== undefined ? `${executionTimeMs}ms` : '—'}
        </div>
        <div className="text-[10px] text-slate-500 truncate">
          Local statistical estimate
        </div>
      </div>
    </div>
  );
};
