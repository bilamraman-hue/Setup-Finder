import React, { useState, useEffect } from 'react';
import { 
  X, 
  ListFilter, 
  Search, 
  ChevronRight, 
  RefreshCw, 
  Bell, 
  Sparkles, 
  ShieldCheck, 
  Trash2,
  Maximize2,
  Zap,
  Compass,
  Cpu,
  Layers,
  BookmarkPlus,
  ChevronDown,
  Info
} from 'lucide-react';
import { WatchlistScanItem, getWatchlistFromStorage, saveWatchlistToStorage, removeWatchlistStock, clearWatchlistStorage, addOrUpdateWatchlistStock } from '../lib/watchlistStore';
import { QuantHorizon } from '../lib/quantSetupEngine';
import { computeMultiEngineWatchlistAnalysis, fetchCandlesForTimeframe } from '../lib/watchlistAnalysisEngine';

interface WatchlistSidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeSymbol?: string;
  onSelectStock: (symbol: string) => void;
  onOpenFullModal: () => void;
  currencySymbol?: string;
}

export const WatchlistSidebarDrawer: React.FC<WatchlistSidebarDrawerProps> = ({
  isOpen,
  onClose,
  activeSymbol = '',
  onSelectStock,
  onOpenFullModal,
  currencySymbol = '₹'
}) => {
  const [watchlist, setWatchlist] = useState<WatchlistScanItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'ALL' | 'INTRADAY' | 'SWING' | 'GRADE_A' | 'IN_ZONE'>('ALL');
  const [recalculatingSymbol, setRecalculatingSymbol] = useState<string | null>(null);
  const [isBulkScanning, setIsBulkScanning] = useState(false);
  const [isImportDropdownOpen, setIsImportDropdownOpen] = useState(false);

  const SECTOR_PRESETS = [
    {
      name: 'NIFTY 50 Leaders',
      icon: '🚀',
      symbols: [
        { symbol: 'RELIANCE', name: 'Reliance Industries' },
        { symbol: 'TCS', name: 'Tata Consultancy Services' },
        { symbol: 'HDFCBANK', name: 'HDFC Bank' },
        { symbol: 'INFY', name: 'Infosys' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank' },
        { symbol: 'SBIN', name: 'State Bank of India' },
        { symbol: 'LT', name: 'Larsen & Toubro' },
        { symbol: 'ITC', name: 'ITC Ltd' }
      ]
    },
    {
      name: 'High-Beta Intraday',
      icon: '⚡',
      symbols: [
        { symbol: 'TATAMOTORS', name: 'Tata Motors' },
        { symbol: 'BAJFINANCE', name: 'Bajaj Finance' },
        { symbol: 'ADANIENT', name: 'Adani Enterprises' },
        { symbol: 'TATASTEEL', name: 'Tata Steel' },
        { symbol: 'JSWSTEEL', name: 'JSW Steel' },
        { symbol: 'TITAN', name: 'Titan Company' }
      ]
    },
    {
      name: 'SMC FVG Retests',
      icon: '🏛️',
      symbols: [
        { symbol: 'DIXON', name: 'Dixon Tech' },
        { symbol: 'POLYCAB', name: 'Polycab' },
        { symbol: 'TRENT', name: 'Trent Ltd' },
        { symbol: 'PERSISTENT', name: 'Persistent' },
        { symbol: 'COFORGE', name: 'Coforge' }
      ]
    }
  ];

  useEffect(() => {
    if (isOpen) {
      setWatchlist(getWatchlistFromStorage());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTimeframeChange = async (
    item: WatchlistScanItem,
    newTf: '5m' | '15m' | '1h' | '1d',
    e: React.MouseEvent
  ) => {
    e.stopPropagation();
    setRecalculatingSymbol(item.symbol);
    try {
      const candles = await fetchCandlesForTimeframe(item.symbol, newTf);
      const autoHorizon: QuantHorizon = (newTf === '5m' || newTf === '15m')
        ? 'Intraday (5m/15m)'
        : 'Swing (3–4 Days)';

      const analysis = computeMultiEngineWatchlistAnalysis(
        item.symbol,
        item.name,
        candles,
        autoHorizon,
        newTf,
        currencySymbol,
        item
      );

      const currentList = getWatchlistFromStorage();
      const updated = currentList.map(it => it.symbol.toUpperCase() === item.symbol.toUpperCase() ? analysis.item : it);
      saveWatchlistToStorage(updated);
      setWatchlist(updated);
    } catch (err) {
      console.error('Drawer timeframe update failed:', err);
    } finally {
      setRecalculatingSymbol(null);
    }
  };

  const handleConvertAll = async (targetHz: QuantHorizon, targetTf: '15m' | '1d') => {
    const currentList = getWatchlistFromStorage();
    if (currentList.length === 0) return;

    setIsBulkScanning(true);
    try {
      const updatedList: WatchlistScanItem[] = [];
      for (const item of currentList) {
        const candles = await fetchCandlesForTimeframe(item.symbol, targetTf);
        const analysis = computeMultiEngineWatchlistAnalysis(
          item.symbol,
          item.name,
          candles,
          targetHz,
          targetTf,
          currencySymbol,
          item
        );
        updatedList.push(analysis.item);
      }
      saveWatchlistToStorage(updatedList);
      setWatchlist(updatedList);
    } catch (err) {
      console.error('Batch recalc error:', err);
    } finally {
      setIsBulkScanning(false);
    }
  };

  const handleImportPreset = async (presetGroup: typeof SECTOR_PRESETS[0]) => {
    setIsImportDropdownOpen(false);
    setIsBulkScanning(true);
    try {
      const isIntra = filterMode === 'INTRADAY';
      const effectiveTf = isIntra ? '15m' : '1d';
      const effectiveHz: QuantHorizon = isIntra ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)';

      for (const s of presetGroup.symbols) {
        const candles = await fetchCandlesForTimeframe(s.symbol, effectiveTf);
        const analysis = computeMultiEngineWatchlistAnalysis(
          s.symbol,
          s.name,
          candles,
          effectiveHz,
          effectiveTf,
          currencySymbol,
          { exchange: 'NSE' }
        );
        addOrUpdateWatchlistStock(analysis.item);
      }
      const refreshed = getWatchlistFromStorage();
      setWatchlist(refreshed);
    } catch (err) {
      console.error('Preset import error:', err);
    } finally {
      setIsBulkScanning(false);
    }
  };

  const filteredItems = watchlist.filter(item => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!item.symbol.toLowerCase().includes(q) && !item.name.toLowerCase().includes(q)) {
        return false;
      }
    }
    if (filterMode === 'INTRADAY') {
      return item.horizon === 'Intraday (5m/15m)' || item.timeframe === '5m' || item.timeframe === '15m';
    }
    if (filterMode === 'SWING') {
      return item.horizon === 'Swing (3–4 Days)' || item.timeframe === '1h' || item.timeframe === '1d';
    }
    if (filterMode === 'GRADE_A') {
      return item.setupGrade === 'GRADE_A_PLUS' || item.setupGrade === 'GRADE_A';
    }
    if (filterMode === 'IN_ZONE') {
      return item.isInEntryZone || (item.cmp >= item.entryRange.min && item.cmp <= item.entryRange.max);
    }
    return true;
  });

  return (
    <div className="fixed top-0 right-0 bottom-0 w-88 sm:w-96 bg-slate-900/95 backdrop-blur-md border-l border-slate-700/80 shadow-2xl z-40 flex flex-col animate-in slide-in-from-right duration-200 font-sans">
      {/* Top Header */}
      <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ListFilter className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-white">Watchlist Terminal</h3>
          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
            {watchlist.length}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Presets Import */}
          <div className="relative">
            <button
              onClick={() => setIsImportDropdownOpen(!isImportDropdownOpen)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 transition cursor-pointer"
              title="Import sector presets"
            >
              <BookmarkPlus className="w-3.5 h-3.5" />
            </button>

            {isImportDropdownOpen && (
              <div className="absolute right-0 top-full mt-1 w-56 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl z-50 p-1.5 space-y-1">
                <div className="px-2 py-0.5 text-[9px] font-bold text-slate-400 uppercase">
                  Quick Import
                </div>
                {SECTOR_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleImportPreset(p)}
                    className="w-full text-left p-1.5 rounded-lg hover:bg-slate-800 text-xs text-white transition flex items-center justify-between cursor-pointer"
                  >
                    <span>{p.icon} {p.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">+{p.symbols.length}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onOpenFullModal}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
            title="Open Full Multi-Engine Screener Modal"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-2.5 bg-slate-950/70 border-b border-slate-850 space-y-2">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Quick search symbol..."
            className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Horizon & Criteria Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none text-[10px] font-semibold">
          {[
            { id: 'ALL', label: `All (${watchlist.length})` },
            { id: 'INTRADAY', label: '⚡ Intraday' },
            { id: 'SWING', label: '🌊 Swing (3-5D)' },
            { id: 'GRADE_A', label: '🌟 Grade A' },
            { id: 'IN_ZONE', label: '🎯 In Zone' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterMode(f.id as any)}
              className={`px-2 py-0.5 rounded transition cursor-pointer whitespace-nowrap ${
                filterMode === f.id
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* 1-Click Batch Recalculate Buttons */}
        {watchlist.length > 0 && (
          <div className="flex items-center gap-1 pt-0.5">
            <button
              onClick={() => handleConvertAll('Intraday (5m/15m)', '15m')}
              disabled={isBulkScanning}
              className="flex-1 py-1 px-1.5 rounded-lg bg-amber-950/70 hover:bg-amber-900 border border-amber-800/60 text-amber-300 text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
              title="Convert all stocks to 15m Intraday calculations"
            >
              <Zap className="w-2.5 h-2.5" />
              <span>Recalc All Intra (15m)</span>
            </button>
            <button
              onClick={() => handleConvertAll('Swing (3–4 Days)', '1d')}
              disabled={isBulkScanning}
              className="flex-1 py-1 px-1.5 rounded-lg bg-indigo-950/70 hover:bg-indigo-900 border border-indigo-800/60 text-indigo-300 text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
              title="Convert all stocks to 1D Swing calculations"
            >
              <Compass className="w-2.5 h-2.5" />
              <span>Recalc All Swing (1D)</span>
            </button>
          </div>
        )}
      </div>

      {/* Stock Items List with 3-Engine Breakdown */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 p-2 space-y-1.5">
        {isBulkScanning && (
          <div className="p-2 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-[11px] flex items-center justify-center gap-1.5 animate-pulse">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Recalculating multi-engine levels...</span>
          </div>
        )}

        {filteredItems.length === 0 ? (
          <div className="py-12 text-center text-slate-500 text-xs">
            No stocks found in this filter.
          </div>
        ) : (
          filteredItems.map(item => {
            const isActive = activeSymbol.toUpperCase().replace(/\.NS$|\.BO$/i, '') === item.symbol.toUpperCase().replace(/\.NS$|\.BO$/i, '');
            const isBullish = item.finalVerdict?.includes('BUY') || item.direction === 'LONG';
            const isBearish = item.finalVerdict?.includes('SELL') || item.direction === 'SHORT';
            const tf = item.timeframe || (item.horizon === 'Intraday (5m/15m)' ? '15m' : '1d');
            const isRecalculating = recalculatingSymbol === item.symbol;

            return (
              <div
                key={item.id}
                onClick={() => onSelectStock(item.symbol)}
                className={`p-2.5 rounded-xl transition cursor-pointer space-y-1.5 group border ${
                  isActive
                    ? 'bg-cyan-950/40 border-cyan-500/50 shadow-sm'
                    : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/60 hover:border-slate-700'
                }`}
              >
                {/* Header: Symbol, Timeframe & CMP */}
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-white text-xs group-hover:text-cyan-300">
                        {item.symbol}
                      </span>
                      
                      {/* Interactive Timeframe Pill */}
                      <span 
                        onClick={(e) => handleTimeframeChange(item, tf === '5m' ? '15m' : tf === '15m' ? '1h' : tf === '1h' ? '1d' : '5m', e)}
                        className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-slate-800 text-cyan-300 border border-slate-700 hover:border-cyan-400 cursor-pointer"
                        title="Click to cycle timeframe (5m -> 15m -> 1h -> 1d)"
                      >
                        {tf} ▾
                      </span>

                      {item.isInEntryZone && (
                        <span className="px-1 py-0.2 rounded text-[8px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                          IN ZONE
                        </span>
                      )}

                      {isRecalculating && <RefreshCw className="w-2.5 h-2.5 text-cyan-400 animate-spin" />}
                    </div>
                    <span className="text-[10px] text-slate-400 block truncate max-w-[140px]">
                      {item.name}
                    </span>
                  </div>

                  <div className="text-right">
                    <div className="font-mono font-bold text-white text-xs">
                      {currencySymbol}{item.cmp.toLocaleString()}
                    </div>
                    <span className={`text-[10px] font-bold ${
                      isBullish ? 'text-emerald-400' : isBearish ? 'text-rose-400' : 'text-amber-400'
                    }`}>
                      {item.finalVerdict ? item.finalVerdict.split('/')[0].trim() : (isBullish ? 'BUY' : 'SELL')} ({item.confluenceScorePct || item.scorePct}%)
                    </span>
                  </div>
                </div>

                {/* 3-Engine Real Mathematical Breakdown Badges */}
                <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-850 space-y-1 text-[9px] font-mono">
                  {/* TimesFM 3.0 */}
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-purple-300 font-bold font-sans">🤖 Local baseline:</span>
                    <span>
                      {item.timesfmResult?.trend ?? 'N/A'} ({(item.timesfmResult?.expectedMovePct || 0) >= 0 ? '+' : ''}{item.timesfmResult?.expectedMovePct ?? 0}%) → <strong className="text-cyan-300">{currencySymbol}{item.timesfmResult?.p50Median ?? item.target1.price}</strong>
                    </span>
                  </div>

                  {/* Quant Engine */}
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-blue-300 font-bold font-sans">📊 Quant:</span>
                    <span>
                      Score {item.quantEngineResult?.scorePct || item.scorePct}% • {item.quantEngineResult?.cprRelation?.replace(/_/g, ' ') || 'Above CPR'}
                    </span>
                  </div>

                  {/* SMC / ICT / FVG */}
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-amber-300 font-bold font-sans">🏛️ SMC:</span>
                    <span>
                      {item.smcIctResult?.pricingZone || 'DISCOUNT'} Zone • FVG {item.smcIctResult?.fvgStatus || 'UNMITIGATED'}
                    </span>
                  </div>
                </div>

                {/* Entry & Targets row */}
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-0.5">
                  <span>Entry: <strong className="text-slate-200">{currencySymbol}{item.entryRange.min}</strong></span>
                  <span>T1: <strong className="text-emerald-400">{currencySymbol}{item.target1.price}</strong></span>
                  <span>SL: <strong className="text-rose-400">{currencySymbol}{item.stopLoss.price}</strong></span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Drawer Footer */}
      <div className="p-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span>Click stock to switch chart</span>
        <button
          onClick={onOpenFullModal}
          className="text-cyan-400 hover:text-cyan-300 font-bold underline cursor-pointer"
        >
          Open Screener Terminal
        </button>
      </div>
    </div>
  );
};
