import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, Laptop, Check, X, Share2, PlusSquare, Sparkles } from 'lucide-react';
import { InstallAppModal } from './InstallAppModal';

interface PWAInstallButtonProps {
  onOpenModal?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onOpenModal }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [isInstalling, setIsInstalling] = useState(false);

  const handleClick = async () => {
    if (onOpenModal) {
      onOpenModal();
      return;
    }

    if (isInstallable) {
      setIsInstalling(true);
      try {
        await install();
      } catch {
        setShowModal(true);
      } finally {
        setIsInstalling(false);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      {isInstalled ? (
        <button
          id="btn-installed-pwa-badge"
          onClick={() => setShowModal(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-950/70 border border-emerald-800/60 text-emerald-300 text-xs font-semibold shadow-sm hover:bg-emerald-900/60 transition cursor-pointer"
          title="Installed as native app. Click for info."
        >
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline">Installed App</span>
          <span className="sm:hidden">App</span>
        </button>
      ) : (
        <button
          id="btn-install-pwa"
          onClick={handleClick}
          disabled={isInstalling}
          title="Install as native app on Android, Windows, Mac, or iOS"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-cyan-950/50 border border-cyan-400/40 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-cyan-200 animate-bounce" />
          <span className="hidden md:inline">Install App (📱/💻)</span>
          <span className="md:hidden">Install</span>
        </button>
      )}

      <InstallAppModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
      />
    </>
  );
};
