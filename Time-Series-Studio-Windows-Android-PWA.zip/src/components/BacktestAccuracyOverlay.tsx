import React, { useState, useMemo, useEffect } from 'react';
import { TimeSeriesPoint } from '../types';
import { 
  runBacktestSimulation, 
  BacktestResult, 
  BacktestSignal,
  BacktestStrategyType
} from '../lib/backtestEngine';
import { BACKTEST_LOOKBACK_BARS } from '../lib/backtestEngine';
import type { SyntheticBuildupTimeframe } from '../lib/syntheticBuildupMatrix';
import { fetchCandlesForTimeframe } from '../lib/watchlistAnalysisEngine';
import { 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  ShieldAlert, 
  Calendar, 
  Percent, 
  X, 
  Zap, 
  Layers, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight,
  Sparkles,
  Info,
  ExternalLink
} from 'lucide-react';

interface BacktestAccuracyOverlayProps {
  symbol: string;
  name: string;
  currencySymbol?: string;
  history?: TimeSeriesPoint[];
  onClose: () => void;
  onPopout?: () => void;
  timeframe?: SyntheticBuildupTimeframe;
}

export const BacktestAccuracyOverlay: React.FC<BacktestAccuracyOverlayProps> = ({
  symbol,
  name,
  currencySymbol = '₹',
  history = [],
  onClose,
  onPopout,
  timeframe: initialTimeframe = '1h'
}) => {
  const [timeframe, setTimeframe] = useState<SyntheticBuildupTimeframe>(initialTimeframe);
  const [lookbackBars, setLookbackBars] = useState<number>(BACKTEST_LOOKBACK_BARS[initialTimeframe]);
  const [backtestHistory, setBacktestHistory] = useState<TimeSeriesPoint[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [strategy, setStrategy] = useState<BacktestStrategyType>('timesfm_momentum');
  const [selectedSignal, setSelectedSignal] = useState<BacktestSignal | null>(null);

  useEffect(() => {
    setTimeframe(initialTimeframe);
    setLookbackBars(BACKTEST_LOOKBACK_BARS[initialTimeframe]);
  }, [initialTimeframe]);

  useEffect(() => {
    let active = true;
    setIsLoadingHistory(true); setBacktestHistory([]);
    void fetchCandlesForTimeframe(symbol, timeframe).then(points => {
      if (active) setBacktestHistory(points);
    }).catch(error => console.warn(`Backtest history fetch failed for ${symbol} @ ${timeframe}`, error)).finally(() => {
      if (active) setIsLoadingHistory(false);
    });
    return () => { active = false; };
  }, [symbol, timeframe]);

  const backtest: BacktestResult = useMemo(() => {
    return runBacktestSimulation(backtestHistory, symbol, {
      lookbackBars,
      timeframe,
      strategy,
      riskRewardRatio: 2.0,
      useTrailingStop: true
    });
  }, [backtestHistory, symbol, lookbackBars, strategy, timeframe]);

  const { chartPoints, signals, winRatePct, avgReturnPct, profitFactor, maxDrawdownPct, wins, losses, totalSignals } = backtest;

  // Compute SVG chart coordinates
  const svgWidth = 800;
  const svgHeight = 220;
  const paddingX = 45;
  const paddingY = 30;

  const closes = chartPoints.map(p => p.close);
  const minPrice = Math.min(...closes) * 0.985;
  const maxPrice = Math.max(...closes) * 1.015;
  const priceRange = Math.max(1, maxPrice - minPrice);

  const getX = (index: number) => {
    if (chartPoints.length <= 1) return paddingX;
    return paddingX + (index / (chartPoints.length - 1)) * (svgWidth - paddingX * 2);
  };

  const getY = (price: number) => {
    return svgHeight - paddingY - ((price - minPrice) / priceRange) * (svgHeight - paddingY * 2);
  };

  // Generate SVG path string
  const pathD = chartPoints.reduce((acc, pt, idx) => {
    const x = getX(idx);
    const y = getY(pt.close);
    return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  // Area path for gradient fill
  const areaD = `${pathD} L ${getX(chartPoints.length - 1)} ${svgHeight - paddingY} L ${getX(0)} ${svgHeight - paddingY} Z`;

  return (
    <div className="bg-slate-950/95 border border-cyan-500/40 rounded-2xl p-4 sm:p-5 shadow-2xl space-y-4 animate-fade-in relative overflow-hidden backdrop-blur-xl">
      {/* Background glow */}
      <div className="absolute top-0 right-1/4 w-96 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-md">
            <Target className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-bold text-white tracking-tight">
                Historical Backtest Accuracy — {symbol}
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                {winRatePct}% Win Rate
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Deterministic forward simulation of past trade entries, Target 1 hits, and Stoploss invalidations.
            </p>
            <p className="text-[11px] text-cyan-300">{isLoadingHistory ? `Loading actual ${timeframe} candles…` : `${backtestHistory.length} fetched ${timeframe} candles${backtestHistory.length ? '' : ' · unavailable'}`}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
          {/* Strategy Selector */}
          <div className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-800 text-[11px]">
            {[
              { id: 'timesfm_momentum', label: 'Momentum' },
              { id: 'smc_fvg_retest', label: 'SMC FVG' },
              { id: 'cpr_orb_breakout', label: 'CPR' },
              { id: 'rsi_mean_reversion', label: 'RSI Rev' },
              { id: 'timeframe_weighted_setup', label: 'Weighted PA+Vol' }
            ].map((s) => (
              <button
                key={s.id}
                onClick={() => setStrategy(s.id as BacktestStrategyType)}
                className={`px-2 py-0.5 rounded-md font-semibold transition cursor-pointer ${
                  strategy === s.id
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          <select value={timeframe} onChange={event => { const tf = event.target.value as SyntheticBuildupTimeframe; setTimeframe(tf); setLookbackBars(BACKTEST_LOOKBACK_BARS[tf]); }} className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-1 text-[11px] text-cyan-200" aria-label="Backtest timeframe">
            {(['5m', '15m', '1h', '1d'] as const).map(tf => <option key={tf} value={tf}>{tf} · {BACKTEST_LOOKBACK_BARS[tf]} bars max</option>)}
          </select>

          {/* Lookback Selector */}
          <div className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-800 text-xs">
            {[60, 180, 500, BACKTEST_LOOKBACK_BARS[timeframe]].filter((v, i, a) => a.indexOf(v) === i).map((bars) => (
              <button
                key={bars}
                onClick={() => setLookbackBars(bars)}
                className={`px-2.5 py-1 rounded-md font-semibold transition cursor-pointer text-xs ${
                  lookbackBars === bars
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {bars} bars
              </button>
            ))}
          </div>

          {/* Pop-out to Separate Window Button (if supported) */}
          {onPopout && (
            <button
              onClick={onPopout}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 transition cursor-pointer flex items-center gap-1 text-xs"
              title="Open Backtest in Separate Window"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span className="hidden sm:inline font-sans text-[11px]">Separate Window</span>
            </button>
          )}

          {/* Close Overlay Button */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Close Backtest Overlay"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Performance Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
        <div className="bg-slate-900/80 p-3 rounded-xl border border-emerald-500/30">
          <span className="text-slate-400 text-[10px] font-mono uppercase tracking-wider block">Win Rate</span>
          <div className="text-xl font-black font-mono text-emerald-400 mt-0.5 flex items-baseline gap-1">
            <span>{winRatePct}%</span>
            <span className="text-[10px] text-slate-400 font-normal">({wins}W / {losses}L)</span>
          </div>
          <span className="text-[10px] text-slate-400">Out of {totalSignals} verified signals</span>
        </div>

        <div className="bg-slate-900/80 p-3 rounded-xl border border-cyan-500/30">
          <span className="text-slate-400 text-[10px] font-mono uppercase tracking-wider block">Avg Return / Trade</span>
          <div className="text-xl font-black font-mono text-cyan-400 mt-0.5">
            +{avgReturnPct}%
          </div>
          <span className="text-[10px] text-slate-400">Net target capture return</span>
        </div>

        <div className="bg-slate-900/80 p-3 rounded-xl border border-indigo-500/30">
          <span className="text-slate-400 text-[10px] font-mono uppercase tracking-wider block">Profit Factor</span>
          <div className="text-xl font-black font-mono text-indigo-300 mt-0.5">
            {profitFactor}x
          </div>
          <span className="text-[10px] text-slate-400">Gross profit / gross loss</span>
        </div>

        <div className="bg-slate-900/80 p-3 rounded-xl border border-rose-500/30">
          <span className="text-slate-400 text-[10px] font-mono uppercase tracking-wider block">Max Drawdown</span>
          <div className="text-xl font-black font-mono text-rose-400 mt-0.5">
            -{maxDrawdownPct}%
          </div>
          <span className="text-[10px] text-slate-400">Peak-to-valley risk tolerance</span>
        </div>
      </div>

      {/* SVG Interactive Chart Overlay */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5 font-medium text-slate-300">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Previous Trade Signals Mapped to Price History (Click pins to inspect trade)
          </span>
          <div className="flex items-center gap-3 text-[11px] font-mono">
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" /> Target Hit
            </span>
            <span className="flex items-center gap-1 text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-400" /> Stoploss Hit
            </span>
          </div>
        </div>

        <div className="relative bg-slate-900/90 rounded-xl border border-slate-800 p-2 sm:p-3 overflow-hidden">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-44 sm:h-52 overflow-visible select-none"
          >
            <defs>
              <linearGradient id="backtestAreaGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal Grid lines */}
            {[0.25, 0.5, 0.75].map((pct, idx) => {
              const y = paddingY + pct * (svgHeight - paddingY * 2);
              const priceVal = maxPrice - pct * priceRange;
              return (
                <g key={idx}>
                  <line
                    x1={paddingX}
                    y1={y}
                    x2={svgWidth - paddingX}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={paddingX - 6}
                    y={y + 3}
                    fill="#64748b"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    {currencySymbol}{priceVal.toFixed(0)}
                  </text>
                </g>
              );
            })}

            {/* Area Fill */}
            <path d={areaD} fill="url(#backtestAreaGrad)" />

            {/* Price Line */}
            <path
              d={pathD}
              fill="none"
              stroke="#06b6d4"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Signal Markers */}
            {signals.map((sig) => {
              const x = getX(sig.index);
              const y = getY(sig.entryPrice);
              const isWin = sig.outcome === 'TARGET_HIT';
              const isSelected = selectedSignal?.id === sig.id;

              return (
                <g
                  key={sig.id}
                  className="cursor-pointer transition-transform hover:scale-125"
                  onClick={() => setSelectedSignal(sig)}
                >
                  {/* Stem line to price */}
                  <line
                    x1={x}
                    y1={y}
                    x2={x}
                    y2={sig.type === 'BUY' ? y + 24 : y - 24}
                    stroke={isWin ? '#10b981' : '#f43f5e'}
                    strokeWidth="1.5"
                    strokeDasharray="2 2"
                  />

                  {/* Signal Node */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isSelected ? 6 : 4.5}
                    fill={isWin ? '#10b981' : '#f43f5e'}
                    stroke="#0f172a"
                    strokeWidth="2"
                  />

                  {/* Badge Label */}
                  <g transform={`translate(${x}, ${sig.type === 'BUY' ? y + 26 : y - 26})`}>
                    <rect
                      x="-20"
                      y={sig.type === 'BUY' ? '0' : '-16'}
                      width="40"
                      height="15"
                      rx="3"
                      fill={isWin ? '#064e3b' : '#881337'}
                      stroke={isWin ? '#10b981' : '#f43f5e'}
                      strokeWidth="1"
                    />
                    <text
                      x="0"
                      y={sig.type === 'BUY' ? '11' : '-5'}
                      fill="#ffffff"
                      fontSize="9"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {sig.type === 'BUY' ? '▲ BUY' : '▼ SELL'}
                    </text>
                  </g>
                </g>
              );
            })}
          </svg>
        </div>
      </div>

      {/* Selected Signal Inspection Card (if clicked) */}
      {selectedSignal && (
        <div className="p-3 bg-slate-900 border border-cyan-500/50 rounded-xl text-xs space-y-2 animate-fade-in relative">
          <button
            onClick={() => setSelectedSignal(null)}
            className="absolute top-2 right-2 text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-2">
            <span className={`px-2 py-0.5 rounded font-black text-xs ${
              selectedSignal.type === 'BUY' ? 'bg-emerald-950 text-emerald-400 border border-emerald-700' : 'bg-rose-950 text-rose-400 border border-rose-700'
            }`}>
              {selectedSignal.type} Signal
            </span>
            <span className="font-mono text-slate-300 font-bold">{selectedSignal.timestamp}</span>
            <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
              selectedSignal.outcome === 'TARGET_HIT' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
            }`}>
              {selectedSignal.outcome === 'TARGET_HIT' ? '🎯 Target Achieved' : '🛑 Stoploss Triggered'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[10px]">Entry Price</span>
              <strong className="text-white">{currencySymbol}{selectedSignal.entryPrice.toLocaleString()}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Target Price</span>
              <strong className="text-emerald-400">{currencySymbol}{selectedSignal.targetPrice.toLocaleString()}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Exit Price</span>
              <strong className={selectedSignal.returnPct >= 0 ? 'text-emerald-300' : 'text-rose-400'}>
                {currencySymbol}{selectedSignal.exitPrice.toLocaleString()} ({selectedSignal.returnPct >= 0 ? '+' : ''}{selectedSignal.returnPct}%)
              </strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px]">Duration</span>
              <strong className="text-cyan-300">{selectedSignal.barsHeld} Days Held</strong>
            </div>
          </div>

          <p className="text-slate-400 text-[11px]">
            <strong className="text-slate-300">Trigger Catalyst:</strong> {selectedSignal.reason}
          </p>
        </div>
      )}

      {/* Historical Signals Log Table */}
      <div className="space-y-1.5">
        <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
          Verified Trade Signal History Log
        </span>
        <div className="max-h-40 overflow-y-auto rounded-xl border border-slate-800 bg-slate-900/60 scrollbar-thin">
          <table className="w-full text-left text-xs border-collapse font-sans">
            <thead>
              <tr className="bg-slate-900 text-slate-400 text-[10px] font-mono uppercase tracking-wider border-b border-slate-800 sticky top-0">
                <th className="py-2 px-3">Date</th>
                <th className="py-2 px-2.5">Signal</th>
                <th className="py-2 px-2.5 text-right">Entry</th>
                <th className="py-2 px-2.5 text-right">Target</th>
                <th className="py-2 px-2.5 text-right">Exit</th>
                <th className="py-2 px-2.5 text-right">Return %</th>
                <th className="py-2 px-2.5 text-center">Outcome</th>
                <th className="py-2 px-2.5 text-center">Held</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
              {signals.map((s) => {
                const isWin = s.outcome === 'TARGET_HIT';
                return (
                  <tr 
                    key={s.id} 
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                    onClick={() => setSelectedSignal(s)}
                  >
                    <td className="py-2 px-3 text-slate-300 font-sans">{s.timestamp}</td>
                    <td className="py-2 px-2.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        s.type === 'BUY' ? 'text-emerald-400 bg-emerald-950/80 border border-emerald-800' : 'text-rose-400 bg-rose-950/80 border border-rose-800'
                      }`}>
                        {s.type}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-right text-white">
                      {currencySymbol}{s.entryPrice.toLocaleString()}
                    </td>
                    <td className="py-2 px-2.5 text-right text-emerald-400">
                      {currencySymbol}{s.targetPrice.toLocaleString()}
                    </td>
                    <td className="py-2 px-2.5 text-right text-slate-200">
                      {currencySymbol}{s.exitPrice.toLocaleString()}
                    </td>
                    <td className={`py-2 px-2.5 text-right font-bold ${
                      s.returnPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {s.returnPct >= 0 ? '+' : ''}{s.returnPct}%
                    </td>
                    <td className="py-2 px-2.5 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        isWin ? 'text-emerald-300 bg-emerald-950' : 'text-rose-300 bg-rose-950'
                      }`}>
                        {isWin ? 'Win' : 'Loss'}
                      </span>
                    </td>
                    <td className="py-2 px-2.5 text-center text-slate-400">
                      {s.barsHeld}d
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
