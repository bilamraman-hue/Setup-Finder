import React from 'react';
import { 
  LineChart, 
  CandlestickChart,
  ShieldCheck, 
  Sparkles,
  BarChart2,
  ListFilter,
  Layers
} from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition';
  setActiveTab: (tab: 'forecast' | 'quant' | 'scenario' | 'anomalies' | 'decomposition') => void;
  onOpenAdvanceChart: () => void;
  onOpenFinalVerdict: () => void;
  onOpenWatchlistScan: () => void;
  watchlistCount?: number;
  onOpenBacktestModal: () => void;
  onOpenChatModal: () => void;
  onScrollToTargets: () => void;
  onRunForecast?: () => void;
  isLoading: boolean;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenAdvanceChart,
  onOpenFinalVerdict,
  onOpenWatchlistScan,
  watchlistCount,
  onOpenBacktestModal,
  onOpenChatModal,
  onScrollToTargets,
  onRunForecast,
  isLoading
}) => {
  return (
    <nav 
      aria-label="Mobile App Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 px-1.5 sm:px-3 py-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] shadow-[0_-8px_30px_rgba(0,0,0,0.7)] flex items-center justify-around max-w-lg mx-auto sm:rounded-t-2xl sm:border-x sm:border-slate-800"
    >
      {/* Tab: Charts */}
      <button
        id="mobile-nav-charts"
        onClick={() => {
          setActiveTab('forecast');
          const el = document.getElementById('primary-charts-section');
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
          } else {
            window.scrollTo({ top: 220, behavior: 'smooth' });
          }
        }}
        className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition min-w-[42px] min-h-[44px] cursor-pointer ${
          activeTab === 'forecast'
            ? 'text-cyan-400 bg-cyan-950/50 font-bold'
            : 'text-slate-400 hover:text-slate-200'
        }`}
        title="View Technical & Forecast Charts"
      >
        <LineChart className="w-4.5 h-4.5 text-cyan-400" />
        <span className="text-[9px] font-semibold mt-0.5">Charts</span>
      </button>

      {/* Action: Advance Chart */}
      <button
        id="mobile-nav-advance-chart"
        onClick={onOpenAdvanceChart}
        className="flex flex-col items-center justify-center py-1 px-1 rounded-xl text-purple-400 hover:text-purple-300 transition min-w-[44px] min-h-[44px] cursor-pointer relative group"
        title="Open Dedicated Advance Chart (Local Forecast Baseline + Indicators)"
      >
        <div className="relative">
          <CandlestickChart className="w-4.5 h-4.5 text-purple-400 group-hover:scale-110 transition-transform" />
          <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
        </div>
        <span className="text-[9px] font-bold mt-0.5 tracking-tight text-purple-300 whitespace-nowrap">Adv Chart</span>
      </button>

      {/* Center Action: Gemini AI Chatbot in middle position */}
      <button
        id="mobile-nav-chatbot"
        onClick={onOpenChatModal}
        className="flex flex-col items-center justify-center -mt-4 w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white shadow-xl shadow-cyan-950/80 border-2 border-slate-900 transition active:scale-95 cursor-pointer ring-3 ring-cyan-500/20 shrink-0"
        title="Open Gemini AI Trading Chatbot"
      >
        <Sparkles className="w-5 h-5 text-white animate-pulse" />
      </button>

      {/* Action: Final Verdict */}
      <button
        id="mobile-nav-final-verdict"
        onClick={onOpenFinalVerdict}
        className="flex flex-col items-center justify-center py-1 px-1 rounded-xl text-amber-400 hover:text-amber-300 transition min-w-[44px] min-h-[44px] cursor-pointer relative group"
        title="Calculate Final Verdict"
      >
        <div className="relative">
          <ShieldCheck className="w-4.5 h-4.5 text-amber-400 group-hover:scale-110 transition-transform" />
          <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
        </div>
        <span className="text-[9px] font-bold mt-0.5 tracking-tight text-amber-300 whitespace-nowrap">Verdict</span>
      </button>

      {/* Action: Watchlist Scan */}
      <button
        id="mobile-nav-watchlist-scan"
        onClick={onOpenWatchlistScan}
        className="flex flex-col items-center justify-center py-1 px-1 rounded-xl text-indigo-400 hover:text-indigo-300 transition min-w-[44px] min-h-[44px] cursor-pointer relative group"
        title="Open Watchlist Scan"
      >
        <div className="relative">
          <ListFilter className="w-4.5 h-4.5 text-indigo-400 group-hover:scale-110 transition-transform" />
          {watchlistCount !== undefined && watchlistCount > 0 && (
            <span className="absolute -top-1 -right-2 px-1 py-0.2 rounded-full bg-indigo-600 border border-indigo-400/80 text-[7px] font-mono font-bold text-white leading-none">
              {watchlistCount > 99 ? '99+' : watchlistCount}
            </span>
          )}
        </div>
        <span className="text-[9px] font-bold mt-0.5 tracking-tight text-indigo-300 whitespace-nowrap">Watchlist</span>
      </button>
    </nav>
  );
};
