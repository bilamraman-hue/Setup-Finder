import React from 'react';
import { AnomalyItem } from '../types';
import { AlertTriangle, ShieldCheck, Filter, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface AnomalyInspectorProps {
  anomalies: AnomalyItem[];
  unit?: string;
  threshold: number;
  onThresholdChange: (threshold: number) => void;
}

export const AnomalyInspector: React.FC<AnomalyInspectorProps> = ({
  anomalies,
  unit = 'Units',
  threshold,
  onThresholdChange
}) => {
  const criticalCount = anomalies.filter(a => a.severity === 'critical').length;
  const highCount = anomalies.filter(a => a.severity === 'high').length;
  const mediumCount = anomalies.filter(a => a.severity === 'medium').length;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
      {/* Header & Metric Badges */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-950/80 border border-red-800/60 flex items-center justify-center text-red-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">
              Residual Anomaly Detection
            </h3>
            <p className="text-xs text-slate-400">
              Flags significant structural breaks and out-of-distribution shocks based on foundation model residual variance.
            </p>
          </div>
        </div>

        {/* Severity Count Chips */}
        <div className="flex items-center gap-2 text-xs">
          <span className="px-2.5 py-1 bg-red-950/80 text-red-300 rounded-lg border border-red-800/70 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            Critical: {criticalCount}
          </span>
          <span className="px-2.5 py-1 bg-orange-950/80 text-orange-300 rounded-lg border border-orange-800/70 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-orange-500" />
            High: {highCount}
          </span>
          <span className="px-2.5 py-1 bg-amber-950/80 text-amber-300 rounded-lg border border-amber-800/70 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            Medium: {mediumCount}
          </span>
        </div>
      </div>

      {/* Threshold Controller Bar */}
      <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-cyan-400" />
          <span className="text-slate-300 font-medium">Detection Z-Score Threshold:</span>
          <span className="font-mono text-cyan-400 font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
            {threshold} σ
          </span>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-64">
          <span className="text-[10px] text-slate-500">Sensitive (1.5)</span>
          <input
            id="anomaly-inspector-threshold"
            type="range"
            min="1.5"
            max="4.5"
            step="0.1"
            value={threshold}
            onChange={(e) => onThresholdChange(parseFloat(e.target.value))}
            className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500">Strict (4.5)</span>
        </div>
      </div>

      {/* Anomalies Table */}
      {anomalies.length === 0 ? (
        <div className="bg-slate-950/30 rounded-xl p-8 text-center border border-slate-800/50">
          <ShieldCheck className="w-9 h-9 text-emerald-400 mx-auto mb-2 opacity-80" />
          <p className="text-sm font-semibold text-slate-300">No Anomalies Detected</p>
          <p className="text-xs text-slate-500 mt-0.5">
            All historical points fall within the expected ±{threshold}σ predictive bounds.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-mono">
                <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                <th className="py-2.5 px-3 font-semibold">Severity</th>
                <th className="py-2.5 px-3 font-semibold">Observed Value</th>
                <th className="py-2.5 px-3 font-semibold">Expected Baseline</th>
                <th className="py-2.5 px-3 font-semibold">Residual σ</th>
                <th className="py-2.5 px-3 font-semibold">Diagnostic Analysis</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {anomalies.map((a, i) => {
                const isSpike = a.actual > a.expected;
                return (
                  <tr key={i} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-3 text-slate-200 font-bold">
                      {a.timestamp}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        a.severity === 'critical'
                          ? 'bg-red-950 text-red-300 border border-red-700'
                          : a.severity === 'high'
                          ? 'bg-orange-950 text-orange-300 border border-orange-700'
                          : 'bg-amber-950 text-amber-300 border border-amber-700'
                      }`}>
                        {a.severity}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1">
                      {isSpike ? (
                        <ArrowUpRight className="w-3.5 h-3.5 text-red-400" />
                      ) : (
                        <ArrowDownRight className="w-3.5 h-3.5 text-blue-400" />
                      )}
                      <span>{a.actual.toLocaleString()}</span>
                      <span className="text-slate-500 font-normal text-[10px]">{unit}</span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">
                      {a.expected.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 text-cyan-400 font-bold">
                      {a.score} σ
                    </td>
                    <td className="py-2.5 px-3 font-sans text-slate-300 max-w-xs truncate">
                      {a.reason}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
