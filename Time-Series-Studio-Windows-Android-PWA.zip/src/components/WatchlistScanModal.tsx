import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  X, 
  ListFilter, 
  Clock, 
  Calendar, 
  Search, 
  Trash2, 
  Zap, 
  ArrowUpRight, 
  ArrowDownRight, 
  AlertCircle, 
  Copy, 
  Check, 
  FileSpreadsheet, 
  RefreshCw, 
  ExternalLink,
  Plus,
  LayoutGrid,
  Table as TableIcon,
  ArrowUpDown,
  Share2,
  ChevronDown,
  Bell,
  BellRing,
  Award,
  Sparkles,
  ShieldAlert,
  ShieldCheck,
  Compass,
  TrendingUp,
  TrendingDown,
  Play,
  Layers,
  Filter,
  BarChart3,
  Cpu,
  Info,
  SlidersHorizontal,
  BookmarkPlus,
  Radar,
  ListPlus,
  Pencil
} from 'lucide-react';
import { 
  WatchlistScanItem, 
  MAX_WATCHLIST_LIMIT, 
  getWatchlistFromStorage, 
  saveWatchlistToStorage,
  addOrUpdateWatchlistStock, 
  removeWatchlistStock, 
  clearWatchlistStorage,
  formatDateTime,
  getWatchlists,
  getActiveWatchlistId,
  setActiveWatchlistId,
  createWatchlist,
  renameWatchlist,
  deleteWatchlist,
  type WatchlistDefinition
} from '../lib/watchlistStore';
import { DatasetPreset } from '../types';
import { QuantHorizon } from '../lib/quantSetupEngine';
import { analyzeOptionChainOi, cacheLiveFuturesOiSignal, cacheLiveOptionChainSignal } from '../lib/marketFlowSignals';
import type { OptionChainPayload } from '../lib/indianOptionsEngine';
import { 
  computeMultiEngineWatchlistAnalysis, 
  fetchCandlesForTimeframe,
  markTimeframeDataUnavailable
} from '../lib/watchlistAnalysisEngine';
import { syncSetupsFromWatchlistScan } from '../lib/mySetupsStore';

interface WatchlistScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentPreset: DatasetPreset;
  presets: DatasetPreset[];
  onSelectStock: (preset: DatasetPreset) => void;
  onFetchSymbol?: (symbol: string) => void;
  currencySymbol?: string;
  onWatchlistChange?: (count: number) => void;
  onOpenFinalVerdictModal?: () => void;
}

type SortOption = 'confluence' | 'grade' | 'entryDist' | 'change' | 'cmp' | 'symbol';
type ViewMode = 'table' | 'cards';
type EnginePerspective = 'ALL_ENGINES' | 'TIMESFM' | 'QUANT' | 'SMC_ICT';
type HorizonFilter = 'ALL' | 'INTRADAY' | 'SWING';
type TimeframeOption = '5m' | '15m' | '1h' | '1d';

export const WatchlistScanModal: React.FC<WatchlistScanModalProps> = ({
  isOpen,
  onClose,
  currentPreset,
  presets,
  onSelectStock,
  onFetchSymbol,
  currencySymbol = '₹',
  onWatchlistChange,
  onOpenFinalVerdictModal
}) => {
  const [watchlist, setWatchlist] = useState<WatchlistScanItem[]>([]);
  const [watchlists, setWatchlists] = useState<WatchlistDefinition[]>([]);
  const [activeWatchlistId, setActiveWatchlistIdState] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [tickerToAdd, setTickerToAdd] = useState('');
  const [isAddingTicker, setIsAddingTicker] = useState(false);
  const [filterVerdict, setFilterVerdict] = useState<'ALL' | 'GRADE_A_PLUS' | 'IN_ENTRY_ZONE' | 'BUY' | 'SELL' | 'ALERTS' | 'CONFLICT'>('ALL');
  const [horizonFilter, setHorizonFilter] = useState<HorizonFilter>('ALL');
  const [timeframeFilter, setTimeframeFilter] = useState<'ALL' | TimeframeOption>('ALL');
  const [activeEngineView, setActiveEngineView] = useState<EnginePerspective>('ALL_ENGINES');
  const [sortBy, setSortBy] = useState<SortOption>('confluence');
  const [viewMode, setViewMode] = useState<ViewMode>(() => typeof window !== 'undefined' && window.innerWidth < 768 ? 'cards' : 'table');
  const [copiedSymbol, setCopiedSymbol] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isBulkScanning, setIsBulkScanning] = useState(false);
  const [isImportDropdownOpen, setIsImportDropdownOpen] = useState(false);
  const [recalculatingSymbol, setRecalculatingSymbol] = useState<string | null>(null);
  const [inspectingItem, setInspectingItem] = useState<WatchlistScanItem | null>(null);
  const [isAutoRefreshActive, setIsAutoRefreshActive] = useState(false);
  const [isAlertDaemonActive, setIsAlertDaemonActive] = useState(true);
  const [activeAlertCount, setActiveAlertCount] = useState(0);
  const autoRefreshTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sectoral Pre-built Watchlists for instant 1-click import
  const SECTOR_PRESETS = [
    {
      name: 'NIFTY 50 Leaders',
      icon: '🚀',
      symbols: [
        { symbol: 'RELIANCE', name: 'Reliance Industries' },
        { symbol: 'TCS', name: 'Tata Consultancy Services' },
        { symbol: 'HDFCBANK', name: 'HDFC Bank' },
        { symbol: 'INFY', name: 'Infosys' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank' },
        { symbol: 'BHARTIARTL', name: 'Bharti Airtel' },
        { symbol: 'SBIN', name: 'State Bank of India' },
        { symbol: 'LT', name: 'Larsen & Toubro' },
        { symbol: 'ITC', name: 'ITC Ltd' },
        { symbol: 'AXISBANK', name: 'Axis Bank' }
      ]
    },
    {
      name: 'Bank Nifty F&O Movers',
      icon: '🏦',
      symbols: [
        { symbol: 'HDFCBANK', name: 'HDFC Bank' },
        { symbol: 'ICICIBANK', name: 'ICICI Bank' },
        { symbol: 'SBIN', name: 'State Bank of India' },
        { symbol: 'KOTAKBANK', name: 'Kotak Mahindra Bank' },
        { symbol: 'AXISBANK', name: 'Axis Bank' },
        { symbol: 'INDUSINDBK', name: 'IndusInd Bank' },
        { symbol: 'FEDERALBNK', name: 'Federal Bank' }
      ]
    },
    {
      name: 'High-Beta Intraday Momentum',
      icon: '⚡',
      symbols: [
        { symbol: 'TATAMOTORS', name: 'Tata Motors' },
        { symbol: 'BAJFINANCE', name: 'Bajaj Finance' },
        { symbol: 'ADANIENT', name: 'Adani Enterprises' },
        { symbol: 'TATASTEEL', name: 'Tata Steel' },
        { symbol: 'JSWSTEEL', name: 'JSW Steel' },
        { symbol: 'MARUTI', name: 'Maruti Suzuki' },
        { symbol: 'TITAN', name: 'Titan Company' }
      ]
    },
    {
      name: 'SMC FVG & Order Block Setups',
      icon: '🏛️',
      symbols: [
        { symbol: 'DIXON', name: 'Dixon Technologies' },
        { symbol: 'POLYCAB', name: 'Polycab India' },
        { symbol: 'TRENT', name: 'Trent Ltd' },
        { symbol: 'PERSISTENT', name: 'Persistent Systems' },
        { symbol: 'COFORGE', name: 'Coforge Ltd' },
        { symbol: 'HAL', name: 'Hindustan Aeronautics' },
        { symbol: 'BEL', name: 'Bharat Electronics' }
      ]
    }
  ];

  // Sync parent count
  useEffect(() => {
    onWatchlistChange?.(watchlist.length);
  }, [watchlist.length, onWatchlistChange]);

  useEffect(() => {
    if (isOpen) setWatchlists(getWatchlists());
  }, [watchlist.length, isOpen]);

  // Load watchlist on mount or modal open
  useEffect(() => {
    if (isOpen) {
      const lists = getWatchlists();
      const activeId = getActiveWatchlistId();
      setWatchlists(lists);
      setActiveWatchlistIdState(activeId);
      const items = getWatchlistFromStorage(activeId);
      setWatchlist(items);
    }
  }, [isOpen]);

  // Auto-refresh daemon
  useEffect(() => {
    if (isOpen && isAutoRefreshActive) {
      autoRefreshTimerRef.current = setInterval(() => {
        handleLiveBatchScan(false);
      }, 30000);
    }
    return () => {
      if (autoRefreshTimerRef.current) clearInterval(autoRefreshTimerRef.current);
    };
  }, [isOpen, isAutoRefreshActive, watchlist.length]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const switchWatchlist = (id: string) => {
    if (isBulkScanning || recalculatingSymbol) return;
    if (!setActiveWatchlistId(id)) return;
    setActiveWatchlistIdState(id);
    const items = getWatchlistFromStorage(id);
    setWatchlist(items);
    setActiveAlertCount(items.filter(item => item.alertTriggered).length);
    onWatchlistChange?.(items.length);
  };

  const handleCreateWatchlist = () => {
    if (isBulkScanning || recalculatingSymbol) return;
    const created = createWatchlist();
    const lists = getWatchlists();
    setWatchlists(lists);
    setActiveWatchlistIdState(created.id);
    setWatchlist([]);
    onWatchlistChange?.(0);
    showToast(`Created ${created.name}. Add up to ${MAX_WATCHLIST_LIMIT} symbols.`);
  };

  const handleRenameWatchlist = () => {
    const current = watchlists.find(list => list.id === activeWatchlistId);
    if (!current) return;
    const nextName = window.prompt('Watchlist name (max 32 characters):', current.name);
    if (nextName === null) return;
    if (!renameWatchlist(activeWatchlistId, nextName)) { showToast('Enter a non-empty watchlist name.'); return; }
    setWatchlists(getWatchlists());
  };

  const handleDeleteWatchlist = () => {
    const current = watchlists.find(list => list.id === activeWatchlistId);
    if (!current || watchlists.length <= 1) return;
    if (!window.confirm(`Delete “${current.name}” and its ${current.items.length} saved stocks?`)) return;
    deleteWatchlist(activeWatchlistId);
    const lists = getWatchlists();
    const nextId = getActiveWatchlistId();
    setWatchlists(lists);
    setActiveWatchlistIdState(nextId);
    const items = getWatchlistFromStorage(nextId);
    setWatchlist(items);
    onWatchlistChange?.(items.length);
  };

  // Sound chime for triggered alerts
  const playAlertChime = () => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1174, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // AudioContext unavailable
    }
  };

  // Add currently active preset to watchlist with all 3 mathematical engines evaluated
  const handleAddCurrentStock = (horizonChoice: QuantHorizon = 'Swing (3–4 Days)', tfChoice: TimeframeOption = '15m') => {
    const symbol = currentPreset.symbol || currentPreset.title;
    const name = currentPreset.title;
    const candles = currentPreset.data || [];

    const analysis = computeMultiEngineWatchlistAnalysis(
      symbol,
      name,
      candles,
      horizonChoice,
      tfChoice,
      currencySymbol,
      { exchange: (currentPreset as any).exchange || 'NSE' }
    );

    const addRes = addOrUpdateWatchlistStock(analysis.item);
    setWatchlist(addRes.watchlist);
    if (addRes.limitReached) {
      showToast(`This watchlist already has ${MAX_WATCHLIST_LIMIT} stocks. Create another watchlist to add more.`);
      return;
    }
    syncSetupsFromWatchlistScan(addRes.watchlist, tfChoice);
    showToast(`Added ${symbol} (${horizonChoice}) with ${analysis.finalVerdict.gradeBadge} to Watchlist!`);
  };

  const handleAddTickerToWatchlist = async (event?: React.FormEvent) => {
    event?.preventDefault();
    const symbol = tickerToAdd.trim().toUpperCase();
    if (!symbol || isAddingTicker || isBulkScanning) return;
    if (!/^[A-Z0-9.^=&-]{1,24}$/.test(symbol)) { showToast('Enter a valid ticker symbol.'); return; }
    const timeframe: TimeframeOption = timeframeFilter === 'ALL' ? '1h' : timeframeFilter;
    const horizon: QuantHorizon = timeframe === '5m' || timeframe === '15m' ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)';
    setIsAddingTicker(true);
    try {
      const candles = await fetchCandlesForTimeframe(symbol, timeframe);
      if (candles.length < 10) { showToast(`No usable ${timeframe} history found for ${symbol}; it was not added.`); return; }
      const preset = presets.find(p => p.symbol?.toUpperCase() === symbol);
      const analysis = computeMultiEngineWatchlistAnalysis(symbol, preset?.title || symbol, candles, horizon, timeframe, currencySymbol, { exchange: 'NSE' });
      const added = addOrUpdateWatchlistStock(analysis.item);
      if (added.limitReached) { showToast(`This watchlist is full (${MAX_WATCHLIST_LIMIT}). Create another list first.`); return; }
      setWatchlist(added.watchlist);
      setTickerToAdd('');
      syncSetupsFromWatchlistScan(added.watchlist, timeframe, activeWatchlistId);
      showToast(`${symbol} added using fresh ${timeframe} data.`);
    } catch (error) {
      console.error('Watchlist ticker add failed:', error);
      showToast(`Could not fetch ${symbol}. Check the ticker and data connection.`);
    } finally { setIsAddingTicker(false); }
  };

  // Change Timeframe & Horizon dynamically for an individual stock
  const handleTimeframeChange = async (
    item: WatchlistScanItem,
    newTimeframe: TimeframeOption,
    e?: React.MouseEvent
  ) => {
    if (e) e.stopPropagation();
    setRecalculatingSymbol(item.symbol);
    showToast(`Recalculating ${item.symbol} on ${newTimeframe} timeframe...`);

    try {
      // 1. Fetch real candles for the selected timeframe
      const candles = await fetchCandlesForTimeframe(item.symbol, newTimeframe);

      // Auto-set Horizon: 5m/15m -> Intraday, 1h/1d -> Swing
      const autoHorizon: QuantHorizon = (newTimeframe === '5m' || newTimeframe === '15m')
        ? 'Intraday (5m/15m)'
        : 'Swing (3–4 Days)';

      // 2. Perform mathematically grounded Multi-Engine re-analysis
      const updatedItem = candles.length >= 10 ? computeMultiEngineWatchlistAnalysis(
        item.symbol,
        item.name,
        candles,
        autoHorizon,
        newTimeframe,
        currencySymbol,
        item
      ).item : markTimeframeDataUnavailable(item, newTimeframe);

      // 3. Update storage and state
      const currentList = getWatchlistFromStorage();
      const updatedList = currentList.map(it => it.symbol.toUpperCase() === item.symbol.toUpperCase() ? updatedItem : it);
      saveWatchlistToStorage(updatedList);
      setWatchlist(updatedList);
      syncSetupsFromWatchlistScan([updatedItem], newTimeframe, activeWatchlistId);
      showToast(`Updated ${item.symbol} to ${newTimeframe} (${autoHorizon})!`);
    } catch (err) {
      console.error(`Failed to recalculate timeframe for ${item.symbol}:`, err);
      showToast(`Failed to update ${item.symbol} timeframe`);
    } finally {
      setRecalculatingSymbol(null);
    }
  };

  // Convert ALL stocks in watchlist to selected horizon & timeframe
  const handleConvertAllHorizon = async (targetHorizon: 'Intraday (5m/15m)' | 'Swing (3–4 Days)', targetTf: TimeframeOption) => {
    const currentList = getWatchlistFromStorage();
    if (currentList.length === 0) {
      showToast('Watchlist is empty. Add stocks first.');
      return;
    }

    setIsBulkScanning(true);
    showToast(`Recalculating all ${currentList.length} stocks for ${targetHorizon} (${targetTf})...`);

    try {
      const updatedList: WatchlistScanItem[] = [];

      for (const item of currentList) {
        const candles = await fetchCandlesForTimeframe(item.symbol, targetTf);

        const updatedItem = candles.length >= 10 ? computeMultiEngineWatchlistAnalysis(
          item.symbol,
          item.name,
          candles,
          targetHorizon,
          targetTf,
          currencySymbol,
          item
        ).item : markTimeframeDataUnavailable(item, targetTf);

        updatedList.push(updatedItem);
      }

      saveWatchlistToStorage(updatedList);
      setWatchlist(updatedList);
      syncSetupsFromWatchlistScan(updatedList, targetTf, activeWatchlistId);
      showToast(`⚡ All ${updatedList.length} stocks recalculated for ${targetHorizon} (${targetTf})!`);
    } catch (err) {
      console.error('Batch horizon conversion error:', err);
      showToast('Error during batch recalculation.');
    } finally {
      setIsBulkScanning(false);
    }
  };

  // Import Sector / Index Preset Watchlist
  const handleImportPreset = async (presetGroup: typeof SECTOR_PRESETS[0]) => {
    setIsImportDropdownOpen(false);
    setIsBulkScanning(true);
    showToast(`Importing ${presetGroup.name} (${presetGroup.symbols.length} stocks)...`);

    try {
      const isIntra = horizonFilter === 'INTRADAY';
      const effectiveTf: TimeframeOption = isIntra ? '15m' : '1d';
      const effectiveHz: QuantHorizon = isIntra ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)';
      let importedCount = 0;
      let capacityReached = false;

      for (const s of presetGroup.symbols) {
        let candles = await fetchCandlesForTimeframe(s.symbol, effectiveTf);
        if (!candles || candles.length === 0) {
          const matched = presets.find(
            p => (p.symbol && p.symbol.toUpperCase() === s.symbol.toUpperCase()) ||
                 (p.title && p.title.toUpperCase() === s.symbol.toUpperCase())
          );
          candles = matched?.data || [];
        }

        const analysis = computeMultiEngineWatchlistAnalysis(
          s.symbol,
          s.name,
          candles,
          effectiveHz,
          effectiveTf,
          currencySymbol,
          { exchange: 'NSE' }
        );

        const added = addOrUpdateWatchlistStock(analysis.item);
        if (added.limitReached) { capacityReached = true; break; }
        importedCount++;
      }

      const refreshed = getWatchlistFromStorage();
      setWatchlist(refreshed);
      syncSetupsFromWatchlistScan(refreshed, effectiveTf);
      showToast(`✅ Imported ${importedCount} stocks from ${presetGroup.name}.${capacityReached ? ` List limit is ${MAX_WATCHLIST_LIMIT}; create another watchlist for more.` : ''}`);
    } catch (err) {
      console.error('Preset import error:', err);
      showToast('Failed to import preset watchlist.');
    } finally {
      setIsBulkScanning(false);
    }
  };

  // LIVE PARALLEL BATCH SCAN
  const handleLiveBatchScan = async (showNotification = true) => {
    const currentList = getWatchlistFromStorage();
    if (currentList.length === 0) {
      if (showNotification) showToast('Watchlist is empty. Add stocks first to scan live prices.');
      return;
    }

    setIsBulkScanning(true);
    try {
      const symbolsToFetch = currentList.map(item => item.symbol);
      const res = await fetch('/api/market/batch-quotes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ symbols: symbolsToFetch })
      });

      let quotes: Record<string, any> = {};
      if (res.ok) {
        const data = await res.json();
        quotes = data.quotes || {};
      }

      let futuresOiSignals: Record<string, any> = {};
      try {
        const savedConfig = localStorage.getItem('timesfm_custom_api_config');
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (savedConfig) headers['x-custom-api-config'] = encodeURIComponent(savedConfig);
        const oiRes = await fetch('/api/market/futures-oi/batch', {
          method: 'POST', headers,
          body: JSON.stringify({ symbols: currentList.map(item => item.symbol) })
        });
        if (oiRes.ok) {
          futuresOiSignals = (await oiRes.json()).signals || {};
          for (const [symbol, snapshot] of Object.entries(futuresOiSignals)) {
            if ((snapshot as any)?.signal?.available) cacheLiveFuturesOiSignal(symbol, (snapshot as any).signal);
          }
        }
      } catch { /* Missing broker futures feed is optional and must not block the watchlist scan. */ }

      let triggeredCount = 0;

      const refreshedList: WatchlistScanItem[] = currentList.map(item => {
        const cleanSym = item.symbol.toUpperCase().replace(/\.NS$|\.BO$/i, '');
        const quote = quotes[cleanSym] || quotes[item.symbol.toUpperCase()];
        const liveCmp = quote?.cmp || item.cmp;

        const matchedPreset = presets.find(
          p => (p.symbol && p.symbol.toUpperCase() === item.symbol.toUpperCase()) ||
               (p.title && p.title.toUpperCase() === item.symbol.toUpperCase())
        ) || (currentPreset.symbol?.toUpperCase() === item.symbol.toUpperCase() ? currentPreset : null);

        const candleData = quote?.candles || matchedPreset?.data || [];
        const effectiveTimeframe = item.timeframe || (item.horizon === 'Intraday (5m/15m)' ? '15m' : '1d');

        // Multi-Engine analysis with live candles
        const analysis = computeMultiEngineWatchlistAnalysis(
          item.symbol,
          item.name,
          candleData,
          item.horizon || 'Swing (3–4 Days)',
          effectiveTimeframe,
          currencySymbol,
          {
            ...item,
            cmp: liveCmp,
            changePct: quote?.changePct ?? item.changePct ?? 0,
            prevClose: quote?.prevClose ?? item.prevClose,
            currentSessionVolume: quote?.currentSessionVolume ?? quote?.volume ?? item.currentSessionVolume,
            marketFlow: {
              ...item.marketFlow,
              futuresOi: futuresOiSignals[cleanSym]?.signal?.available ? futuresOiSignals[cleanSym].signal : item.marketFlow?.futuresOi
            }
          }
        );

        if (analysis.item.alertTriggered) triggeredCount++;
        return analysis.item;
      });

      saveWatchlistToStorage(refreshedList);
      setWatchlist(refreshedList);
      syncSetupsFromWatchlistScan(refreshedList);
      setActiveAlertCount(triggeredCount);

      if (triggeredCount > 0 && isAlertDaemonActive) {
        playAlertChime();
      }

      if (showNotification) {
        showToast(`⚡ Scanned ${refreshedList.length} stocks live! ${triggeredCount > 0 ? `(${triggeredCount} Alerts Active)` : ''}`);
      }
    } catch (err) {
      console.error('Error during batch quote scan:', err);
      if (showNotification) showToast('Could not complete live scan. Using cached levels.');
    } finally {
      setIsBulkScanning(false);
    }
  };

  const handleFetchLiveOiForItem = async (item: WatchlistScanItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecalculatingSymbol(item.symbol);
    try {
      const savedConfig = localStorage.getItem('timesfm_custom_api_config');
      const headers: Record<string, string> = {};
      if (savedConfig) headers['x-custom-api-config'] = encodeURIComponent(savedConfig);
      const response = await fetch(`/api/market/options?symbol=${encodeURIComponent(item.symbol)}&cmp=${encodeURIComponent(String(item.cmp))}`, { headers });
      const payload = response.ok ? await response.json() as OptionChainPayload : null;
      const signal = payload ? analyzeOptionChainOi(payload) : null;
      if (!signal?.available) {
        const failure = payload?.sourceState === 'LIVE'
          ? 'Live option quotes arrived, but the broker has not shown an OI change yet. Try again after a few seconds.'
          : 'No live option-chain OI was fetched. Check Angel One JWT, SmartAPI headers, and F&O eligibility.';
        showToast(failure);
        return;
      }
      cacheLiveOptionChainSignal(item.symbol, signal);
      const candles = await fetchCandlesForTimeframe(item.symbol, item.timeframe || '1d');
      const analysis = computeMultiEngineWatchlistAnalysis(
        item.symbol,
        item.name,
        candles,
        item.horizon,
        item.timeframe || '1d',
        currencySymbol,
        { ...item, marketFlowAt: Date.now() }
      );
      const currentList = getWatchlistFromStorage();
      const updated = currentList.map(row => row.symbol.toUpperCase() === item.symbol.toUpperCase() ? analysis.item : row);
      saveWatchlistToStorage(updated);
      setWatchlist(updated);
      syncSetupsFromWatchlistScan(updated);
      showToast(`${item.symbol}: live option-chain OI added to verdict (${signal.direction}).`);
    } catch (err: any) {
      showToast(err?.message || `Could not fetch live option-chain OI for ${item.symbol}.`);
    } finally {
      setRecalculatingSymbol(null);
    }
  };

  // Remove single stock
  const handleRemoveStock = (symbol: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = removeWatchlistStock(symbol);
    setWatchlist(updated);
    showToast(`Removed ${symbol} from Watchlist`);
  };

  // Clear all
  const handleClearAll = () => {
    if (window.confirm('Clear all stocks from Watchlist Scan?')) {
      clearWatchlistStorage();
      setWatchlist([]);
      showToast('Watchlist cleared');
    }
  };

  // Export to CSV with full 3-engine columns
  const handleExportCsv = () => {
    if (watchlist.length === 0) {
      showToast('Watchlist is empty');
      return;
    }
    const headers = [
      'Symbol,Name,CMP,Change %,Timeframe,Horizon,Final Verdict,Setup Grade,Confluence %,TimesFM Trend,TimesFM Move %,TimesFM p50,Quant Score %,CPR Status,Volume POC,SMC Zone,SMC FVG,Entry Min,Entry Max,Target 1,Stoploss,R:R,Scan Time'
    ];
    const rows = watchlist.map(i => 
      `"${i.symbol}","${i.name}",${i.cmp},${i.changePct || 0}%,"${i.timeframe || '15m'}","${i.horizon}","${i.finalVerdict || i.direction}","${i.gradeBadge || 'N/A'}",${i.confluenceScorePct || i.scorePct}%,"${i.timesfmResult?.trend || 'N/A'}",${i.timesfmResult?.expectedMovePct || 0}%,${i.timesfmResult?.p50Median || 0},${i.quantEngineResult?.scorePct || 0}%,"${i.quantEngineResult?.cprRelation || 'N/A'}",${i.quantEngineResult?.volumeProfilePoc || 0},"${i.smcIctResult?.pricingZone || 'N/A'}","${i.smcIctResult?.fvgStatus || 'N/A'}",${i.entryRange.min},${i.entryRange.max},${i.target1.price},${i.stopLoss.price},"${i.riskRewardText}","${i.dateTimeFormatted}"`
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `watchlist_multi_engine_verdicts_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported Multi-Engine Watchlist with Final Verdicts to CSV');
  };

  // Select stock to load onto main chart
  const handleSelectStock = (item: WatchlistScanItem) => {
    const matched = presets.find(
      p => (p.symbol && p.symbol.toUpperCase() === item.symbol.toUpperCase()) ||
           (p.title && p.title.toUpperCase() === item.symbol.toUpperCase())
    );

    if (matched) {
      onSelectStock(matched);
      onClose();
    } else if (onFetchSymbol) {
      onFetchSymbol(item.symbol);
      onClose();
    } else {
      showToast(`Selected ${item.symbol}`);
      onClose();
    }
  };

  // Copy symbol
  const handleCopy = (sym: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(sym);
    setCopiedSymbol(sym);
    setTimeout(() => setCopiedSymbol(null), 1800);
  };

  // Filtered and Sorted items
  const filteredAndSortedList = useMemo(() => {
    let result = [...watchlist];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(i => 
        i.symbol.toLowerCase().includes(q) || 
        i.name.toLowerCase().includes(q)
      );
    }

    // Horizon filter (Intraday vs Swing)
    if (horizonFilter === 'INTRADAY') {
      result = result.filter(i => 
        i.horizon === 'Intraday (5m/15m)' || i.timeframe === '5m' || i.timeframe === '15m'
      );
    } else if (horizonFilter === 'SWING') {
      result = result.filter(i => 
        i.horizon === 'Swing (3–4 Days)' || i.timeframe === '1h' || i.timeframe === '1d'
      );
    }

    // Timeframe selection recalculates the whole list. Keep every symbol visible;
    // symbols without usable data remain in the list with an explicit status.

    // Verdict and Grade Filters
    if (filterVerdict === 'GRADE_A_PLUS') {
      result = result.filter(i => i.setupGrade === 'GRADE_A_PLUS');
    } else if (filterVerdict === 'IN_ENTRY_ZONE') {
      result = result.filter(i => i.isInEntryZone || (i.cmp >= i.entryRange.min && i.cmp <= i.entryRange.max));
    } else if (filterVerdict === 'BUY') {
      result = result.filter(i => i.finalVerdict?.includes('BUY') || i.direction === 'LONG');
    } else if (filterVerdict === 'SELL') {
      result = result.filter(i => i.finalVerdict?.includes('SELL') || i.direction === 'SHORT');
    } else if (filterVerdict === 'ALERTS') {
      result = result.filter(i => i.alertTriggered);
    } else if (filterVerdict === 'CONFLICT') {
      result = result.filter(i => i.finalVerdict?.includes('CONFLICT') || i.status === 'AVOID');
    }

    // Rank qualifying setups first, then non-qualifying rows, before user sort.
    result.sort((a, b) => {
      const tier = (item: WatchlistScanItem) => item.setupGrade === 'GRADE_A_PLUS' && item.direction !== 'NEUTRAL' && (item.confluenceScorePct ?? item.scorePct) >= 65 ? 0
        : item.setupGrade === 'GRADE_A' && item.direction !== 'NEUTRAL' && (item.confluenceScorePct ?? item.scorePct) >= 65 ? 1
        : 2;
      const tierDiff = tier(a) - tier(b);
      if (tierDiff) return tierDiff;
      if (sortBy === 'confluence') {
        const scA = a.confluenceScorePct || a.scorePct || 0;
        const scB = b.confluenceScorePct || b.scorePct || 0;
        return scB - scA;
      }
      if (sortBy === 'grade') {
        const gradeRank: Record<string, number> = { GRADE_A_PLUS: 4, GRADE_A: 3, GRADE_B: 2, NO_TRADE: 1 };
        return (gradeRank[b.setupGrade || ''] || 0) - (gradeRank[a.setupGrade || ''] || 0);
      }
      if (sortBy === 'entryDist') {
        return (a.distanceToEntryPct ?? 99) - (b.distanceToEntryPct ?? 99);
      }
      if (sortBy === 'change') {
        return (b.changePct ?? 0) - (a.changePct ?? 0);
      }
      if (sortBy === 'cmp') {
        return b.cmp - a.cmp;
      }
      return a.symbol.localeCompare(b.symbol);
    });

    return result;
  }, [watchlist, searchQuery, horizonFilter, timeframeFilter, filterVerdict, sortBy]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-7xl bg-slate-900 border border-slate-700/80 rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[96dvh] sm:max-h-[95vh] text-slate-100 ring-1 ring-cyan-500/20">
        
        {/* Header Modal Bar */}
        <div className="px-4 py-3 bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-cyan-500/20">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-wide flex items-center gap-1.5">
                  Multi-Engine Watchlist Screener
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  {watchlist.length}/{MAX_WATCHLIST_LIMIT} Stocks
                </span>
                {activeAlertCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/50 flex items-center gap-1 animate-pulse">
                    <BellRing className="w-3 h-3 text-amber-400" />
                    <span>{activeAlertCount} Alerts Active</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Intraday & Swing 3–5D • local statistical baseline • Quant Engine (CPR/Vol) • SMC/ICT/FVG • Final Verdict
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Import Pre-built Sector Watchlists */}
            <div className="relative">
              <button
                onClick={() => setIsImportDropdownOpen(!isImportDropdownOpen)}
                className="px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1 transition cursor-pointer"
                title="Import pre-configured Indian sector and index watchlists"
              >
                <BookmarkPlus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Presets</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {isImportDropdownOpen && (
                <div className="absolute right-0 top-full mt-1.5 w-64 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl z-50 p-1.5 space-y-1">
                  <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Quick Import Sector Sets
                  </div>
                  {SECTOR_PRESETS.map((p, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleImportPreset(p)}
                      className="w-full text-left p-2 rounded-lg hover:bg-slate-800 text-xs text-white transition flex items-center justify-between cursor-pointer"
                    >
                      <span className="flex items-center gap-1.5">
                        <span>{p.icon}</span>
                        <span className="font-semibold">{p.name}</span>
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">+{p.symbols.length}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Live Parallel Batch Scan Button */}
            <button
              onClick={() => handleLiveBatchScan(true)}
              disabled={isBulkScanning || watchlist.length === 0}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer ${
                isBulkScanning
                  ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-cyan-500/20'
              }`}
              title="Parallel live quote scan for all watchlist stocks"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isBulkScanning ? 'animate-spin' : ''}`} />
              <span>{isBulkScanning ? 'Scanning Live...' : '⚡ Scan Live All'}</span>
            </button>

            {/* Auto Refresh Toggle */}
            <button
              onClick={() => setIsAutoRefreshActive(!isAutoRefreshActive)}
              className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold border flex items-center gap-1 transition cursor-pointer ${
                isAutoRefreshActive
                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Toggle automatic 30-second live scan"
            >
              <span className={`w-2 h-2 rounded-full ${isAutoRefreshActive ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
              <span className="hidden sm:inline">Auto 30s</span>
            </button>

            {/* Export CSV */}
            <button
              onClick={handleExportCsv}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
              title="Export Watchlist with 3-Engine Verdicts to CSV"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 bg-slate-950 px-3 py-2 sm:px-4">
          <label className="flex min-w-0 flex-1 items-center gap-2 text-xs text-slate-400 sm:flex-none">
            <span className="shrink-0">Watchlist</span>
            <select value={activeWatchlistId} onChange={e => switchWatchlist(e.target.value)} disabled={isBulkScanning || Boolean(recalculatingSymbol)} className="min-w-0 max-w-full rounded-lg border border-slate-700 bg-slate-900 px-2.5 py-1.5 text-sm font-semibold text-white disabled:opacity-50 sm:min-w-48">
              {watchlists.map(list => <option key={list.id} value={list.id}>{list.name} ({list.items.length}/{MAX_WATCHLIST_LIMIT})</option>)}
            </select>
          </label>
          <span className="text-[11px] text-slate-500">Up to {MAX_WATCHLIST_LIMIT} unique symbols per list</span>
          <button onClick={handleCreateWatchlist} disabled={isBulkScanning || Boolean(recalculatingSymbol)} className="flex items-center gap-1 rounded-lg border border-cyan-800 bg-cyan-950/50 px-2.5 py-1.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-900/60 disabled:opacity-40"><ListPlus className="h-4 w-4" />New</button>
          <button onClick={handleRenameWatchlist} disabled={!activeWatchlistId || isBulkScanning || Boolean(recalculatingSymbol)} className="flex items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-slate-800 disabled:opacity-40"><Pencil className="h-3.5 w-3.5" />Rename</button>
          <button onClick={handleDeleteWatchlist} disabled={watchlists.length <= 1 || isBulkScanning || Boolean(recalculatingSymbol)} className="flex items-center gap-1 rounded-lg border border-rose-900/70 px-2.5 py-1.5 text-xs text-rose-300 hover:bg-rose-950/60 disabled:opacity-40"><Trash2 className="h-3.5 w-3.5" />Delete</button>
        </div>

        {/* Action Controls & Filters Bar */}
        <div className="p-3 bg-slate-950/90 border-b border-slate-800 space-y-2.5 shrink-0">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-sm">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search symbol (e.g. RELIANCE, TCS)..."
                className="w-full pl-9 pr-4 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-white text-xs"
                >
                  ×
                </button>
              )}
            </div>

            {/* FEATURE 1: Horizon & Timeframe Controls + 1-Click Converter */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Horizon Selector (Intraday vs Swing 3-5D) */}
              <div className="inline-flex rounded-xl p-0.5 bg-slate-900 border border-slate-800 text-xs font-semibold">
                <button
                  onClick={() => setHorizonFilter('ALL')}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                    horizonFilter === 'ALL' ? 'bg-cyan-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setHorizonFilter('INTRADAY')}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                    horizonFilter === 'INTRADAY' ? 'bg-amber-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Intraday 5m/15m setups"
                >
                  <Zap className="w-3 h-3 text-amber-300" />
                  <span>⚡ Intraday</span>
                </button>
                <button
                  onClick={() => setHorizonFilter('SWING')}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                    horizonFilter === 'SWING' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Swing 3–5 Days setups"
                >
                  <Compass className="w-3 h-3 text-indigo-300" />
                  <span>🌊 Swing (3-5D)</span>
                </button>
              </div>

              {/* 1-Click Convert All Button */}
              {watchlist.length > 0 && (
                <div className="inline-flex rounded-xl p-0.5 bg-slate-900 border border-slate-800 text-[11px] font-semibold">
                  <button
                    onClick={() => handleConvertAllHorizon('Intraday (5m/15m)', '15m')}
                    disabled={isBulkScanning}
                    className="px-2 py-0.5 rounded-lg bg-amber-950/60 hover:bg-amber-900/80 text-amber-300 border border-amber-800/60 transition cursor-pointer flex items-center gap-1"
                    title="Recalculate all stocks in watchlist with 15m Intraday parameters"
                  >
                    <Zap className="w-3 h-3" />
                    <span>Recalc All Intra (15m)</span>
                  </button>
                  <button
                    onClick={() => handleConvertAllHorizon('Swing (3–4 Days)', '1d')}
                    disabled={isBulkScanning}
                    className="px-2 py-0.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border border-indigo-800/60 transition cursor-pointer flex items-center gap-1"
                    title="Recalculate all stocks in watchlist with Daily Swing parameters"
                  >
                    <Compass className="w-3 h-3" />
                    <span>Recalc All Swing (1D)</span>
                  </button>
                </div>
              )}

              {/* Timeframe Filter Dropdown */}
              <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 text-xs">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span className="text-[10px] text-slate-400">TF:</span>
                <select
                  value={timeframeFilter}
                  onChange={(e) => {
                    const next = e.target.value as 'ALL' | TimeframeOption;
                    setTimeframeFilter(next);
                    if (next !== 'ALL') {
                      setHorizonFilter('ALL');
                      setFilterVerdict('ALL');
                      handleConvertAllHorizon(next === '5m' || next === '15m' ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)', next);
                    }
                  }}
                  disabled={isBulkScanning}
                  className="bg-transparent text-cyan-300 text-xs font-mono font-bold focus:outline-none cursor-pointer"
                >
                  <option value="ALL" className="bg-slate-900 text-white">All TFs</option>
                  <option value="5m" className="bg-slate-900 text-white">5m (Intraday)</option>
                  <option value="15m" className="bg-slate-900 text-white">15m (Intraday)</option>
                  <option value="1h" className="bg-slate-900 text-white">1h (Swing)</option>
                  <option value="1d" className="bg-slate-900 text-white">1d (Swing 3-5D)</option>
                </select>
              </div>

              <form onSubmit={handleAddTickerToWatchlist} className="flex min-w-[190px] items-center gap-1 rounded-xl border border-slate-800 bg-slate-900 p-1">
                <input value={tickerToAdd} onChange={e => setTickerToAdd(e.target.value.toUpperCase())} placeholder="Add ticker (e.g. INFY)" aria-label="Ticker to add to watchlist" className="min-w-0 flex-1 bg-transparent px-2 py-1 text-xs text-white outline-none placeholder:text-slate-500" />
                <button type="submit" disabled={isAddingTicker || isBulkScanning || !tickerToAdd.trim()} className="rounded-lg bg-cyan-700 px-2 py-1 text-xs font-semibold text-white disabled:opacity-50">{isAddingTicker ? '…' : 'Add'}</button>
              </form>

              {/* Quick Add Active Stock Button */}
              <button
                onClick={() => handleAddCurrentStock(horizonFilter === 'INTRADAY' ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)', horizonFilter === 'INTRADAY' ? '15m' : '1d')}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1 border border-slate-700 transition cursor-pointer"
                title={`Add ${currentPreset.symbol || currentPreset.title} to Watchlist`}
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Add</span> <span>{currentPreset.symbol || currentPreset.title}</span>
              </button>

              {/* View Mode Toggle */}
              <div className="inline-flex rounded-lg p-0.5 bg-slate-900 border border-slate-800 text-xs">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-1 rounded-md transition cursor-pointer ${
                    viewMode === 'table' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Table View"
                >
                  <TableIcon className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewMode('cards')}
                  className={`p-1 rounded-md transition cursor-pointer ${
                    viewMode === 'cards' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                  title="Cards View"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Clear All */}
              {watchlist.length > 0 && (
                <button
                  onClick={handleClearAll}
                  className="p-1.5 rounded-lg bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-800 transition cursor-pointer text-xs"
                  title="Clear all watchlist items"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* FEATURE 2: 3-Engine Perspective Selector alongside Final Verdict */}
          <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-slate-850">
            {/* Engine Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
              <span className="text-[11px] font-semibold text-slate-400 shrink-0 flex items-center gap-1">
                <Layers className="w-3 h-3 text-indigo-400" />
                Engine View:
              </span>
              {[
                { id: 'ALL_ENGINES', label: '🎯 Composite (Final Verdict)' },
                { id: 'TIMESFM', label: '🤖 local statistical baseline Model' },
                { id: 'QUANT', label: '📊 Quant Engine (CPR/Vol)' },
                { id: 'SMC_ICT', label: '🏛️ SMC / ICT / FVG' }
              ].map((eng) => (
                <button
                  key={eng.id}
                  onClick={() => setActiveEngineView(eng.id as EnginePerspective)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                    activeEngineView === eng.id
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
                  }`}
                >
                  {eng.label}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1 bg-slate-900 px-2 py-1 rounded-xl border border-slate-800 text-xs">
              <ArrowUpDown className="w-3 h-3 text-slate-400" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="bg-transparent text-slate-300 text-xs focus:outline-none cursor-pointer"
              >
                <option value="confluence" className="bg-slate-900 text-white">Confluence % (High)</option>
                <option value="grade" className="bg-slate-900 text-white">Setup Grade (A+ to Avoid)</option>
                <option value="entryDist" className="bg-slate-900 text-white">Closest to Entry Zone</option>
                <option value="change" className="bg-slate-900 text-white">Day % Change</option>
                <option value="cmp" className="bg-slate-900 text-white">Price (High to Low)</option>
                <option value="symbol" className="bg-slate-900 text-white">Symbol (A–Z)</option>
              </select>
            </div>
          </div>

          {/* Quick Selection Verdict Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pt-0.5">
            <span className="text-[11px] font-semibold text-slate-400 shrink-0 flex items-center gap-1">
              <Filter className="w-3 h-3 text-cyan-400" />
              Filter Verdict:
            </span>
            {[
              { id: 'ALL', label: `All (${watchlist.length})` },
              { id: 'GRADE_A_PLUS', label: '🌟 Grade A+ Only' },
              { id: 'IN_ENTRY_ZONE', label: '🎯 In Entry Zone' },
              { id: 'BUY', label: '🟢 BUY Verdict' },
              { id: 'SELL', label: '🔴 SELL Verdict' },
              { id: 'ALERTS', label: `🔔 Alerts (${activeAlertCount})` },
              { id: 'CONFLICT', label: '⚠️ Conflicts / Avoid' }
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilterVerdict(f.id as any)}
                className={`px-2 py-0.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  filterVerdict === f.id
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Toast Alert Banner */}
        {toastMessage && (
          <div className="px-4 py-2 bg-cyan-950/90 border-b border-cyan-800 text-cyan-200 text-xs font-medium flex items-center justify-between animate-in fade-in">
            <span>{toastMessage}</span>
            <button onClick={() => setToastMessage(null)} className="text-cyan-400 hover:text-white">×</button>
          </div>
        )}

        {/* Content Body: Table or Cards View */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3">
          {watchlist.length === 0 ? (
            <div className="py-16 text-center text-slate-500 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-800/80 border border-slate-700 mx-auto flex items-center justify-center text-slate-400">
                <ListFilter className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-300">Your Screener Watchlist is Empty</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                  Add stocks to calculate local statistical baseline, Quant Engine (CPR/Vol), and SMC/ICT/FVG analyses in parallel for both Intraday and Swing horizons.
                </p>
              </div>
              <div className="flex items-center justify-center gap-2 pt-2 flex-wrap">
                <button
                  onClick={() => handleAddCurrentStock('Intraday (5m/15m)', '15m')}
                  className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5" />
                  + Add Current as Intraday
                </button>
                <button
                  onClick={() => handleAddCurrentStock('Swing (3–4 Days)', '1d')}
                  className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <Compass className="w-3.5 h-3.5" />
                  + Add Current as Swing (3–5D)
                </button>
                <button
                  onClick={() => handleImportPreset(SECTOR_PRESETS[0])}
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                >
                  <BookmarkPlus className="w-3.5 h-3.5" />
                  Import NIFTY 50 Leaders
                </button>
              </div>
            </div>
          ) : filteredAndSortedList.length === 0 ? (
            <div className="py-12 text-center text-slate-500">
              <p className="text-sm">No stocks match your current filter.</p>
              <button
                onClick={() => { setFilterVerdict('ALL'); setHorizonFilter('ALL'); setTimeframeFilter('ALL'); }}
                className="mt-2 text-xs text-cyan-400 underline cursor-pointer"
              >
                Reset all filters
              </button>
            </div>
          ) : viewMode === 'table' ? (
            /* INSTITUTIONAL MULTI-ENGINE TABLE */
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse font-sans">
                  <thead>
                    <tr className="bg-slate-900 text-slate-400 text-[10px] font-mono uppercase tracking-wider border-b border-slate-800 sticky top-0">
                      <th className="py-2.5 px-3">Stock / TF</th>
                      <th className="py-2.5 px-2 text-right">Live CMP</th>
                      <th className="py-2.5 px-2 text-right">Day %</th>

                      {/* Dynamic Columns Based on Engine Perspective */}
                      {activeEngineView === 'ALL_ENGINES' && (
                        <>
                          <th className="py-2.5 px-2 text-center">Final Verdict</th>
                          <th className="py-2.5 px-2 text-center">Grade</th>
                          <th className="py-2.5 px-2 text-center">Confluence</th>
                          <th className="py-2.5 px-2 text-left">Ideal Entry Zone</th>
                          <th className="py-2.5 px-2 text-right">Target 1</th>
                          <th className="py-2.5 px-2 text-right">Stop Loss</th>
                          <th className="py-2.5 px-2 text-center">R:R</th>
                          <th className="py-2.5 px-2 text-center">Engine Status</th>
                        </>
                      )}

                      {activeEngineView === 'TIMESFM' && (
                        <>
                          <th className="py-2.5 px-2 text-center">RevIN Trend</th>
                          <th className="py-2.5 px-2 text-right">Expected Move</th>
                          <th className="py-2.5 px-2 text-center">Velocity</th>
                          <th className="py-2.5 px-2 text-right">p10 Support</th>
                          <th className="py-2.5 px-2 text-right">p50 Median</th>
                          <th className="py-2.5 px-2 text-right">p90 Ceiling</th>
                          <th className="py-2.5 px-2 text-center">Confidence</th>
                          <th className="py-2.5 px-2 text-left">Local Forecast Outlook</th>
                        </>
                      )}

                      {activeEngineView === 'QUANT' && (
                        <>
                          <th className="py-2.5 px-2 text-center">Quant Score</th>
                          <th className="py-2.5 px-2 text-center">CPR Position</th>
                          <th className="py-2.5 px-2 text-right">Central Pivot</th>
                          <th className="py-2.5 px-2 text-right">RSI(14)</th>
                          <th className="py-2.5 px-2 text-right">Z-Score</th>
                          <th className="py-2.5 px-2 text-right">Volume POC</th>
                          <th className="py-2.5 px-2 text-center">R:R Ratio</th>
                          <th className="py-2.5 px-2 text-left">Quant Summary</th>
                        </>
                      )}

                      {activeEngineView === 'SMC_ICT' && (
                        <>
                          <th className="py-2.5 px-2 text-center">Structure</th>
                          <th className="py-2.5 px-2 text-center">Pricing Zone</th>
                          <th className="py-2.5 px-2 text-left">FVG Range</th>
                          <th className="py-2.5 px-2 text-center">FVG Status</th>
                          <th className="py-2.5 px-2 text-right">Bullish OB</th>
                          <th className="py-2.5 px-2 text-right">Bearish OB</th>
                          <th className="py-2.5 px-2 text-center">CHoCH</th>
                          <th className="py-2.5 px-2 text-left">SMC Summary</th>
                        </>
                      )}

                      <th className="py-2.5 px-2 text-left">Flow / Trap</th>
                      <th className="py-2.5 px-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                    {filteredAndSortedList.map((item) => {
                      const isBullish = item.finalVerdict?.includes('BUY') || item.direction === 'LONG';
                      const isBearish = item.finalVerdict?.includes('SELL') || item.direction === 'SHORT';
                      const isConflict = item.finalVerdict?.includes('CONFLICT') || item.status === 'AVOID';
                      const change = item.changePct ?? 0;
                      const isRecalculating = recalculatingSymbol === item.symbol;
                      const tf = item.timeframe || (item.horizon === 'Intraday (5m/15m)' ? '15m' : '1d');

                      return (
                        <tr
                          key={item.id}
                          onClick={() => handleSelectStock(item)}
                          className="hover:bg-slate-850/70 cursor-pointer transition-colors group"
                        >
                          {/* Symbol, Name & Interactive Timeframe Selector */}
                          <td className="py-2.5 px-3">
                            <div className="flex items-center gap-1.5 font-sans">
                              <span className="font-bold text-white group-hover:text-cyan-300 transition">
                                {item.symbol}
                              </span>
                              
                              {/* FEATURE 1: Interactive Timeframe Switcher */}
                              <div onClick={(e) => e.stopPropagation()} className="inline-flex">
                                <select
                                  value={tf}
                                  onChange={(e) => handleTimeframeChange(item, e.target.value as TimeframeOption, e as any)}
                                  disabled={isRecalculating}
                                  className="text-[9px] font-mono px-1 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700 hover:border-cyan-500 cursor-pointer focus:outline-none"
                                  title="Change timeframe to re-run mathematical analysis"
                                >
                                  <option value="5m">5m (Intra)</option>
                                  <option value="15m">15m (Intra)</option>
                                  <option value="1h">1h (Swing)</option>
                                  <option value="1d">1d (Swing 3-5D)</option>
                                </select>
                              </div>

                              {isRecalculating && (
                                <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin" />
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 block truncate max-w-[120px] font-sans">
                              {item.name}
                            </span>
                          </td>

                          {/* Live CMP */}
                          <td className="py-2.5 px-2 text-right text-white font-bold text-xs">
                            {currencySymbol}{item.cmp.toLocaleString()}
                          </td>

                          {/* Day % Change */}
                          <td className={`py-2.5 px-2 text-right font-bold ${
                            change > 0 ? 'text-emerald-400' : change < 0 ? 'text-rose-400' : 'text-slate-400'
                          }`}>
                            {change > 0 ? '+' : ''}{change}%
                          </td>

                          {/* ALL ENGINES / FINAL VERDICT PERSPECTIVE */}
                          {activeEngineView === 'ALL_ENGINES' && (
                            <>
                              <td className="py-2.5 px-2 text-center font-sans">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold inline-block ${
                                  isBullish 
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                                    : isBearish 
                                    ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                                    : isConflict 
                                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                    : 'bg-slate-800 text-slate-300 border border-slate-700'
                                }`}>
                                  {item.finalVerdict || (isBullish ? 'BUY / ACCUMULATE' : 'SELL / SHORT')}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-center">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.setupGrade === 'GRADE_A_PLUS'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                                    : item.setupGrade === 'GRADE_A'
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                                    : item.setupGrade === 'GRADE_B'
                                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                                }`}>
                                  {item.setupGrade ? item.setupGrade.replace(/_/g, ' ') : 'GRADE A'}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-center font-bold text-cyan-300">
                                {item.confluenceScorePct || item.scorePct}%
                              </td>

                              <td className="py-2.5 px-2 text-left font-sans">
                                <span className="font-mono text-slate-200">
                                  {currencySymbol}{item.entryRange.min} – {currencySymbol}{item.entryRange.max}
                                </span>
                                {item.isInEntryZone && (
                                  <span className="ml-1 px-1 py-0.2 rounded text-[8px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                                    IN ZONE
                                  </span>
                                )}
                              </td>

                              <td className="py-2.5 px-2 text-right text-emerald-400 font-bold">
                                {currencySymbol}{item.target1.price}
                              </td>

                              <td className="py-2.5 px-2 text-right text-rose-400">
                                {currencySymbol}{item.stopLoss.price}
                              </td>

                              <td className="py-2.5 px-2 text-center text-slate-300">
                                {item.riskRewardText || '1:2.0'}
                              </td>

                              <td className="py-2.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                                <button
                                  onClick={() => setInspectingItem(item)}
                                  className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 flex items-center gap-1 mx-auto cursor-pointer"
                                  title="View side-by-side mathematical breakdown of all 3 engines"
                                >
                                  <Cpu className="w-3 h-3 text-cyan-400" />
                                  <span>3 Engines</span>
                                </button>
                              </td>
                            </>
                          )}

                          {/* TIMESFM 3.0 PERSPECTIVE */}
                          {activeEngineView === 'TIMESFM' && (
                            <>
                              <td className="py-2.5 px-2 text-center">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.timesfmResult?.trend === 'BULLISH'
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                    : item.timesfmResult?.trend === 'BEARISH'
                                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                    : 'bg-slate-800 text-slate-300'
                                }`}>
                                  {item.timesfmResult?.trend || (isBullish ? 'BULLISH' : 'SIDEWAYS')}
                                </span>
                              </td>

                              <td className={`py-2.5 px-2 text-right font-bold ${
                                (item.timesfmResult?.expectedMovePct || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
                              }`}>
                                {(item.timesfmResult?.expectedMovePct || 0) >= 0 ? '+' : ''}{item.timesfmResult?.expectedMovePct || 0}%
                              </td>

                              <td className="py-2.5 px-2 text-center text-slate-300 text-[10px]">
                                {item.timesfmResult?.velocity || 'STEADY'}
                              </td>

                              <td className="py-2.5 px-2 text-right text-rose-300">
                                {currencySymbol}{item.timesfmResult?.p10Support || item.stopLoss.price}
                              </td>

                              <td className="py-2.5 px-2 text-right text-cyan-300 font-bold">
                                {currencySymbol}{item.timesfmResult?.p50Median || item.target1.price}
                              </td>

                              <td className="py-2.5 px-2 text-right text-emerald-300">
                                {currencySymbol}{item.timesfmResult?.p90Resistance || item.target2.price}
                              </td>

                              <td className="py-2.5 px-2 text-center text-cyan-400 font-bold">
                                {item.timesfmResult?.confidencePct !== undefined ? `${item.timesfmResult.confidencePct}%` : 'N/A'}
                              </td>

                              <td className="py-2.5 px-2 text-left text-[10px] text-slate-400 max-w-[180px] truncate">
                                {item.timesfmResult?.signalSummary || 'Local return-drift estimate; interval uncalibrated'}
                              </td>
                            </>
                          )}

                          {/* QUANT ENGINE PERSPECTIVE */}
                          {activeEngineView === 'QUANT' && (
                            <>
                              <td className="py-2.5 px-2 text-center font-bold text-cyan-300">
                                {item.quantEngineResult?.scorePct || item.scorePct}%
                              </td>

                              <td className="py-2.5 px-2 text-center">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.quantEngineResult?.cprRelation === 'ABOVE_CPR'
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                    : item.quantEngineResult?.cprRelation === 'BELOW_CPR'
                                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                                }`}>
                                  {item.quantEngineResult?.cprRelation?.replace(/_/g, ' ') || 'ABOVE CPR'}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-right text-slate-300">
                                {currencySymbol}{item.quantEngineResult?.cprPivot || Math.round(item.cmp * 0.995)}
                              </td>

                              <td className="py-2.5 px-2 text-right font-bold text-cyan-300">
                                {item.quantEngineResult?.rsi14 ?? 'N/A'}
                              </td>

                              <td className="py-2.5 px-2 text-right text-slate-300">
                                {item.quantEngineResult?.zScore || 0.42}
                              </td>

                              <td className="py-2.5 px-2 text-right text-amber-300 font-bold">
                                {currencySymbol}{item.quantEngineResult?.volumeProfilePoc || item.entryRange.min}
                              </td>

                              <td className="py-2.5 px-2 text-center text-slate-300">
                                {item.quantEngineResult?.riskRewardText || item.riskRewardText}
                              </td>

                              <td className="py-2.5 px-2 text-left text-[10px] text-slate-400 max-w-[180px] truncate">
                                {item.quantEngineResult?.signalSummary || 'Quant metrics calculated'}
                              </td>
                            </>
                          )}

                          {/* SMC / ICT / FVG PERSPECTIVE */}
                          {activeEngineView === 'SMC_ICT' && (
                            <>
                              <td className="py-2.5 px-2 text-center">
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                                  {item.smcIctResult?.marketStructure || 'BOS'}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-center">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  item.smcIctResult?.pricingZone === 'DISCOUNT'
                                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                    : item.smcIctResult?.pricingZone === 'PREMIUM'
                                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                    : 'bg-slate-800 text-slate-300'
                                }`}>
                                  {item.smcIctResult?.pricingZone || 'DISCOUNT'}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-left text-slate-200">
                                {item.smcIctResult?.fvgZone
                                  ? `${currencySymbol}${item.smcIctResult.fvgZone[0]} - ${currencySymbol}${item.smcIctResult.fvgZone[1]}`
                                  : `${currencySymbol}${item.entryRange.min} - ${currencySymbol}${item.entryRange.max}`}
                              </td>

                              <td className="py-2.5 px-2 text-center">
                                <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-amber-950/80 text-amber-300 border border-amber-800/60">
                                  {item.smcIctResult?.fvgStatus || 'UNMITIGATED'}
                                </span>
                              </td>

                              <td className="py-2.5 px-2 text-right text-emerald-400">
                                {currencySymbol}{item.smcIctResult?.bullishOrderBlock || item.entryRange.min}
                              </td>

                              <td className="py-2.5 px-2 text-right text-rose-400">
                                {currencySymbol}{item.smcIctResult?.bearishOrderBlock || item.target1.price}
                              </td>

                              <td className="py-2.5 px-2 text-center text-slate-300">
                                {item.smcIctResult?.chochActive ? '✅ Yes' : '⏳ Pending'}
                              </td>

                              <td className="py-2.5 px-2 text-left text-[10px] text-slate-400 max-w-[180px] truncate">
                                {item.smcIctResult?.signalSummary || 'SMC structure evaluated'}
                              </td>
                            </>
                          )}

                          <td className="max-w-56 px-2 py-2 text-[9px] text-slate-400" onClick={e => e.stopPropagation()}>
                            <div className={`max-w-56 truncate ${item.marketFlow?.syntheticBuildup?.category === 'LONG_BUILDUP' ? 'text-emerald-300' : item.marketFlow?.syntheticBuildup?.category === 'SHORT_BUILDUP' ? 'text-rose-300' : item.marketFlow?.syntheticBuildup?.category === 'LONG_UNWINDING' ? 'text-orange-300' : item.marketFlow?.syntheticBuildup?.category === 'SHORT_COVERING' ? 'text-lime-200' : 'text-cyan-300'}`} title={item.marketFlow?.syntheticBuildup?.detail || 'Synthetic buildup unavailable'}>{item.marketFlow?.syntheticBuildup?.category?.replaceAll('_', ' ') || 'Buildup unavailable'}{item.marketFlow?.syntheticBuildup?.available ? ` · ${item.marketFlow.syntheticBuildup.metric.toFixed(2)}` : ''}</div>
                            <div className={item.marketFlow?.trapRisk?.kind && item.marketFlow.trapRisk.kind !== 'NONE' ? 'max-w-56 truncate text-amber-300' : 'max-w-56 truncate'} title={item.marketFlow?.trapRisk?.detail || 'Trap check unavailable'}>{item.marketFlow?.trapRisk?.kind === 'NONE' ? 'No trap signal' : item.marketFlow?.trapRisk?.label || 'Trap check unavailable'}</div>
                          </td>

                          {/* Row Actions */}
                          <td className="py-2.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={(e) => handleFetchLiveOiForItem(item, e)}
                                disabled={Boolean(recalculatingSymbol)}
                                className="px-1.5 py-1 rounded-lg bg-cyan-950 text-cyan-300 border border-cyan-800 hover:border-cyan-500 disabled:opacity-50 text-[9px] font-bold transition cursor-pointer"
                                title="Fetch verified Angel One option-chain OI and update verdict"
                              >
                                OI
                              </button>
                              <button
                                onClick={() => handleSelectStock(item)}
                                className="px-2 py-1 rounded-lg bg-cyan-600/80 hover:bg-cyan-600 text-white font-bold text-[10px] transition cursor-pointer"
                                title="Load stock onto Chart & Forecast"
                              >
                                Select
                              </button>
                              <button
                                onClick={(e) => handleRemoveStock(item.symbol, e)}
                                className="p-1 rounded-lg hover:bg-rose-950 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                                title="Remove from Watchlist"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* MULTI-ENGINE QUANT CARDS VIEW */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {filteredAndSortedList.map((item) => {
                const isBullish = item.finalVerdict?.includes('BUY') || item.direction === 'LONG';
                const isBearish = item.finalVerdict?.includes('SELL') || item.direction === 'SHORT';
                const tf = item.timeframe || (item.horizon === 'Intraday (5m/15m)' ? '15m' : '1d');
                const isRecalculating = recalculatingSymbol === item.symbol;

                return (
                  <div
                    key={item.id}
                    onClick={() => handleSelectStock(item)}
                    className="p-3.5 bg-slate-950 border border-slate-800 hover:border-cyan-500/50 rounded-xl space-y-3 cursor-pointer transition shadow-md hover:shadow-cyan-500/10 group flex flex-col justify-between"
                  >
                    {/* Top Row: Symbol, Timeframe & CMP */}
                    <div>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-bold text-white text-sm group-hover:text-cyan-300 transition">
                              {item.symbol}
                            </h4>
                            
                            {/* Interactive Timeframe Pill */}
                            <div onClick={(e) => e.stopPropagation()}>
                              <select
                                value={tf}
                                onChange={(e) => handleTimeframeChange(item, e.target.value as TimeframeOption, e as any)}
                                disabled={isRecalculating}
                                className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-700 hover:border-cyan-500 cursor-pointer"
                              >
                                <option value="5m">5m (Intra)</option>
                                <option value="15m">15m (Intra)</option>
                                <option value="1h">1h (Swing)</option>
                                <option value="1d">1d (Swing 3-5D)</option>
                              </select>
                              <button
                                type="button"
                                onClick={(e) => handleFetchLiveOiForItem(item, e)}
                                disabled={Boolean(recalculatingSymbol)}
                                className="ml-1 px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 hover:border-cyan-500 disabled:opacity-50 text-[9px] font-bold cursor-pointer"
                                title="Fetch verified Angel One option-chain OI and refresh this symbol's verdict"
                              >
                                {recalculatingSymbol === item.symbol ? '…' : 'Fetch live OI'}
                              </button>
                            </div>

                            {isRecalculating && <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin" />}
                          </div>
                          <span className="text-[11px] text-slate-400 block truncate max-w-[180px]">
                            {item.name}
                          </span>
                        </div>

                        <div className="text-right font-mono">
                          <div className="text-base font-black text-white">
                            {currencySymbol}{item.cmp.toLocaleString()}
                          </div>
                          <span className={`text-[10px] font-bold ${
                            (item.changePct ?? 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {(item.changePct ?? 0) >= 0 ? '+' : ''}{item.changePct}%
                          </span>
                        </div>
                      </div>

                      <div className="mt-1 space-y-0.5 text-[9px] text-slate-400">
                        <div>{item.volumeSpike?.detail || 'Volume comparison unavailable'}</div>
                        {item.marketFlow?.optionChainOi?.available && <div className="text-cyan-300">Option-chain OI: {item.marketFlow.optionChainOi.label} ({item.marketFlow.optionChainOi.scorePct > 0 ? '+' : ''}{item.marketFlow.optionChainOi.scorePct}%)</div>}
                        {item.marketFlow?.futuresOi?.available && <div className="text-indigo-300">Symbol futures OI: {item.marketFlow.futuresOi.label}</div>}
                        {item.marketFlow?.syntheticBuildup && <div className="text-cyan-300">Synthetic buildup ({item.marketFlow.syntheticBuildup.timeframe}; 15% verdict weight): {item.marketFlow.syntheticBuildup.detail}</div>}
                        {item.verdictWeights && <div className="text-slate-400">Verdict weighting ({item.timeframe || '15m'}): PA {item.verdictWeights.priceAction}% · Vol {item.verdictWeights.volume}% · Matrix {item.verdictWeights.syntheticMatrix}% · Live OI {item.verdictWeights.liveOi}% · Bullish support {item.verdictDirectionalScorePct ?? 50}/100</div>}
                        {item.marketFlow?.trapRisk?.available && <div className={item.marketFlow.trapRisk.kind === 'NONE' ? '' : 'text-amber-300'}>{item.marketFlow.trapRisk.detail}</div>}
                        {!item.marketFlow?.optionChainOi?.available && !item.marketFlow?.futuresOi?.available && <div>Live OI: unavailable / waiting for a second snapshot</div>}
                      </div>

                      {/* Final Verdict Banner */}
                      <div className="flex items-center justify-between gap-1 flex-wrap pt-2 mt-2 border-t border-slate-850">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isBullish 
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                            : isBearish 
                            ? 'bg-rose-950 text-rose-300 border border-rose-800' 
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {item.finalVerdict || (isBullish ? 'BUY / ACCUMULATE' : 'SELL / SHORT')}
                        </span>

                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                          item.setupGrade === 'GRADE_A_PLUS'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50'
                            : item.setupGrade === 'GRADE_A'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {item.gradeBadge || 'Grade A'} ({item.confluenceScorePct || item.scorePct}%)
                        </span>
                      </div>

                      {/* FEATURE 2: 3 Mathematical Engine Results Matrix */}
                      <div className="mt-2.5 p-2 rounded-lg bg-slate-900/90 border border-slate-800 space-y-1.5 text-[10px] font-mono">
                        {/* 1. local statistical baseline Engine */}
                        <div className="flex items-center justify-between border-b border-slate-800/60 pb-1">
                          <span className="text-purple-300 font-bold flex items-center gap-1 font-sans">
                            🤖 Local baseline:
                          </span>
                          <span className="text-slate-200">
                            {item.timesfmResult?.trend || 'BULLISH'} ({(item.timesfmResult?.expectedMovePct || 0) >= 0 ? '+' : ''}{item.timesfmResult?.expectedMovePct || 1.8}%) → <strong className="text-cyan-300">{currencySymbol}{item.timesfmResult?.p50Median || item.target1.price}</strong>
                          </span>
                        </div>

                        {/* 2. Quant Engine (CPR/Vol) */}
                        <div className="flex items-center justify-between border-b border-slate-800/60 pb-1">
                          <span className="text-blue-300 font-bold flex items-center gap-1 font-sans">
                            📊 Quant:
                          </span>
                          <span className="text-slate-200">
                            Score {item.quantEngineResult?.scorePct || item.scorePct}% • {item.quantEngineResult?.cprRelation?.replace(/_/g, ' ') || 'Above CPR'} (POC {currencySymbol}{item.quantEngineResult?.volumeProfilePoc || item.entryRange.min})
                          </span>
                        </div>

                        {/* 3. SMC / ICT / FVG */}
                        <div className="flex items-center justify-between">
                          <span className="text-amber-300 font-bold flex items-center gap-1 font-sans">
                            🏛️ SMC/ICT:
                          </span>
                          <span className="text-slate-200">
                            {item.smcIctResult?.pricingZone || 'DISCOUNT'} • FVG {item.smcIctResult?.fvgStatus || 'UNMITIGATED'} • OB {currencySymbol}{item.smcIctResult?.bullishOrderBlock || item.entryRange.min}
                          </span>
                        </div>
                      </div>

                      {/* Levels Grid */}
                      <div className="grid grid-cols-3 gap-1.5 text-xs font-mono bg-slate-900/60 p-2 rounded-lg border border-slate-850 mt-2">
                        <div>
                          <span className="text-[9px] text-slate-400 block">Entry Zone</span>
                          <strong className="text-slate-200 text-[11px] truncate block">
                            {currencySymbol}{item.entryRange.min}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-emerald-400 block">Target 1</span>
                          <strong className="text-emerald-400 text-[11px] truncate block">
                            {currencySymbol}{item.target1.price}
                          </strong>
                        </div>
                        <div>
                          <span className="text-[9px] text-rose-400 block">Stop Loss</span>
                          <strong className="text-rose-400 text-[11px] truncate block">
                            {currencySymbol}{item.stopLoss.price}
                          </strong>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-850" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setInspectingItem(item)}
                        className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Info className="w-3 h-3" />
                        <span>Inspect Engines</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleSelectStock(item)}
                          className="px-2.5 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[10px] transition cursor-pointer"
                        >
                          Load Stock
                        </button>
                        <button
                          onClick={(e) => handleRemoveStock(item.symbol, e)}
                          className="p-1 rounded hover:bg-rose-950 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-4 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-300">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Local Forecast Baseline + Technical Analysis + SMC</span>
            </span>
            <span className="text-[11px] text-slate-500 hidden sm:inline">
              Select any timeframe (5m/15m/1h/1d) to trigger mathematical recalculation.
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>

      {/* DETAILED 3-ENGINE INSPECTION MODAL */}
      {inspectingItem && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 bg-slate-950/90 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <span>{inspectingItem.symbol} — Multi-Engine Analysis Breakdown</span>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                    {inspectingItem.timeframe || '15m'} • {inspectingItem.horizon}
                  </span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Real mathematical verification across 3 quantitative perspectives
                </p>
              </div>
              <button
                onClick={() => setInspectingItem(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. Local Statistical Baseline */}
            <div className="p-3.5 rounded-xl bg-purple-950/30 border border-purple-800/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  🤖 1. Local Statistical Baseline (not pretrained TimesFM)
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-900/60 text-purple-200">
                  {inspectingItem.timesfmResult?.confidencePct !== undefined ? `Confidence: ${inspectingItem.timesfmResult.confidencePct}%` : 'Confidence: not calibrated'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {inspectingItem.timesfmResult?.signalSummary || 'Local return-drift estimate; interval uncalibrated'}
              </p>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs pt-1">
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">p10 Support</span>
                  <strong className="text-rose-400">{currencySymbol}{inspectingItem.timesfmResult?.p10Support || inspectingItem.stopLoss.price}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">p50 Median Target</span>
                  <strong className="text-cyan-400">{currencySymbol}{inspectingItem.timesfmResult?.p50Median || inspectingItem.target1.price}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">p90 Ceiling</span>
                  <strong className="text-emerald-400">{currencySymbol}{inspectingItem.timesfmResult?.p90Resistance || inspectingItem.target2.price}</strong>
                </div>
              </div>
            </div>

            {/* 2. Quant Engine Breakdown */}
            <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-800/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                  📊 2. Quantitative Setup Engine (CPR & Volatility)
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-900/60 text-blue-200">
                  Score: {inspectingItem.quantEngineResult?.scorePct || inspectingItem.scorePct}%
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {inspectingItem.quantEngineResult?.signalSummary || 'Quant CPR position evaluated'}
              </p>
              <div className="grid grid-cols-4 gap-2 font-mono text-xs pt-1">
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-400 block">CPR Pivot</span>
                  <strong className="text-slate-200">{currencySymbol}{inspectingItem.quantEngineResult?.cprPivot || Math.round(inspectingItem.cmp * 0.995)}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-400 block">RSI(14)</span>
                  <strong className="text-cyan-300">{inspectingItem.quantEngineResult?.rsi14 ?? 'N/A'}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-400 block">Volume POC</span>
                  <strong className="text-amber-300">{currencySymbol}{inspectingItem.quantEngineResult?.volumeProfilePoc || inspectingItem.entryRange.min}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[9px] text-slate-400 block">Risk:Reward</span>
                  <strong className="text-emerald-400">{inspectingItem.quantEngineResult?.riskRewardText || inspectingItem.riskRewardText}</strong>
                </div>
              </div>
            </div>

            {/* 3. SMC / ICT / FVG Breakdown */}
            <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/40 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  🏛️ 3. SMC / ICT / Fair Value Gap (FVG) Engine
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-900/60 text-amber-200">
                  Zone: {inspectingItem.smcIctResult?.pricingZone || 'DISCOUNT'}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {inspectingItem.smcIctResult?.signalSummary || 'SMC order block & FVG mitigation evaluated'}
              </p>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs pt-1">
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">FVG Mitigation</span>
                  <strong className="text-amber-300">{inspectingItem.smcIctResult?.fvgStatus || 'UNMITIGATED'}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Bullish Order Block</span>
                  <strong className="text-emerald-400">{currencySymbol}{inspectingItem.smcIctResult?.bullishOrderBlock || inspectingItem.entryRange.min}</strong>
                </div>
                <div className="p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Market Structure</span>
                  <strong className="text-cyan-300">{inspectingItem.smcIctResult?.marketStructure || 'BOS'}</strong>
                </div>
              </div>
            </div>

            {/* Final Verdict Summary */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between flex-wrap gap-2">
              <div>
                <span className="text-[10px] text-slate-400 block">Composite Verdict:</span>
                <strong className="text-sm font-bold text-white">{inspectingItem.finalVerdict} ({inspectingItem.confluenceScorePct}% Confluence)</strong>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleSelectStock(inspectingItem);
                    setInspectingItem(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
                >
                  Load on Chart
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
