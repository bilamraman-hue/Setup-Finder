import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Mic, Radio, Sparkles, Check, Play, Square } from 'lucide-react';

interface VoiceCopilotProps {
  symbol: string;
  name: string;
  cmp: number;
  direction?: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  grade?: string;
  confluenceScore?: number;
  entryZoneMin?: number;
  entryZoneMax?: number;
  target1?: number;
  stopLoss?: number;
  currencySymbol?: string;
  riskReward?: string;
  compact?: boolean;
}

export const VoiceCopilotButton: React.FC<VoiceCopilotProps> = ({
  symbol,
  name,
  cmp,
  direction = 'NEUTRAL',
  grade = 'Not rated',
  confluenceScore,
  entryZoneMin,
  entryZoneMax,
  target1,
  stopLoss,
  currencySymbol = '₹',
  riskReward,
  compact = false
}) => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [language, setLanguage] = useState<'hi' | 'en'>('hi');
  const [isVoiceAlertEnabled, setIsVoiceAlertEnabled] = useState(false);
  const [hasAnnouncedEntry, setHasAnnouncedEntry] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
      const loadVoices = () => {
        synthRef.current?.getVoices();
      };
      loadVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = loadVoices;
      }
    }
  }, []);

  // Background audio alert when price enters accumulation zone
  useEffect(() => {
    if (!isVoiceAlertEnabled || hasAnnouncedEntry || !entryZoneMin || !entryZoneMax) return;

    if (cmp >= entryZoneMin && cmp <= entryZoneMax) {
      setHasAnnouncedEntry(true);
      speakText(
        language === 'hi'
          ? `Dhyan dijiye! ${symbol} apne Ideal Entry Zone me enter ho chuka hai. Live price ${currencySymbol}${cmp} hai.`
          : `Attention! ${symbol} has just entered the optimal entry zone at ${currencySymbol}${cmp}. Check chart for execution!`
      );
    }
  }, [cmp, isVoiceAlertEnabled, entryZoneMin, entryZoneMax, hasAnnouncedEntry, language, symbol, currencySymbol]);

  const speakText = (text: string) => {
    if (!synthRef.current) return;

    // Cancel ongoing speech
    synthRef.current.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.98; // natural cadence
    utterance.pitch = 1.05;

    // Pick best voice
    const voices = synthRef.current.getVoices();
    if (language === 'hi') {
      const hiVoice = voices.find(v => v.lang.startsWith('hi') || v.name.toLowerCase().includes('india') || v.name.toLowerCase().includes('hindi'));
      if (hiVoice) utterance.voice = hiVoice;
    } else {
      const enVoice = voices.find(v => v.lang === 'en-IN' || (v.lang.startsWith('en') && v.name.toLowerCase().includes('natural')));
      if (enVoice) utterance.voice = enVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthRef.current.speak(utterance);
  };

  const handleToggleSpeak = () => {
    if (isSpeaking) {
      synthRef.current?.cancel();
      setIsSpeaking(false);
      return;
    }

    const cleanSymbol = symbol.replace(/\.NS$|\.BO$/i, '');
    const entryMin = entryZoneMin == null ? undefined : Math.round(entryZoneMin);
    const entryMax = entryZoneMax == null ? undefined : Math.round(entryZoneMax);
    const t1 = target1 == null ? undefined : Math.round(target1);
    const sl = stopLoss == null ? undefined : Math.round(stopLoss);
    const entryText = entryMin == null || entryMax == null ? 'not available' : `${entryMin} to ${entryMax}`;
    const riskText = sl == null ? 'not available' : String(sl);
    const targetText = t1 == null ? 'not available' : String(t1);

    let script = '';
    if (language === 'hi') {
      if (direction === 'BULLISH') {
        script = `${cleanSymbol} ka observed market price ${Math.round(cmp)} rupaye hai. Local analysis direction Bullish hai; yeh calibrated probability nahi hai. Setup grade ${grade}. Entry zone ${entryText}, stop loss ${riskText}, aur target 1 ${targetText} hai. Risk reward ${riskReward ?? 'not available'} hai.`;
      } else if (direction === 'BEARISH') {
        script = `${cleanSymbol} ka observed market price ${Math.round(cmp)} rupaye hai. Local analysis direction Bearish hai; yeh guarantee nahi hai. Short entry zone ${entryText}, stop loss ${riskText}, aur target 1 ${targetText} hai.`;
      } else {
        script = `${cleanSymbol} ke inputs se clear direction nahi mil rahi. Forecast aur analysis uncalibrated hain; trade decision se pehle data aur risk ko verify karein.`;
      }
    } else {
      if (direction === 'BULLISH') {
        script = `${cleanSymbol} observed price is ${Math.round(cmp)} ${currencySymbol}. The local analysis direction is Bullish; its score is not a calibrated probability. Grade: ${grade}. Entry zone: ${entryText}; stop: ${riskText}; target: ${targetText}; risk-reward: ${riskReward ?? 'not available'}.`;
      } else if (direction === 'BEARISH') {
        script = `${cleanSymbol} observed price is ${Math.round(cmp)} ${currencySymbol}. The local analysis direction is Bearish, rated ${grade}. Short entry zone: ${entryText}; stop: ${riskText}; target: ${targetText}. This is an estimate, not a guarantee.`;
      } else {
        script = `The available inputs do not show a clear direction for ${cleanSymbol}. Forecasts are uncalibrated estimates; verify the data and risk before making a trade decision.`;
      }
    }

    speakText(script);
  };

  return (
    <div className="inline-flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-700/80 shadow-md">
      {/* Play/Stop Audio Button */}
      <button
        type="button"
        onClick={handleToggleSpeak}
        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
          isSpeaking
            ? 'bg-rose-600 text-white animate-pulse shadow-md shadow-rose-600/30'
            : 'bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-sm'
        }`}
        title="Listen to 15-second Prop Desk Audio Briefing"
      >
        {isSpeaking ? (
          <>
            <Square className="w-3.5 h-3.5 fill-white" />
            <span>Stop Audio</span>
          </>
        ) : (
          <>
            <Volume2 className="w-3.5 h-3.5" />
            <span>{compact ? 'Copilot' : '🎙️ Listen Nichod'}</span>
          </>
        )}
      </button>

      {/* Language Toggle (Hindi / English) */}
      <button
        type="button"
        onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
        className="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 transition cursor-pointer"
        title="Switch Audio Language (Hindi / English)"
      >
        {language === 'hi' ? '🇮🇳 HIN' : '🇬🇧 ENG'}
      </button>

      {/* Background Proximity Voice Alert Toggle */}
      <button
        type="button"
        onClick={() => {
          setIsVoiceAlertEnabled(!isVoiceAlertEnabled);
          setHasAnnouncedEntry(false);
          if (!isVoiceAlertEnabled) {
            speakText(language === 'hi' ? 'Voice alert chalu ho gaya hai.' : 'Voice alert active. Monitoring entry zone.');
          }
        }}
        className={`p-1.5 rounded-lg text-xs transition cursor-pointer ${
          isVoiceAlertEnabled
            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50 shadow-sm'
            : 'text-slate-400 hover:text-slate-200'
        }`}
        title={isVoiceAlertEnabled ? 'Background Voice Alert: Active (Announces when price hits Entry Zone)' : 'Enable Background Voice Alert'}
      >
        <Radio className={`w-3.5 h-3.5 ${isVoiceAlertEnabled ? 'animate-pulse text-emerald-400' : ''}`} />
      </button>
    </div>
  );
};
