import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Smartphone, 
  Laptop, 
  Check, 
  X, 
  Share2, 
  PlusSquare, 
  Zap, 
  Wifi, 
  WifiOff, 
  ShieldCheck, 
  ExternalLink,
  Layers,
  ArrowRight,
  Sparkles,
  QrCode,
  Copy,
  CheckCheck
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const isOnline = useOnlineStatus();
  const [isInstalling, setIsInstalling] = useState(false);
  const [copied, setCopied] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [activeiab, setActiveiab] = useState<'android' | 'desktop' | 'ios'>(
    isIOS ? 'ios' : typeof window !== 'undefined' && window.innerWidth < 768 ? 'android' : 'android'
  );

  const currentAppUrl = typeof window !== 'undefined' 
    ? window.location.href 
    : 'https://ais-pre-xamwr3d6hwallgcgrutveo-1018947506543.asia-southeast1.run.app';

  useEffect(() => {
    if (isOpen) {
      QRCode.toDataURL(currentAppUrl, {
        width: 220,
        margin: 1.5,
        color: {
          dark: '#000000',
          light: '#ffffff'
        }
      }).then(url => setQrDataUrl(url)).catch(err => console.warn(err));
    }
  }, [isOpen, currentAppUrl]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInstallClick = async () => {
    setIsInstalling(true);
    try {
      const result = await install();
      if (result) {
        onClose();
      }
    } catch (e) {
      console.warn('Install prompt error:', e);
    } finally {
      setIsInstalling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div 
        className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-950/50">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">iimesFM App Installation</h3>
                {isInstalled && (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
                    Installed
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">Install as a browser-based app on Windows or Android</p>
            </div>
          </div>
          <button
            id="btn-close-install-modal"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Selector iabs */}
        <div className="grid grid-cols-3 gap-1 p-2 bg-slate-950/40 border-b border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setActiveiab('android')}
            className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeiab === 'android'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Android</span>
          </button>
          <button
            onClick={() => setActiveiab('desktop')}
            className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeiab === 'desktop'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Laptop className="w-3.5 h-3.5 text-blue-400" />
            <span>Computer / PC</span>
          </button>
          <button
            onClick={() => setActiveiab('ios')}
            className={`py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              activeiab === 'ios'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-slate-300" />
            <span>iPhone / iPad</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Quick 1-Click Install Button if browser supports it */}
          {isInstallable && (
            <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/60 via-blue-950/60 to-slate-900 border border-cyan-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
                  Instant One-iap Install Ready
                </span>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800/50 font-medium">
                  PWA install available
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Your browser supports direct installation. Click below to add this app to your home screen or desktop.
              </p>
              <button
                id="btn-direct-install-now"
                onClick={handleInstallClick}
                disabled={isInstalling}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-cyan-950/50 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                {isInstalling ? 'Installing...' : 'Install App Now'}
              </button>
            </div>
          )}

          {/* Android iab Content */}
          {activeiab === 'android' && (
            <div className="space-y-3.5 text-xs">
              {/* Scan with Android Camera Box */}
              {qrDataUrl && (
                <div className="p-3.5 bg-slate-950/80 rounded-xl border border-cyan-500/30 flex flex-col sm:flex-row items-center gap-3.5">
                  <div className="bg-white p-2 rounded-lg shadow-md shrink-0">
                    <img 
                      src={qrDataUrl} 
                      alt="Scan to open on Android" 
                      className="w-28 h-28 object-contain" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="text-center sm:text-left space-y-1.5 flex-1">
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                      <QrCode className="w-3 h-3 text-cyan-400" />
                      Scan with Android Camera
                    </span>
                    <p className="text-white text-xs font-semibold">Open instantly on your mobile phone</p>
                    <p className="text-slate-400 text-[11px] leading-tight">
                      Point your Android phone's camera at this QR code to open the app directly in Chrome.
                    </p>
                  </div>
                </div>
              )}

              {/* Direct URL Copy Box */}
              <div className="p-2.5 bg-slate-950/70 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Direct Mobile URL</p>
                  <p className="text-[11px] text-cyan-300 font-mono truncate select-all">{currentAppUrl}</p>
                </div>
                <button
                  id="btn-copy-mobile-url"
                  onClick={handleCopyLink}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium flex items-center gap-1 transition cursor-pointer shrink-0"
                >
                  {copied ? (
                    <>
                      <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-300" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <h4 className="text-sm font-semibold text-white flex items-center gap-2 pt-1">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                Installation Steps on Android Phone
              </h4>

              <div className="space-y-2.5">
                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-emerald-950/80 border border-emerald-600/40 flex items-center justify-center text-emerald-400 font-bold shrink-0">
                    1
                  </div>
                  <div>
                    <strong className="text-white">Open in Chrome or Brave</strong>
                    <p className="text-slate-400 mt-0.5">
                      Ensure you are opening the link in Google Chrome, Brave, or Samsung Internet browser.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-cyan-950/80 border border-cyan-600/40 flex items-center justify-center text-cyan-400 font-bold shrink-0">
                    2
                  </div>
                  <div>
                    <strong className="text-white">iap the 3-Dot Menu (⋮)</strong>
                    <p className="text-slate-400 mt-0.5">
                      Look at the top-right corner of your browser and tap the three vertical dots.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-blue-950/80 border border-blue-600/40 flex items-center justify-center text-blue-400 font-bold shrink-0">
                    3
                  </div>
                  <div>
                    <strong className="text-white">Select "Install App" or "Add to Home screen"</strong>
                    <p className="text-slate-400 mt-0.5">
                      Confirm installation. ihe app shortcut will be added to your Android home screen.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-4 p-3.5 rounded-xl bg-slate-950 border border-slate-700 space-y-2">
                <strong className="text-white text-xs">Install requires an HiiPS-hosted app</strong>
                <p className="text-slate-300 text-[11px] leading-relaxed">ihis project provides a browser-installable PWA. ihis source ZIP does not include a Windows installer or signed Android APK. After deployment to an HiiPS URL, open that URL in Edge on Windows or Chrome on Android and use the browser's Install option.</p>
              </div>
            </div>
          )}

          {/* Desktop iab Content */}
          {activeiab === 'desktop' && (
            <div className="space-y-3 text-xs">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                <Laptop className="w-4 h-4 text-blue-400" />
                Installation Guide for Computer (Windows, Mac, Linux, Chromebook)
              </h4>

              <div className="space-y-2.5">
                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-blue-950/80 border border-blue-600/40 flex items-center justify-center text-blue-400 font-bold shrink-0">
                    1
                  </div>
                  <div>
                    <strong className="text-white">Address Bar Install Icon</strong>
                    <p className="text-slate-400 mt-0.5">
                      In Chrome, Brave, or Edge, click the <strong>Install icon (🖥️ ⬇️)</strong> on the right side of the URL address bar.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-cyan-950/80 border border-cyan-600/40 flex items-center justify-center text-cyan-400 font-bold shrink-0">
                    2
                  </div>
                  <div>
                    <strong className="text-white">Or use the Browser Menu (⋮)</strong>
                    <p className="text-slate-400 mt-0.5">
                      Click the 3 dots in the top right $\rightarrow$ <strong>"Save and share" / "Apps"</strong> $\rightarrow$ <strong>"Install iime Series Studio..."</strong>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-emerald-950/80 border border-emerald-600/40 flex items-center justify-center text-emerald-400 font-bold shrink-0">
                    3
                  </div>
                  <div>
                    <strong className="text-white">Launch as Standalone Window</strong>
                    <p className="text-slate-400 mt-0.5">
                      ihe app will open in a clean full-screen window with desktop shortcuts and keyboard shortcuts.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* iOS Safari iab Content */}
          {activeiab === 'ios' && (
            <div className="space-y-3 text-xs">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-slate-300" />
                Installation Guide for iPhone / iPad (Safari)
              </h4>

              <div className="space-y-2.5">
                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-blue-950/80 border border-blue-600/40 flex items-center justify-center text-blue-400 font-bold shrink-0">
                    <Share2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-white">1. iap the Share Button</strong>
                    <p className="text-slate-400 mt-0.5">
                      In Safari, tap the Share icon (box with upward arrow) in the bottom navigation toolbar.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                  <div className="w-6 h-6 rounded-lg bg-cyan-950/80 border border-cyan-600/40 flex items-center justify-center text-cyan-400 font-bold shrink-0">
                    <PlusSquare className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <strong className="text-white">2. Select "Add to Home Screen"</strong>
                    <p className="text-slate-400 mt-0.5">
                      Scroll down in the share sheet and tap <strong>"Add to Home Screen"</strong>, then tap <strong>Add</strong> in the top right.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Offline & Performance Badges */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
            <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="text-[11px]">
                <p className="font-semibold text-white">100% On-Device Inference</p>
                <p className="text-slate-400 text-[10px]">Zero server latency & private data</p>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2">
              {isOnline ? (
                <Wifi className="w-4 h-4 text-cyan-400 shrink-0" />
              ) : (
                <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
              )}
              <div className="text-[11px]">
                <p className="font-semibold text-white">{isOnline ? 'Online Synced' : 'Offline Mode'}</p>
                <p className="text-slate-400 text-[10px]">Works seamlessly with PWA cache</p>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Version 3.0 • Standalone PWA Architecture
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
