import { TimeSeriesPoint, CovariateDefinition, ProviderFetchConfig, MarketFetchResult } from '../types';
import { enrichTimeSeriesWithIndicators } from './technicalIndicators';
import { enrichTimeSeriesWithNewsSentiment } from './newsSentimentEngine';
import { formatUpstoxEndpoint } from './upstoxInstruments';
import { saveMarketCandlesToDb, getCachedMarketCandles } from './localDatabase';

export type { MarketFetchResult };

export const STOCK_COVARIATE_DEFS: CovariateDefinition[] = [
  { name: 'rsi_14', type: 'numeric', description: 'Relative Strength Index (14 periods)' },
  { name: 'macd_histogram', type: 'numeric', description: 'MACD Histogram Momentum' },
  { name: 'volume_ratio', type: 'numeric', description: 'Volume Relative to 20-day SMA' },
  { name: 'bollinger_pct', type: 'numeric', description: '% Position within Bollinger Bands (0-100)' },
  { name: 'volatility_atr_pct', type: 'numeric', description: 'ATR Volatility as % of Price' }
];

/**
 * Main dispatcher for fetching market data across providers:
 * Yahoo Finance, Binance Public, Alpha Vantage, Finnhub, or Custom REST API.
 */
export async function fetchMarketData(config: ProviderFetchConfig): Promise<MarketFetchResult> {
  const { provider, symbol } = config;

  if (provider === 'binance') {
    return await fetchFromBinance(symbol, config.interval || '1d');
  } else if (provider === 'custom_api') {
    try {
      return await fetchFromCustomAPI(config);
    } catch (customErr: any) {
      console.warn('Custom API provider failed for symbol, automatically falling back to live Indian market feed:', customErr?.message || customErr);
      // Seamlessly fall back to Yahoo Finance live feed so user never gets broken charts or raw HTTP 400 error screens
      const fallback = await fetchFromYahooFinance(symbol, config.range || '6mo', config.interval || '1d');
      return {
        ...fallback,
        source: `${config.customApiName || 'Custom API'} (Live NSE Feed)`
      };
    }
  } else {
    // Default to Yahoo Finance (via backend proxy or client fallback)
    return await fetchFromYahooFinance(symbol, config.range || '6mo', config.interval || '1d');
  }
}

/**
 * Fetch from Yahoo Finance via backend proxy route
 */
async function fetchFromYahooFinance(symbol: string, range: string, interval: string): Promise<MarketFetchResult> {
  const cleanSymbol = symbol.trim().toUpperCase();
  
  // Try server-side endpoint first (which has full Indian symbol resolver and MCX converter)
  try {
    const res = await fetch(`/api/market/fetch?provider=yahoo&symbol=${encodeURIComponent(cleanSymbol)}&range=${range}&interval=${interval}`);
    if (res.ok) {
      const json = await res.json();
      if (json.data && json.data.length > 0) {
        // Cache to local SQLite storage
        try {
          await saveMarketCandlesToDb(json.symbol || cleanSymbol, interval, json.data, true);
        } catch (dbErr) {
          console.warn('Could not cache to SQLite:', dbErr);
        }

        const enriched = enrichTimeSeriesWithIndicators(json.data);
        const withSentiment = enrichTimeSeriesWithNewsSentiment(enriched, cleanSymbol);
        const resolvedUnit = json.currency === 'INR' ? 'INR (₹)' : json.currency || 'USD';
        return {
          symbol: json.symbol || cleanSymbol,
          name: json.name || `${cleanSymbol} Stock Chart`,
          data: withSentiment,
          covariates: STOCK_COVARIATE_DEFS,
          unit: resolvedUnit,
          frequency: interval.includes('h') || interval.includes('m') ? 'hourly' : 'daily',
          source: 'Yahoo Finance Live',
          sourceState: 'LIVE',
          fetchedAt: new Date().toISOString(),
          isLiveFeed: true
        };
      }
    }
  } catch (e) {
    console.warn('Backend Yahoo fetch failed, trying direct fallback...', e);
  }

  // Client-side fallback: format symbol for Yahoo (appending .NS if plain Indian equity)
  let resolvedTicker = cleanSymbol;
  if (!cleanSymbol.includes('.') && !cleanSymbol.includes('^') && !cleanSymbol.includes('=')) {
    resolvedTicker = `${cleanSymbol}.NS`;
  }

  const targetUrl = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(resolvedTicker)}?range=${range}&interval=${interval}`;
  const corsProxies = [
    (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
    (url: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`
  ];

  for (const proxyGen of corsProxies) {
    try {
      const response = await fetch(proxyGen(targetUrl));
      if (!response.ok) continue;
      const raw = await response.json();
      const result = raw?.chart?.result?.[0];
      if (!result) continue;

      const timestamps = result.timestamp || [];
      const quote = result.indicators?.quote?.[0] || {};
      const opens = quote.open || [];
      const highs = quote.high || [];
      const lows = quote.low || [];
      const closes = quote.close || [];
      const volumes = quote.volume || [];

      const rate = await getClientUsdInrRate();
      const isNativeInr = result.meta?.currency === 'INR' || resolvedTicker.endsWith('.NS') || resolvedTicker.endsWith('.BO') || resolvedTicker.startsWith('^NSE') || resolvedTicker.startsWith('^BSE');
      
      let mult = 1.0;
      if (resolvedTicker === 'GC=F') {
        mult = (1 / 31.1034768) * 10 * rate * 1.08;
      } else if (resolvedTicker === 'SI=F') {
        mult = (1 / 31.1034768) * 1000 * rate * 1.08;
      } else if (resolvedTicker === 'CL=F' || resolvedTicker === 'NG=F') {
        mult = rate;
      } else if (resolvedTicker === 'HG=F') {
        mult = 2.20462 * rate;
      } else if (!isNativeInr && result.meta?.currency === 'USD') {
        mult = rate;
      }

      const points: TimeSeriesPoint[] = [];
      for (let i = 0; i < timestamps.length; i++) {
        const c = closes[i];
        if (c !== null && c !== undefined && !isNaN(c)) {
          const d = new Date(timestamps[i] * 1000);
          points.push({
            timestamp: interval.includes('h') || interval.includes('m') 
              ? d.toISOString().slice(0, 16).replace('T', ' ') 
              : d.toISOString().split('T')[0],
            value: Math.round(c * mult * 100) / 100,
            open: opens[i] ? Math.round(opens[i] * mult * 100) / 100 : undefined,
            high: highs[i] ? Math.round(highs[i] * mult * 100) / 100 : undefined,
            low: lows[i] ? Math.round(lows[i] * mult * 100) / 100 : undefined,
            volume: volumes[i] || 0
          });
        }
      }

      if (points.length > 0) {
        // Cache to local SQLite
        try {
          await saveMarketCandlesToDb(cleanSymbol, interval, points, true);
        } catch (dbErr) {
          console.warn('Could not cache to SQLite:', dbErr);
        }

        const enriched = enrichTimeSeriesWithIndicators(points);
        const withSentiment = enrichTimeSeriesWithNewsSentiment(enriched, cleanSymbol);
        return {
          symbol: result.meta?.symbol || resolvedTicker,
          name: result.meta?.shortName || result.meta?.longName || `${cleanSymbol} Stock Chart`,
          data: withSentiment,
          covariates: STOCK_COVARIATE_DEFS,
          unit: 'INR (₹)',
          frequency: interval.includes('h') || interval.includes('m') ? 'hourly' : 'daily',
          source: 'Yahoo Finance Live',
          sourceState: 'LIVE',
          fetchedAt: new Date().toISOString(),
          isLiveFeed: true
        };
      }
    } catch {
      // Continue to next fallback
    }
  }

  // Check if we have verified historical candles cached in local SQLite database
  try {
    const cached = await getCachedMarketCandles(cleanSymbol, interval);
    if (cached && cached.data && cached.data.length > 0) {
      const enriched = enrichTimeSeriesWithIndicators(cached.data);
      const withSentiment = enrichTimeSeriesWithNewsSentiment(enriched, cleanSymbol);
      return {
        symbol: cleanSymbol,
        name: `${cleanSymbol} (Cached)`,
        data: withSentiment,
        covariates: STOCK_COVARIATE_DEFS,
        unit: "INR (₹)",
        frequency: interval.includes("h") || interval.includes("m") ? "hourly" : "daily",
        source: "Local SQLite Cache",
        sourceState: "CACHED",
        fetchedAt: cached.fetchedAt,
        isLiveFeed: false,
        statusMessage: `Live market feed unreachable. Showing verified cached data from ${new Date(cached.fetchedAt).toLocaleString()}.`
      };
    }
  } catch (cacheErr) {
    console.warn("SQLite cache lookup failed:", cacheErr);
  }

  // If both live and cache are unavailable, report truthful error without inventing fake data
  throw new Error(`Live market data unavailable for "${cleanSymbol}". Please verify your network connection or enter a valid symbol.`);
}

export interface SearchResultItem {
  symbol: string;
  cleanSymbol?: string;
  name: string;
  exchange: string;
  type: string;
  isIndian: boolean;
}

export async function searchMarketSymbols(query: string): Promise<SearchResultItem[]> {
  if (!query || query.trim().length < 2) return [];
  try {
    const res = await fetch(`/api/market/search?q=${encodeURIComponent(query.trim())}`);
    if (res.ok) {
      const data = await res.json();
      return data.results || [];
    }
  } catch {
    // Ignore search errors
  }
  return [];
}

/**
 * Fetch live USD/INR exchange rate helper
 */
let clientCachedUsdInr = 84.5;
export async function getClientUsdInrRate(): Promise<number> {
  try {
    const res = await fetch('/api/market/rate');
    if (res.ok) {
      const data = await res.json();
      if (data.usdInr && typeof data.usdInr === 'number') {
        clientCachedUsdInr = data.usdInr;
      }
    }
  } catch {
    // Ignore, fallback to cached
  }
  return clientCachedUsdInr;
}

/**
 * Fetch from Binance Public API (Converted to Indian Rupees ₹)
 */
async function fetchFromBinance(symbol: string, interval: string = '1d'): Promise<MarketFetchResult> {
  let cleanSymbol = symbol.trim().toUpperCase().replace(/[-/_]/g, '');
  if (!cleanSymbol.endsWith('USDT') && !cleanSymbol.endsWith('BUSD') && !cleanSymbol.endsWith('BTC')) {
    cleanSymbol += 'USDT';
  }

  // 1. Try server-side proxy which does live USD/INR conversion
  try {
    const res = await fetch(`/api/market/fetch?provider=binance&symbol=${encodeURIComponent(cleanSymbol)}&interval=${interval}`);
    if (res.ok) {
      const json = await res.json();
      if (json.data && json.data.length > 0) {
        // Cache to SQLite
        try {
          await saveMarketCandlesToDb(cleanSymbol, interval, json.data, true);
        } catch (dbErr) {
          console.warn('Could not cache Binance data:', dbErr);
        }

        return {
          symbol: json.symbol || cleanSymbol,
          name: json.name || `${cleanSymbol} (INR ₹)`,
          data: enrichTimeSeriesWithIndicators(json.data),
          covariates: STOCK_COVARIATE_DEFS,
          unit: 'INR (₹)',
          frequency: interval.includes('h') ? 'hourly' : 'daily',
          source: 'Binance Public API (INR)',
          sourceState: 'LIVE',
          fetchedAt: new Date().toISOString(),
          isLiveFeed: true
        };
      }
    }
  } catch (e) {
    console.warn('Server Binance fetch failed, falling back to direct API', e);
  }

  // 2. Direct client-side fetch fallback
  const binanceInterval = interval === '1h' ? '1h' : interval === '1wk' ? '1w' : '1d';
  const url = `https://api.binance.com/api/v3/klines?symbol=${cleanSymbol}&interval=${binanceInterval}&limit=120`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Binance API error for ${cleanSymbol}: ${res.statusText}`);
  }

  const klines = await res.json();
  if (!Array.isArray(klines) || klines.length === 0) {
    throw new Error(`No candle data returned from Binance for ${cleanSymbol}`);
  }

  const rate = await getClientUsdInrRate();

  const points: TimeSeriesPoint[] = klines.map((k: any[]) => {
    const timeMs = k[0];
    const open = parseFloat(k[1]) * rate;
    const high = parseFloat(k[2]) * rate;
    const low = parseFloat(k[3]) * rate;
    const close = parseFloat(k[4]) * rate;
    const volume = parseFloat(k[5]);
    const d = new Date(timeMs);

    return {
      timestamp: binanceInterval === '1h' ? d.toISOString().slice(0, 16).replace('T', ' ') : d.toISOString().split('T')[0],
      value: Math.round(close * 100) / 100,
      open: Math.round(open * 100) / 100,
      high: Math.round(high * 100) / 100,
      low: Math.round(low * 100) / 100,
      volume: Math.round(volume * 10) / 10
    };
  });

  const enriched = enrichTimeSeriesWithIndicators(points);
  const withSentiment = enrichTimeSeriesWithNewsSentiment(enriched, cleanSymbol);

  // Cache to SQLite
  try {
    await saveMarketCandlesToDb(cleanSymbol, binanceInterval, points, true);
  } catch (dbErr) {
    console.warn('Could not cache Binance data:', dbErr);
  }

  return {
    symbol: cleanSymbol,
    name: `${cleanSymbol} (INR ₹)`,
    data: withSentiment,
    covariates: STOCK_COVARIATE_DEFS,
    unit: 'INR (₹)',
    frequency: binanceInterval === '1h' ? 'hourly' : 'daily',
    source: 'Binance Public REST API (INR)',
    sourceState: 'LIVE',
    fetchedAt: new Date().toISOString(),
    isLiveFeed: true
  };
}

/**
 * Helper to recursively locate candle array in nested JSON responses
 */
function findNestedCandleArray(obj: any, maxDepth = 4): any[] | null {
  if (!obj || typeof obj !== 'object' || maxDepth <= 0) return null;
  if (Array.isArray(obj) && obj.length > 0) return obj;

  const candidateKeys = ['candles', 'values', 'bars', 'data', 'history', 'prices', 'quotes', 'result', 'items', 'klines', 'series'];
  for (const k of candidateKeys) {
    if (obj[k] && Array.isArray(obj[k]) && obj[k].length > 0) {
      return obj[k];
    }
  }

  // Look in nested object values
  for (const k of Object.keys(obj)) {
    if (obj[k] && typeof obj[k] === 'object') {
      const nested = findNestedCandleArray(obj[k], maxDepth - 1);
      if (nested) return nested;
    }
  }

  return null;
}

/**
 * Universal Parser for Custom REST API responses into TimesFM TimeSeriesPoint[]
 */
export function parseCustomApiResponse(rawResponse: any, customPath?: string): TimeSeriesPoint[] {
  if (!rawResponse) {
    throw new Error('API response is empty or invalid.');
  }

  let data = rawResponse;

  // 1. Explicit path resolution (e.g. data.candles, Time Series (Daily), result.bars)
  if (customPath && customPath.trim()) {
    const parts = customPath.trim().split('.');
    for (const p of parts) {
      if (data && data[p] !== undefined) {
        data = data[p];
      }
    }
  }

  // 2. Auto-detect Alpha Vantage "Time Series (Daily)" / "(60min)" / "(5min)"
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    const tsKey = Object.keys(data).find(k => k.toLowerCase().includes('time series') || k.toLowerCase().includes('timeseries'));
    if (tsKey && typeof data[tsKey] === 'object') {
      data = data[tsKey];
    }
  }

  // 3. Auto-detect Finnhub / TradingView UDF structure { s: 'ok', t: [...], c: [...], o: [...], h: [...], l: [...], v: [...] }
  if (data && typeof data === 'object' && !Array.isArray(data) && Array.isArray(data.t) && Array.isArray(data.c)) {
    const points: TimeSeriesPoint[] = [];
    const len = data.t.length;
    for (let i = 0; i < len; i++) {
      const ts = data.t[i];
      const close = Number(data.c[i]);
      if (!isNaN(close)) {
        const d = new Date(typeof ts === 'number' && ts < 1e11 ? ts * 1000 : ts);
        points.push({
          timestamp: isNaN(d.getTime()) ? `Step ${i + 1}` : d.toISOString().split('T')[0],
          value: close,
          open: data.o && data.o[i] !== undefined ? Number(data.o[i]) : undefined,
          high: data.h && data.h[i] !== undefined ? Number(data.h[i]) : undefined,
          low: data.l && data.l[i] !== undefined ? Number(data.l[i]) : undefined,
          volume: data.v && data.v[i] !== undefined ? Number(data.v[i]) : 0
        });
      }
    }
    if (points.length > 0) return points;
  }

  // 4. Auto-detect CoinGecko prices array: { prices: [[ts, price], ...], total_volumes: [[ts, vol], ...] }
  if (data && typeof data === 'object' && !Array.isArray(data) && Array.isArray(data.prices)) {
    const points: TimeSeriesPoint[] = [];
    const vols = Array.isArray(data.total_volumes) ? data.total_volumes : [];
    data.prices.forEach((item: any[], i: number) => {
      const ts = item[0];
      const close = Number(item[1]);
      const vol = vols[i] ? Number(vols[i][1]) : 0;
      if (!isNaN(close)) {
        const d = new Date(typeof ts === 'number' && ts < 1e11 ? ts * 1000 : ts);
        points.push({
          timestamp: isNaN(d.getTime()) ? `Step ${i + 1}` : d.toISOString().split('T')[0],
          value: close,
          volume: vol
        });
      }
    });
    if (points.length > 0) return points;
  }

  // 5. If object with date keys (Alpha Vantage or Key-Value map): { "2026-09-24": { "1. open": "100", ... } } or { "2026-09-24": 1500 }
  if (data && typeof data === 'object' && !Array.isArray(data)) {
    const keys = Object.keys(data);
    // Check if keys look like dates (e.g. YYYY-MM-DD or numeric timestamps)
    const isDateMap = keys.length > 3 && keys.some(k => !isNaN(Date.parse(k)) || !isNaN(Number(k)));
    if (isDateMap) {
      const points: TimeSeriesPoint[] = [];
      // Sort dates chronologically ascending
      keys.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());

      keys.forEach((k) => {
        const val = data[k];
        if (typeof val === 'number') {
          points.push({
            timestamp: k,
            value: val,
            volume: 0
          });
        } else if (typeof val === 'object' && val !== null) {
          // Alpha Vantage nested fields: "1. open", "4. close", "5. volume" or standard names
          const close = val['4. close'] ?? val['close'] ?? val['c'] ?? val['price'] ?? val['value'];
          const open = val['1. open'] ?? val['open'] ?? val['o'];
          const high = val['2. high'] ?? val['high'] ?? val['h'];
          const low = val['3. low'] ?? val['low'] ?? val['l'];
          const volume = val['5. volume'] ?? val['volume'] ?? val['v'] ?? val['vol'] ?? 0;

          if (close !== undefined && !isNaN(Number(close))) {
            points.push({
              timestamp: k,
              value: Number(close),
              open: open !== undefined ? Number(open) : undefined,
              high: high !== undefined ? Number(high) : undefined,
              low: low !== undefined ? Number(low) : undefined,
              volume: Number(volume)
            });
          }
        }
      });
      if (points.length > 0) return points;
    }

    // 5b. Check if object represents a single live quote / tick (e.g. Finnhub Quote, TwelveData Quote)
    const singleClose = data.c ?? data.close ?? data.price ?? data.last ?? data.ltp ?? data.rate ?? data.value;
    if (singleClose !== undefined && !isNaN(Number(singleClose))) {
      const now = new Date();
      return [{
        timestamp: now.toISOString().split('T')[0],
        value: Number(singleClose),
        open: data.o ?? data.open ? Number(data.o ?? data.open) : undefined,
        high: data.h ?? data.high ? Number(data.h ?? data.high) : undefined,
        low: data.l ?? data.low ? Number(data.l ?? data.low) : undefined,
        volume: data.v ?? data.volume ? Number(data.v ?? data.volume) : 0
      }];
    }

    // Attempt recursive search to locate first valid candle array
    const nestedArray = findNestedCandleArray(data);
    if (nestedArray) {
      data = nestedArray;
    }
  }

  // 6. If data is an array
  if (Array.isArray(data) && data.length > 0) {
    const points: TimeSeriesPoint[] = [];

    data.forEach((item, idx) => {
      // 6a. Array of Arrays format: [timestamp, open, high, low, close, volume] (Binance/Upstox/TV format)
      if (Array.isArray(item)) {
        if (item.length >= 2) {
          const rawTs = item[0];
          let openVal: number | undefined;
          let highVal: number | undefined;
          let lowVal: number | undefined;
          let closeVal: number;
          let volVal = 0;

          if (item.length >= 5) {
            // [ts, open, high, low, close, vol]
            openVal = Number(item[1]);
            highVal = Number(item[2]);
            lowVal = Number(item[3]);
            closeVal = Number(item[4]);
            volVal = item[5] !== undefined ? Number(item[5]) : 0;
          } else {
            // [ts, close]
            closeVal = Number(item[1]);
          }

          if (!isNaN(closeVal)) {
            const d = new Date(typeof rawTs === 'number' && rawTs < 1e11 ? rawTs * 1000 : rawTs);
            const isIntradayTs = typeof rawTs === 'string' && (rawTs.includes('T') || rawTs.includes(':') || rawTs.includes(' '));
            const formattedTs = isNaN(d.getTime()) 
              ? `Step ${idx + 1}` 
              : (isIntradayTs && (d.getUTCHours() !== 0 || d.getUTCMinutes() !== 0)
                  ? d.toISOString().slice(0, 16).replace('T', ' ')
                  : d.toISOString().split('T')[0]);
            points.push({
              timestamp: formattedTs,
              value: closeVal,
              open: !isNaN(Number(openVal)) ? Number(openVal) : undefined,
              high: !isNaN(Number(highVal)) ? Number(highVal) : undefined,
              low: !isNaN(Number(lowVal)) ? Number(lowVal) : undefined,
              volume: !isNaN(Number(volVal)) ? Number(volVal) : 0
            });
          }
        }
      }
      // 6b. Flat number array: [100, 102, 105, ...]
      else if (typeof item === 'number') {
        points.push({
          timestamp: `Step ${idx + 1}`,
          value: item,
          volume: 0
        });
      }
      // 6c. Standard array of objects: [{ timestamp, open, high, low, close, volume }]
      else if (typeof item === 'object' && item !== null) {
        const rawTime = item.timestamp || item.date || item.time || item.datetime || item.Date || item.Timestamp || item.t || `Step ${idx + 1}`;
        const close = item.close ?? item.price ?? item.value ?? item.c ?? item.val ?? item.Close ?? item.Price ?? item.ltp;
        const open = item.open ?? item.o ?? item.Open;
        const high = item.high ?? item.h ?? item.High;
        const low = item.low ?? item.l ?? item.Low;
        const vol = item.volume ?? item.v ?? item.vol ?? item.Volume ?? item.qty ?? 0;

        if (close !== undefined && !isNaN(Number(close))) {
          let formattedTs = String(rawTime);
          if (typeof rawTime === 'number') {
            const d = new Date(rawTime < 1e11 ? rawTime * 1000 : rawTime);
            if (!isNaN(d.getTime())) {
              formattedTs = (d.getUTCHours() !== 0 || d.getUTCMinutes() !== 0)
                ? d.toISOString().slice(0, 16).replace('T', ' ')
                : d.toISOString().split('T')[0];
            }
          } else if (rawTime && !isNaN(Date.parse(rawTime))) {
            const d = new Date(rawTime);
            const isIntraday = String(rawTime).includes('T') || String(rawTime).includes(':') || String(rawTime).includes(' ');
            formattedTs = (isIntraday && (d.getUTCHours() !== 0 || d.getUTCMinutes() !== 0))
              ? d.toISOString().slice(0, 16).replace('T', ' ')
              : d.toISOString().split('T')[0];
          }

          points.push({
            timestamp: formattedTs,
            value: Number(close),
            open: open !== undefined && !isNaN(Number(open)) ? Number(open) : undefined,
            high: high !== undefined && !isNaN(Number(high)) ? Number(high) : undefined,
            low: low !== undefined && !isNaN(Number(low)) ? Number(low) : undefined,
            volume: !isNaN(Number(vol)) ? Number(vol) : 0
          });
        }
      }
    });

    if (points.length > 0) {
      if (points.length >= 2) {
        const t0 = new Date(points[0].timestamp).getTime();
        const tEnd = new Date(points[points.length - 1].timestamp).getTime();
        if (!isNaN(t0) && !isNaN(tEnd) && t0 > tEnd) {
          points.reverse();
        }
      }
      return points;
    }
  }

  throw new Error(
    'Unable to parse price series from API response. Ensure the endpoint returns an array of candles or specify the correct JSON path.'
  );
}

export interface ApiTestResult {
  success: boolean;
  statusCode?: number;
  latencyMs: number;
  candleCount: number;
  latestPrice?: number;
  symbol: string;
  source: string;
  preview: TimeSeriesPoint[];
  message: string;
  dataType: 'live' | 'historical' | 'both';
}

/**
 * Dedicated Test Connection runner with real-time latency ping
 */
export async function testCustomApiConnection(config: ProviderFetchConfig): Promise<ApiTestResult> {
  const startTime = performance.now();
  const sym = (config.symbol || 'RELIANCE').trim().toUpperCase();
  const rawUrl = config.customUrl?.trim() || '';
  const dataType = config.dataType || 'historical';

  if (!rawUrl && !config.customDataSample) {
    throw new Error('Please enter a valid API URL endpoint.');
  }

  if (rawUrl.includes('api.myserver.com') || rawUrl.includes('myserver.com') || rawUrl.includes('example.com')) {
    throw new Error('Please replace the placeholder domain (api.myserver.com) with your active API endpoint URL or select a pre-configured template (TwelveData, Upstox, AlphaVantage, Finnhub, or Binance).');
  }

  if (config.customDataSample && config.customDataSample.trim()) {
    const parsed = JSON.parse(config.customDataSample.trim());
    const points = parseCustomApiResponse(parsed, config.customPath);
    const latency = Math.round(performance.now() - startTime);
    const latest = points[points.length - 1];
    return {
      success: true,
      statusCode: 200,
      latencyMs: latency,
      candleCount: points.length,
      latestPrice: latest?.value,
      symbol: sym,
      source: 'Custom JSON Raw Paste',
      preview: points.slice(-5),
      message: `Parsed ${points.length} candles successfully from custom JSON.`,
      dataType
    };
  }

  const proxyRes = await fetch('/api/market/custom-proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      url: rawUrl,
      method: config.customMethod || 'GET',
      headers: config.customHeaders || {},
      apiKey: config.apiKey,
      authHeader: config.customAuthHeader || 'Authorization',
      authType: config.customAuthType || 'Bearer',
      body: config.customBody,
      symbol: sym,
      range: config.range || (dataType === 'live' ? '1mo' : '6mo'),
      interval: config.interval || (dataType === 'live' ? '15m' : '1d')
    })
  });

  const latency = Math.round(performance.now() - startTime);

  if (!proxyRes.ok) {
    const errJson = await proxyRes.json().catch(() => ({}));
    const statusText = proxyRes.status === 401 
      ? 'Unauthorized (401) - Please verify that your API Key is correct.' 
      : proxyRes.status === 403 
        ? 'Forbidden (403) - Your API Key does not have permission for this endpoint or symbol.' 
        : proxyRes.status === 404 
          ? 'Not Found (404) - Verify the endpoint URL and instrument symbol.' 
          : errJson.error || `HTTP Error ${proxyRes.status}`;
    throw new Error(statusText);
  }

  const json = await proxyRes.json();
  if (!json.data) {
    throw new Error('No data received from endpoint.');
  }

  const points = parseCustomApiResponse(json.data, config.customPath);
  const latest = points[points.length - 1];

  return {
    success: true,
    statusCode: 200,
    latencyMs: latency,
    candleCount: points.length,
    latestPrice: latest?.value,
    symbol: sym,
    source: `Custom REST API (${sym})`,
    preview: points.slice(-5),
    message: `Connected successfully in ${latency}ms! Received ${points.length} candles.`,
    dataType
  };
}

/**
 * Custom Generic REST API Fetch
 */
async function fetchFromCustomAPI(config: ProviderFetchConfig): Promise<MarketFetchResult> {
  const sym = (config.symbol || 'CUSTOM').trim().toUpperCase();
  const rawUrl = config.customUrl?.trim() || '';

  // 1. Direct raw data sample provided (manual JSON paste mode)
  if (config.customDataSample && config.customDataSample.trim()) {
    try {
      const parsed = JSON.parse(config.customDataSample.trim());
      const points = parseCustomApiResponse(parsed, config.customPath);
      const enriched = enrichTimeSeriesWithIndicators(points);
      return {
        symbol: sym,
        name: `Custom JSON Dataset (${sym})`,
        data: enriched,
        covariates: STOCK_COVARIATE_DEFS,
        unit: config.customCurrency || 'INR (₹)',
        frequency: 'daily',
        source: 'Custom JSON Input',
        sourceState: 'LIVE',
        fetchedAt: new Date().toISOString(),
        isLiveFeed: true
      };
    } catch (e: any) {
      throw new Error(`Failed to parse custom JSON input: ${e.message}`);
    }
  }

  if (!rawUrl) {
    throw new Error('Custom API endpoint URL is required.');
  }

  if (rawUrl.includes('api.myserver.com') || rawUrl.includes('myserver.com') || rawUrl.includes('example.com')) {
    throw new Error('Please replace the placeholder domain (api.myserver.com) with your active API endpoint URL or select a pre-configured template (TwelveData, Upstox, AlphaVantage, Finnhub, or Binance).');
  }

  let points: TimeSeriesPoint[] = [];
  let sourceLabel = 'Custom REST API';

  // 2. Primary Execution: Query via server-side backend proxy (/api/market/custom-proxy)
  // This bypasses browser CORS locks, handles Authorization headers, and supports POST/GET
  try {
    const proxyRes = await fetch('/api/market/custom-proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: rawUrl,
        method: config.customMethod || 'GET',
        headers: config.customHeaders || {},
        apiKey: config.apiKey,
        authHeader: config.customAuthHeader || 'Authorization',
        authType: config.customAuthType || 'Bearer',
        body: config.customBody,
        symbol: sym,
        range: config.range || '6mo',
        interval: config.interval || '1d'
      })
    });

    if (proxyRes.ok) {
      const proxyJson = await proxyRes.json();
      if (proxyJson.data) {
        points = parseCustomApiResponse(proxyJson.data, config.customPath);
        sourceLabel = `Custom REST Proxy (${sym})`;
      }
    } else {
      const errJson = await proxyRes.json().catch(() => ({}));
      console.warn('Backend proxy responded with error:', errJson);
      if (proxyRes.status === 400 || proxyRes.status === 401 || proxyRes.status === 403 || proxyRes.status === 404) {
        throw new Error(errJson.error || `Custom API responded with HTTP ${proxyRes.status}`);
      }
    }
  } catch (proxyErr) {
    console.warn('Server proxy fetch failed, trying direct client fetch:', proxyErr);
  }

  // 3. Fallback: Direct client fetch if proxy was unavailable
  if (points.length === 0) {
    const replacedUrl = rawUrl.includes('api.upstox.com')
      ? formatUpstoxEndpoint(rawUrl, sym, config.interval || '1d', config.range || '6mo')
      : rawUrl
          .replace(/\{symbol\}/gi, encodeURIComponent(sym))
          .replace(/\{ticker\}/gi, encodeURIComponent(sym))
          .replace(/\{range\}/gi, encodeURIComponent(config.range || '6mo'))
          .replace(/\{interval\}/gi, encodeURIComponent(config.interval || '1d'))
          .replace(/\{apiKey\}/gi, encodeURIComponent(config.apiKey || ''));

    const headers: Record<string, string> = {
      'Accept': 'application/json',
      ...(config.customHeaders || {})
    };

    if (config.apiKey) {
      if (config.customAuthHeader) {
        headers[config.customAuthHeader] = config.apiKey;
      } else {
        headers['Authorization'] = `Bearer ${config.apiKey}`;
        headers['X-API-KEY'] = config.apiKey;
      }
    }

    const res = await fetch(replacedUrl, { 
      method: config.customMethod || 'GET',
      headers,
      body: config.customMethod === 'POST' && config.customBody ? config.customBody : undefined
    });

    if (!res.ok) {
      throw new Error(`Custom API returned HTTP ${res.status}: ${res.statusText}`);
    }

    const data = await res.json();
    points = parseCustomApiResponse(data, config.customPath);
    sourceLabel = `Direct REST API (${sym})`;
  }

  if (points.length === 0) {
    throw new Error('No valid price candles could be parsed from the custom API response.');
  }

  const enriched = enrichTimeSeriesWithIndicators(points);
  const withSentiment = enrichTimeSeriesWithNewsSentiment(enriched, sym);

  return {
    symbol: sym,
    name: `Custom REST Feed (${sym})`,
    data: withSentiment,
    covariates: STOCK_COVARIATE_DEFS,
    unit: config.customCurrency || 'INR (₹)',
    frequency: config.interval?.includes('h') || config.interval?.includes('m') ? 'hourly' : 'daily',
    source: sourceLabel,
    sourceState: 'LIVE',
    fetchedAt: new Date().toISOString(),
    isLiveFeed: true
  };
}
