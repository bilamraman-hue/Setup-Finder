import { ProviderFetchConfig } from '../types';
import { UPSTOX_INSTRUMENT_MAP, POPULAR_COMPANY_ALIASES, normalizeSymbol } from './upstoxInstruments';
import { INDIAN_MARKET_TICKERS } from '../data/presets';

/**
 * Comprehensive list of verified valid Indian Stock tickers (NSE / BSE),
 * Indices, and MCX Commodities for client-side cross-referencing.
 */
export const LOCAL_VALID_TICKER_REGISTRY: Set<string> = new Set([
  // NIFTY 50 & Top NSE / BSE Equities
  'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'SBIN', 'BHARTIARTL',
  'TATAMOTORS', 'TMPV', 'TMCV', 'ITC', 'KOTAKBANK', 'LT', 'AXISBANK',
  'MARUTI', 'SUNPHARMA', 'TITAN', 'BAJFINANCE', 'BAJAJFINSV', 'ASIANPAINT',
  'WIPRO', 'HCLTECH', 'NTPC', 'POWERGRID', 'TATASTEEL', 'JSWSTEEL',
  'COALINDIA', 'ADANIENT', 'ADANIPORTS', 'ULTRACEMCO', 'ONGC', 'NESTLEIND',
  'HEROMOTOCO', 'BAJAJ-AUTO', 'EICHERMOT', 'GRASIM', 'HINDUNILVR', 'DIVISLAB',
  'CIPLA', 'DRREDDY', 'APOLLOHOSP', 'TECHM', 'BPCL', 'BRITANNIA',
  'INDUSINDBK', 'HINDALCO', 'SBILIFE', 'HDFCLIFE', 'BEL', 'HAL', 'TRENT',
  'ZOMATO', 'JIOFIN', 'SUZLON', 'SYRMA', 'VEDL', 'IRFC', 'BHEL', 'IOC',
  'GAIL', 'DLF', 'PFC', 'RECLTD', 'MOTHERSON', 'POLYCAB', 'PERSISTENT',
  'SIEMENS', 'ABB', 'CHOLAFIN', 'MUTHOOTFIN', 'TVSMOTOR', 'SHREECEM',
  'PIDILITIND', 'HAVELLS', 'DABUR', 'GODREJCP', 'BERGEPAINT', 'INDIGO',
  'AUROPHARMA', 'LUPIN', 'AMBUJACEM', 'ACC', 'BANKBARODA', 'PNB', 'CANBK',
  'UNIONBANK', 'IDFCFIRSTB', 'FEDERALBNK', 'TATACOMM', 'TATACONSUM',
  'TATAPOWER', 'TATAELXSI', 'VOLTAS', 'COLPAL', 'MARICO', 'SRF', 'CUMMINSIND',
  'BOSCHLTD', 'ASHOKLEY', 'BALKRISIND', 'MRF', 'PAGEIND', 'LTIM', 'OFSS',
  'MPHASIS', 'COFORGE', 'LTTS', 'KPITTECH', 'TATACHEM', 'DEEPAKNTR', 'PIIND',
  'NAVINFLUOR', 'ASTRAL', 'SUPREMEIND', 'DIXON', 'KAYNES', 'CGPOWER',
  'SUNDRMFAST', 'TIINDIA', 'APLAPOLLO', 'HDFCAMC', 'NAM-INDIA', 'BSE', 'CDSL',
  'MCX', 'CAMS', 'IEX', 'KFINTECH', 'SWIGGY', 'PAYTM', 'IREDA', 'RVNL',
  'NHPC', 'SJVN', 'EXIDEIND', 'AMBER', 'PRESTIGE', 'OBEROIRLTY', 'GODREJPROP',
  'PHOENIXLTD', 'MAZDOCK', 'COCHINSHIP', 'BDL', 'POLICYBZR', 'NYKAA',
  'DELHIVERY', 'KALYANKJIL', 'KPIL', 'M&M',

  // Major Benchmark & Sectoral Indices
  'NIFTY', 'NIFTY 50', 'NIFTY50', '^NSEI', 'BANKNIFTY', 'NIFTY BANK',
  'BANK NIFTY', '^NSEBANK', 'FINNIFTY', '^CNXFIN', 'MIDCPNIFTY', '^NSEMDCP50',
  'SENSEX', 'BSE SENSEX', '^BSESN', 'NIFTY IT', 'NIFTY NEXT 50',

  // MCX Commodities
  'GOLD', 'MCX GOLD', 'GC=F', 'SILVER', 'MCX SILVER', 'SI=F',
  'CRUDE', 'CRUDE OIL', 'CRUDEOIL', 'CL=F', 'NATURAL GAS', 'NATURALGAS',
  'NATGAS', 'NG=F', 'COPPER', 'MCX COPPER', 'HG=F', 'ALUMINIUM', 'ALI=F',
  'ZINC', 'ZNC=F', 'GOLDBEES', 'SILVERBEES'
]);

// Populate from presets and aliases
INDIAN_MARKET_TICKERS.forEach(t => LOCAL_VALID_TICKER_REGISTRY.add(t.symbol.toUpperCase()));
Object.keys(UPSTOX_INSTRUMENT_MAP).forEach(k => LOCAL_VALID_TICKER_REGISTRY.add(k.toUpperCase()));
Object.keys(POPULAR_COMPANY_ALIASES).forEach(k => LOCAL_VALID_TICKER_REGISTRY.add(k.toUpperCase()));

export interface TickerValidationResult {
  isValid: boolean;
  isKnown: boolean;
  normalizedSymbol: string;
  warning?: string;
  suggestion?: string;
  errorType?: 'INVALID_CHARS' | 'EMPTY' | 'UNRECOGNIZED' | 'BROKER_FORMAT_RISK' | 'UNUSUAL_LENGTH';
}

/**
 * Calculates Levenshtein distance for fuzzy matching typos
 */
function levenshtein(a: string, b: string): number {
  const an = a.length;
  const bn = b.length;
  if (an === 0) return bn;
  if (bn === 0) return an;
  const matrix = Array.from({ length: bn + 1 }, (_, i) => [i]);
  for (let j = 0; j <= an; j++) matrix[0][j] = j;

  for (let i = 1; i <= bn; i++) {
    for (let j = 1; j <= an; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1,     // insertion
          matrix[i - 1][j] + 1      // deletion
        );
      }
    }
  }
  return matrix[bn][an];
}

/**
 * Finds the closest known ticker symbol for potential typos
 */
export function findClosestValidTicker(query: string): string | null {
  const clean = query.trim().toUpperCase().replace(/[\s\-_]/g, '');
  if (clean.length < 3) return null;

  let bestMatch: string | null = null;
  let minDistance = 3; // Maximum allowed distance

  for (const ticker of LOCAL_VALID_TICKER_REGISTRY) {
    if (ticker.includes('|') || ticker.startsWith('^') || ticker.includes('=')) continue;
    const cleanTicker = ticker.replace(/[\s\-_]/g, '');
    
    // Direct substring match priority
    if (cleanTicker.includes(clean) || clean.includes(cleanTicker)) {
      if (Math.abs(cleanTicker.length - clean.length) <= 3) {
        return ticker;
      }
    }

    const dist = levenshtein(clean, cleanTicker);
    if (dist < minDistance) {
      minDistance = dist;
      bestMatch = ticker;
    }
  }

  return bestMatch;
}

/**
 * Client-Side Validation Layer
 * Cross-references the user's input with the local list of valid ticker symbols
 * before hitting provider APIs, flagging formats that are likely to cause 400 Bad Request errors.
 */
export function validateTickerSymbol(
  input: string,
  providerConfig?: ProviderFetchConfig
): TickerValidationResult {
  const raw = (input || '').trim();

  // 1. Empty Check
  if (!raw) {
    return {
      isValid: false,
      isKnown: false,
      normalizedSymbol: 'RELIANCE',
      errorType: 'EMPTY',
      warning: 'Please enter a stock symbol or company name before fetching.'
    };
  }

  // 2. Strict Illegal Character Detection (Guaranteed to cause 400 on external APIs)
  // Allowed characters: A-Z, 0-9, spaces, '.', '-', '&', '^' (indices), '=', '|' (ISIN keys)
  const illegalCharRegex = /[^a-zA-Z0-9\s.\-&^=|]/;
  if (illegalCharRegex.test(raw)) {
    const invalidChars = raw.match(/[^a-zA-Z0-9\s.\-&^=|]/g)?.join(' ') || '';
    return {
      isValid: false,
      isKnown: false,
      normalizedSymbol: normalizeSymbol(raw.replace(/[^a-zA-Z0-9\s.\-&^=|]/g, '')),
      errorType: 'INVALID_CHARS',
      warning: `Input contains invalid characters [${invalidChars}] that trigger HTTP 400 (Bad Request). Please use alphanumeric tickers like RELIANCE, TATAMOTORS, or NIFTY 50.`
    };
  }

  // 3. Length Boundaries
  if (raw.length > 35) {
    return {
      isValid: false,
      isKnown: false,
      normalizedSymbol: normalizeSymbol(raw.slice(0, 30)),
      errorType: 'UNUSUAL_LENGTH',
      warning: 'Symbol length exceeds 35 characters and will likely be rejected with a 400 error.'
    };
  }

  const normalized = (raw.includes('.') || raw.startsWith('^') || raw.includes('='))
    ? raw.trim().toUpperCase()
    : normalizeSymbol(raw);

  const cleanNoExchange = normalized
    .replace(/\.NS$/i, '')
    .replace(/\.BO$/i, '')
    .trim();

  // 4. Broker / Upstox API Specific Validation
  if (providerConfig?.provider === 'custom_api') {
    const isUpstox = providerConfig.customUrl?.includes('api.upstox.com') || providerConfig.customApiName?.toLowerCase().includes('upstox');
    if (isUpstox) {
      if (raw.includes(':') || raw.includes('/') || (raw.includes('|') && !raw.startsWith('NSE_') && !raw.startsWith('BSE_') && !raw.startsWith('MCX_'))) {
        return {
          isValid: true,
          isKnown: false,
          normalizedSymbol: normalized,
          errorType: 'BROKER_FORMAT_RISK',
          warning: `Warning: "${raw}" format is invalid for Upstox API v2 and will trigger a 400 error. Normalizing to clean instrument key...`
        };
      }
    }
  }

  // 5. Cross-reference with Local Verified Registry
  const isDirectlyKnown = LOCAL_VALID_TICKER_REGISTRY.has(normalized) ||
    LOCAL_VALID_TICKER_REGISTRY.has(cleanNoExchange) ||
    LOCAL_VALID_TICKER_REGISTRY.has(raw.toUpperCase());

  if (isDirectlyKnown) {
    return {
      isValid: true,
      isKnown: true,
      normalizedSymbol: normalized
    };
  }

  // 6. If not directly known, check for common typo / recommendation
  const suggestion = findClosestValidTicker(cleanNoExchange);

  // If the symbol has a standard exchange suffix (.NS / .BO) or is a valid alphanumeric ticker, allow with warning notice
  const isStandardTickerPattern = /^[A-Z0-9\-&]+(\.NS|\.BO)?$/i.test(normalized);

  if (isStandardTickerPattern) {
    return {
      isValid: true,
      isKnown: false,
      normalizedSymbol: normalized,
      suggestion: suggestion || undefined,
      warning: suggestion && suggestion.toUpperCase() !== cleanNoExchange
        ? `Symbol "${cleanNoExchange}" is not in local registry. Did you mean "${suggestion}"? (Resolving via live market feed)`
        : undefined
    };
  }

  // Unrecognized pattern
  return {
    isValid: true,
    isKnown: false,
    normalizedSymbol: normalized,
    suggestion: suggestion || undefined,
    errorType: 'UNRECOGNIZED',
    warning: `Unverified symbol format "${raw}". Will attempt live exchange resolution.`
  };
}
