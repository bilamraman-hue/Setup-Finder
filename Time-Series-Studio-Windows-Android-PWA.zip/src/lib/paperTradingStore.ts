import { persistLocalDatabase } from './localDatabase';

export interface VirtualPosition {
  id: string;
  symbol: string;
  name: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  stopLoss: number;
  target1: number;
  target2: number;
  entryTime: string;
  closeTime?: string;
  status: 'OPEN' | 'TARGET1_HIT' | 'TARGET2_HIT' | 'STOPPED_OUT' | 'MANUALLY_CLOSED';
  pnl: number;
  pnlPct: number;
  feesPaid: number;
  scoreAtEntry: number;
}

export interface PaperPortfolio {
  virtualCash: number;
  initialCash: number;
  positions: VirtualPosition[];
  closedTrades: VirtualPosition[];
  totalFeesPaid: number;
  realizedPnl: number;
}

const STORAGE_KEY = 'timesfm_paper_portfolio_v2';
const DEFAULT_INITIAL_CASH = 1000000; // ₹10,00,000
const TRANSACTION_FEE_PCT = 0.03; // 0.03% Brokerage + STT + Turnover charges

let inMemoryPortfolio: PaperPortfolio | null = null;

export function getPaperPortfolio(): PaperPortfolio {
  if (inMemoryPortfolio) {
    return inMemoryPortfolio;
  }

  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        inMemoryPortfolio = JSON.parse(raw);
        return inMemoryPortfolio!;
      }
    }
  } catch (e) {
    console.warn('Failed to load paper portfolio:', e);
  }

  inMemoryPortfolio = {
    virtualCash: DEFAULT_INITIAL_CASH,
    initialCash: DEFAULT_INITIAL_CASH,
    positions: [],
    closedTrades: [],
    totalFeesPaid: 0,
    realizedPnl: 0
  };
  return inMemoryPortfolio;
}

export function savePaperPortfolio(portfolio: PaperPortfolio): void {
  inMemoryPortfolio = portfolio;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(portfolio));
    }
    persistLocalDatabase();
  } catch (e) {
    console.warn('Failed to save paper portfolio:', e);
  }
}

export function openVirtualTrade(params: {
  symbol: string;
  name: string;
  direction: 'LONG' | 'SHORT';
  entryPrice: number;
  quantity: number;
  stopLoss: number;
  target1: number;
  target2: number;
  score: number;
}): VirtualPosition | null {
  const portfolio = getPaperPortfolio();
  const tradeTurnover = params.entryPrice * params.quantity;
  const entryFee = Math.round(tradeTurnover * (TRANSACTION_FEE_PCT / 100) * 100) / 100;
  const totalCost = tradeTurnover + entryFee;

  if (portfolio.virtualCash < totalCost) {
    const affordableQty = Math.floor((portfolio.virtualCash * 0.999) / params.entryPrice);
    if (affordableQty <= 0) return null;
    params.quantity = affordableQty;
  }

  const finalTurnover = params.entryPrice * params.quantity;
  const finalFee = Math.round(finalTurnover * (TRANSACTION_FEE_PCT / 100) * 100) / 100;

  const newPosition: VirtualPosition = {
    id: `pos-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    symbol: params.symbol,
    name: params.name,
    direction: params.direction,
    entryPrice: params.entryPrice,
    currentPrice: params.entryPrice,
    quantity: params.quantity,
    stopLoss: params.stopLoss,
    target1: params.target1,
    target2: params.target2,
    entryTime: new Date().toISOString(),
    status: 'OPEN',
    pnl: -finalFee,
    pnlPct: 0,
    feesPaid: finalFee,
    scoreAtEntry: params.score
  };

  portfolio.virtualCash -= (finalTurnover + finalFee);
  portfolio.totalFeesPaid += finalFee;
  portfolio.positions.unshift(newPosition);
  savePaperPortfolio(portfolio);

  return newPosition;
}

export function updatePositionPrices(currentQuotes: Record<string, number>): PaperPortfolio {
  const portfolio = getPaperPortfolio();
  let changed = false;

  const remainingPositions: VirtualPosition[] = [];

  for (const pos of portfolio.positions) {
    const livePrice = currentQuotes[pos.symbol] ?? pos.currentPrice;
    pos.currentPrice = livePrice;

    const exitTurnover = livePrice * pos.quantity;
    const exitFee = Math.round(exitTurnover * (TRANSACTION_FEE_PCT / 100) * 100) / 100;

    if (pos.direction === 'LONG') {
      const grossPnl = (livePrice - pos.entryPrice) * pos.quantity;
      pos.pnl = Math.round((grossPnl - pos.feesPaid - exitFee) * 100) / 100;
      pos.pnlPct = Math.round(((livePrice - pos.entryPrice) / pos.entryPrice) * 1000) / 10;

      // Check SL
      if (livePrice <= pos.stopLoss) {
        pos.status = 'STOPPED_OUT';
        pos.closeTime = new Date().toISOString();
        pos.feesPaid += exitFee;
        portfolio.virtualCash += (exitTurnover - exitFee);
        portfolio.totalFeesPaid += exitFee;
        portfolio.realizedPnl += pos.pnl;
        portfolio.closedTrades.unshift(pos);
        changed = true;
        continue;
      }
      // Check Target 2
      if (livePrice >= pos.target2) {
        pos.status = 'TARGET2_HIT';
        pos.closeTime = new Date().toISOString();
        pos.feesPaid += exitFee;
        portfolio.virtualCash += (exitTurnover - exitFee);
        portfolio.totalFeesPaid += exitFee;
        portfolio.realizedPnl += pos.pnl;
        portfolio.closedTrades.unshift(pos);
        changed = true;
        continue;
      }
      // Check Target 1
      if (livePrice >= pos.target1 && pos.status === 'OPEN') {
        pos.status = 'TARGET1_HIT';
        changed = true;
      }
    } else {
      // SHORT
      const grossPnl = (pos.entryPrice - livePrice) * pos.quantity;
      pos.pnl = Math.round((grossPnl - pos.feesPaid - exitFee) * 100) / 100;
      pos.pnlPct = Math.round(((pos.entryPrice - livePrice) / pos.entryPrice) * 1000) / 10;

      if (livePrice >= pos.stopLoss) {
        pos.status = 'STOPPED_OUT';
        pos.closeTime = new Date().toISOString();
        pos.feesPaid += exitFee;
        portfolio.virtualCash += (pos.entryPrice * pos.quantity + grossPnl - exitFee);
        portfolio.totalFeesPaid += exitFee;
        portfolio.realizedPnl += pos.pnl;
        portfolio.closedTrades.unshift(pos);
        changed = true;
        continue;
      }

      if (livePrice <= pos.target2) {
        pos.status = 'TARGET2_HIT';
        pos.closeTime = new Date().toISOString();
        pos.feesPaid += exitFee;
        portfolio.virtualCash += (pos.entryPrice * pos.quantity + grossPnl - exitFee);
        portfolio.totalFeesPaid += exitFee;
        portfolio.realizedPnl += pos.pnl;
        portfolio.closedTrades.unshift(pos);
        changed = true;
        continue;
      }

      if (livePrice <= pos.target1 && pos.status === 'OPEN') {
        pos.status = 'TARGET1_HIT';
        changed = true;
      }
    }

    remainingPositions.push(pos);
  }

  portfolio.positions = remainingPositions;
  if (changed) {
    savePaperPortfolio(portfolio);
  }

  return portfolio;
}

export function closeVirtualTrade(positionId: string): PaperPortfolio {
  const portfolio = getPaperPortfolio();
  const index = portfolio.positions.findIndex(p => p.id === positionId);
  if (index >= 0) {
    const pos = portfolio.positions[index];
    pos.status = 'MANUALLY_CLOSED';
    pos.closeTime = new Date().toISOString();

    const exitTurnover = pos.currentPrice * pos.quantity;
    const exitFee = Math.round(exitTurnover * (TRANSACTION_FEE_PCT / 100) * 100) / 100;
    pos.feesPaid += exitFee;

    const grossPnl = pos.direction === 'LONG'
      ? (pos.currentPrice - pos.entryPrice) * pos.quantity
      : (pos.entryPrice - pos.currentPrice) * pos.quantity;

    pos.pnl = Math.round((grossPnl - pos.feesPaid) * 100) / 100;
    
    // Return capital + net PnL
    portfolio.virtualCash += (pos.entryPrice * pos.quantity) + pos.pnl;
    portfolio.totalFeesPaid += exitFee;
    portfolio.realizedPnl += pos.pnl;
    portfolio.closedTrades.unshift(pos);
    portfolio.positions.splice(index, 1);
    
    savePaperPortfolio(portfolio);
  }
  return portfolio;
}

export function resetPaperPortfolio(): PaperPortfolio {
  const fresh: PaperPortfolio = {
    virtualCash: DEFAULT_INITIAL_CASH,
    initialCash: DEFAULT_INITIAL_CASH,
    positions: [],
    closedTrades: [],
    totalFeesPaid: 0,
    realizedPnl: 0
  };
  inMemoryPortfolio = fresh;
  savePaperPortfolio(fresh);
  return fresh;
}
