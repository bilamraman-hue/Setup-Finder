import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface DecodedFirebaseToken {
  uid: string;
  email?: string;
  name?: string;
  picture?: string;
  iss: string;
  aud: string;
  sub: string;
  exp: number;
  iat: number;
  auth_time?: number;
}

// Load Firebase Project ID
let firebaseProjectId = 'praxis-racer-zxfb9';
try {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    const raw = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    if (raw.projectId) {
      firebaseProjectId = raw.projectId;
    }
  }
} catch (err) {
  console.warn('Could not read firebase-applet-config.json:', err);
}

// In-memory cache for Google public x509 certificates
let cachedCertificates: Record<string, string> = {};
let certificatesExpiresAt = 0;

async function fetchGooglePublicCertificates(): Promise<Record<string, string>> {
  const now = Date.now();
  if (Object.keys(cachedCertificates).length > 0 && now < certificatesExpiresAt) {
    return cachedCertificates;
  }

  const certUrl = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
  const res = await fetch(certUrl, {
    headers: { 'User-Agent': 'TimesFM-AuthVerifier/1.0' },
    signal: AbortSignal.timeout(5000)
  });

  if (!res.ok) {
    throw new Error(`Failed to fetch Google public certificates: HTTP ${res.status}`);
  }

  const cacheControl = res.headers.get('cache-control') || '';
  const maxAgeMatch = cacheControl.match(/max-age=(\d+)/i);
  const maxAgeSeconds = maxAgeMatch ? parseInt(maxAgeMatch[1], 10) : 3600;

  cachedCertificates = await res.json();
  certificatesExpiresAt = now + maxAgeSeconds * 1000;
  return cachedCertificates;
}

/**
 * Cryptographically verifies and validates a Firebase ID token.
 * 1. Checks algorithm is RS256
 * 2. Matches kid to Google's public x509 certificates
 * 3. Verifies RSA-SHA256 signature
 * 4. Checks expiration, issued-at, issuer, and audience
 */
export async function verifyFirebaseIdToken(token: string): Promise<DecodedFirebaseToken> {
  if (!token || typeof token !== 'string') {
    throw new Error('Token is required');
  }

  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('Malformed JWT token: expected 3 dot-separated segments');
  }

  const [headerB64, payloadB64, signatureB64] = parts;

  // 1. Decode header
  let header: { alg: string; kid: string; typ?: string };
  try {
    const rawHeader = Buffer.from(headerB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
    header = JSON.parse(rawHeader);
  } catch {
    throw new Error('Failed to parse token header');
  }

  if (header.alg !== 'RS256') {
    throw new Error(`Invalid token algorithm: ${header.alg}. Expected RS256.`);
  }

  if (!header.kid) {
    throw new Error('Token header is missing key ID (kid)');
  }

  // 2. Decode payload
  let payload: DecodedFirebaseToken;
  try {
    const rawPayload = Buffer.from(payloadB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
    payload = JSON.parse(rawPayload);
  } catch {
    throw new Error('Failed to parse token payload');
  }

  // 3. Retrieve Google certificates and verify RSA signature
  const certs = await fetchGooglePublicCertificates();
  const publicCert = certs[header.kid];
  if (!publicCert) {
    throw new Error(`Public key not found for kid: ${header.kid}`);
  }

  const signedContent = `${headerB64}.${payloadB64}`;
  const signatureBuffer = Buffer.from(signatureB64.replace(/-/g, '+').replace(/_/g, '/'), 'base64');

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(signedContent);
  const isValidSignature = verifier.verify(publicCert, signatureBuffer);

  if (!isValidSignature) {
    throw new Error('Cryptographic signature verification failed for Firebase ID token');
  }

  // 4. Validate Claims
  const nowSeconds = Math.floor(Date.now() / 1000);

  // Check expiration (with 10-second clock skew allowance)
  if (!payload.exp || payload.exp < nowSeconds - 10) {
    throw new Error('Firebase ID token has expired');
  }

  // Check issued at (not issued in the future, with 60s skew allowance)
  if (!payload.iat || payload.iat > nowSeconds + 60) {
    throw new Error('Firebase ID token issued in the future');
  }

  // Check issuer
  const expectedIss = `https://securetoken.google.com/${firebaseProjectId}`;
  if (payload.iss !== expectedIss) {
    throw new Error(`Invalid token issuer. Expected ${expectedIss}, got ${payload.iss}`);
  }

  // Check audience
  if (payload.aud !== firebaseProjectId) {
    throw new Error(`Invalid token audience. Expected ${firebaseProjectId}, got ${payload.aud}`);
  }

  // Ensure subject (UID) exists
  if (!payload.sub || typeof payload.sub !== 'string') {
    throw new Error('Missing sub claim in token');
  }

  return {
    ...payload,
    uid: payload.sub
  };
}
