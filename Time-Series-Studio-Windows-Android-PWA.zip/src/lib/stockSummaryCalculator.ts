import {
  TimeSeriesPoint,
  ForecastPoint,
  TradingMetrics,
  StockSummaryReportData,
  TargetLevel,
  StrictStoploss,
  HistoricalDataSpan,
  EntryLevelGuide,
  TradeActionVerdict
} from '../types';

/**
 * Calculates a comprehensive Institutional Stock Summary & Price Target Report:
 * 1. Historical Data Span Used for Calculation (Months/Years, Candles, Date Range)
 * 2. Rule-based targets derived from forecasts and observed volatility
 * 3. Perfect Entry Levels (Ideal Buy Zone, Aggressive CMP, Conservative Pullback Dip, Breakout Trigger)
 * 4. Strict Exit Levels & Time Expected for each target with dynamic Trailing Stoploss
 * 5. Action Verdict: TRADE NOW vs. WAIT FOR DIP / BREAKOUT vs. AVOID / HIGH RISK
 */
export function calculateStockSummaryReport(params: {
  symbol: string;
  name: string;
  unit?: string;
  history: TimeSeriesPoint[];
  forecasts: ForecastPoint[];
  tradingMetrics?: TradingMetrics;
  frequency?: string;
  overrideDirection?: 'BULLISH' | 'BEARISH';
}): StockSummaryReportData {
  const {
    symbol,
    name,
    unit = 'INR (₹)',
    history,
    forecasts,
    tradingMetrics,
    frequency = 'daily',
    overrideDirection
  } = params;

  const currSym = unit.includes('INR') || unit.includes('₹') ? '₹' : unit.includes('USD') || unit.includes('$') ? '$' : '₹';

  const nHist = history.length;
  if (nHist < 2) {
    throw new Error('At least two valid historical price observations are required to create a stock summary.');
  }
  const lastPoint = history[nHist - 1] || { value: 100, timestamp: new Date().toISOString() };
  const firstPoint = history[0] || { value: 100, timestamp: new Date().toISOString() };
  const prevPoint = nHist >= 2 ? history[nHist - 2] : null;

  const cmp = lastPoint.value || 100;
  const prevClose = prevPoint ? prevPoint.value : cmp;
  const changeAmount = Math.round((cmp - prevClose) * 100) / 100;
  const changePct = prevClose > 0 ? Math.round(((cmp - prevClose) / prevClose) * 10000) / 100 : 0;

  // 1. Calculate Historical Data Span (Months/Years, Total Candles, Date Range)
  const formatShortDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      if (!isNaN(d.getTime())) {
        return d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
      }
    } catch {
      // pass
    }
    return dateStr;
  };

  const startDateFormatted = formatShortDate(firstPoint.timestamp);
  const endDateFormatted = formatShortDate(lastPoint.timestamp);

  let durationHuman = `${nHist} Candles`;
  try {
    const d1 = new Date(firstPoint.timestamp).getTime();
    const d2 = new Date(lastPoint.timestamp).getTime();
    if (!isNaN(d1) && !isNaN(d2) && d2 > d1) {
      const diffDays = Math.round((d2 - d1) / (1000 * 60 * 60 * 24));
      if (diffDays >= 365) {
        const years = Math.floor(diffDays / 365.25);
        const remMonths = Math.round((diffDays % 365.25) / 30.4);
        durationHuman = remMonths > 0
          ? `${years} ${years === 1 ? 'Year' : 'Years'} ${remMonths} ${remMonths === 1 ? 'Month' : 'Months'} (${nHist} Candles)`
          : `${years} ${years === 1 ? 'Year' : 'Years'} (${nHist} Candles)`;
      } else if (diffDays >= 30) {
        const months = Math.floor(diffDays / 30.4);
        const remDays = diffDays % 30;
        durationHuman = remDays > 5
          ? `${months} ${months === 1 ? 'Month' : 'Months'} ${remDays} Days (${nHist} Candles)`
          : `${months} ${months === 1 ? 'Month' : 'Months'} (${nHist} Candles)`;
      } else if (diffDays >= 1) {
        durationHuman = `${diffDays} Days (${nHist} Candles)`;
      } else {
        durationHuman = `Intraday Session (${nHist} Candles)`;
      }
    }
  } catch {
    durationHuman = `${nHist} Historical Data Points`;
  }

  const is15m = frequency.includes('15m') || frequency.includes('15min') || frequency.includes('minute') || frequency.includes('m');
  const isHourly = frequency.includes('hour') || frequency.includes('1h') || frequency.includes('h');
  const isWeekly = frequency.includes('week') || frequency.includes('1w') || frequency.includes('1wk');

  const freqName = is15m
    ? '15 Minutes (15M Intraday)'
    : isHourly
    ? 'Hourly (1H Intraday)'
    : isWeekly
    ? 'Weekly (1W Positional)'
    : 'Daily (1D Swing)';

  const historicalSpan: HistoricalDataSpan = {
    startDate: startDateFormatted,
    endDate: endDateFormatted,
    durationText: durationHuman,
    totalCandles: nHist,
    frequency: freqName,
    providerName: symbol.includes('^') || symbol.includes('NIFTY') || symbol.includes('SENSEX')
      ? 'National Stock Exchange (NSE Benchmark)'
      : 'Live Multi-Source Market Stream'
  };

  // 2. Realistic local statistical baseline Predictions & Direction based on loaded candles
  const hasForecast = forecasts.length > 0;
  const nFore = Math.max(1, forecasts.length);
  const finalForecast = forecasts[nFore - 1] || { p50: cmp, p10: cmp, p90: cmp, p25: cmp, p75: cmp, timestamp: '' };

  const rawProjectedReturn = ((finalForecast.p50 - cmp) / cmp) * 100;
  const direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = overrideDirection
    ? overrideDirection
    : !hasForecast
    ? 'NEUTRAL'
    : rawProjectedReturn >= 0.4
    ? 'BULLISH'
    : rawProjectedReturn <= -0.4
    ? 'BEARISH'
    : 'NEUTRAL';

  const isBullish = direction === 'BULLISH';

  // Compute empirical candle-by-candle True Range directly from loaded historical candles
  let candleTrSum = 0;
  let candleTrCount = 0;
  for (let i = 1; i < nHist; i++) {
    const cur = history[i];
    const prev = history[i - 1];
    const high = cur.high ?? cur.value;
    const low = cur.low ?? cur.value;
    const tr = Math.max(high - low, Math.abs(high - prev.value), Math.abs(low - prev.value));
    candleTrSum += tr;
    candleTrCount++;
  }
  const avgCandleTr = candleTrCount > 0 ? candleTrSum / candleTrCount : 0;
  const candleVolatilityPct = (avgCandleTr / Math.max(1e-4, cmp)) * 100;

  // Use observed candle true ranges without timeframe-based floors or caps.
  const atrPct = candleVolatilityPct;

  const atrAmount = (cmp * atrPct) / 100;

  // Horizon steps for targets
  const h1Step = Math.max(1, Math.min(nFore, Math.round(nFore * 0.20)));
  const h2Step = Math.max(h1Step + 1, Math.min(nFore, Math.round(nFore * 0.55)));
  const h3Step = nFore;

  const f1 = forecasts[h1Step - 1] || { p50: cmp * (isBullish ? 1.018 : 0.982), timestamp: '' };
  const f2 = forecasts[h2Step - 1] || { p50: cmp * (isBullish ? 1.048 : 0.952), timestamp: '' };
  const f3 = finalForecast;

  // Format forecast date helper
  const formatDateStr = (rawDateStr?: string, defaultDays?: number) => {
    if (rawDateStr && (rawDateStr.includes('-') || rawDateStr.includes('/') || rawDateStr.includes(':'))) {
      try {
        const d = new Date(rawDateStr);
        if (!isNaN(d.getTime())) {
          return is15m || isHourly
            ? `${d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} ${d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`
            : d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
        }
      } catch {
        // pass
      }
    }
    const future = new Date();
    future.setDate(future.getDate() + (defaultDays || 5));
    return future.toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const t1Date = formatDateStr(f1.timestamp, is15m ? 1 : isHourly ? 1 : Math.max(1, h1Step));
  const t2Date = formatDateStr(f2.timestamp, is15m ? 1 : isHourly ? 3 : Math.max(3, h2Step));
  const t3Date = formatDateStr(f3.timestamp, is15m ? 1 : isHourly ? 6 : Math.max(7, h3Step));

  // --- TARGET 1: QUICK MOMENTUM HURDLE ---
  let t1Price: number;
  let t1Timeframe = is15m
    ? `30 to 60 Minutes (2–4 candles of 15m)`
    : isHourly
    ? `2 to 4 Hours (by ${t1Date})`
    : isWeekly
    ? `1 to 2 Weeks (by ${t1Date})`
    : `1 to 3 Trading Days (by ${t1Date})`;

  t1Price = hasForecast ? f1.p50 : cmp;
  t1Price = Math.round(t1Price * 100) / 100;
  const t1ReturnPct = Math.round(((t1Price - cmp) / cmp) * 10000) / 100;

  const targetOne: TargetLevel = {
    label: is15m ? 'Target 1 (T1) — 15m Momentum Hurdle' : 'Target 1 (T1) — Initial Momentum Hurdle',
    targetPrice: t1Price,
    returnPct: t1ReturnPct,
    estimatedSteps: h1Step,
    timeframeText: t1Timeframe,
    estimatedDate: t1Date,
    description: isBullish
      ? `Primary immediate resistance derived from local statistical baseline short-horizon step with ${nHist} candle back-data confirmation.`
      : `Immediate breakdown hurdle derived from local statistical baseline short-horizon step with ${nHist} candle back-data confirmation.`,
    exitStrategy: 'Book 40%–50% profit at T1 and immediately move Stoploss to Cost Price (Break-Even).'
  };

  // --- TARGET 2: PRIMARY TIMESFM MEDIAN TARGET ---
  let t2Price: number;
  let t2Timeframe = is15m
    ? `1.5 to 3 Hours (6–12 candles of 15m)`
    : isHourly
    ? `1 to 2 Trading Days (by ${t2Date})`
    : isWeekly
    ? `3 to 6 Weeks (by ${t2Date})`
    : `4 to 8 Trading Days (by ${t2Date})`;

  t2Price = hasForecast ? f2.p50 : cmp;
  t2Price = Math.round(t2Price * 100) / 100;
  const t2ReturnPct = Math.round(((t2Price - cmp) / cmp) * 10000) / 100;

  const targetTwo: TargetLevel = {
    label: is15m ? 'Target 2 (T2) — 15m Core Median Target' : 'Target 2 (T2) — local statistical baseline Core Median Target',
    targetPrice: t2Price,
    returnPct: t2ReturnPct,
    estimatedSteps: h2Step,
    timeframeText: t2Timeframe,
    estimatedDate: t2Date,
    description: isBullish
      ? `local statistical baseline p50 median trajectory target grounded on ${nHist} candle historical context.`
      : `local statistical baseline p50 median short target grounded on ${nHist} candle historical context.`,
    exitStrategy: 'Book 30%–40% additional profit at T2. Trail remaining balance with 20-period EMA / 1.5 ATR.'
  };

  // --- TARGET 3: EXTENDED SWING CONTINUATION ---
  let t3Price: number;
  let t3Timeframe = is15m
    ? `End of Day Session / Intraday Peak Extension`
    : isHourly
    ? `3 to 5 Trading Days (by ${t3Date})`
    : isWeekly
    ? `2 to 3 Months (by ${t3Date})`
    : `10 to 18 Trading Days (by ${t3Date})`;

  t3Price = hasForecast ? f3.p50 : cmp;
  t3Price = Math.round(t3Price * 100) / 100;
  const t3ReturnPct = Math.round(((t3Price - cmp) / cmp) * 10000) / 100;

  const targetThree: TargetLevel = {
    label: is15m ? 'Target 3 (T3) — Intraday Extended Target' : 'Target 3 (T3) — Upper Quantile Swing Extension',
    targetPrice: t3Price,
    returnPct: t3ReturnPct,
    estimatedSteps: h3Step,
    timeframeText: t3Timeframe,
    estimatedDate: t3Date,
    description: isBullish
      ? 'Upper estimated range (p75/p90 quantile-style estimate). Captures full extended trend continuation.'
      : 'Lower estimated range (p25/p10 quantile floor). Full bearish wave exhaustion target.',
    exitStrategy: 'Complete trade exit at T3 or trail closely with tight 1.0 ATR trailing stop.'
  };

  // --- 3. PERFECT ENTRY LEVELS ---
  let idealEntryMin: number;
  let idealEntryMax: number;
  let aggressiveEntry: number;
  let conservativePullbackEntry: number;
  let breakoutTriggerLevel: number;
  let entryStrategyText: string;

  if (isBullish) {
    idealEntryMin = Math.round((cmp - atrAmount * 0.45) * 100) / 100;
    idealEntryMax = Math.round((cmp + atrAmount * 0.15) * 100) / 100;
    aggressiveEntry = cmp;
    conservativePullbackEntry = Math.round((cmp - atrAmount * 0.75) * 100) / 100;
    breakoutTriggerLevel = Math.round((cmp + atrAmount * 0.5) * 100) / 100;
    entryStrategyText = `Optimal buy zone between ${currSym}${idealEntryMin.toLocaleString('en-IN')} – ${currSym}${idealEntryMax.toLocaleString('en-IN')}. Enter 60% at current levels, reserving 40% for pullback dips near ${currSym}${conservativePullbackEntry.toLocaleString('en-IN')}.`;
  } else {
    idealEntryMin = Math.round((cmp - atrAmount * 0.15) * 100) / 100;
    idealEntryMax = Math.round((cmp + atrAmount * 0.45) * 100) / 100;
    aggressiveEntry = cmp;
    conservativePullbackEntry = Math.round((cmp + atrAmount * 0.75) * 100) / 100;
    breakoutTriggerLevel = Math.round((cmp - atrAmount * 0.5) * 100) / 100;
    entryStrategyText = `Optimal short zone between ${currSym}${idealEntryMin.toLocaleString('en-IN')} – ${currSym}${idealEntryMax.toLocaleString('en-IN')}. Enter on test of recent breakdown pivot.`;
  }

  const entryGuide: EntryLevelGuide = {
    idealEntryRange: `${currSym}${idealEntryMin.toLocaleString('en-IN', { minimumFractionDigits: 2 })} – ${currSym}${idealEntryMax.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
    idealEntryMin,
    idealEntryMax,
    aggressiveEntry,
    conservativePullbackEntry,
    breakoutTriggerLevel,
    entryStrategyText
  };

  // --- 4. STRICT STOPLOSS ---
  let slPrice: number;
  let supportBasisText: string;

  if (isBullish) {
    const atrStop = cmp - (atrAmount * 1.5);
    const p10Stop = hasForecast && Number.isFinite(f1.p10) ? f1.p10 : atrStop;
    slPrice = Math.min(atrStop, p10Stop);
    supportBasisText = `Positioned at 1.5× ATR volatility floor below recent swing low with local statistical baseline p10 quantile support.`;
  } else {
    const atrStop = cmp + (atrAmount * 1.5);
    const p90Stop = hasForecast && Number.isFinite(f1.p90) ? f1.p90 : atrStop;
    slPrice = Math.max(atrStop, p90Stop);
    supportBasisText = `Positioned at 1.5× ATR volatility resistance ceiling above recent swing high.`;
  }
  slPrice = Math.round(slPrice * 100) / 100;
  const riskAmount = Math.round(Math.abs(cmp - slPrice) * 100) / 100;
  const riskPct = Math.round((riskAmount / cmp) * 10000) / 100;

  // Risk to Reward Ratio (based on Target 2 vs SL)
  const rewardAmount = Math.abs(t2Price - cmp);
  const rrr = riskAmount > 0 ? Math.round((rewardAmount / riskAmount) * 10) / 10 : 0;

  const strictStoploss: StrictStoploss = {
    stoplossPrice: slPrice,
    riskPct,
    riskAmount,
    supportBasis: supportBasisText,
    riskRewardRatio: rrr,
    trailingRule: isBullish
      ? `Strict invalidation exit on daily candle closing below ${currSym}${slPrice.toLocaleString('en-IN')}. Once Target 1 is achieved, immediately move stoploss to Entry Price (${currSym}${cmp.toLocaleString('en-IN')}). Trail behind 20-day SMA for Target 2 & Target 3.`
      : `Strict invalidation exit on daily candle closing above ${currSym}${slPrice.toLocaleString('en-IN')}. Move stoploss to Break-Even at Target 1.`,
    maxCapitalRiskPct: 1.5
  };

  // --- 5. ACTION VERDICT: TRADE NOW vs. WAIT FOR DIP vs. WAIT FOR BREAKOUT vs. AVOID ---
  const rsiVal = tradingMetrics?.rsi14;
  let actionRecommendation: TradeActionVerdict = 'TRADE_NOW';
  let actionBadgeText = 'TRADE NOW — FAVORABLE SETUP';
  let actionReason = '';

  if (!hasForecast) {
    actionRecommendation = 'AVOID_HIGH_RISK';
    actionBadgeText = 'NO FORECAST DATA — AVOID';
    actionReason = 'No forecast points were supplied. Targets and forecast probabilities are unavailable; provide a forecast before evaluating a trade.';
  } else if (rrr < 1.3 || (isBullish && t2ReturnPct < 1.2) || (!isBullish && t2ReturnPct > -1.2)) {
    actionRecommendation = 'AVOID_HIGH_RISK';
    actionBadgeText = 'AVOID — UNFAVORABLE RISK/REWARD';
    actionReason = `Risk-Reward ratio (${rrr}:1) is below institutional threshold (1.5:1). Downside risk of ${currSym}${riskAmount} (${riskPct}%) outweighs anticipated return. Preserve capital.`;
  } else if (isBullish && rsiVal !== undefined && rsiVal > 72) {
    actionRecommendation = 'WAIT_FOR_DIP';
    actionBadgeText = 'WAIT FOR DIP (OVERBOUGHT)';
    actionReason = `RSI(14) at ${rsiVal} indicates short-term overbought exhaustion. Avoid buying the peak; wait for a healthy pullback into the ideal buy zone (${entryGuide.idealEntryRange}) or near ${currSym}${conservativePullbackEntry.toLocaleString('en-IN')}.`;
  } else if (!isBullish && rsiVal !== undefined && rsiVal < 28) {
    actionRecommendation = 'WAIT_FOR_DIP';
    actionBadgeText = 'WAIT FOR BOUNCE (OVERSOLD)';
    actionReason = `RSI(14) at ${rsiVal} is heavily oversold. Avoid fresh shorting at the bottom; wait for a relief rally into resistance before initiating shorts.`;
  } else if (Math.abs(cmp - aggressiveEntry) <= atrAmount * 0.35 && rrr >= 1.6) {
    actionRecommendation = 'TRADE_NOW';
    actionBadgeText = 'TRADE NOW — HIGH PROBABILITY';
    actionReason = `local statistical baseline 3.0 confirms strong ${direction.toLowerCase()} alignment with favorable 1:${rrr} Risk-Reward. Price is actively within the optimal entry zone with Target 1 at ${currSym}${t1Price.toLocaleString('en-IN')} and Target 2 at ${currSym}${t2Price.toLocaleString('en-IN')}.`;
  } else {
    actionRecommendation = 'WAIT_FOR_BREAKOUT';
    actionBadgeText = 'WAIT FOR BREAKOUT CONFIRMATION';
    actionReason = `Asset is consolidating near pivot. Enter on confirmed candle close above ${currSym}${breakoutTriggerLevel.toLocaleString('en-IN')} with volume confirmation, or buy dips near ${currSym}${idealEntryMin.toLocaleString('en-IN')}.`;
  }

  const signal = tradingMetrics?.signal || (isBullish ? 'BUY' : 'SELL');

  const summaryNote = `${symbol} (${durationHuman} from ${startDateFormatted} to ${endDateFormatted}) trades at ${currSym}${cmp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}. local statistical baseline 3.0 forecast issues a ${direction.toUpperCase()} setup with action: ${actionBadgeText}. Ideal Entry Zone: ${entryGuide.idealEntryRange}. Target 1: ${currSym}${t1Price.toLocaleString('en-IN')} (${t1Timeframe}), Target 2: ${currSym}${t2Price.toLocaleString('en-IN')} (${t2Timeframe}), Target 3: ${currSym}${t3Price.toLocaleString('en-IN')} (${t3Timeframe}), with a Strict Stoploss at ${currSym}${slPrice.toLocaleString('en-IN')} (Risk: ${riskPct}% | R:R 1:${rrr}).`;

  return {
    symbol,
    name,
    unit,
    currencySymbol: currSym,
    currentMarketPrice: cmp,
    previousClose: prevClose,
    changePct,
    changeAmount,
    direction,
    signal,
    actionRecommendation,
    actionBadgeText,
    actionReason,
    historicalSpan,
    entryGuide,
    targetOne,
    targetTwo,
    targetThree,
    strictStoploss,
    forecastHorizonSteps: nFore,
    frequency,
    lastUpdated: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    summaryNote
  };
}
