import { WatchlistScanItem } from './watchlistStore';

export type SetupTimeframe = '5m' | '15m' | '1h' | '1d';

export interface TimeframeQualification {
  timeframe: SetupTimeframe;
  qualifiedAt: number;        // Timestamp when it qualified on this timeframe
  expiresAt: number;          // qualifiedAt + SETUP_TTL_MS[timeframe]
  ttlMs: number;
  setupGrade: string;         // 'GRADE_A' | 'GRADE_A_PLUS'
  gradeBadge: string;         // '⚡ Grade A' | '🌟 Grade A+'
  scorePct: number;
  confluenceScorePct: number;
  finalVerdict: string;
  direction: 'LONG' | 'SHORT';
  entryRange: { min: number; max: number; text: string };
  stopLoss: { price: number; pct: number };
  target1: { price: number; pct: number };
  target2: { price: number; pct: number };
  riskRewardText: string;
  status: string;
  optionsSuggestion?: string;
  sourceWatchlistId?: string;
  analysis?: {
    cmp: number;
    coreDriver?: string;
    actionTrigger?: string;
    timesfmResult?: WatchlistScanItem['timesfmResult'];
    quantEngineResult?: WatchlistScanItem['quantEngineResult'];
    smcIctResult?: WatchlistScanItem['smcIctResult'];
    marketFlow?: WatchlistScanItem['marketFlow'];
    volumeSpike?: WatchlistScanItem['volumeSpike'];
    verdictDirectionalScorePct?: number;
    verdictWeights?: WatchlistScanItem['verdictWeights'];
  };
}

export interface SetupScanChange {
  detectedAt: number;
  timeframe: SetupTimeframe;
  description: string;
}

export interface MySetupItem {
  id: string; // Unique per symbol: `setup_${symbol}`
  symbol: string;
  name: string;
  exchange: string;
  primaryTimeframe: SetupTimeframe;
  timeframe: SetupTimeframe; // Active/primary timeframe for backward compatibility
  // Map of all active qualified timeframes for this symbol
  timeframes: Partial<Record<SetupTimeframe, TimeframeQualification>>;
  // Convenience array of active qualified timeframes, e.g. ['5m', '15m']
  activeTimeframeList: SetupTimeframe[];
  // Overall most recent qualified timestamp across all timeframes
  qualifiedAt: number;
  // Furthest expiration timestamp among active timeframes
  expiresAt: number;
  ttlMs: number;
  cmp: number;
  prevClose: number;
  changePct: number;
  direction: 'LONG' | 'SHORT' | 'NEUTRAL';
  finalVerdict: string;
  setupGrade: string;
  gradeBadge: string;
  scorePct: number;
  confluenceScorePct: number;
  status: string;
  entryRange: { min: number; max: number; text: string };
  stopLoss: { price: number; pct: number };
  target1: { price: number; pct: number };
  target2: { price: number; pct: number };
  riskRewardText: string;
  optionsSuggestion?: string;
  timesfmResult?: any;
  quantEngineResult?: any;
  smcIctResult?: any;
  oiBuildupResult?: any;
  lastScannedWatchlistId?: string;
  scanChanges?: SetupScanChange[];
}

// Strict Time-To-Live (TTL) definitions as specified:
// 5m: 2 hours | 15m: 6 hours | 1h: 2 days (48h) | 1d: 5 days (120h)
export const SETUP_TTL_MS: Record<SetupTimeframe, number> = {
  '5m': 2 * 60 * 60 * 1000,          // 2 Hours
  '15m': 6 * 60 * 60 * 1000,         // 6 Hours
  '1h': 2 * 24 * 60 * 60 * 1000,     // 2 Days (48 Hours)
  '1d': 5 * 24 * 60 * 60 * 1000      // 5 Days (120 Hours)
};

export const SETUP_TTL_LABELS: Record<SetupTimeframe, string> = {
  '5m': '2 Hours',
  '15m': '6 Hours',
  '1h': '2 Days',
  '1d': '5 Days'
};

/**
 * Normalizes any timeframe string into strict SetupTimeframe ('5m' | '15m' | '1h' | '1d')
 */
export function normalizeSetupTimeframe(tf?: any): SetupTimeframe {
  if (!tf) return '15m';
  const clean = String(tf).toLowerCase().trim();
  if (clean.includes('5m')) return '5m';
  if (clean.includes('15m')) return '15m';
  if (clean.includes('1h') || clean.includes('60') || clean === 'hourly') return '1h';
  if (clean.includes('1d') || clean === 'daily' || clean === 'd') return '1d';
  return '15m';
}

/**
 * Normalizes any ticker symbol into clean uppercase symbol without .NS/.BO or exchange prefix
 */
export function normalizeSymbolKey(sym?: string): string {
  if (!sym) return '';
  return String(sym).trim().toUpperCase().replace(/\.NS$|\.BO$/i, '').replace(/^NSE:|^BSE:/i, '');
}

const STORAGE_KEY = 'timesfm_my_setups_v2';
const BACKUP_STORAGE_KEY = 'timesfm_my_setups_backup';
const LEGACY_STORAGE_KEY = 'timesfm_my_setups_v1';
const UPDATE_EVENT = 'timesfm:my_setups_updated';

// In-memory runtime cache ensuring zero data loss across re-renders or storage throttling
let inMemorySetupsCache: MySetupItem[] | null = null;

/**
 * Validates if an item qualifies strictly as a GRADE A / GRADE A+ trade setup.
 * Rule:
 * 1. Must be GRADE_A or GRADE_A_PLUS (Grade B and No Trade are strictly excluded).
 * 2. Final verdict must be directional BUY/ACCUMULATE or SELL/SHORT.
 * 3. It cannot be CONFLICT, AVOID, or NO TRADE.
 * 4. Confluence score must be at least 65%.
 */
export function isGradeAQualified(item: {
  setupGrade?: string;
  gradeBadge?: string;
  confluenceScorePct?: number;
  finalVerdict?: string;
  scorePct?: number;
  direction?: string;
  status?: string;
  cmp?: number;
}): boolean {
  if (!item) return false;
  const grade = String(item.setupGrade || '').toUpperCase();
  const badge = String(item.gradeBadge || '').toUpperCase();
  const verdict = String(item.finalVerdict || '').toUpperCase();
  const status = String(item.status || '').toUpperCase();

  // Explicit non-trade / conflict exclusions
  if (
    grade === 'NO_TRADE' ||
    badge.includes('NO TRADE') ||
    verdict.includes('CONFLICT') ||
    verdict.includes('AVOID') ||
    status === 'AVOID'
  ) {
    return false;
  }

  // Labels alone are insufficient: require an explicit Grade A/A+ classification,
  // a directional verdict, and the documented minimum confluence score.
  const gradeA = grade === 'GRADE_A' || grade === 'GRADE_A_PLUS' ||
    badge.includes('GRADE A');
  const score = item.confluenceScorePct ?? item.scorePct ?? 0;
  const isDirectional = (verdict.includes('BUY') || verdict.includes('SELL')) &&
    (item.direction === 'LONG' || item.direction === 'SHORT');
  return gradeA && Number.isFinite(score) && score >= 65 && isDirectional &&
    Number.isFinite(item.cmp) && Number(item.cmp) > 0 &&
    grade !== 'GRADE_B' && !badge.includes('GRADE B');
}

/**
 * Alias for isGradeAQualified to enforce user's strict rule:
 * "only grade a qualified setups isme hone chahiye"
 */
export function isQualifyingSetup(item: {
  setupGrade?: string;
  gradeBadge?: string;
  confluenceScorePct?: number;
  finalVerdict?: string;
  scorePct?: number;
  direction?: string;
  status?: string;
}): boolean {
  return isGradeAQualified(item);
}

/**
 * Format relative time elapsed since qualification (e.g., "12m ago", "2h ago", "1d ago")
 */
export function formatTimeAgo(timestamp: number): string {
  const diffMs = Math.max(0, Date.now() - timestamp);
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHrs = Math.floor(diffMin / 60);
  const remMin = diffMin % 60;
  if (diffHrs < 24) return remMin > 0 ? `${diffHrs}h ${remMin}m ago` : `${diffHrs}h ago`;
  const diffDays = Math.floor(diffHrs / 24);
  const remHrs = diffHrs % 24;
  return remHrs > 0 ? `${diffDays}d ${remHrs}h ago` : `${diffDays}d ago`;
}

/**
 * Format remaining time until expiration (e.g. "Expires in 1h 45m")
 */
export function formatRemainingTime(expiresAt: number): { text: string; isExpired: boolean; progressPct: number } {
  const now = Date.now();
  const diffMs = expiresAt - now;
  if (diffMs <= 0) {
    return { text: 'Expired', isExpired: true, progressPct: 100 };
  }

  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHrs = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHrs / 24);

  let text = '';
  if (diffDays > 0) {
    const remH = diffHrs % 24;
    text = remH > 0 ? `${diffDays}d ${remH}h left` : `${diffDays}d left`;
  } else if (diffHrs > 0) {
    const remM = diffMin % 60;
    text = remM > 0 ? `${diffHrs}h ${remM}m left` : `${diffHrs}h left`;
  } else if (diffMin > 0) {
    text = `${diffMin}m left`;
  } else {
    text = `${diffSec}s left`;
  }

  return { text, isExpired: false, progressPct: 0 };
}

/**
 * Retrieve raw setups from multi-tier persistent storage:
 * 1. Primary: localStorage (timesfm_my_setups_v2)
 * 2. Secondary: localStorage backup (timesfm_my_setups_backup)
 * 3. Tertiary: sessionStorage (timesfm_my_setups_v2)
 * 4. Quaternary: localStorage legacy (timesfm_my_setups_v1)
 * 5. Quinary: in-memory cache
 */
function getRawSetups(): any[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw !== null) {
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          inMemorySetupsCache = parsed;
          return parsed;
        }
      } catch {
        // Primary JSON corrupted, proceed to fallbacks below
      }
    }

    // Secondary fallback: backup key
    const backup = localStorage.getItem(BACKUP_STORAGE_KEY);
    if (backup !== null) {
      try {
        const parsedBackup = JSON.parse(backup);
        if (Array.isArray(parsedBackup)) {
          inMemorySetupsCache = parsedBackup;
          return parsedBackup;
        }
      } catch {
        // Backup corrupted
      }
    }

    // Tertiary fallback: sessionStorage
    const sess = sessionStorage.getItem(STORAGE_KEY);
    if (sess !== null) {
      try {
        const parsedSess = JSON.parse(sess);
        if (Array.isArray(parsedSess)) {
          inMemorySetupsCache = parsedSess;
          return parsedSess;
        }
      } catch {
        // Session corrupted
      }
    }

    // Quaternary fallback: legacy storage key
    const legacy = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacy !== null) {
      try {
        const parsedLegacy = JSON.parse(legacy);
        if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
          inMemorySetupsCache = parsedLegacy;
          return parsedLegacy;
        }
      } catch {
        // Legacy corrupted
      }
    }

    if (inMemorySetupsCache && inMemorySetupsCache.length > 0) {
      return inMemorySetupsCache;
    }
    return [];
  } catch (err) {
    console.warn('Failed to parse my_setups from localStorage, using memory cache:', err);
    return inMemorySetupsCache || [];
  }
}

/**
 * Save setups to multi-tier storage (localStorage, backup, sessionStorage, and memory cache)
 * and broadcast real-time update event across components.
 */
function saveSetups(items: MySetupItem[]): void {
  inMemorySetupsCache = items;
  try {
    const serialized = JSON.stringify(items);
    localStorage.setItem(STORAGE_KEY, serialized);
    localStorage.setItem(BACKUP_STORAGE_KEY, serialized);
    sessionStorage.setItem(STORAGE_KEY, serialized);
    window.dispatchEvent(new CustomEvent(UPDATE_EVENT, { detail: { count: items.length } }));
  } catch (err) {
    console.warn('Failed to save my_setups to localStorage/sessionStorage:', err);
    window.dispatchEvent(new CustomEvent(UPDATE_EVENT, { detail: { count: items.length } }));
  }
}

/**
 * Normalizes legacy records into modern single-card per symbol structure
 */
function normalizeRawSetups(raw: any[]): MySetupItem[] {
  const symbolMap = new Map<string, MySetupItem>();
  const now = Date.now();

  for (const item of raw) {
    if (!item || !item.symbol) continue;
    const sym = normalizeSymbolKey(item.symbol);
    if (!sym) continue;
    const rawTf: SetupTimeframe = normalizeSetupTimeframe(item.primaryTimeframe || item.timeframe);

    // If item is already in modern structure with timeframes object
    if (item.timeframes && typeof item.timeframes === 'object' && Object.keys(item.timeframes).length > 0) {
      const normalizedTimeframes: Partial<Record<SetupTimeframe, TimeframeQualification>> = {};
      for (const [k, v] of Object.entries(item.timeframes)) {
        if (!v) continue;
        const normKey = normalizeSetupTimeframe(k);
        const q = v as TimeframeQualification;
        const ttl = SETUP_TTL_MS[normKey] || SETUP_TTL_MS['15m'];
        const qAt = (typeof q.qualifiedAt === 'number' && q.qualifiedAt > 0) ? q.qualifiedAt : now;
        const expAt = (typeof q.expiresAt === 'number' && q.expiresAt > 0) ? q.expiresAt : (qAt + ttl);
        normalizedTimeframes[normKey] = {
          ...q,
          timeframe: normKey,
          qualifiedAt: qAt,
          expiresAt: expAt,
          ttlMs: ttl
        };
      }

      const activeKeys = Object.keys(normalizedTimeframes) as SetupTimeframe[];
      if (activeKeys.length > 0) {
        const maxExp = Math.max(...activeKeys.map(t => normalizedTimeframes[t]!.expiresAt));
        const maxQual = Math.max(...activeKeys.map(t => normalizedTimeframes[t]!.qualifiedAt));
        const existing = symbolMap.get(sym);
        if (!existing) {
          symbolMap.set(sym, {
            ...item,
            id: `setup_${sym}`,
            symbol: sym,
            primaryTimeframe: activeKeys[0],
            timeframe: activeKeys[0],
            timeframes: normalizedTimeframes,
            activeTimeframeList: activeKeys,
            qualifiedAt: maxQual,
            expiresAt: maxExp,
            ttlMs: SETUP_TTL_MS[activeKeys[0]] || SETUP_TTL_MS['15m']
          });
        } else {
          existing.timeframes = { ...existing.timeframes, ...normalizedTimeframes };
          existing.activeTimeframeList = Object.keys(existing.timeframes) as SetupTimeframe[];
          existing.expiresAt = Math.max(existing.expiresAt, maxExp);
          existing.qualifiedAt = Math.max(existing.qualifiedAt, maxQual);
          existing.cmp = item.cmp || existing.cmp;
          existing.changePct = item.changePct ?? existing.changePct;
        }
      }
      continue;
    }

    // Convert legacy flat item:
    const ttl = SETUP_TTL_MS[rawTf] || SETUP_TTL_MS['15m'];
    const qAt = (typeof item.qualifiedAt === 'number' && item.qualifiedAt > 0) ? item.qualifiedAt : now;
    const expAt = (typeof item.expiresAt === 'number' && item.expiresAt > 0) ? item.expiresAt : (qAt + ttl);

    const tfQual: TimeframeQualification = {
      timeframe: rawTf,
      qualifiedAt: qAt,
      expiresAt: expAt,
      ttlMs: ttl,
      setupGrade: item.setupGrade || 'GRADE_A',
      gradeBadge: item.gradeBadge || '⚡ Grade A',
      scorePct: item.scorePct || 75,
      confluenceScorePct: item.confluenceScorePct || item.scorePct || 75,
      finalVerdict: item.finalVerdict || 'BUY / ACCUMULATE',
      direction: item.direction || 'LONG',
      entryRange: item.entryRange || { min: item.cmp * 0.995, max: item.cmp * 1.005, text: '' },
      stopLoss: item.stopLoss || { price: item.cmp * 0.985, pct: 1.5 },
      target1: item.target1 || { price: item.cmp * 1.025, pct: 2.5 },
      target2: item.target2 || { price: item.cmp * 1.055, pct: 5.5 },
      riskRewardText: item.riskRewardText || '1:2.0',
      status: item.status || 'TRADE NOW'
    };

    const existing = symbolMap.get(sym);
    if (!existing) {
      const newItem: MySetupItem = {
        ...item,
        id: `setup_${sym}`,
        symbol: sym,
        primaryTimeframe: rawTf,
        timeframe: rawTf,
        timeframes: { [rawTf]: tfQual },
        activeTimeframeList: [rawTf],
        qualifiedAt: qAt,
        expiresAt: expAt,
        ttlMs: ttl
      };
      symbolMap.set(sym, newItem);
    } else {
      existing.timeframes[rawTf] = tfQual;
      if (!existing.activeTimeframeList.includes(rawTf)) {
        existing.activeTimeframeList.push(rawTf);
      }
      if (qAt > existing.qualifiedAt) {
        existing.qualifiedAt = qAt;
        existing.primaryTimeframe = rawTf;
        existing.timeframe = rawTf;
      }
      if (expAt > existing.expiresAt) {
        existing.expiresAt = expAt;
      }
    }
  }

  return Array.from(symbolMap.values());
}

/**
 * Get active setups, automatically filtering and omitting only expired timeframes (past TTL).
 * Preserves all active setups in device local cache memory until their specified TTL expires.
 * Only omits a symbol completely when ALL of its qualified timeframes have expired.
 */
export function getActiveSetups(): MySetupItem[] {
  const raw = getRawSetups();
  const normalized = normalizeRawSetups(raw);
  const now = Date.now();
  let hasPruned = false;

  const validSetups: MySetupItem[] = [];

  for (const setup of normalized) {
    const updatedTimeframes: Partial<Record<SetupTimeframe, TimeframeQualification>> = {};
    const tfKeys = (Object.keys(setup.timeframes || {}) as SetupTimeframe[]);

    for (const tf of tfKeys) {
      const q = setup.timeframes[tf];
      if (!q) continue;
      const ttl = SETUP_TTL_MS[tf] || SETUP_TTL_MS['15m'];
      const qAt = (typeof q.qualifiedAt === 'number' && q.qualifiedAt > 0) ? q.qualifiedAt : now;
      const expAt = (typeof q.expiresAt === 'number' && q.expiresAt > 0) ? q.expiresAt : (qAt + ttl);

      // Keep setups strictly as long as TTL has not expired
      if (expAt > now) {
        updatedTimeframes[tf] = {
          ...q,
          expiresAt: expAt,
          qualifiedAt: qAt,
          ttlMs: ttl
        };
      } else {
        hasPruned = true; // This specific timeframe expired past TTL
      }
    }

    const activeList = Object.keys(updatedTimeframes) as SetupTimeframe[];
    if (activeList.length > 0) {
      // Find latest qualification and maximum expiration
      let maxQualified = 0;
      let maxExpires = 0;
      let latestTf: SetupTimeframe = activeList[0];

      for (const tf of activeList) {
        const q = updatedTimeframes[tf]!;
        if (q.qualifiedAt >= maxQualified) {
          maxQualified = q.qualifiedAt;
          latestTf = tf;
        }
        if (q.expiresAt > maxExpires) {
          maxExpires = q.expiresAt;
        }
      }

      // Check if current primary timeframe is still active, else use latestTf
      const effPrimary = (setup.primaryTimeframe && updatedTimeframes[setup.primaryTimeframe])
        ? setup.primaryTimeframe
        : latestTf;

      const primaryQual = updatedTimeframes[effPrimary]!;

      validSetups.push({
        ...setup,
        primaryTimeframe: effPrimary,
        timeframe: effPrimary,
        timeframes: updatedTimeframes,
        activeTimeframeList: activeList,
        qualifiedAt: maxQualified,
        expiresAt: maxExpires,
        entryRange: primaryQual.entryRange || setup.entryRange,
        stopLoss: primaryQual.stopLoss || setup.stopLoss,
        target1: primaryQual.target1 || setup.target1,
        target2: primaryQual.target2 || setup.target2,
        finalVerdict: primaryQual.finalVerdict || setup.finalVerdict,
        setupGrade: primaryQual.setupGrade || setup.setupGrade,
        gradeBadge: primaryQual.gradeBadge || setup.gradeBadge,
        riskRewardText: primaryQual.riskRewardText || setup.riskRewardText
      });
    } else {
      hasPruned = true; // All timeframes expired for this symbol
    }
  }

  if (hasPruned) {
    saveSetups(validSetups);
  }

  // Sort: most recently qualified first
  return validSetups.sort((a, b) => b.qualifiedAt - a.qualifiedAt);
}

/**
 * Get total count of active, non-expired unique symbols
 */
export function getActiveSetupsCount(): number {
  return getActiveSetups().length;
}

/**
 * Maps a WatchlistScanItem into a TimeframeQualification object,
 * setting the full TTL window for the scanned timeframe.
 */
function createTimeframeQualification(
  item: WatchlistScanItem,
  timeframe: SetupTimeframe,
  existingQual?: TimeframeQualification,
  sourceWatchlistId?: string
): TimeframeQualification {
  const now = Date.now();
  const normTf = normalizeSetupTimeframe(timeframe);
  const ttl = SETUP_TTL_MS[normTf] || SETUP_TTL_MS['15m'];

  // A repeat scan must not silently extend the TTL: the timer is measured from qualification.
  const qualifiedAt = (existingQual?.qualifiedAt && (now - existingQual.qualifiedAt < ttl))
    ? existingQual.qualifiedAt
    : now;
  const expiresAt = qualifiedAt + ttl;

  return {
    timeframe: normTf,
    qualifiedAt,
    expiresAt,
    ttlMs: ttl,
    setupGrade: item.setupGrade || 'GRADE_A',
    gradeBadge: item.gradeBadge || '⚡ Grade A',
    scorePct: item.scorePct || 75,
    confluenceScorePct: item.confluenceScorePct || item.scorePct || 75,
    finalVerdict: item.finalVerdict || (item.direction === 'SHORT' ? 'SELL / SHORT' : 'BUY / ACCUMULATE'),
    direction: item.direction === 'SHORT' ? 'SHORT' : 'LONG',
    entryRange: item.entryRange || {
      min: Math.round(item.cmp * 0.995 * 100) / 100,
      max: Math.round(item.cmp * 1.005 * 100) / 100,
      text: `₹${Math.round(item.cmp * 0.995)} – ₹${Math.round(item.cmp * 1.005)}`
    },
    stopLoss: item.stopLoss || {
      price: Math.round(item.cmp * (item.direction === 'SHORT' ? 1.015 : 0.985) * 100) / 100,
      pct: 1.5
    },
    target1: item.target1 || {
      price: Math.round(item.cmp * (item.direction === 'SHORT' ? 0.975 : 1.025) * 100) / 100,
      pct: 2.5
    },
    target2: item.target2 || {
      price: Math.round(item.cmp * (item.direction === 'SHORT' ? 0.955 : 1.055) * 100) / 100,
      pct: 5.5
    },
    riskRewardText: item.riskRewardText || '1:2.0',
    status: item.status || 'TRADE NOW',
    optionsSuggestion: item.optionsSuggestion,
    sourceWatchlistId,
    analysis: {
      cmp: item.cmp,
      coreDriver: item.coreDriver,
      actionTrigger: item.actionTrigger,
      timesfmResult: item.timesfmResult,
      quantEngineResult: item.quantEngineResult,
      smcIctResult: item.smcIctResult,
      marketFlow: item.marketFlow,
      volumeSpike: item.volumeSpike,
      verdictDirectionalScorePct: item.verdictDirectionalScorePct,
      verdictWeights: item.verdictWeights
    }
  };
}

function describeQualificationChange(previous: TimeframeQualification, next: TimeframeQualification): string | undefined {
  const changes: string[] = [];
  if (previous.setupGrade !== next.setupGrade) changes.push(`grade ${previous.setupGrade} → ${next.setupGrade}`);
  if (previous.direction !== next.direction) changes.push(`direction ${previous.direction} → ${next.direction}`);
  if (previous.finalVerdict !== next.finalVerdict) changes.push(`verdict ${previous.finalVerdict} → ${next.finalVerdict}`);
  if (Math.round(previous.confluenceScorePct) !== Math.round(next.confluenceScorePct)) changes.push(`score ${Math.round(previous.confluenceScorePct)}% → ${Math.round(next.confluenceScorePct)}%`);
  for (const [label, before, after] of [
    ['entry', previous.entryRange.text, next.entryRange.text],
    ['stop', previous.stopLoss.price.toFixed(2), next.stopLoss.price.toFixed(2)],
    ['target 1', previous.target1.price.toFixed(2), next.target1.price.toFixed(2)],
    ['target 2', previous.target2.price.toFixed(2), next.target2.price.toFixed(2)]
  ]) if (before !== after) changes.push(`${label} changed`);
  const oldFlow = previous.analysis?.marketFlow;
  const newFlow = next.analysis?.marketFlow;
  if (oldFlow?.syntheticBuildup?.category !== newFlow?.syntheticBuildup?.category) changes.push(`buildup ${oldFlow?.syntheticBuildup?.category || 'unavailable'} → ${newFlow?.syntheticBuildup?.category || 'unavailable'}`);
  if (oldFlow?.trapRisk?.kind !== newFlow?.trapRisk?.kind) changes.push(`trap signal ${oldFlow?.trapRisk?.kind || 'unavailable'} → ${newFlow?.trapRisk?.kind || 'unavailable'}`);
  if (oldFlow?.optionChainOi?.direction !== newFlow?.optionChainOi?.direction || oldFlow?.optionChainOi?.available !== newFlow?.optionChainOi?.available) changes.push('option-chain OI signal changed');
  if (oldFlow?.futuresOi?.direction !== newFlow?.futuresOi?.direction || oldFlow?.futuresOi?.available !== newFlow?.futuresOi?.available) changes.push('futures OI signal changed');
  if (oldFlow?.volumeSpike?.isSpike !== newFlow?.volumeSpike?.isSpike) changes.push('volume-spike state changed');
  return changes.length ? changes.join('; ') : undefined;
}

/**
 * Core Synchronization Function:
 * 1. Only Grade A qualified setups are added.
 * 2. Cross-Watchlist & Cross-Timeframe Persistence: scanning the next watchlist or timeframe
 *    PRESERVES previously saved setups from other watchlists / timeframes in local cache memory.
 * 3. Unified Symbol Representation: If 1 symbol qualifies on multiple timeframes (e.g. 5m, 15m, 1h),
 *    it is NOT duplicated into multiple cards; it is stored as ONE entry with all qualified timeframes
 *    and each timeframe's individual qualification time!
 * 4. Strict TTL enforcement: 5m (2h), 15m (6h), 1h (2d), 1d (5d).
 */
export function syncSetupsFromWatchlistScan(
  scannedItems: WatchlistScanItem[],
  defaultTf: SetupTimeframe = '15m',
  sourceWatchlistId?: string,
  replaceScannedTimeframe = false
): { updatedCount: number; activeSetups: MySetupItem[]; changes: string[] } {
  const currentList = getActiveSetups(); // Prunes only strictly expired timeframes
  const now = Date.now();
  const normalizedDefaultTf = normalizeSetupTimeframe(defaultTf);

  // Map of existing setups by symbol (unique key)
  const setupMap = new Map<string, MySetupItem>();
  for (const s of currentList) {
    setupMap.set(s.symbol.toUpperCase().trim(), s);
  }

  let updatedCount = 0;
  const changes: string[] = [];

  for (const item of scannedItems) {
    const sym = item.symbol.toUpperCase().trim();
    const effectiveTf: SetupTimeframe = normalizeSetupTimeframe(item.timeframe || normalizedDefaultTf);

    // Strict Qualification: ONLY Grade A / Grade A+ setups qualify!
    if (isQualifyingSetup(item)) {
      const existing = setupMap.get(sym);
      const prevTfQual = existing?.timeframes?.[effectiveTf];
      const tfQual = createTimeframeQualification(item, effectiveTf, prevTfQual, sourceWatchlistId);
      const changeDescription = prevTfQual
        ? describeQualificationChange(prevTfQual, tfQual)
        : `New ${effectiveTf} setup: ${tfQual.setupGrade} ${tfQual.direction}, ${Math.round(tfQual.confluenceScorePct)}%`;
      if (changeDescription) {
        const entry: SetupScanChange = { detectedAt: now, timeframe: effectiveTf, description: changeDescription };
        changes.push(`${sym} · ${effectiveTf}: ${changeDescription}`);
        if (existing) existing.scanChanges = [entry, ...(existing.scanChanges || [])].slice(0, 20);
      }

      if (existing) {
        // Merge this timeframe into existing symbol record without losing other timeframes
        const updatedTimeframes = {
          ...existing.timeframes,
          [effectiveTf]: tfQual
        };
        const activeList = Object.keys(updatedTimeframes) as SetupTimeframe[];
        const maxExp = Math.max(...activeList.map(t => updatedTimeframes[t]!.expiresAt));
        const maxQual = Math.max(...activeList.map(t => updatedTimeframes[t]!.qualifiedAt));

        setupMap.set(sym, {
          ...existing,
          name: item.name || existing.name,
          cmp: item.cmp,
          prevClose: item.prevClose || existing.prevClose,
          changePct: item.changePct ?? existing.changePct,
          primaryTimeframe: effectiveTf,
          timeframe: effectiveTf,
          timeframes: updatedTimeframes,
          activeTimeframeList: activeList,
          qualifiedAt: maxQual,
          expiresAt: maxExp,
          direction: item.direction || existing.direction,
          finalVerdict: item.finalVerdict || existing.finalVerdict,
          setupGrade: item.setupGrade || existing.setupGrade,
          gradeBadge: item.gradeBadge || existing.gradeBadge,
          scorePct: item.scorePct || existing.scorePct,
          confluenceScorePct: item.confluenceScorePct || existing.confluenceScorePct,
          status: item.status || existing.status,
          entryRange: tfQual.entryRange,
          stopLoss: tfQual.stopLoss,
          target1: tfQual.target1,
          target2: tfQual.target2,
          riskRewardText: tfQual.riskRewardText,
          optionsSuggestion: item.optionsSuggestion || existing.optionsSuggestion,
          scanChanges: existing.scanChanges,
          timesfmResult: item.timesfmResult || existing.timesfmResult,
          quantEngineResult: item.quantEngineResult || existing.quantEngineResult,
          smcIctResult: item.smcIctResult || existing.smcIctResult,
          oiBuildupResult: existing.oiBuildupResult,
          lastScannedWatchlistId: sourceWatchlistId || existing.lastScannedWatchlistId
        });
        updatedCount++;
      } else {
        // Create new unified setup for this symbol
        const newSetup: MySetupItem = {
          id: `setup_${sym}`,
          symbol: sym,
          name: item.name || sym,
          exchange: item.exchange || 'NSE',
          primaryTimeframe: effectiveTf,
          timeframe: effectiveTf,
          timeframes: { [effectiveTf]: tfQual },
          activeTimeframeList: [effectiveTf],
          qualifiedAt: tfQual.qualifiedAt,
          expiresAt: tfQual.expiresAt,
          ttlMs: tfQual.ttlMs,
          cmp: item.cmp,
          prevClose: item.prevClose || item.cmp,
          changePct: item.changePct ?? 0,
          direction: item.direction || 'LONG',
          finalVerdict: item.finalVerdict || (item.direction === 'SHORT' ? 'SELL / SHORT' : 'BUY / ACCUMULATE'),
          setupGrade: item.setupGrade || 'GRADE_A',
          gradeBadge: item.gradeBadge || '⚡ Grade A',
          scorePct: item.scorePct || 75,
          confluenceScorePct: item.confluenceScorePct || item.scorePct || 75,
          status: item.status || 'TRADE NOW',
          entryRange: tfQual.entryRange,
          stopLoss: tfQual.stopLoss,
          target1: tfQual.target1,
          target2: tfQual.target2,
          riskRewardText: tfQual.riskRewardText,
          optionsSuggestion: item.optionsSuggestion,
          timesfmResult: item.timesfmResult,
          quantEngineResult: item.quantEngineResult,
          smcIctResult: item.smcIctResult,
          lastScannedWatchlistId: sourceWatchlistId,
          scanChanges: changeDescription ? [{ detectedAt: now, timeframe: effectiveTf, description: changeDescription }] : []
        };
        setupMap.set(sym, newSetup);
        updatedCount++;
      }
    } else if (replaceScannedTimeframe) {
      const existing = setupMap.get(sym);
      if (existing?.timeframes?.[effectiveTf]) {
        const removed = existing.timeframes[effectiveTf]!;
        const removalDescription = `${effectiveTf} setup disqualified: ${removed.setupGrade} ${removed.direction} ${Math.round(removed.confluenceScorePct)}% no longer qualifies`;
        changes.push(`${sym} · ${removalDescription}`);
        const removalEvent: SetupScanChange = { detectedAt: now, timeframe: effectiveTf, description: removalDescription };
        const timeframes = { ...existing.timeframes };
        delete timeframes[effectiveTf];
        const activeList = Object.keys(timeframes) as SetupTimeframe[];
        if (!activeList.length) setupMap.delete(sym);
        else {
          const maxExpires = Math.max(...activeList.map(tf => timeframes[tf]!.expiresAt));
          const maxQualified = Math.max(...activeList.map(tf => timeframes[tf]!.qualifiedAt));
          setupMap.set(sym, {
            ...existing,
            cmp: item.cmp || existing.cmp,
            prevClose: item.prevClose || existing.prevClose,
            changePct: item.changePct ?? existing.changePct,
            timeframes,
            scanChanges: [removalEvent, ...(existing.scanChanges || [])].slice(0, 20),
            activeTimeframeList: activeList,
            qualifiedAt: maxQualified,
            expiresAt: maxExpires
          });
        }
      }
    }
  }

  // Preserve all setups from other watchlists/timeframes that haven't expired
  const finalized: MySetupItem[] = [];
  for (const setup of setupMap.values()) {
    const activeTfs: Partial<Record<SetupTimeframe, TimeframeQualification>> = {};
    for (const [tfKey, q] of Object.entries(setup.timeframes || {})) {
      const tf = normalizeSetupTimeframe(tfKey);
      if (q && q.expiresAt > now) {
        activeTfs[tf] = q;
      }
    }
    const activeList = Object.keys(activeTfs) as SetupTimeframe[];
    if (activeList.length > 0) {
      const maxExp = Math.max(...activeList.map(t => activeTfs[t]!.expiresAt));
      const maxQual = Math.max(...activeList.map(t => activeTfs[t]!.qualifiedAt));
      const primaryTf = activeList.reduce((best, tf) => activeTfs[tf]!.qualifiedAt > activeTfs[best]!.qualifiedAt ? tf : best, activeList[0]);
      const primary = activeTfs[primaryTf]!;
      finalized.push({
        ...setup,
        timeframes: activeTfs,
        activeTimeframeList: activeList,
        primaryTimeframe: primaryTf,
        timeframe: primaryTf,
        ttlMs: primary.ttlMs,
        direction: primary.direction,
        finalVerdict: primary.finalVerdict,
        setupGrade: primary.setupGrade,
        gradeBadge: primary.gradeBadge,
        scorePct: primary.scorePct,
        confluenceScorePct: primary.confluenceScorePct,
        status: primary.status,
        entryRange: primary.entryRange,
        stopLoss: primary.stopLoss,
        target1: primary.target1,
        target2: primary.target2,
        riskRewardText: primary.riskRewardText,
        expiresAt: maxExp,
        qualifiedAt: maxQual
      });
    }
  }

  finalized.sort((a, b) => b.qualifiedAt - a.qualifiedAt);
  saveSetups(finalized);
  return { updatedCount, activeSetups: finalized, changes };
}

/**
 * Add or update a single setup (from single stock calculation or drawer)
 */
export function addOrUpdateSingleSetup(
  item: WatchlistScanItem,
  timeframe: SetupTimeframe,
  sourceWatchlistId?: string
): MySetupItem | null {
  if (!isQualifyingSetup(item)) return null;

  const current = getActiveSetups();
  const sym = item.symbol.toUpperCase().trim();
  const normTf = normalizeSetupTimeframe(timeframe);
  const setupMap = new Map<string, MySetupItem>();
  for (const s of current) {
    setupMap.set(s.symbol.toUpperCase().trim(), s);
  }

  const existing = setupMap.get(sym);
  const prevTfQual = existing?.timeframes?.[normTf];
  const tfQual = createTimeframeQualification(item, normTf, prevTfQual, sourceWatchlistId);

  let updatedItem: MySetupItem;

  if (existing) {
    const updatedTimeframes = {
      ...existing.timeframes,
      [normTf]: tfQual
    };
    const activeList = Object.keys(updatedTimeframes) as SetupTimeframe[];
    const maxExp = Math.max(...activeList.map(t => updatedTimeframes[t]!.expiresAt));
    const maxQual = Math.max(...activeList.map(t => updatedTimeframes[t]!.qualifiedAt));

    updatedItem = {
      ...existing,
      name: item.name || existing.name,
      cmp: item.cmp,
      changePct: item.changePct ?? existing.changePct,
      primaryTimeframe: normTf,
      timeframe: normTf,
      timeframes: updatedTimeframes,
      activeTimeframeList: activeList,
      qualifiedAt: maxQual,
      expiresAt: maxExp,
      entryRange: tfQual.entryRange,
      stopLoss: tfQual.stopLoss,
      target1: tfQual.target1,
      target2: tfQual.target2,
      riskRewardText: tfQual.riskRewardText,
      optionsSuggestion: item.optionsSuggestion || existing.optionsSuggestion
    };
  } else {
    updatedItem = {
      id: `setup_${sym}`,
      symbol: sym,
      name: item.name || sym,
      exchange: item.exchange || 'NSE',
      primaryTimeframe: normTf,
      timeframe: normTf,
      timeframes: { [normTf]: tfQual },
      activeTimeframeList: [normTf],
      qualifiedAt: tfQual.qualifiedAt,
      expiresAt: tfQual.expiresAt,
      ttlMs: tfQual.ttlMs,
      cmp: item.cmp,
      prevClose: item.prevClose || item.cmp,
      changePct: item.changePct ?? 0,
      direction: item.direction || 'LONG',
      finalVerdict: item.finalVerdict || (item.direction === 'SHORT' ? 'SELL / SHORT' : 'BUY / ACCUMULATE'),
      setupGrade: item.setupGrade || 'GRADE_A',
      gradeBadge: item.gradeBadge || '⚡ Grade A',
      scorePct: item.scorePct || 75,
      confluenceScorePct: item.confluenceScorePct || item.scorePct || 75,
      status: item.status || 'TRADE NOW',
      entryRange: tfQual.entryRange,
      stopLoss: tfQual.stopLoss,
      target1: tfQual.target1,
      target2: tfQual.target2,
      riskRewardText: tfQual.riskRewardText,
      optionsSuggestion: item.optionsSuggestion,
      timesfmResult: item.timesfmResult,
      quantEngineResult: item.quantEngineResult,
      smcIctResult: item.smcIctResult,
      lastScannedWatchlistId: sourceWatchlistId
    };
  }

  setupMap.set(sym, updatedItem);
  const finalized = Array.from(setupMap.values()).sort((a, b) => b.qualifiedAt - a.qualifiedAt);
  saveSetups(finalized);
  return updatedItem;
}

/**
 * Remove a specific setup or timeframe for a symbol
 */
export function removeSetup(idOrSymbol: string, timeframeToRemove?: SetupTimeframe): MySetupItem[] {
  const current = getActiveSetups();
  const cleanKey = idOrSymbol.replace(/^setup_/, '').toUpperCase().trim();

  let updated: MySetupItem[] = [];

  for (const item of current) {
    if (item.symbol.toUpperCase() === cleanKey || item.id === idOrSymbol) {
      if (timeframeToRemove && item.timeframes && item.timeframes[timeframeToRemove]) {
        // Remove only this timeframe
        const updatedTimeframes = { ...item.timeframes };
        delete updatedTimeframes[timeframeToRemove];
        const remainingTfs = Object.keys(updatedTimeframes) as SetupTimeframe[];
        if (remainingTfs.length > 0) {
          const nextPrimary = remainingTfs[0];
          updated.push({
            ...item,
            primaryTimeframe: nextPrimary,
            timeframe: nextPrimary,
            timeframes: updatedTimeframes,
            activeTimeframeList: remainingTfs
          });
        }
        // If no timeframes left, do not push (omits the symbol)
      }
      // If no specific timeframeToRemove, omit the whole symbol
    } else {
      updated.push(item);
    }
  }

  saveSetups(updated);
  return updated;
}

/**
 * Clear all setups manually
 */
export function clearAllSetups(): void {
  saveSetups([]);
}

/**
 * Subscribe to My Setups updates
 */
export function subscribeToSetups(callback: () => void): () => void {
  const handler = () => callback();
  const storageHandler = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY || e.key === LEGACY_STORAGE_KEY) callback();
  };
  window.addEventListener(UPDATE_EVENT, handler);
  window.addEventListener('storage', storageHandler);
  return () => {
    window.removeEventListener(UPDATE_EVENT, handler);
    window.removeEventListener('storage', storageHandler);
  };
}
