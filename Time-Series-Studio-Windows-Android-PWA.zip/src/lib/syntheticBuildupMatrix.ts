import type { TimeSeriesPoint } from '../types';

export type SyntheticBuildupTimeframe = '5m' | '15m' | '1h' | '1d';
export type SyntheticBuildupCategory = 'LONG_BUILDUP' | 'SHORT_BUILDUP' | 'LONG_UNWINDING' | 'SHORT_COVERING' | 'NEUTRAL' | 'UNAVAILABLE';

export interface SyntheticBuildupSignal {
  available: boolean;
  timeframe: SyntheticBuildupTimeframe;
  formulaLabel: string;
  category: SyntheticBuildupCategory;
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  metric: number;
  confidencePct: number;
  efficiency?: number;
  relativeVolume?: number;
  zVolume?: number;
  priceMovePct?: number;
  detail: string;
}

export interface SyntheticBuildupConfig {
  scalpMbiThreshold: number; minEfficiency: number; scalpEmaLength: number;
  intradayCbsThreshold: number; intradayAtrLength: number; intradayVolumeLength: number;
  swingPriceMoveThresholdPct: number; swingZVolumeThreshold: number; swingVolumeLength: number;
  dailyPbiThreshold: number; dailyAtrLength: number; dailyVolumeLength: number;
}

export const DEFAULT_SYNTHETIC_BUILDUP_CONFIG: SyntheticBuildupConfig = {
  scalpMbiThreshold: 1.2, minEfficiency: 0.6, scalpEmaLength: 10,
  intradayCbsThreshold: 1.5, intradayAtrLength: 14, intradayVolumeLength: 20,
  swingPriceMoveThresholdPct: 0.4, swingZVolumeThreshold: 1, swingVolumeLength: 50,
  dailyPbiThreshold: 1.8, dailyAtrLength: 20, dailyVolumeLength: 20
};

const sma = (values: number[], length: number) => values.length < length ? NaN : values.slice(-length).reduce((a, b) => a + b, 0) / length;
const stdev = (values: number[], length: number) => {
  const mean = sma(values, length);
  if (!Number.isFinite(mean)) return NaN;
  return Math.sqrt(values.slice(-length).reduce((sum, value) => sum + (value - mean) ** 2, 0) / length);
};
const ema = (values: number[], length: number) => {
  if (!values.length) return NaN;
  const alpha = 2 / (length + 1);
  return values.slice(1).reduce((previous, value) => alpha * value + (1 - alpha) * previous, values[0]);
};
function atr(candles: TimeSeriesPoint[], length: number): number {
  if (candles.length < length + 1) return NaN;
  const trs = candles.slice(1).map((bar, index) => {
    const prev = candles[index]; const high = Number(bar.high); const low = Number(bar.low);
    return Math.max(high - low, Math.abs(high - prev.value), Math.abs(low - prev.value));
  });
  if (trs.length < length) return NaN;
  let result = sma(trs.slice(0, length), length);
  for (const tr of trs.slice(length)) result = (result * (length - 1) + tr) / length;
  return result;
}
const round = (v: number) => Math.round(v * 10000) / 10000;
const unavailable = (timeframe: SyntheticBuildupTimeframe, formulaLabel: string, detail: string): SyntheticBuildupSignal => ({
  available: false, timeframe, formulaLabel, category: 'UNAVAILABLE', direction: 'NEUTRAL', metric: 0, confidencePct: 0, detail
});

/** Timeframe-specific synthetic price/volume classification. It does not infer actual OI. */
export function calculateSyntheticBuildupMatrix(
  candles: TimeSeriesPoint[], timeframe: SyntheticBuildupTimeframe = '15m', config: Partial<SyntheticBuildupConfig> = {}
): SyntheticBuildupSignal {
  const cfg = { ...DEFAULT_SYNTHETIC_BUILDUP_CONFIG, ...config };
  const formulaLabel = timeframe === '5m' ? 'Scalping: MBI = Efficiency × RVOL(EMA)' : timeframe === '15m' ? 'Intraday: CBS = Price/ATR × RVOL(SMA)' : timeframe === '1h' ? 'Swing: Price % + Volume Z-score' : 'Daily/Positional: PBI = Price/ATR × RVOL';
  const bars = candles.filter(c => [c.value, c.open, c.high, c.low, c.volume].every(v => Number.isFinite(Number(v))));
  if (bars.length !== candles.length || !bars.length) return unavailable(timeframe, formulaLabel, 'Valid OHLCV history is required; no signal is inferred from missing data.');
  const last = bars[bars.length - 1], prev = bars[bars.length - 2];
  if (!prev || last.value <= 0 || prev.value <= 0 || last.volume! < 0) return unavailable(timeframe, formulaLabel, 'More valid bars are required for this timeframe formula.');
  const volumes = bars.map(c => Number(c.volume));
  const move = last.value - prev.value;
  let metric = NaN, strength = 0, efficiency: number | undefined, relativeVolume: number | undefined, zVolume: number | undefined;
  let priceMovePct: number | undefined;
  let long = false, short = false;

  if (timeframe === '5m') {
    const spread = Number(last.high) - Number(last.low);
    efficiency = Math.abs(Number(last.value) - Number(last.open)) / (spread === 0 ? 1 : spread);
    relativeVolume = Number(last.volume) / ema(volumes, cfg.scalpEmaLength);
    metric = efficiency * relativeVolume * (last.value >= Number(last.open) ? 1 : -1);
    if (![efficiency, relativeVolume, metric].every(Number.isFinite)) return unavailable(timeframe, formulaLabel, `Requires EMA(${cfg.scalpEmaLength}) volume history.`);
    long = metric >= cfg.scalpMbiThreshold && efficiency >= cfg.minEfficiency && last.value > Number(last.open);
    short = metric <= -cfg.scalpMbiThreshold && efficiency >= cfg.minEfficiency && last.value < Number(last.open);
    strength = Math.min(Math.abs(metric) / cfg.scalpMbiThreshold, efficiency / cfg.minEfficiency);
  } else if (timeframe === '15m') {
    const averageVolume = sma(volumes, cfg.intradayVolumeLength);
    const atrValue = atr(bars, cfg.intradayAtrLength);
    relativeVolume = Number(last.volume) / averageVolume;
    metric = (move / atrValue) * relativeVolume;
    if (![averageVolume, atrValue, metric].every(Number.isFinite) || averageVolume <= 0 || atrValue <= 0) return unavailable(timeframe, formulaLabel, `Requires ${cfg.intradayVolumeLength}+ volume bars and ATR(${cfg.intradayAtrLength}) history.`);
    long = metric >= cfg.intradayCbsThreshold;
    short = metric <= -cfg.intradayCbsThreshold;
    strength = Math.abs(metric) / cfg.intradayCbsThreshold;
  } else if (timeframe === '1h') {
    const meanVolume = sma(volumes, cfg.swingVolumeLength);
    const deviation = stdev(volumes, cfg.swingVolumeLength);
    priceMovePct = move / prev.value * 100;
    zVolume = (Number(last.volume) - meanVolume) / (deviation === 0 ? 1 : deviation);
    metric = zVolume;
    if (![meanVolume, deviation, priceMovePct, zVolume].every(Number.isFinite)) return unavailable(timeframe, formulaLabel, `Requires ${cfg.swingVolumeLength} volume bars for Z-score.`);
    long = priceMovePct > cfg.swingPriceMoveThresholdPct && zVolume >= cfg.swingZVolumeThreshold;
    short = priceMovePct < -cfg.swingPriceMoveThresholdPct && zVolume >= cfg.swingZVolumeThreshold;
    strength = Math.min(Math.abs(priceMovePct) / cfg.swingPriceMoveThresholdPct, zVolume / cfg.swingZVolumeThreshold);
  } else {
    const averageVolume = sma(volumes, cfg.dailyVolumeLength);
    const atrValue = atr(bars, cfg.dailyAtrLength);
    relativeVolume = Number(last.volume) / averageVolume;
    metric = (move / atrValue) * relativeVolume;
    if (![averageVolume, atrValue, metric].every(Number.isFinite) || averageVolume <= 0 || atrValue <= 0) return unavailable(timeframe, formulaLabel, `Requires ${cfg.dailyVolumeLength}+ volume bars and ATR(${cfg.dailyAtrLength}) history.`);
    long = metric >= cfg.dailyPbiThreshold && Number(last.volume) > averageVolume;
    short = metric <= -cfg.dailyPbiThreshold && Number(last.volume) > averageVolume;
    strength = Math.abs(metric) / cfg.dailyPbiThreshold;
  }

  let category: SyntheticBuildupCategory = 'NEUTRAL';
  if (long) category = 'LONG_BUILDUP';
  else if (short) category = 'SHORT_BUILDUP';
  else if (move > 0) category = 'SHORT_COVERING';
  else if (move < 0) category = 'LONG_UNWINDING';
  const direction = category === 'LONG_BUILDUP' || category === 'SHORT_COVERING' ? 'BULLISH' : category === 'SHORT_BUILDUP' || category === 'LONG_UNWINDING' ? 'BEARISH' : 'NEUTRAL';
  const confidencePct = category === 'NEUTRAL' ? 0 : Math.max(0, Math.min(100, Math.round((category === 'LONG_BUILDUP' || category === 'SHORT_BUILDUP' ? strength : Math.min(1, strength) * 0.5) * 100)));
  const metricText = timeframe === '1h' ? `Z-volume ${round(metric).toFixed(2)}, price move ${round(priceMovePct!).toFixed(2)}%` : `${timeframe === '5m' ? 'MBI' : timeframe === '15m' ? 'CBS' : 'PBI'} ${round(metric).toFixed(2)}`;
  const categoryLabel: Record<SyntheticBuildupCategory, string> = { LONG_BUILDUP: 'Long Buildup', SHORT_BUILDUP: 'Short Buildup', LONG_UNWINDING: 'Long Unwinding / Weak Sell-off', SHORT_COVERING: 'Short Covering / Weak Rally', NEUTRAL: 'Neutral', UNAVAILABLE: 'Unavailable' };
  const extra = [efficiency !== undefined ? `efficiency ${efficiency.toFixed(2)}` : '', relativeVolume !== undefined ? `RVOL ${relativeVolume.toFixed(2)}×` : '', zVolume !== undefined ? `Z-volume ${zVolume.toFixed(2)}` : ''].filter(Boolean).join(', ');
  return { available: true, timeframe, formulaLabel, category, direction, metric: round(metric), confidencePct, efficiency, relativeVolume, zVolume, priceMovePct, detail: `${categoryLabel[category]} — ${metricText}${extra ? `; ${extra}` : ''}. Synthetic price/volume proxy, not actual OI.` };
}

/** Projects matrix evidence onto a 0–100 directional support scale for the 15% verdict blend. */
export function syntheticBuildupSupportScore(signal: SyntheticBuildupSignal, expected: 'BULLISH' | 'BEARISH' | 'NEUTRAL'): number {
  if (!signal.available || expected === 'NEUTRAL' || signal.category === 'NEUTRAL') return 50;
  const strong = signal.category === 'LONG_BUILDUP' || signal.category === 'SHORT_BUILDUP';
  const aligns = signal.direction === expected;
  return Math.round(50 + (aligns ? 1 : -1) * signal.confidencePct * (strong ? 0.5 : 0.25));
}

export function blendSyntheticBuildupVerdict(baseScore: number, signal: SyntheticBuildupSignal, expected: 'BULLISH' | 'BEARISH' | 'NEUTRAL'): number {
  const base = Math.max(0, Math.min(100, baseScore));
  if (!signal.available) return Math.round(base);
  return Math.round(base * 0.85 + syntheticBuildupSupportScore(signal, expected) * 0.15);
}
