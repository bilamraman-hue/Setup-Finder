import type { SyntheticBuildupSignal, SyntheticBuildupTimeframe } from './syntheticBuildupMatrix';

export interface VerdictWeightProfile {
  priceAction: number;
  volume: number;
  syntheticMatrix: number;
  liveOi: number;
}

export interface WeightedVerdictInput {
  timeframe: SyntheticBuildupTimeframe;
  priceActionSigned: number; // -100 bearish to +100 bullish
  volumeAvailable: boolean;
  volumeDirection: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  volumeStrengthPct: number;
  syntheticBuildup?: SyntheticBuildupSignal;
  liveOiSignals: Array<{ available: boolean; scorePct: number }>;
}

export interface WeightedVerdictResult {
  directionalScorePct: number; // 0 bearish, 50 neutral, 100 bullish
  confidencePct: number; // strength away from neutral, 50–100
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  weights: VerdictWeightProfile;
  weightedEvidence: number;
}

/** Nominal contributions when live OI is available. Matrix stays at 15% when present. */
export const TIMEFRAME_VERDICT_WEIGHT_PROFILES: Record<SyntheticBuildupTimeframe, VerdictWeightProfile> = {
  '5m': { priceAction: 40, volume: 25, syntheticMatrix: 15, liveOi: 20 },
  '15m': { priceAction: 45, volume: 25, syntheticMatrix: 15, liveOi: 15 },
  '1h': { priceAction: 50, volume: 20, syntheticMatrix: 15, liveOi: 15 },
  '1d': { priceAction: 55, volume: 15, syntheticMatrix: 15, liveOi: 15 }
};

type ComponentKey = keyof VerdictWeightProfile;
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

/** Redistributes unavailable evidence across present components; never inserts synthetic OI. */
export function calculateTimeframeWeightedVerdict(input: WeightedVerdictInput): WeightedVerdictResult {
  const nominal = TIMEFRAME_VERDICT_WEIGHT_PROFILES[input.timeframe];
  const oiScore = input.liveOiSignals.filter(signal => signal.available && Number.isFinite(signal.scorePct));
  const hasOi = oiScore.length > 0;
  const matrix = input.syntheticBuildup?.available ? input.syntheticBuildup : undefined;
  const available: Record<ComponentKey, boolean> = {
    priceAction: true,
    volume: input.volumeAvailable,
    syntheticMatrix: !!matrix,
    liveOi: hasOi
  };
  const rawWeights: Record<ComponentKey, number> = { ...nominal };
  // If live OI is absent, preserve a present matrix's 15% allocation and split OI's share
  // between price action and volume in proportion to their nominal weights.
  if (!hasOi) {
    const share = rawWeights.liveOi;
    const recipients = rawWeights.priceAction + rawWeights.volume;
    rawWeights.priceAction += recipients ? share * rawWeights.priceAction / recipients : share;
    rawWeights.volume += recipients ? share * rawWeights.volume / recipients : 0;
    rawWeights.liveOi = 0;
  }
  // Exclude unavailable feeds. Distribute their weight proportionally over the remaining
  // present inputs; this keeps the weights normalized and makes missing data non-directional.
  const missingWeight = (Object.keys(rawWeights) as ComponentKey[])
    .filter(key => !available[key]).reduce((sum, key) => sum + rawWeights[key], 0);
  const remainingWeight = (Object.keys(rawWeights) as ComponentKey[])
    .filter(key => available[key]).reduce((sum, key) => sum + rawWeights[key], 0);
  const weights = { ...rawWeights };
  for (const key of Object.keys(weights) as ComponentKey[]) {
    if (!available[key]) weights[key] = 0;
    else if (remainingWeight > 0) weights[key] += missingWeight * rawWeights[key] / remainingWeight;
  }
  const weightTotal = Object.values(weights).reduce((sum, weight) => sum + weight, 0);
  if (weightTotal > 0) for (const key of Object.keys(weights) as ComponentKey[]) weights[key] = weights[key] * 100 / weightTotal;

  const volumeSigned = input.volumeDirection === 'BULLISH' ? 1 : input.volumeDirection === 'BEARISH' ? -1 : 0;
  const matrixSigned = matrix ? clamp((matrix.direction === 'BULLISH' ? 1 : matrix.direction === 'BEARISH' ? -1 : 0) * matrix.confidencePct, -100, 100) : 0;
  const liveOiSigned = hasOi ? oiScore.reduce((sum, signal) => sum + clamp(signal.scorePct, -100, 100), 0) / oiScore.length : 0;
  const weightedEvidence = clamp(
    (clamp(input.priceActionSigned, -100, 100) * weights.priceAction
      + volumeSigned * clamp(input.volumeStrengthPct, 0, 100) * weights.volume
      + matrixSigned * weights.syntheticMatrix
      + liveOiSigned * weights.liveOi) / 100,
    -100, 100
  );
  const directionalScorePct = Math.round(50 + weightedEvidence / 2);
  const direction = directionalScorePct >= 60 ? 'BULLISH' : directionalScorePct <= 40 ? 'BEARISH' : 'NEUTRAL';
  return {
    directionalScorePct,
    confidencePct: Math.round(50 + Math.abs(weightedEvidence) / 2),
    direction,
    weights: Object.fromEntries(Object.entries(weights).map(([key, value]) => [key, Math.round(value * 10) / 10])) as unknown as VerdictWeightProfile,
    weightedEvidence
  };
}
