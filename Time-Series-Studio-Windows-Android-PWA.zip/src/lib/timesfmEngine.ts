import {
  TimeSeriesPoint,
  ForecastPoint,
  ModelConfig,
  ForecastResult,
  ForecastMetrics,
  TradingMetrics,
  TradingSignal,
  DecompositionResult,
  AnomalyItem,
  FrequencyType
} from '../types';

/**
 * Local statistical forecast baseline. This is not Google's pretrained TimesFM.
 */

// Helper: Calculate Mean and Sample Standard Deviation
export function computeStats(values: number[]): { mean: number; std: number } {
  if (values.length === 0) return { mean: 0, std: 1 };
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / Math.max(1, values.length - 1);
  const std = Math.max(1e-5, Math.sqrt(variance));
  return { mean, std };
}

// Helper: Calculate Skewness and Kurtosis (Fat-tail asymmetric distribution)
export function computeHigherMoments(values: number[]): { skewness: number; kurtosis: number } {
  if (values.length < 4) return { skewness: 0, kurtosis: 3 };
  const { mean, std } = computeStats(values);
  let m3 = 0;
  let m4 = 0;
  for (let i = 0; i < values.length; i++) {
    const diff = (values[i] - mean) / std;
    m3 += Math.pow(diff, 3);
    m4 += Math.pow(diff, 4);
  }
  const n = values.length;
  const skewness = Math.max(-2.5, Math.min(2.5, m3 / n));
  const kurtosis = Math.max(1.5, Math.min(8.0, m4 / n));
  return { skewness, kurtosis };
}

// Reversible Instance Normalization (RevIN)
export class RevIN {
  mean: number = 0;
  std: number = 1;

  normalize(values: number[]): number[] {
    const stats = computeStats(values);
    this.mean = stats.mean;
    this.std = stats.std;
    return values.map(v => (v - this.mean) / this.std);
  }

  denormalize(normalizedValues: number[]): number[] {
    return normalizedValues.map(v => v * this.std + this.mean);
  }

  denormalizeSingle(v: number): number {
    return v * this.std + this.mean;
  }
}

/**
 * Adaptive Microstructure Noise Filter (Savitzky-Golay / Adaptive Local Kernel)
 * Smooths high-frequency bid-ask bouncing without shifting peak/trough phases.
 */
export function denoiseMicrostructureSeries(values: number[]): number[] {
  const n = values.length;
  if (n < 7) return [...values];

  const denoised: number[] = new Array(n);
  // Boundary preserve
  denoised[0] = values[0];
  denoised[1] = (values[0] * 2 + values[1] * 3 + values[2] * 2) / 7;
  denoised[n - 2] = (values[n - 3] * 2 + values[n - 2] * 3 + values[n - 1] * 2) / 7;
  denoised[n - 1] = values[n - 1];

  // 5-point Savitzky-Golay quadratic filter coefficients: [-3, 12, 17, 12, -3] / 35
  for (let i = 2; i < n - 2; i++) {
    const smoothed = (-3 * values[i - 2] + 12 * values[i - 1] + 17 * values[i] + 12 * values[i + 1] - 3 * values[i + 2]) / 35;
    // Edge-preservation: don't over-smooth sharp structural breaks
    const rawDelta = Math.abs(values[i] - values[i - 1]);
    const avgDelta = (Math.abs(values[i - 1] - values[i - 2]) + Math.abs(values[i + 1] - values[i])) / 2;
    if (rawDelta > 2.5 * (avgDelta + 1e-4)) {
      denoised[i] = values[i]; // Keep structural pivot
    } else {
      denoised[i] = smoothed;
    }
  }

  return denoised;
}

/**
 * TimesFM 3.0 Dual-Resolution Multi-Scale Patch Token Cross-Attention
 * Blends Micro-patches (P=8 for high-frequency microstructure reversals) and
 * Macro-patches (P=16–32 for multi-day cyclical waves) using multi-head scaled dot product.
 */
export function computeDualPatchAttentionProjection(
  normalizedValues: number[],
  patchLength: number,
  horizon: number
): { deltas: number[]; microConfidence: number; macroConfidence: number } {
  const n = normalizedValues.length;
  const pMacro = Math.max(12, Math.min(patchLength, Math.floor(n / 2)));
  const pMicro = Math.max(4, Math.min(8, Math.floor(n / 4)));

  if (n < pMacro * 2 && n < pMicro * 2) {
    return { deltas: new Array(horizon).fill(0), microConfidence: 0.5, macroConfidence: 0.5 };
  }

  // Helper for single patch attention projection
  const runPatchAttention = (p: number): { deltas: number[]; entropy: number } => {
    const numPatches = Math.floor(n / p);
    if (numPatches < 2) return { deltas: new Array(horizon).fill(0), entropy: 1 };

    const patches: number[][] = [];
    for (let i = 0; i < numPatches; i++) {
      patches.push(normalizedValues.slice(i * p, (i + 1) * p));
    }

    const queryPatch = patches[patches.length - 1];
    const keys = patches.slice(0, patches.length - 1);

    const scores = keys.map(k => {
      let dot = 0;
      for (let j = 0; j < p; j++) {
        dot += queryPatch[j] * k[j];
      }
      return dot / Math.sqrt(p);
    });

    const maxScore = Math.max(...scores);
    const expScores = scores.map(s => Math.exp(Math.max(-10, Math.min(10, s - maxScore))));
    const sumExp = expScores.reduce((a, b) => a + b, 0) || 1;
    const attentionWeights = expScores.map(e => e / sumExp);

    // Compute normalized attention entropy (lower entropy = higher concentration/confidence)
    let entropy = 0;
    for (const w of attentionWeights) {
      if (w > 1e-6) entropy -= w * Math.log(w);
    }
    const maxEntropy = Math.log(Math.max(2, keys.length));
    const normEntropy = maxEntropy > 0 ? entropy / maxEntropy : 1;

    const deltas: number[] = [];
    for (let h = 0; h < horizon; h++) {
      let projectedDelta = 0;
      for (let k = 0; k < keys.length; k++) {
        const stepInPatch = h % p;
        const priorPatchDelta = (k < patches.length - 1)
          ? (patches[k + 1][stepInPatch] - patches[k][stepInPatch])
          : 0;
        projectedDelta += attentionWeights[k] * priorPatchDelta;
      }
      deltas.push(projectedDelta * 0.42);
    }

    return { deltas, entropy: normEntropy };
  };

  const macroRes = runPatchAttention(pMacro);
  const microRes = runPatchAttention(pMicro);

  // Confidence inversely proportional to attention entropy
  const macroWeightRaw = Math.max(0.2, 1 - macroRes.entropy);
  const microWeightRaw = Math.max(0.2, 1 - microRes.entropy);
  const sumW = macroWeightRaw + microWeightRaw;
  const macroW = macroWeightRaw / sumW;
  const microW = microWeightRaw / sumW;

  const combinedDeltas: number[] = [];
  for (let h = 0; h < horizon; h++) {
    const val = (macroRes.deltas[h] || 0) * macroW + (microRes.deltas[h] || 0) * microW;
    combinedDeltas.push(val);
  }

  return {
    deltas: combinedDeltas,
    microConfidence: Math.round(microW * 100) / 100,
    macroConfidence: Math.round(macroW * 100) / 100
  };
}

// Backward-compatible alias
export function computePatchAttentionProjection(
  normalizedValues: number[],
  patchLength: number,
  horizon: number
): number[] {
  return computeDualPatchAttentionProjection(normalizedValues, patchLength, horizon).deltas;
}

// Detect period for seasonality based on frequency and Auto-Correlation Function (ACF)
export function getSeasonalPeriod(frequency: string, dataLength: number, values?: number[]): number {
  // If values provided, calculate dominant autocorrelation lag
  if (values && values.length >= 24) {
    const { mean } = computeStats(values);
    const maxLag = Math.min(30, Math.floor(values.length / 2));
    let bestLag = 5;
    let maxAcf = 0.05;

    let varTotal = 0;
    for (let i = 0; i < values.length; i++) {
      varTotal += Math.pow(values[i] - mean, 2);
    }

    if (varTotal > 1e-6) {
      for (let lag = 3; lag <= maxLag; lag++) {
        let cov = 0;
        for (let i = 0; i < values.length - lag; i++) {
          cov += (values[i] - mean) * (values[i + lag] - mean);
        }
        const acf = cov / varTotal;
        if (acf > maxAcf) {
          maxAcf = acf;
          bestLag = lag;
        }
      }
      if (maxAcf > 0.3) {
        return bestLag;
      }
    }
  }

  switch (frequency) {
    case 'hourly':
      return 24; // 24 hours in a day
    case 'daily':
      // In financial markets (NSE/BSE/US), 1 trading week = 5 daily candles
      return 5;
    case 'weekly':
      return 52; // 52 weeks in a year
    case 'monthly':
      return 12; // 12 months in a year
    default:
      // Auto-detect heuristic
      return Math.min(20, Math.max(5, Math.floor(dataLength / 5)));
  }
}

// Decompose time series into Trend, Seasonality, and Residuals (Additive Model)
export function decomposeTimeSeries(points: TimeSeriesPoint[], frequency: string): DecompositionResult {
  const values = points.map(p => p.value);
  const timestamps = points.map(p => p.timestamp);
  const n = values.length;
  const differences = values.slice(1).map((value, i) => value - values[i]);
  const period = getSeasonalPeriod(frequency, n, differences);

  // 1. Compute Centered Moving Average for Trend
  const trend: number[] = new Array(n).fill(0);
  const half = Math.floor(period / 2);

  for (let i = 0; i < n; i++) {
    const start = Math.max(0, i - half);
    const end = Math.min(n, i + half + 1);
    let sum = 0;
    let count = 0;
    for (let j = start; j < end; j++) {
      sum += values[j];
      count++;
    }
    trend[i] = sum / count;
  }

  // 2. Detrend and compute average seasonal factors for each phase modulo period
  const detrended = values.map((v, i) => v - trend[i]);
  const seasonalSums = new Array(period).fill(0);
  const seasonalCounts = new Array(period).fill(0);

  for (let i = 0; i < n; i++) {
    const phase = i % period;
    seasonalSums[phase] += detrended[i];
    seasonalCounts[phase] += 1;
  }

  const seasonalFactor = seasonalSums.map((sum, idx) => seasonalCounts[idx] > 0 ? sum / seasonalCounts[idx] : 0);
  // Center seasonal factor so its mean is 0
  const factorMean = seasonalFactor.reduce((a, b) => a + b, 0) / period;
  const centeredSeasonalFactor = seasonalFactor.map(f => f - factorMean);

  const seasonal: number[] = values.map((_, i) => centeredSeasonalFactor[i % period]);
  const residual: number[] = values.map((v, i) => v - trend[i] - seasonal[i]);

  return {
    timestamps,
    observed: values,
    trend,
    seasonal,
    residual,
    period
  };
}

// Anomaly Detection Algorithm (TimesFM Residual & Quantile Envelopes)
export function detectAnomalies(
  points: TimeSeriesPoint[],
  decomposition: DecompositionResult,
  thresholdZScore: number = 2.5
): AnomalyItem[] {
  const anomalies: AnomalyItem[] = [];
  const residuals = decomposition.residual;
  const { mean, std } = computeStats(residuals);

  points.forEach((point, i) => {
    // If dataset already has ground-truth anomaly flag or calculated residual anomaly
    const res = residuals[i];
    const zScore = Math.abs(res - mean) / Math.max(1e-5, std);
    const expected = decomposition.trend[i] + decomposition.seasonal[i];
    const margin = thresholdZScore * std;
    const lower = expected - margin;
    const upper = expected + margin;

    const isBreach = zScore >= thresholdZScore || point.isAnomaly;

    if (isBreach) {
      let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
      if (zScore >= 5.0) severity = 'critical';
      else if (zScore >= 3.8) severity = 'high';
      else if (zScore >= 2.8) severity = 'medium';

      let reason = `Deviation of ${Math.round(zScore * 10) / 10}σ from baseline (${point.value.toFixed(1)} vs expected ${expected.toFixed(1)})`;
      if (point.value > upper) {
        reason = `Spike anomaly: +${((point.value - expected) / Math.max(1, Math.abs(expected)) * 100).toFixed(1)}% above expected seasonal band.`;
      } else if (point.value < lower) {
        reason = `Drop anomaly: -${((expected - point.value) / Math.max(1, Math.abs(expected)) * 100).toFixed(1)}% drop below normal operating floor.`;
      }

      anomalies.push({
        index: i,
        timestamp: point.timestamp,
        actual: point.value,
        expected: Math.round(expected * 100) / 100,
        score: Math.round(zScore * 100) / 100,
        severity: point.anomalySeverity || severity,
        lowerBound: Math.round(lower * 100) / 100,
        upperBound: Math.round(upper * 100) / 100,
        reason
      });
    }
  });

  return anomalies;
}

// Generate future timestamps matching history frequency
export function generateFutureTimestamps(history: TimeSeriesPoint[], horizon: number, frequency: string): string[] {
  if (history.length === 0) return [];
  const lastPoint = history[history.length - 1].timestamp;
  const future: string[] = [];

  // Check if timestamp is a pure year (e.g. "2024")
  if (/^\d{4}$/.test(lastPoint)) {
    let year = parseInt(lastPoint, 10);
    for (let i = 1; i <= horizon; i++) {
      future.push(`${year + i}`);
    }
    return future;
  }

  // Check if timestamp is time format (HH:MM)
  if (/^\d{2}:\d{2}$/.test(lastPoint)) {
    const [h, m] = lastPoint.split(':').map(Number);
    let totalMinutes = h * 60 + m;
    for (let i = 1; i <= horizon; i++) {
      totalMinutes += 5; // 5-minute interval
      const nh = Math.floor((totalMinutes / 60) % 24).toString().padStart(2, '0');
      const nm = (totalMinutes % 60).toString().padStart(2, '0');
      future.push(`${nh}:${nm}`);
    }
    return future;
  }

  // Fallback: parse as standard Date
  const lastDate = new Date(lastPoint);
  const isValidDate = !isNaN(lastDate.getTime());

  if (!isValidDate) {
    for (let i = 1; i <= horizon; i++) {
      future.push(`Step +${i}`);
    }
    return future;
  }

  // Check if history has step interval (e.g. 15min, 30min, 1h)
  let detectedStepMs = 0;
  if (history.length >= 2) {
    const tLast = new Date(history[history.length - 1].timestamp).getTime();
    const tPrev = new Date(history[history.length - 2].timestamp).getTime();
    if (!isNaN(tLast) && !isNaN(tPrev) && tLast > tPrev) {
      detectedStepMs = tLast - tPrev;
    }
  }

  // Detect if history is daily trading days (i.e. Saturday and Sunday are absent in financial markets)
  const isDailyCandidate = frequency === 'daily' || (!detectedStepMs || detectedStepMs >= 18 * 3600 * 1000);
  let isTradingDaySeries = false;
  if (isDailyCandidate && history.length >= 5) {
    let weekendCount = 0;
    const checkSample = Math.min(25, history.length);
    for (let k = history.length - checkSample; k < history.length; k++) {
      const day = new Date(history[k].timestamp).getDay();
      if (day === 0 || day === 6) weekendCount++;
    }
    // If no weekend days found in recent history, it is a strict financial trading-day series
    if (weekendCount === 0) {
      isTradingDaySeries = true;
    }
  }

  let tradingDateCursor = new Date(lastDate);

  for (let i = 1; i <= horizon; i++) {
    if (isTradingDaySeries) {
      // Advance only through active trading days (Monday to Friday, skipping Saturday & Sunday)
      do {
        tradingDateCursor.setDate(tradingDateCursor.getDate() + 1);
      } while (tradingDateCursor.getDay() === 0 || tradingDateCursor.getDay() === 6);
      future.push(tradingDateCursor.toISOString().split('T')[0]);
    } else if (detectedStepMs > 0 && detectedStepMs <= 4 * 3600 * 1000) {
      // 15-minute, 30-minute, or 1-hour intraday steps
      const nextDate = new Date(lastDate.getTime() + detectedStepMs * i);
      future.push(nextDate.toISOString().slice(0, 16).replace('T', ' '));
    } else if (frequency === 'hourly') {
      const nextDate = new Date(lastDate.getTime() + i * 3600 * 1000);
      future.push(nextDate.toISOString().slice(0, 16).replace('T', ' '));
    } else if (frequency === 'weekly') {
      const nextDate = new Date(lastDate);
      nextDate.setDate(lastDate.getDate() + i * 7);
      future.push(nextDate.toISOString().split('T')[0]);
    } else if (frequency === 'monthly') {
      const nextDate = new Date(lastDate);
      nextDate.setMonth(lastDate.getMonth() + i);
      future.push(nextDate.toISOString().slice(0, 7));
    } else {
      const nextDate = new Date(lastDate);
      nextDate.setDate(lastDate.getDate() + i);
      future.push(nextDate.toISOString().split('T')[0]);
    }
  }

  return future;
}

// Covariate effect calculation (TimesFM CPM - Covariate Projection Module)
export function computeCovariateLift(
  covariates: Record<string, number> | undefined,
  history: TimeSeriesPoint[]
): number {
  if (!covariates || Object.keys(covariates).length === 0) return 0;

  let totalLift = 0;

  // Compute baseline stats for each covariate in history to calculate relative change
  Object.entries(covariates).forEach(([key, val]) => {
    const histVals = history
      .map(h => h.covariates?.[key])
      .filter((v): v is number => typeof v === 'number');

    const histMean = histVals.length > 0 ? histVals.reduce((a, b) => a + b, 0) / histVals.length : 0;
    const diff = val - histMean;

    // Specific domain weights based on covariate naming patterns
    if (key.includes('rsi')) {
      // Relative Strength Index mean-reversion & momentum dynamics
      if (val < 30) totalLift += (30 - val) * 0.003; // Oversold dip buying potential
      else if (val > 70) totalLift -= (val - 70) * 0.0025; // Overbought exhaustion
    } else if (key.includes('macd')) {
      // MACD histogram momentum
      totalLift += Math.max(-0.06, Math.min(0.06, val * 0.03));
    } else if (key.includes('volume')) {
      // High volume breakout confirmation
      if (val > 1.5) totalLift += Math.sign(diff) * 0.02;
    } else if (key.includes('bollinger')) {
      if (val < 15) totalLift += 0.02; // Near lower band bounce
      else if (val > 85) totalLift -= 0.02; // Near upper band resistance
    } else if (key.includes('vwap')) {
      // Price relative to VWAP
      if (val > 0) totalLift += Math.min(0.04, val * 0.015);
      else totalLift += Math.max(-0.04, val * 0.015);
    } else if (key.includes('supertrend')) {
      totalLift += val > 0 ? 0.025 : -0.025;
    } else if (key.includes('ema') || key.includes('sma')) {
      totalLift += Math.max(-0.04, Math.min(0.04, diff * 0.02));
    } else if (key.includes('promo') || key.includes('discount')) {
      // E.g. discount_pct 25% -> lift ~ +0.35
      totalLift += (val > 0 ? (val > 1 ? val / 100 : val) * 0.9 : 0);
    } else if (key.includes('spend') || key.includes('budget')) {
      totalLift += (diff / (histMean || 1000)) * 0.25;
    } else if (key.includes('holiday') || key.includes('earnings')) {
      totalLift += val > 0 ? 0.15 : 0;
    } else if (key.includes('temp')) {
      // Cooling/heating degree days effect
      if (val > 24) totalLift += (val - 24) * 0.035;
      else if (val < 10) totalLift += (10 - val) * 0.02;
    } else if (key.includes('volatility') || key.includes('vix') || key.includes('atr')) {
      totalLift -= (diff / (histMean || 15)) * 0.08;
    } else {
      // General normalized relative impact
      if (histMean !== 0) {
        totalLift += (diff / Math.abs(histMean)) * 0.12;
      }
    }
  });

  return Math.max(-0.5, Math.min(1.2, totalLift)); // bound lift
}

/**
 * Automatically detects TimesFM Frequency Token based on timestamp delta analysis
 * Token 0: High-frequency / Sub-daily / 15m / 1h / Intraday
 * Token 1: Daily (1D)
 * Token 2: Weekly (1W)
 * Token 3: Monthly (1M)
 */
export function detectTimesFmFrequencyToken(
  history: TimeSeriesPoint[],
  userFrequency?: FrequencyType
): { token: number; name: string; type: FrequencyType } {
  if (userFrequency && userFrequency !== 'auto') {
    if (userFrequency === 'hourly') return { token: 0, name: '0 (High-Freq / Sub-Daily)', type: 'hourly' };
    if (userFrequency === 'daily') return { token: 1, name: '1 (Daily Cadence)', type: 'daily' };
    if (userFrequency === 'weekly') return { token: 2, name: '2 (Weekly Cadence)', type: 'weekly' };
    if (userFrequency === 'monthly') return { token: 3, name: '3 (Monthly Cadence)', type: 'monthly' };
  }

  if (history.length < 2) {
    return { token: 1, name: '1 (Daily Default)', type: 'daily' };
  }

  // Sample the last up to 30 timestamp differences
  const sampleCount = Math.min(30, history.length - 1);
  let totalDeltaMs = 0;
  let validDeltas = 0;

  for (let i = history.length - sampleCount; i < history.length; i++) {
    const tCur = new Date(history[i].timestamp).getTime();
    const tPrev = new Date(history[i - 1].timestamp).getTime();
    if (!isNaN(tCur) && !isNaN(tPrev) && tCur > tPrev) {
      totalDeltaMs += (tCur - tPrev);
      validDeltas++;
    }
  }

  if (validDeltas === 0) {
    return { token: 1, name: '1 (Daily Auto)', type: 'daily' };
  }

  const avgDeltaMinutes = (totalDeltaMs / validDeltas) / (60 * 1000);

  if (avgDeltaMinutes <= 180) {
    // 5m, 15m, 30m, 1h, 2h intraday
    return { token: 0, name: '0 (High-Freq / 15m–1h)', type: 'hourly' };
  } else if (avgDeltaMinutes <= 36 * 60) {
    // Daily (up to ~36 hours for weekend/overnight gaps)
    return { token: 1, name: '1 (Daily 1D)', type: 'daily' };
  } else if (avgDeltaMinutes <= 10 * 24 * 60) {
    // Weekly (~7 days)
    return { token: 2, name: '2 (Weekly 1W)', type: 'weekly' };
  } else {
    // Monthly / Multi-week
    return { token: 3, name: '3 (Monthly 1M)', type: 'monthly' };
  }
}

/**
 * Main TimesFM Forecast Engine
 */
export function runTimesFmForecast(
  history: TimeSeriesPoint[],
  config: ModelConfig,
  futureCovariatesList?: Record<string, number>[]
): ForecastResult {
  const startTime = performance.now();

  // Automatically detect TimesFM Frequency Token
  const freqDetection = detectTimesFmFrequencyToken(history, config.frequency);
  const effectiveFrequency = config.frequency === 'auto' ? freqDetection.type : config.frequency;

  // Maximum context length input pipeline: ingest full history up to max supported context
  const requestedContext = config.contextLength || 512;
  const effectiveContextLength = Math.max(1, Math.min(history.length, requestedContext));
  const contextPoints = history.slice(-effectiveContextLength);
  const rawValues = contextPoints.map(p => p.value);
  const n = rawValues.length;

  // 1. Reversible Instance Normalization (RevIN) with Microstructure Denoising
  const revin = new RevIN();
  const normalizedValues = revin.normalize(rawValues);

  // Denoised normalized values for robust structural patch token attention
  const denoisedRawValues = denoiseMicrostructureSeries(rawValues);
  const denoisedNormValues = denoisedRawValues.map(value => (value - revin.mean) / revin.std);

  // 2. Frequency & Seasonal-Trend Decomposition of Context Window
  const decomp = decomposeTimeSeries(contextPoints, effectiveFrequency);
  const period = decomp.period;

  // 3. Higher Order Statistical Moments (Asymmetric Skewness & Kurtosis for Financial Quantiles)
  const { skewness: residualSkew, kurtosis: residualKurt } = computeHigherMoments(decomp.residual);

  // 4. Autoregressive Trend Projection in Scale-Invariant RevIN Space with Log-Returns Drift Guard
  const windowForSlope = Math.min(n, Math.max(12, period * 2));
  const slopeNormValues = denoisedNormValues.slice(-windowForSlope);
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < windowForSlope; i++) {
    sumX += i;
    sumY += slopeNormValues[i];
    sumXY += i * slopeNormValues[i];
    sumXX += i * i;
  }
  let normSlope = (windowForSlope * sumXY - sumX * sumY) / Math.max(1e-5, windowForSlope * sumXX - sumX * sumX);
  
  // Calculate historical log-return standard deviation to prevent runaway linear overshoot
  const logReturns: number[] = [];
  for (let i = 1; i < n; i++) {
    if (rawValues[i - 1] > 0 && rawValues[i] > 0) {
      logReturns.push(Math.log(rawValues[i] / rawValues[i - 1]));
    }
  }
  const avgLogReturn = logReturns.length > 0 ? logReturns.reduce((a, b) => a + b, 0) / logReturns.length : 0;
  const stdLogReturn = logReturns.length > 1
    ? Math.sqrt(logReturns.reduce((acc, r) => acc + Math.pow(r - avgLogReturn, 2), 0) / (logReturns.length - 1))
    : 0.015;
  
  // Bound normSlope to within 2.8 standard deviations in RevIN space
  const maxNormSlope = (stdLogReturn * (rawValues[n - 1] || 100)) / (revin.std || 1) * 2.8;
  normSlope = Math.max(-maxNormSlope, Math.min(maxNormSlope, normSlope));

  const lastNormValue = normalizedValues[n - 1];
  const lastHistoricalValue = rawValues[n - 1] ?? 100;

  // 5. TimesFM 3.0 Dual-Resolution Multi-Scale Patch Token Attention Dynamics
  const dualPatch = computeDualPatchAttentionProjection(denoisedNormValues, config.patchLength || 32, config.horizon || 32);
  const patchAttentionDeltas = dualPatch.deltas;

  // 6. Model Architecture Hyperparameters (TimesFM 3.0 vs 2.5 vs 1.0)
  const dampingFactor = 0.91;
  const uncertaintyGrowthRate = config.confidenceLevel === 95 ? 1.96 : config.confidenceLevel === 80 ? 1.2816 : 0.6745;
  const { std: residualStd } = computeStats(decomp.residual);

  // 7. Future Timestamps
  const effectiveHorizon = config.horizon || 32;
  const futureTimestamps = generateFutureTimestamps(contextPoints, effectiveHorizon, effectiveFrequency);

  // 8. Generate Point Forecasts & Quantiles with RevIN inverse restoration
  const forecasts: ForecastPoint[] = [];

  for (let h = 0; h < effectiveHorizon; h++) {
    const timestamp = futureTimestamps[h] || `Step +${h + 1}`;
    const futureCovariates = futureCovariatesList?.[h] || contextPoints[contextPoints.length - 1]?.covariates;

    // Scale-invariant trend component in RevIN space with progressive stabilization
    const normTrendContribution = normSlope * (h + 1) * Math.pow(dampingFactor, h);
    const patchAttnContribution = patchAttentionDeltas[h] || 0;

    // Projected normalized value
    const normBase = lastNormValue + normTrendContribution + patchAttnContribution;

    // Seasonal component aligned with historical cyclical phase
    const seasonalIndex = (n + h) % period;
    const seasonalContribution = decomp.seasonal[seasonalIndex % decomp.seasonal.length] || 0;

    // Denormalize projected base back to scale
    const baseDenormPrice = revin.denormalizeSingle(normBase) + seasonalContribution;

    // Covariate CPM module adjustment
    const covLift = config.useCovariates ? computeCovariateLift(futureCovariates, contextPoints) : 0;
    const covariateAdjusted = Math.max(0.01, baseDenormPrice * (1 + covLift));

    // Dynamic uncertainty cone: expands with sqrt(horizon) + fat-tailed kurtosis
    const fatTailMultiplier = Math.sqrt(1 + 0.12 * Math.max(0, residualKurt - 3.0));
    const stepStd = residualStd * (1 + 0.18 * Math.sqrt(h + 1)) * fatTailMultiplier;

    // 95% Confidence Cone (z = 1.96)
    const z95 = 1.96;
    const downSpread95 = z95 * stepStd * (1 - 0.25 * residualSkew);
    const upSpread95 = z95 * stepStd * (1 + 0.25 * residualSkew);
    const p025 = Math.max(0.01, covariateAdjusted - downSpread95 * 1.15);
    const p975 = covariateAdjusted + upSpread95 * 1.15;

    // 90% Bound (z = 1.645)
    const z90 = 1.645;
    const downSpread90 = z90 * stepStd * (1 - 0.20 * residualSkew);
    const upSpread90 = z90 * stepStd * (1 + 0.20 * residualSkew);
    const p10 = Math.max(0.01, covariateAdjusted - downSpread90 * 1.05);
    const p90 = covariateAdjusted + upSpread90 * 1.05;

    // 50% Interquartile Bound (p25 to p75)
    const p25 = Math.max(0.01, covariateAdjusted - (0.674 * stepStd * (1 - 0.1 * residualSkew)));
    const p75 = covariateAdjusted + (0.674 * stepStd * (1 + 0.1 * residualSkew));
    const p50 = covariateAdjusted;
    const mean = (p025 + p10 + p25 + p50 * 2 + p75 + p90 + p975) / 8;

    forecasts.push({
      timestamp,
      mean: Math.round(mean * 100) / 100,
      p025: Math.round(p025 * 100) / 100,
      p10: Math.round(p10 * 100) / 100,
      p25: Math.round(p25 * 100) / 100,
      p50: Math.round(p50 * 100) / 100,
      p75: Math.round(p75 * 100) / 100,
      p90: Math.round(p90 * 100) / 100,
      p975: Math.round(p975 * 100) / 100,
      covariates: futureCovariates
    });
  }

  // 7. Calculate Anomaly flags on Historical Context
  const anomalies = detectAnomalies(contextPoints, decomp, config.anomalyThreshold);

  // 8. Backtesting Metrics on Context Hold-out slice with Directional Accuracy (MDA)
  let metrics: ForecastMetrics | undefined;
  const testWindow = Math.min(14, Math.floor(n * 0.2));
  if (testWindow >= 4) {
    const actuals = rawValues.slice(-testWindow);
    const preds = decomp.trend.slice(-testWindow).map((t, idx) => t + decomp.seasonal.slice(-testWindow)[idx]);

    let sumAbsErr = 0;
    let sumSqErr = 0;
    let sumPctErr = 0;
    let sumSymmetricPct = 0;
    let inCoverage = 0;
    let correctDirectionCount = 0;
    let grossGains = 0;
    let grossLosses = 0;

    for (let i = 0; i < testWindow; i++) {
      const act = actuals[i];
      const prd = preds[i];
      const err = Math.abs(act - prd);
      sumAbsErr += err;
      sumSqErr += err * err;
      sumPctErr += Math.abs(act) > 0 ? (err / Math.abs(act)) : 0;
      sumSymmetricPct += (2 * err) / (Math.abs(act) + Math.abs(prd) + 1e-5);

      const upper = prd + uncertaintyGrowthRate * residualStd;
      const lower = prd - uncertaintyGrowthRate * residualStd;
      if (act >= lower && act <= upper) inCoverage++;

      // Mean Directional Accuracy (MDA) check
      if (i > 0) {
        const actualDelta = actuals[i] - actuals[i - 1];
        const predDelta = preds[i] - preds[i - 1];
        if (Math.sign(actualDelta) === Math.sign(predDelta) || actualDelta === 0) {
          correctDirectionCount++;
          grossGains += Math.abs(actualDelta);
        } else {
          grossLosses += Math.abs(actualDelta);
        }
      }
    }

    const directionEvalCount = Math.max(1, testWindow - 1);
    const mda = Math.round((correctDirectionCount / directionEvalCount) * 100);
    const profitFactor = grossLosses > 0 ? Math.round((grossGains / grossLosses) * 100) / 100 : 2.5;
    const rmseVal = Math.sqrt(sumSqErr / testWindow);
    const sharpeProxy = Math.round(((Math.abs(avgLogReturn) * Math.sqrt(252)) / (stdLogReturn * Math.sqrt(252) + 1e-4)) * 100) / 100;

    metrics = {
      mae: Math.round((sumAbsErr / testWindow) * 100) / 100,
      rmse: Math.round(rmseVal * 100) / 100,
      mape: Math.round((sumPctErr / testWindow) * 1000) / 10, // in %
      smape: Math.round((sumSymmetricPct / testWindow) * 1000) / 10, // in %
      coverageRate: Math.round((inCoverage / testWindow) * 100), // in %
      mda,
      sharpeProxy,
      profitFactor
    };
  }
  // The decomposition is fitted on the full context, so this is not an out-of-sample evaluation.
  metrics = undefined;

  // 9. Financial Trading Metrics & Signals
  const lastClose = lastHistoricalValue || 100;
  const lastPoint = contextPoints[contextPoints.length - 1];
  const finalForecast = forecasts[forecasts.length - 1] || { p50: lastClose, p10: lastClose * 0.95, p90: lastClose * 1.05 };
  const targetMedian = finalForecast.p50;
  const projectedReturnPct = Math.round(((targetMedian - lastClose) / Math.max(1e-4, lastClose)) * 10000) / 100;
  const p10Floor = finalForecast.p10;
  const p90Ceiling = finalForecast.p90;

  // Value at Risk (VaR 95% / 90%): Maximum anticipated loss to the support floor
  const valueAtRiskPct = Math.max(0, Math.round(((lastClose - (finalForecast.p025 ?? p10Floor)) / lastClose) * 10000) / 100);
  
  // Risk to Reward Ratio
  const upside = Math.max(0, p90Ceiling - targetMedian);
  const downside = Math.max(1e-4, targetMedian - p10Floor);
  const riskRewardRatio = Math.round((upside / downside) * 100) / 100;

  // Signal formulation
  let signal: TradingSignal = 'NEUTRAL';
  if (projectedReturnPct >= 2.5 && valueAtRiskPct < 3.5) {
    signal = 'STRONG_BUY';
  } else if (projectedReturnPct >= 0.7) {
    signal = 'BUY';
  } else if (projectedReturnPct <= -2.5) {
    signal = 'STRONG_SELL';
  } else if (projectedReturnPct <= -0.7) {
    signal = 'SELL';
  }

  // Directional confidence (based on historical metrics coverage and quantile spread)
  const directionalConfidence = undefined;

  const tradingMetrics: TradingMetrics = {
    signal,
    projectedReturnPct,
    directionalConfidence,
    targetMedianPrice: Math.round(targetMedian * 100) / 100,
    supportFloorP10: Math.round(p10Floor * 100) / 100,
    resistanceCeilingP90: Math.round(p90Ceiling * 100) / 100,
    valueAtRiskPct,
    riskRewardRatio,
    rsi14: lastPoint?.covariates?.rsi_14,
    sma20: decomp.trend[decomp.trend.length - 1] ? Math.round(decomp.trend[decomp.trend.length - 1] * 100) / 100 : undefined,
    atr14: lastPoint?.covariates?.volatility_atr_pct
  };

  const executionTimeMs = Math.round(performance.now() - startTime);

  return {
    engineName: 'Local Statistical Heuristic (not Google TimesFM)',
    history: contextPoints,
    forecasts,
    metrics,
    tradingMetrics,
    decomposition: decomp,
    anomalies,
    modelConfig: {
      ...config,
      frequency: effectiveFrequency,
      frequencyToken: freqDetection.token
    },
    frequencyToken: freqDetection.token,
    frequencyName: freqDetection.name,
    executionTimeMs,
    isLocalExecution: config.executionMode === 'local_device'
  };
}
