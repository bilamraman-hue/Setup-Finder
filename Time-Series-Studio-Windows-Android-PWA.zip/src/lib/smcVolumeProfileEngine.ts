import { TimeSeriesPoint, ForecastPoint } from '../types';

export interface InstitutionalSmcPayload {
  dataset_metadata: {
    loaded_history_months: number;
    htf_timeframe: string;
    ltf_timeframe: string;
    total_candles_loaded: number;
  };
  timesfm_3_output: {
    predicted_trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
    forecast_horizon_candles: number;
    expected_move_velocity: 'HIGH' | 'MODERATE' | 'STEADY';
    projected_price_points: number[];
  };
  market_data: {
    symbol: string;
    current_price: number;
    smc_ict: {
      htf_ssl_swept: boolean;
      htf_bsl_swept?: boolean;
      sweep_price: number;
      ltf_choch: boolean;
      unmitigated_fvg_zone: [number, number];
      fvg_consequent_encroachment?: number; // 50% equilibrium level
      fvg_mitigation_status?: 'UNMITIGATED' | '50% MITIGATED' | 'FULLY FILLED';
      bullish_ob: number;
      bearish_ob?: number;
      breaker_block?: number; // Inverted OB
      vsa_signal?: 'ABSORPTION (Accumulation)' | 'EXHAUSTION (Climax)' | 'BALANCED';
    };
    volume_profile: {
      poc: number;
      vah: number;
      val: number;
    };
  };
}

/**
 * Computes realistic Volume Profile (POC, VAH, VAL) from historical bar data
 */
export function computeVolumeProfile(
  points: TimeSeriesPoint[],
  binsCount: number = 30
): { poc: number; vah: number; val: number } {
  if (!points || points.length === 0) {
    return { poc: 100, vah: 105, val: 95 };
  }

  let minPrice = Infinity;
  let maxPrice = -Infinity;

  for (const pt of points) {
    const low = pt.low ?? pt.value;
    const high = pt.high ?? pt.value;
    if (low < minPrice) minPrice = low;
    if (high > maxPrice) maxPrice = high;
  }

  if (minPrice === maxPrice || !isFinite(minPrice) || !isFinite(maxPrice)) {
    const cmp = points[points.length - 1].value;
    return {
      poc: Math.round(cmp * 100) / 100,
      vah: Math.round(cmp * 1.01 * 100) / 100,
      val: Math.round(cmp * 0.99 * 100) / 100
    };
  }

  const step = (maxPrice - minPrice) / binsCount;
  const bins = new Float64Array(binsCount);
  let totalVolume = 0;

  for (const pt of points) {
    const vol = pt.volume && pt.volume > 0 ? pt.volume : 1000;
    const mid = pt.open && pt.value ? (pt.open + pt.value) / 2 : pt.value;
    const binIdx = Math.min(binsCount - 1, Math.max(0, Math.floor((mid - minPrice) / step)));
    bins[binIdx] += vol;
    totalVolume += vol;
  }

  // Find Point of Control (POC)
  let maxVol = 0;
  let pocIdx = Math.floor(binsCount / 2);
  for (let i = 0; i < binsCount; i++) {
    if (bins[i] > maxVol) {
      maxVol = bins[i];
      pocIdx = i;
    }
  }

  const poc = minPrice + (pocIdx + 0.5) * step;

  // Value Area = 70% of total volume around POC
  const targetAreaVol = totalVolume * 0.7;
  let accumulatedVol = bins[pocIdx];
  let left = pocIdx;
  let right = pocIdx;

  while (accumulatedVol < targetAreaVol && (left > 0 || right < binsCount - 1)) {
    const nextLeftVol = left > 0 ? bins[left - 1] : 0;
    const nextRightVol = right < binsCount - 1 ? bins[right + 1] : 0;

    if (nextLeftVol >= nextRightVol && left > 0) {
      left--;
      accumulatedVol += bins[left];
    } else if (right < binsCount - 1) {
      right++;
      accumulatedVol += bins[right];
    } else if (left > 0) {
      left--;
      accumulatedVol += bins[left];
    } else {
      break;
    }
  }

  const val = minPrice + left * step;
  const vah = minPrice + (right + 1) * step;

  return {
    poc: Math.round(poc * 100) / 100,
    vah: Math.round(vah * 100) / 100,
    val: Math.round(val * 100) / 100
  };
}

/**
 * Computes Smart Money Concepts (SMC/ICT) liquidity sweeps, order blocks, and Fair Value Gaps
 */
export function computeSmcIctLevels(
  points: TimeSeriesPoint[],
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS'
): {
  htf_ssl_swept: boolean;
  htf_bsl_swept: boolean;
  sweep_price: number;
  ltf_choch: boolean;
  unmitigated_fvg_zone: [number, number];
  fvg_consequent_encroachment?: number;
  fvg_mitigation_status?: 'UNMITIGATED' | '50% MITIGATED' | 'FULLY FILLED';
  bullish_ob: number;
  bearish_ob: number;
  breaker_block?: number;
  vsa_signal?: 'ABSORPTION (Accumulation)' | 'EXHAUSTION (Climax)' | 'BALANCED';
} {
  const n = points.length;
  if (n < 5) {
    const cmp = points[n - 1]?.value || 100;
    return {
      htf_ssl_swept: false,
      htf_bsl_swept: false,
      sweep_price: Math.round(cmp * 0.992 * 100) / 100,
      ltf_choch: false,
      unmitigated_fvg_zone: [
        Math.round(cmp * 0.995 * 100) / 100,
        Math.round(cmp * 0.998 * 100) / 100
      ],
      fvg_consequent_encroachment: Math.round(cmp * 0.9965 * 100) / 100,
      fvg_mitigation_status: 'UNMITIGATED',
      bullish_ob: Math.round(cmp * 0.99 * 100) / 100,
      bearish_ob: Math.round(cmp * 1.01 * 100) / 100,
      breaker_block: Math.round(cmp * 0.99 * 100) / 100,
      vsa_signal: 'BALANCED'
    };
  }

  const cmp = points[n - 1].value;

  // 1. Detect Swing Highs and Swing Lows (Fractals)
  const swingLows: { index: number; price: number }[] = [];
  const swingHighs: { index: number; price: number }[] = [];

  for (let i = 2; i < n - 2; i++) {
    const low = points[i].low ?? points[i].value;
    const l1 = points[i - 1].low ?? points[i - 1].value;
    const l2 = points[i - 2].low ?? points[i - 2].value;
    const r1 = points[i + 1].low ?? points[i + 1].value;
    const r2 = points[i + 2].low ?? points[i + 2].value;
    if (low <= l1 && low <= l2 && low <= r1 && low <= r2) {
      swingLows.push({ index: i, price: low });
    }

    const high = points[i].high ?? points[i].value;
    const h1 = points[i - 1].high ?? points[i - 1].value;
    const h2 = points[i - 2].high ?? points[i - 2].value;
    const r1h = points[i + 1].high ?? points[i + 1].value;
    const r2h = points[i + 2].high ?? points[i + 2].value;
    if (high >= h1 && high >= h2 && high >= r1h && high >= r2h) {
      swingHighs.push({ index: i, price: high });
    }
  }

  // 2. Identify Liquidity Sweeps
  // SSL Sweep: recent bar dipped below previous swing low but closed higher
  let htf_ssl_swept = false;
  let sweep_price = cmp * 0.99;
  if (swingLows.length > 0) {
    const recentLow = swingLows[swingLows.length - 1];
    sweep_price = recentLow.price;
    // Check if subsequent candle wicked below recentLow but CMP > recentLow.price
    for (let j = recentLow.index + 1; j < n; j++) {
      const barLow = points[j].low ?? points[j].value;
      if (barLow < recentLow.price && points[j].value >= recentLow.price) {
        htf_ssl_swept = true;
        sweep_price = barLow;
        break;
      }
    }
  }

  // BSL Sweep
  let htf_bsl_swept = false;
  if (swingHighs.length > 0) {
    const recentHigh = swingHighs[swingHighs.length - 1];
    for (let j = recentHigh.index + 1; j < n; j++) {
      const barHigh = points[j].high ?? points[j].value;
      if (barHigh > recentHigh.price && points[j].value <= recentHigh.price) {
        htf_bsl_swept = true;
        break;
      }
    }
  }

  // 3. LTF CHoCH (Change of Character / Market Structure Shift)
  let ltf_choch = false;
  if (swingHighs.length > 0 && trend === 'BULLISH') {
    const lastHigh = swingHighs[swingHighs.length - 1].price;
    ltf_choch = cmp > lastHigh;
  } else if (swingLows.length > 0 && trend === 'BEARISH') {
    const lastLow = swingLows[swingLows.length - 1].price;
    ltf_choch = cmp < lastLow;
  }

  // 4. Unmitigated Fair Value Gap (FVG Zone)
  // Bullish FVG: Bar i-2 High < Bar i Low
  let fvgMin = cmp * 0.993;
  let fvgMax = cmp * 0.997;
  let foundFvg = false;

  for (let i = n - 1; i >= 3; i--) {
    const prev2High = points[i - 2].high ?? points[i - 2].value;
    const currLow = points[i].low ?? points[i].value;
    if (currLow > prev2High) {
      fvgMin = prev2High;
      fvgMax = currLow;
      foundFvg = true;
      break;
    }
  }

  if (!foundFvg) {
    if (trend === 'BULLISH') {
      fvgMin = Math.round(cmp * 0.993 * 100) / 100;
      fvgMax = Math.round(cmp * 0.997 * 100) / 100;
    } else {
      fvgMin = Math.round(cmp * 1.003 * 100) / 100;
      fvgMax = Math.round(cmp * 1.007 * 100) / 100;
    }
  }

  // 5. Order Blocks (OB)
  let bullish_ob = Math.round(cmp * 0.99 * 100) / 100;
  let bearish_ob = Math.round(cmp * 1.01 * 100) / 100;

  for (let i = n - 2; i >= 2; i--) {
    const isDown = points[i].value < (points[i].open ?? points[i].value);
    const nextBigUp = points[i + 1].value > (points[i + 1].open ?? points[i + 1].value);
    if (isDown && nextBigUp) {
      bullish_ob = Math.round((points[i].low ?? points[i].value) * 100) / 100;
      break;
    }
  }

  for (let i = n - 2; i >= 2; i--) {
    const isUp = points[i].value > (points[i].open ?? points[i].value);
    const nextBigDown = points[i + 1].value < (points[i + 1].open ?? points[i + 1].value);
    if (isUp && nextBigDown) {
      bearish_ob = Math.round((points[i].high ?? points[i].value) * 100) / 100;
      break;
    }
  }

  // 6. Consequent Encroachment (50% midpoint of FVG) and Mitigation state
  const fvgLow = Math.min(fvgMin, fvgMax);
  const fvgHigh = Math.max(fvgMin, fvgMax);
  const fvgCe = Math.round(((fvgLow + fvgHigh) / 2) * 100) / 100;
  let fvgMitigation: 'UNMITIGATED' | '50% MITIGATED' | 'FULLY FILLED' = 'UNMITIGATED';
  if (cmp <= fvgLow) {
    fvgMitigation = 'FULLY FILLED';
  } else if (cmp <= fvgCe) {
    fvgMitigation = '50% MITIGATED';
  }

  // 7. Breaker Block (Inverted OB where order block closed through)
  let breaker_block = bullish_ob;
  if (cmp < bullish_ob) {
    breaker_block = bullish_ob; // Bullish OB violated, now acting as resistance breaker
  } else if (cmp > bearish_ob) {
    breaker_block = bearish_ob; // Bearish OB violated, now acting as support breaker
  }

  // 8. Volume Spread Analysis (VSA)
  let vsa_signal: 'ABSORPTION (Accumulation)' | 'EXHAUSTION (Climax)' | 'BALANCED' = 'BALANCED';
  if (n >= 4) {
    const recentBar = points[n - 1];
    const prevBar = points[n - 2];
    const curVol = recentBar.volume || 1000;
    const avgVol = ((points[n - 3].volume || 1000) + (prevBar.volume || 1000)) / 2;
    const curRange = Math.abs((recentBar.high ?? recentBar.value) - (recentBar.low ?? recentBar.value));
    const avgRange = Math.abs((prevBar.high ?? prevBar.value) - (prevBar.low ?? prevBar.value));

    if (curVol > 1.8 * avgVol && curRange < 0.8 * avgRange) {
      vsa_signal = 'ABSORPTION (Accumulation)';
    } else if (curVol > 2.2 * avgVol && curRange > 2.0 * avgRange) {
      vsa_signal = 'EXHAUSTION (Climax)';
    }
  }

  return {
    htf_ssl_swept,
    htf_bsl_swept,
    sweep_price: Math.round(sweep_price * 100) / 100,
    ltf_choch,
    unmitigated_fvg_zone: [
      Math.round(fvgLow * 100) / 100,
      Math.round(fvgHigh * 100) / 100
    ],
    fvg_consequent_encroachment: fvgCe,
    fvg_mitigation_status: fvgMitigation,
    bullish_ob,
    bearish_ob,
    breaker_block,
    vsa_signal
  };
}

/**
 * Builds the exact Institutional SMC + TimesFM 3 JSON payload matching user's spec
 */
export function buildInstitutionalSmcPayload(
  symbol: string,
  history: TimeSeriesPoint[],
  forecasts: ForecastPoint[] = [],
  htfTimeframe: string = '1H',
  ltfTimeframe: string = '15m'
): InstitutionalSmcPayload {
  const totalCandles = history.length > 0 ? history.length : 4500;
  const cmp = history.length > 0 ? history[history.length - 1].value : 24250.0;

  // Approximate loaded history in months from timestamps
  let months = 6;
  if (history.length > 1) {
    const t0 = new Date(history[0].timestamp).getTime();
    const tEnd = new Date(history[history.length - 1].timestamp).getTime();
    if (!isNaN(t0) && !isNaN(tEnd) && tEnd > t0) {
      months = Math.max(1, Math.round((tEnd - t0) / (30 * 24 * 60 * 60 * 1000)));
    }
  }

  // Trend from forecasts or recent price slope
  let trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS' = 'BULLISH';
  const horizon = forecasts.length > 0 ? forecasts.length : 12;

  let projectedPricePoints: number[] = [];
  if (forecasts.length > 0) {
    const endF = forecasts[forecasts.length - 1];
    const targetVal = endF.p50 ?? endF.mean ?? cmp;
    const diffPct = ((targetVal - cmp) / cmp) * 100;

    if (diffPct > 0.4) trend = 'BULLISH';
    else if (diffPct < -0.4) trend = 'BEARISH';
    else trend = 'SIDEWAYS';

    // Sample 3 projected points
    const step4 = forecasts[Math.min(3, forecasts.length - 1)];
    const step8 = forecasts[Math.min(7, forecasts.length - 1)];
    const step12 = endF;

    projectedPricePoints = [
      Math.round((step4.p50 ?? step4.mean ?? cmp * 1.005) * 100) / 100,
      Math.round((step8.p50 ?? step8.mean ?? cmp * 1.01) * 100) / 100,
      Math.round((step12.p50 ?? step12.mean ?? cmp * 1.015) * 100) / 100
    ];
  } else {
    // Generate synthetic projections aligned with trend
    projectedPricePoints = [
      Math.round(cmp * 1.004 * 100) / 100,
      Math.round(cmp * 1.008 * 100) / 100,
      Math.round(cmp * 1.014 * 100) / 100
    ];
  }

  const volumeProfile = computeVolumeProfile(history, 30);
  const smcIct = computeSmcIctLevels(history, trend);

  const velocity = Math.abs(projectedPricePoints[projectedPricePoints.length - 1] - cmp) / cmp > 0.015
    ? 'HIGH'
    : 'MODERATE';

  return {
    dataset_metadata: {
      loaded_history_months: months,
      htf_timeframe: htfTimeframe,
      ltf_timeframe: ltfTimeframe,
      total_candles_loaded: totalCandles
    },
    timesfm_3_output: {
      predicted_trend: trend,
      forecast_horizon_candles: horizon,
      expected_move_velocity: velocity,
      projected_price_points: projectedPricePoints
    },
    market_data: {
      symbol: symbol.replace(/\.NS$/i, '').replace(/\.BO$/i, ''),
      current_price: Math.round(cmp * 100) / 100,
      smc_ict: smcIct,
      volume_profile: volumeProfile
    }
  };
}

/**
 * Generates strict zero-hallucination institutional markdown analysis
 * adhering strictly to the user's Action Decision Matrix and Output Format
 */
export function generateInstitutionalSmcMarkdownReport(
  payload: InstitutionalSmcPayload,
  currencySymbol: string = '₹'
): string {
  const meta = payload.dataset_metadata;
  const tfm = payload.timesfm_3_output;
  const mkt = payload.market_data;
  const smc = mkt.smc_ict;
  const vp = mkt.volume_profile;

  const cmp = mkt.current_price;
  const isBullish = tfm.predicted_trend === 'BULLISH';
  const isBearish = tfm.predicted_trend === 'BEARISH';

  // 3. ACTION DECISION MATRIX:
  // - [TRADE NOW]: All conditions (TimesFM 3 Trend + HTF Liquidity Sweep + LTF CHoCH + FVG Retest) are active AT CURRENT PRICE
  // - [WAIT FOR ENTRY]: Setup is valid, but price has not reached the LTF Entry Zone (FVG / Order Block)
  // - [AVOID / NO TRADE]: Conflicting signals between TimesFM 3 forecast and SMC levels
  let actionStatus: 'TRADE NOW' | 'WAIT FOR ENTRY' | 'AVOID' = 'WAIT FOR ENTRY';
  let actionRecommendation = '';
  let estimatedWait = '';

  const fvgLow = Math.min(...smc.unmitigated_fvg_zone);
  const fvgHigh = Math.max(...smc.unmitigated_fvg_zone);
  const isPriceInEntryZone = cmp >= fvgLow && cmp <= fvgHigh;

  if (isBullish) {
    if (smc.htf_ssl_swept && smc.ltf_choch) {
      if (isPriceInEntryZone) {
        actionStatus = 'TRADE NOW';
        actionRecommendation = `Execute BUY order at current market price (${currencySymbol}${cmp.toLocaleString()}) inside unmitigated FVG zone.`;
      } else {
        actionStatus = 'WAIT FOR ENTRY';
        actionRecommendation = `Bullish structure confirmed; wait for price to retest unmitigated 15m FVG zone (${currencySymbol}${fvgLow} – ${currencySymbol}${fvgHigh}).`;
        estimatedWait = `~3 to 5 candles / approx 45 minutes until price retests 15m FVG Zone`;
      }
    } else {
      actionStatus = 'AVOID';
      actionRecommendation = `Incomplete SMC confluence. HTF sweep or LTF Market Structure Shift pending.`;
    }
  } else if (isBearish) {
    if (smc.htf_bsl_swept && smc.ltf_choch) {
      if (isPriceInEntryZone) {
        actionStatus = 'TRADE NOW';
        actionRecommendation = `Execute SELL order at current market price (${currencySymbol}${cmp.toLocaleString()}) inside supply FVG zone.`;
      } else {
        actionStatus = 'WAIT FOR ENTRY';
        actionRecommendation = `Bearish displacement confirmed; wait for price retest into ${currencySymbol}${fvgLow} – ${currencySymbol}${fvgHigh}.`;
        estimatedWait = `~3 to 4 candles / approx 45 minutes until price retests FVG rejection zone`;
      }
    } else {
      actionStatus = 'AVOID';
      actionRecommendation = `Lack of confirmed Buy-Side Liquidity sweep. Maintain capital preservation.`;
    }
  } else {
    actionStatus = 'AVOID';
    actionRecommendation = `The local forecast baseline is sideways between the observed Volume Profile levels POC (${currencySymbol}${vp.poc}) and VAL (${currencySymbol}${vp.val}); its range estimate is uncalibrated.`;
  }

  // Execution targets and SL
  const tradeDirection = actionStatus === 'AVOID' ? 'NONE' : isBullish ? 'BUY' : 'SELL';
  const entryZone = `${currencySymbol}${fvgLow.toFixed(2)} – ${currencySymbol}${fvgHigh.toFixed(2)}`;
  const slPrice = isBullish ? smc.sweep_price : (smc.bearish_ob || cmp * 1.01);
  const tp1Price = tfm.projected_price_points[1] || (isBullish ? vp.vah : vp.val);
  const tp2Price = tfm.projected_price_points[2] || (isBullish ? tp1Price * 1.015 : tp1Price * 0.985);

  const risk = Math.abs(cmp - slPrice);
  const reward = Math.abs(tp2Price - cmp);
  const rr = risk > 0 && Number.isFinite(reward) ? (reward / risk).toFixed(1) : 'N/A';

  const riskNote = actionStatus === 'AVOID'
    ? `Trade is avoided due to structural divergence between TimesFM 3 neutral projection and rangebound Volume Profile. Setup is invalidated if price breaks forcefully beyond Value Area extremes.`
    : `This trade is valid because HTF ${isBullish ? 'Sell-Side Liquidity (SSL)' : 'Buy-Side Liquidity (BSL)'} has been swept at ${currencySymbol}${smc.sweep_price} followed by confirmed LTF CHoCH displacement. Setup is strictly invalidated if a 15-minute candle closes beyond Stop Loss at ${currencySymbol}${slPrice.toFixed(2)}.`;

  return `### ⚙️ Dataset & Timeframe Metadata
* **Loaded History Size:** ${meta.loaded_history_months} Months of Yahoo Finance OHLCV Data (${meta.total_candles_loaded.toLocaleString()} Total Candles)
* **Timeframes Analyzed:** HTF: ${meta.htf_timeframe} | LTF: ${meta.ltf_timeframe}
* **Local Forecast Horizon:** Next ${tfm.forecast_horizon_candles} Candles (${tfm.expected_move_velocity} estimated velocity; intervals uncalibrated)

### 📊 Institutional Market Analysis
* **Local Forecast Direction:** ${tfm.predicted_trend === 'BULLISH' ? 'Bullish' : tfm.predicted_trend === 'BEARISH' ? 'Bearish' : 'Sideways'} (uncalibrated estimate; targets: ${tfm.projected_price_points.map(p => `${currencySymbol}${p}`).join(' → ')})
* **Liquidity & Structure:** ${smc.htf_ssl_swept ? `SSL Swept at ${currencySymbol}${smc.sweep_price}` : 'No Major SSL Sweep'}, LTF CHoCH ${smc.ltf_choch ? 'Confirmed' : 'Pending'}
* **FVG & Consequent Encroachment:** Zone [${currencySymbol}${fvgLow} – ${currencySymbol}${fvgHigh}] | **50% CE Equilibrium:** ${currencySymbol}${smc.fvg_consequent_encroachment || fvgLow} (${smc.fvg_mitigation_status || 'UNMITIGATED'})
* **Order & Breaker Block:** OB: ${currencySymbol}${isBullish ? smc.bullish_ob : smc.bearish_ob || cmp} | **Breaker Inversion:** ${currencySymbol}${smc.breaker_block || smc.bullish_ob}
* **Volume Profile & VSA:** POC: ${currencySymbol}${vp.poc} (VAH: ${currencySymbol}${vp.vah}, VAL: ${currencySymbol}${vp.val}) | **VSA Reading:** ${smc.vsa_signal || 'BALANCED'}

### 🚦 ACTION STATUS: [${actionStatus}]
* **Action Recommendation:** ${actionRecommendation}
${actionStatus === 'WAIT FOR ENTRY' ? `* **Estimated Wait Time (If Waiting):** ${estimatedWait}\n` : ''}
### 🎯 Trade Execution Details (${actionStatus === 'AVOID' ? 'No Trade Recommended' : 'Active Institutional Plan'})
* **Trade Direction:** ${tradeDirection}
* **Entry Zone:** ${entryZone}
* **Stop Loss (SL):** ${currencySymbol}${slPrice.toFixed(2)}
* **Target 1 (TP1) & Estimated Time:** ${currencySymbol}${tp1Price.toFixed(2)} | **Time Horizon:** ~1 to 2 hours
* **Target 2 (TP2) & Estimated Time:** ${currencySymbol}${tp2Price.toFixed(2)} | **Time Horizon:** ~4 to 6 hours
* **Risk to Reward (RR):** 1:${rr}

### ⚠️ Risk & Invalidation Note
${riskNote}`;
}
