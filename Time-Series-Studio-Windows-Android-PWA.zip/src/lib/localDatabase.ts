import initSqlJs, { Database } from 'sql.js';
import { TimeSeriesPoint } from '../types';

let dbInstance: Database | null = null;
let isInitialized = false;
let initPromise: Promise<Database | null> | null = null;

const DB_STORAGE_KEY = 'timeseries_studio_sqlite_data';
const FALLBACK_CACHE_PREFIX = 'timeseries_mkt_cache_';
const FALLBACK_FORECASTS_KEY = 'timeseries_forecast_runs_fallback';

/**
 * Safely fetches and verifies WebAssembly binary bytes before instantiation.
 */
async function loadWasmBinary(): Promise<ArrayBuffer | null> {
  // 1. Node.js / test environment
  if (typeof window === 'undefined') {
    try {
      const fs = await import(/* @vite-ignore */ 'node:fs');
      const path = await import(/* @vite-ignore */ 'node:path');
      const wasmPath = path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm');
      if (fs.existsSync(wasmPath)) {
        const buf = fs.readFileSync(wasmPath);
        return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
      }
    } catch (e) {
      console.warn('Node.js wasm load failed:', e);
    }
  }

  // 2. Browser environment: try candidate URLs
  const candidateUrls = [
    '/sql-wasm.wasm',
    'https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.12.0/sql-wasm.wasm'
  ];

  for (const url of candidateUrls) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const buf = await res.arrayBuffer();
      if (buf.byteLength >= 4) {
        const bytes = new Uint8Array(buf.slice(0, 4));
        // WebAssembly magic bytes: \0asm -> 0x00, 0x61, 0x73, 0x6d
        if (bytes[0] === 0x00 && bytes[1] === 0x61 && bytes[2] === 0x73 && bytes[3] === 0x6d) {
          return buf;
        }
      }
      console.warn(`Buffer from ${url} does not contain WebAssembly magic bytes; skipping.`);
    } catch {
      // Ignore and try next candidate
    }
  }

  return null;
}

/**
 * Initializes the local SQLite database schema and migrations.
 */
export async function getLocalDatabase(): Promise<Database | null> {
  if (dbInstance && isInitialized) {
    return dbInstance;
  }

  if (initPromise) {
    return initPromise;
  }

  initPromise = (async () => {
    try {
      const wasmBinary = await loadWasmBinary();
      const config: any = {};
      if (wasmBinary) {
        config.wasmBinary = wasmBinary;
      } else {
        config.locateFile = (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.12.0/${file}`;
      }

      const SQL = await initSqlJs(config);

      // Try to load existing database from storage
      let savedData: Uint8Array | null = null;
      try {
        if (typeof localStorage !== 'undefined') {
          const b64 = localStorage.getItem(DB_STORAGE_KEY);
          if (b64) {
            const binStr = atob(b64);
            const len = binStr.length;
            const bytes = new Uint8Array(len);
            for (let i = 0; i < len; i++) {
              bytes[i] = binStr.charCodeAt(i);
            }
            savedData = bytes;
          }
        }
      } catch (e) {
        console.warn('Could not read existing SQLite data from storage:', e);
      }

      dbInstance = savedData ? new SQL.Database(savedData) : new SQL.Database();

      // Run schema definitions
      dbInstance.run(`
        CREATE TABLE IF NOT EXISTS market_cache (
          symbol TEXT NOT NULL,
          interval TEXT NOT NULL,
          timestamp TEXT NOT NULL,
          open REAL,
          high REAL,
          low REAL,
          close REAL NOT NULL,
          volume REAL,
          is_live INTEGER DEFAULT 1,
          fetched_at TEXT NOT NULL,
          PRIMARY KEY (symbol, interval, timestamp)
        );

        CREATE TABLE IF NOT EXISTS paper_portfolio (
          id TEXT PRIMARY KEY,
          cash_balance REAL NOT NULL,
          realized_pnl REAL NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS paper_trades (
          id TEXT PRIMARY KEY,
          symbol TEXT NOT NULL,
          side TEXT NOT NULL,
          qty REAL NOT NULL,
          entry_price REAL NOT NULL,
          exit_price REAL,
          pnl REAL DEFAULT 0,
          fees REAL DEFAULT 0,
          slippage REAL DEFAULT 0,
          status TEXT NOT NULL,
          opened_at TEXT NOT NULL,
          closed_at TEXT
        );

        CREATE TABLE IF NOT EXISTS backtest_runs (
          id TEXT PRIMARY KEY,
          symbol TEXT NOT NULL,
          strategy TEXT NOT NULL,
          lookback_days INTEGER NOT NULL,
          win_rate REAL,
          profit_factor REAL,
          sharpe_ratio REAL,
          max_drawdown REAL,
          metrics_json TEXT NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS forecast_runs (
          id TEXT PRIMARY KEY,
          symbol TEXT NOT NULL,
          model_type TEXT NOT NULL,
          horizon INTEGER NOT NULL,
          last_price REAL NOT NULL,
          predicted_end REAL NOT NULL,
          p10_end REAL NOT NULL,
          p90_end REAL NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS watchlists (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          symbols_json TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS app_settings (
          key TEXT PRIMARY KEY,
          value_json TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
      `);

      isInitialized = true;
      return dbInstance;
    } catch (err) {
      console.warn('SQLite engine failed to initialize, switching to resilient fallback storage:', err);
      return null;
    } finally {
      initPromise = null;
    }
  })();

  return initPromise;
}

/**
 * Persists the in-memory SQLite database state to storage.
 */
export function persistLocalDatabase(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    let binary = '';
    const len = data.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(data[i]);
    }
    const b64 = btoa(binary);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(DB_STORAGE_KEY, b64);
    }
  } catch (e) {
    console.warn('Failed to persist SQLite database:', e);
  }
}

/**
 * Saves candles incrementally into local SQLite cache (with localStorage fallback).
 */
export async function saveMarketCandlesToDb(
  symbol: string,
  interval: string,
  candles: TimeSeriesPoint[],
  isLive: boolean = true
): Promise<void> {
  const cleanSymbol = symbol.trim().toUpperCase();
  const nowStr = new Date().toISOString();

  // Try SQLite first
  try {
    const db = await getLocalDatabase();
    if (db) {
      db.run('BEGIN TRANSACTION;');
      const stmt = db.prepare(`
        INSERT OR REPLACE INTO market_cache 
        (symbol, interval, timestamp, open, high, low, close, volume, is_live, fetched_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const c of candles) {
        stmt.run([
          cleanSymbol,
          interval,
          c.timestamp,
          c.open ?? null,
          c.high ?? null,
          c.low ?? null,
          c.value,
          c.volume ?? 0,
          isLive ? 1 : 0,
          nowStr
        ]);
      }
      stmt.free();
      db.run('COMMIT;');
      persistLocalDatabase();
      return;
    }
  } catch (err) {
    console.warn('Failed to save to SQLite cache, falling back to local storage:', err);
  }

  // Fallback to localStorage
  try {
    if (typeof localStorage !== 'undefined') {
      const key = `${FALLBACK_CACHE_PREFIX}${cleanSymbol}_${interval}`;
      const payload = {
        symbol: cleanSymbol,
        interval,
        candles,
        isLive,
        fetchedAt: nowStr
      };
      localStorage.setItem(key, JSON.stringify(payload));
    }
  } catch (e) {
    console.warn('Failed to write to fallback storage:', e);
  }
}

/**
 * Retrieves cached market candles from local SQLite storage (or localStorage fallback).
 */
export async function getCachedMarketCandles(
  symbol: string,
  interval: string
): Promise<{ data: TimeSeriesPoint[]; fetchedAt: string; isLive: boolean } | null> {
  const cleanSymbol = symbol.trim().toUpperCase();

  try {
    const db = await getLocalDatabase();
    if (db) {
      const res = db.exec(`
        SELECT timestamp, open, high, low, close, volume, is_live, fetched_at
        FROM market_cache
        WHERE symbol = '${cleanSymbol}' AND interval = '${interval}'
        ORDER BY timestamp ASC
      `);

      if (res && res.length > 0 && res[0].values && res[0].values.length > 0) {
        const rows = res[0].values;
        const data: TimeSeriesPoint[] = rows.map((r: any[]) => ({
          timestamp: String(r[0]),
          open: r[1] !== null ? Number(r[1]) : undefined,
          high: r[2] !== null ? Number(r[2]) : undefined,
          low: r[3] !== null ? Number(r[3]) : undefined,
          value: Number(r[4]),
          volume: r[5] !== null ? Number(r[5]) : 0
        }));

        const lastRow = rows[rows.length - 1];
        return {
          data,
          isLive: Boolean(lastRow[6]),
          fetchedAt: String(lastRow[7])
        };
      }
    }
  } catch (err) {
    console.warn('SQLite query error, attempting fallback storage retrieval:', err);
  }

  // Fallback check in localStorage
  try {
    if (typeof localStorage !== 'undefined') {
      const key = `${FALLBACK_CACHE_PREFIX}${cleanSymbol}_${interval}`;
      const item = localStorage.getItem(key);
      if (item) {
        const parsed = JSON.parse(item);
        if (parsed && Array.isArray(parsed.candles) && parsed.candles.length > 0) {
          return {
            data: parsed.candles,
            isLive: Boolean(parsed.isLive),
            fetchedAt: parsed.fetchedAt || new Date().toISOString()
          };
        }
      }
    }
  } catch {
    // Ignore error
  }

  return null;
}

/**
 * Gets the most recent timestamp in local cache for incremental syncing.
 */
export async function getLastCachedTimestamp(
  symbol: string,
  interval: string
): Promise<string | null> {
  const cleanSymbol = symbol.trim().toUpperCase();

  try {
    const db = await getLocalDatabase();
    if (db) {
      const res = db.exec(`
        SELECT timestamp FROM market_cache
        WHERE symbol = '${cleanSymbol}' AND interval = '${interval}'
        ORDER BY timestamp DESC
        LIMIT 1
      `);

      if (res && res.length > 0 && res[0].values && res[0].values.length > 0) {
        return String(res[0].values[0][0]);
      }
    }
  } catch (err) {
    console.warn('Error reading last cached timestamp from SQLite:', err);
  }

  // Fallback
  try {
    if (typeof localStorage !== 'undefined') {
      const key = `${FALLBACK_CACHE_PREFIX}${cleanSymbol}_${interval}`;
      const item = localStorage.getItem(key);
      if (item) {
        const parsed = JSON.parse(item);
        if (parsed && Array.isArray(parsed.candles) && parsed.candles.length > 0) {
          return parsed.candles[parsed.candles.length - 1].timestamp;
        }
      }
    }
  } catch {
    // Ignore error
  }

  return null;
}

/**
 * Saves a forecast run into local SQLite (with fallback).
 */
export async function recordForecastRun(
  symbol: string,
  modelType: string,
  horizon: number,
  lastPrice: number,
  predictedEnd: number,
  p10End: number,
  p90End: number
): Promise<void> {
  const id = `fc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  try {
    const db = await getLocalDatabase();
    if (db) {
      db.run(`
        INSERT INTO forecast_runs (id, symbol, model_type, horizon, last_price, predicted_end, p10_end, p90_end, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [id, symbol.toUpperCase(), modelType, horizon, lastPrice, predictedEnd, p10End, p90End, now]);
      persistLocalDatabase();
      return;
    }
  } catch (err) {
    console.warn('Failed to record forecast in SQLite, using fallback:', err);
  }

  try {
    if (typeof localStorage !== 'undefined') {
      const existing = JSON.parse(localStorage.getItem(FALLBACK_FORECASTS_KEY) || '[]');
      existing.push({
        id,
        symbol: symbol.toUpperCase(),
        modelType,
        horizon,
        lastPrice,
        predictedEnd,
        p10End,
        p90End,
        createdAt: now
      });
      localStorage.setItem(FALLBACK_FORECASTS_KEY, JSON.stringify(existing.slice(-50)));
    }
  } catch {
    // Ignore fallback errors
  }
}
