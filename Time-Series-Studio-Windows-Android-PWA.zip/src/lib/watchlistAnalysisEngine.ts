import { TimeSeriesPoint } from '../types';
import { QuantHorizon, evaluateQuantSetup } from './quantSetupEngine';
import { calculateFinalVerdict } from '../components/FinalVerdictModal';
import { computeVolumeProfile, computeSmcIctLevels } from './smcVolumeProfileEngine';
import { WatchlistScanItem, formatDateTime } from './watchlistStore';
import { analyzeVolumeSpike, detectPriceVolumeTrap, readRecentFuturesOiSignal, readRecentOptionChainSignal } from './marketFlowSignals';
import { calculateSyntheticBuildupMatrix } from './syntheticBuildupMatrix';

export interface MultiEngineAnalysisResult {
  timesfmResult: {
    trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
    expectedMovePct: number;
    velocity: 'HIGH' | 'MODERATE' | 'STEADY';
    horizonCandles: number;
    confidencePct?: number;
    p10Support: number;
    p50Median: number;
    p90Resistance: number;
    signalSummary: string;
  };
  quantEngineResult: {
    scorePct: number;
    direction: string;
    zScore: number;
    atrValue?: number;
    rsi14?: number;
    cprRelation: 'ABOVE_CPR' | 'INSIDE_CPR' | 'BELOW_CPR';
    cprPivot: number;
    cprTop: number;
    cprBottom: number;
    volumeProfilePoc: number;
    volumeProfileVah: number;
    volumeProfileVal: number;
    riskRewardText: string;
    signalSummary: string;
  };
  smcIctResult: {
    marketStructure: 'BOS' | 'CHOCH' | 'CONSOLIDATION';
    chochActive: boolean;
    sslSwept: boolean;
    bslSwept: boolean;
    fvgZone: [number, number];
    fvgStatus: 'UNMITIGATED' | '50% MITIGATED' | 'FULLY FILLED';
    bullishOrderBlock: number;
    bearishOrderBlock: number;
    pricingZone: 'DISCOUNT' | 'PREMIUM' | 'EQUILIBRIUM';
    signalSummary: string;
  };
  finalVerdict: {
    verdict: 'BUY / ACCUMULATE' | 'SELL / SHORT' | 'CONFLICT — AVOID / WAIT' | 'NEUTRAL CONSOLIDATION';
    setupGrade: 'GRADE_A_PLUS' | 'GRADE_A' | 'GRADE_B' | 'NO_TRADE';
    gradeBadge: string;
    confluenceScorePct: number;
    directionalScorePct: number;
    timeframeWeights: import('./timeframeVerdictWeights').VerdictWeightProfile;
    entryZone: { min: number; max: number; text: string };
    strictStopLoss: { price: number; pct: number };
    target1: { price: number; pct: number };
    target2: { price: number; pct: number };
    riskRewardText: string;
    optionsSuggestion?: string;
    isInEntryZone: boolean;
    distanceToEntryPct: number;
  };
  item: WatchlistScanItem;
}

/** Yahoo's practical maximum history windows by candle interval. */
export const WATCHLIST_HISTORY_RANGE: Record<'5m' | '15m' | '1h' | '1d', string> = {
  '5m': '60d',
  '15m': '60d',
  '1h': '730d',
  '1d': '5y'
};

/** Minimum history needed for the selected synthetic price/volume formula.
 * Below this, grading can silently omit the 15% buildup component or use a
 * partial baseline, so Find Setups must report the timeframe as unavailable.
 */
export const MIN_WATCHLIST_CANDLES: Record<'5m' | '15m' | '1h' | '1d', number> = {
  '5m': 10,  // EMA(10) volume baseline
  '15m': 21, // SMA(20) volume + ATR(14) and previous close
  '1h': 50,  // 50-bar volume Z-score
  '1d': 21   // SMA(20) volume + ATR(20) and previous close
};

export function hasSufficientWatchlistHistory(timeframe: keyof typeof MIN_WATCHLIST_CANDLES, candleCount: number): boolean {
  return Number.isFinite(candleCount) && candleCount >= MIN_WATCHLIST_CANDLES[timeframe];
}

export function markTimeframeDataUnavailable(
  item: WatchlistScanItem,
  timeframe: '5m' | '15m' | '1h' | '1d',
  detail = `No fresh ${timeframe} OHLCV history was returned; setup not assessed.`
): WatchlistScanItem {
  return {
    ...item,
    timeframe,
    horizon: timeframe === '5m' || timeframe === '15m' ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)',
    status: 'WAIT FOR LEVEL',
    direction: 'NEUTRAL',
    finalVerdict: 'NEUTRAL CONSOLIDATION',
    setupGrade: 'NO_TRADE',
    gradeBadge: 'DATA UNAVAILABLE',
    confluenceScorePct: 0,
    verdictDirectionalScorePct: 50,
    verdictWeights: undefined,
    analysisDataStatus: detail,
    marketFlow: undefined,
    volumeSpike: undefined,
    isInEntryZone: false,
    alertTriggered: false,
    alertReason: undefined
  };
}

/**
 * Computes local statistical baseline, Quant Engine, SMC/ICT/FVG, and Final Verdict,
 * strictly adapting mathematical formulas for Intraday (5m/15m) vs Swing (1h/1d).
 */
export function computeMultiEngineWatchlistAnalysis(
  symbol: string,
  name: string,
  candles: TimeSeriesPoint[],
  horizon: QuantHorizon,
  timeframe: '5m' | '15m' | '1h' | '1d' = '15m',
  currencySymbol: string = '₹',
  existingItem?: Partial<WatchlistScanItem>
): MultiEngineAnalysisResult {
  const n = candles.length;
  const lastBar = n > 0 ? candles[n - 1] : { value: 100, timestamp: new Date().toISOString() };
  const cmp = existingItem?.cmp && existingItem.cmp > 0 ? existingItem.cmp : lastBar.value;
  // Daily aggregate quote volume is comparable only to daily bars. For intraday bars
  // compare the latest interval's volume to prior intervals of the same timeframe.
  const comparableLiveVolume = timeframe === '1d' ? existingItem?.currentSessionVolume : undefined;
  const volumeSpike = analyzeVolumeSpike(candles, comparableLiveVolume);
  const syntheticBuildup = calculateSyntheticBuildupMatrix(candles, timeframe);
  const trapRisk = detectPriceVolumeTrap(candles, comparableLiveVolume);
  // Flow cache timestamps are written only when a new live broker response arrives;
  // never extend a cached signal's lifetime just because the watchlist recalculated.
  const optionChainOi = readRecentOptionChainSignal(symbol);
  const futuresOi = readRecentFuturesOiSignal(symbol);
  const marketFlow = { ...existingItem?.marketFlow, optionChainOi, futuresOi, volumeSpike, syntheticBuildup, trapRisk };

  // Horizon-specific configuration
  const isIntraday = horizon === 'Intraday (5m/15m)' || timeframe === '5m' || timeframe === '15m';
  const effectiveHorizon: QuantHorizon = isIntraday ? 'Intraday (5m/15m)' : 'Swing (3–4 Days)';
  const horizonCandles = isIntraday ? 8 : 12;

  // 1. Local statistical forecast baseline; this is not Google's pretrained TimesFM.
  const windowLen = Math.min(n, isIntraday ? 32 : 64);
  const recentSlice = candles.slice(-windowLen);
  const values = recentSlice.map(c => c.value);
  if (values.length < 2 || values.some(value => !Number.isFinite(value) || value <= 0)) {
    throw new Error('At least two finite, positive observations are required for watchlist analysis.');
  }
  
  // Instance Normalization (Mean & Std Dev)
  const meanVal = values.reduce((acc, v) => acc + v, 0) / Math.max(1, values.length);
  const variance = values.reduce((acc, v) => acc + Math.pow(v - meanVal, 2), 0) / Math.max(1, values.length);
  const stdVal = Math.max(1e-12, Math.sqrt(variance));

  // Autoregressive Drift & Normalized Linear Slope
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < values.length; i++) {
    const normV = (values[i] - meanVal) / stdVal;
    sumX += i;
    sumY += normV;
    sumXY += i * normV;
    sumXX += i * i;
  }
  const lenW = values.length;
  const normSlope = (lenW * sumXY - sumX * sumY) / Math.max(1e-5, lenW * sumXX - sumX * sumX);

  // Horizon-scaled arithmetic on log returns; interval is an uncalibrated approximation.
  const logReturns = values.slice(1).map((value, i) => Math.log(value / values[i]));
  const meanLogReturn = logReturns.reduce((sum, value) => sum + value, 0) / logReturns.length;
  const returnVariance = logReturns.reduce((sum, value) => sum + (value - meanLogReturn) ** 2, 0) / Math.max(1, logReturns.length - 1);
  const returnStd = Math.sqrt(returnVariance);
  const expectedMovePct = (Math.exp(meanLogReturn * horizonCandles) - 1) * 100;
  
  // Intraday threshold is 0.20%, Swing threshold is 0.60%
  const trendThreshold = isIntraday ? 0.20 : 0.60;
  let tfmTrend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS' = 'SIDEWAYS';
  if (expectedMovePct >= trendThreshold) tfmTrend = 'BULLISH';
  else if (expectedMovePct <= -trendThreshold) tfmTrend = 'BEARISH';

  // Empirical Quantile Intervals scaled for horizon
  const intervalLogWidth = 1.2815515655446004 * returnStd * Math.sqrt(horizonCandles);
  const p50Median = Math.round((cmp * Math.exp(meanLogReturn * horizonCandles)) * 100) / 100;
  const p10Support = Math.round((p50Median * Math.exp(-intervalLogWidth)) * 100) / 100;
  const p90Resistance = Math.round((p50Median * Math.exp(intervalLogWidth)) * 100) / 100;

  // Expected move velocity
  const absMove = Math.abs(expectedMovePct);
  const velocityThreshold = isIntraday ? 0.8 : 2.0;
  const velocity: 'HIGH' | 'MODERATE' | 'STEADY' = absMove > velocityThreshold ? 'HIGH' : absMove > (velocityThreshold / 2) ? 'MODERATE' : 'STEADY';

  const tfmSignalSummary = tfmTrend === 'BULLISH'
    ? `${isIntraday ? 'Intraday' : 'Swing'} RevIN trend projects +${expectedMovePct}% upside to ${currencySymbol}${p50Median} (${velocity} velocity)`
    : tfmTrend === 'BEARISH'
      ? `${isIntraday ? 'Intraday' : 'Swing'} RevIN trend projects ${expectedMovePct}% downside to ${currencySymbol}${p50Median} (${velocity} velocity)`
      : `${isIntraday ? 'Intraday' : 'Swing'} RevIN trend projects consolidation between ${currencySymbol}${p10Support} and ${currencySymbol}${p90Resistance}`;

  const timesfmResult = {
    trend: tfmTrend,
    expectedMovePct,
    velocity,
    horizonCandles,
    p10Support,
    p50Median,
    p90Resistance,
    signalSummary: tfmSignalSummary
  };

  // 2. REAL MATHEMATICAL QUANT SETUP ENGINE CALCULATION
  const quantReport = evaluateQuantSetup(
    symbol,
    name,
    candles,
    effectiveHorizon,
    currencySymbol,
    true,
    false
  );

  // Calculate CPR (Central Pivot Range) from previous bar or daily context
  const prevBar = n > 1 ? candles[n - 2] : lastBar;
  const pHigh = prevBar.high ?? prevBar.value;
  const pLow = prevBar.low ?? prevBar.value;
  const pClose = prevBar.value;
  const cprPivot = Math.round(((pHigh + pLow + pClose) / 3) * 100) / 100;
  const cprBottom = Math.round(((pHigh + pLow) / 2) * 100) / 100;
  const cprTop = Math.round(((cprPivot - cprBottom) + cprPivot) * 100) / 100;
  const cprMin = Math.min(cprBottom, cprTop);
  const cprMax = Math.max(cprBottom, cprTop);

  let cprRelation: 'ABOVE_CPR' | 'INSIDE_CPR' | 'BELOW_CPR' = 'INSIDE_CPR';
  if (cmp > cprMax) cprRelation = 'ABOVE_CPR';
  else if (cmp < cprMin) cprRelation = 'BELOW_CPR';

  // Technical Moments: RSI(14), ATR(14), and Z-Score
  const rsi14 = quantReport.levels.rsi14;
  const atrValue = quantReport.levels.atr14;
  const zScore = Math.round(((cmp - meanVal) / stdVal) * 100) / 100;

  // Volume Profile (POC, VAH, VAL)
  const vp = computeVolumeProfile(candles.slice(-Math.min(n, isIntraday ? 30 : 50)));

  const quantSignalSummary = cprRelation === 'ABOVE_CPR'
    ? `${isIntraday ? 'Intraday Bullish' : 'Swing Bullish'} above CPR (${currencySymbol}${cprPivot}) | RSI: ${rsi14} | POC: ${currencySymbol}${vp.poc} | R:R ${quantReport.riskRewardText}`
    : cprRelation === 'BELOW_CPR'
      ? `${isIntraday ? 'Intraday Bearish' : 'Swing Bearish'} below CPR (${currencySymbol}${cprPivot}) | RSI: ${rsi14} | POC: ${currencySymbol}${vp.poc} | R:R ${quantReport.riskRewardText}`
      : `${isIntraday ? 'Intraday Range' : 'Swing Range'} inside CPR (${currencySymbol}${cprMin} - ${currencySymbol}${cprMax}) | RSI: ${rsi14} | POC: ${currencySymbol}${vp.poc}`;

  const quantEngineResult = {
    scorePct: quantReport.scorePct,
    direction: quantReport.direction,
    zScore,
    atrValue,
    rsi14,
    cprRelation,
    cprPivot,
    cprTop,
    cprBottom,
    volumeProfilePoc: vp.poc,
    volumeProfileVah: vp.vah,
    volumeProfileVal: vp.val,
    riskRewardText: quantReport.riskRewardText,
    signalSummary: quantSignalSummary
  };

  // 3. REAL MATHEMATICAL SMC / ICT / FVG ENGINE CALCULATION
  const smcLevels = computeSmcIctLevels(candles, tfmTrend);

  // Equilibrium Premium vs Discount zone
  let high50 = -Infinity, low50 = Infinity;
  for (const c of candles.slice(-Math.min(n, isIntraday ? 20 : 30))) {
    const h = c.high ?? c.value;
    const l = c.low ?? c.value;
    if (h > high50) high50 = h;
    if (l < low50) low50 = l;
  }
  const eqMid = (high50 + low50) / 2;
  const pricingZone: 'DISCOUNT' | 'PREMIUM' | 'EQUILIBRIUM' = 
    cmp < eqMid * 0.995 ? 'DISCOUNT' : cmp > eqMid * 1.005 ? 'PREMIUM' : 'EQUILIBRIUM';

  const marketStructure: 'BOS' | 'CHOCH' | 'CONSOLIDATION' = 
    smcLevels.ltf_choch ? 'CHOCH' : (tfmTrend === 'BULLISH' || tfmTrend === 'BEARISH') ? 'BOS' : 'CONSOLIDATION';

  const fvgStatus = smcLevels.fvg_mitigation_status || 'UNMITIGATED';
  const fvgLow = smcLevels.unmitigated_fvg_zone[0];
  const fvgHigh = smcLevels.unmitigated_fvg_zone[1];

  const smcSignalSummary = `SMC ${isIntraday ? 'Intraday' : 'Structure'}: ${pricingZone} Zone | FVG: ${currencySymbol}${fvgLow}-${currencySymbol}${fvgHigh} (${fvgStatus}) | OB: ${currencySymbol}${smcLevels.bullish_ob} | CHoCH: ${smcLevels.ltf_choch ? 'Confirmed' : 'Pending'}`;

  const smcIctResult = {
    marketStructure,
    chochActive: smcLevels.ltf_choch,
    sslSwept: smcLevels.htf_ssl_swept,
    bslSwept: smcLevels.htf_bsl_swept,
    fvgZone: smcLevels.unmitigated_fvg_zone,
    fvgStatus,
    bullishOrderBlock: smcLevels.bullish_ob,
    bearishOrderBlock: smcLevels.bearish_ob,
    pricingZone,
    signalSummary: smcSignalSummary
  };

  // 4. ACCURATE STOCK CONTEXT FOR FINAL VERDICT CALCULATION
  const stockContext = {
    direction: tfmTrend === 'BULLISH' ? ('BULLISH' as const) : tfmTrend === 'BEARISH' ? ('BEARISH' as const) : ('NEUTRAL' as const),
    targetOne: { targetPrice: p50Median },
    targetTwo: { targetPrice: p90Resistance },
    targetThree: { targetPrice: Math.round((p90Resistance * 1.015) * 100) / 100 },
    strictStoploss: { stoplossPrice: p10Support },
    currentMarketPrice: cmp,
    entryGuide: {
      idealEntryMin: quantReport.entryRange.min,
      idealEntryMax: quantReport.entryRange.max
    }
  };

  // COMBINED FINAL VERDICT WITH MULTI-ENGINE CONFLUENCE
  const verdictResult = calculateFinalVerdict(
    effectiveHorizon,
    candles,
    symbol,
    name,
    currencySymbol,
    stockContext as any,
    quantReport,
    undefined,
    marketFlow
  );
  const blockedByTrap = verdictResult.trapBlocksVerdict;

  const entryMin = verdictResult.entryZone.min || Math.round(cmp * (isIntraday ? 0.996 : 0.992) * 100) / 100;
  const entryMax = verdictResult.entryZone.max || Math.round(cmp * (isIntraday ? 1.002 : 1.004) * 100) / 100;
  const isInEntry = cmp >= entryMin && cmp <= entryMax;
  const entryMid = (entryMin + entryMax) / 2;
  const distToEntry = Math.round(Math.abs(cmp - entryMid) / cmp * 1000) / 10;

  const now = new Date();
  const { full, dateOnly, timeOnly } = formatDateTime(now);

  const finalVerdict = {
    verdict: verdictResult.verdict,
    setupGrade: verdictResult.setupGrade,
    gradeBadge: verdictResult.gradeLabel,
    confluenceScorePct: verdictResult.confluenceScorePct,
    directionalScorePct: verdictResult.directionalScorePct,
    timeframeWeights: verdictResult.timeframeWeights,
    entryZone: { min: entryMin, max: entryMax, text: verdictResult.entryZone.text },
    strictStopLoss: { price: verdictResult.strictStopLoss.price, pct: verdictResult.strictStopLoss.pct },
    target1: { price: verdictResult.target1.price, pct: verdictResult.target1.pct },
    target2: { price: verdictResult.target2.price, pct: verdictResult.target2.pct },
    riskRewardText: verdictResult.riskRewardText,
    optionsSuggestion: verdictResult.optionsRecommendation?.recommendedContract,
    isInEntryZone: verdictResult.hasActionableVerdict && !blockedByTrap && isInEntry,
    distanceToEntryPct: distToEntry
  };

  const item: WatchlistScanItem = {
    id: existingItem?.id || `wl-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    symbol: symbol.toUpperCase(),
    name,
    exchange: existingItem?.exchange || 'NSE',
    cmp,
    prevClose: existingItem?.prevClose || prevBar.value,
    changePct: existingItem?.changePct || Math.round(((cmp - prevBar.value) / prevBar.value) * 10000) / 100,
    volumeSpike,
    marketFlow,
    marketFlowAt: (optionChainOi?.available || futuresOi?.available) ? Date.now() : undefined,
    currentSessionVolume: existingItem?.currentSessionVolume,
    direction: blockedByTrap || !verdictResult.hasActionableVerdict ? 'NEUTRAL' : verdictResult.direction === 'BULLISH' ? 'LONG' : 'SHORT',
    status: blockedByTrap ? 'AVOID' : !verdictResult.hasActionableVerdict ? 'WAIT FOR LEVEL' : quantReport.status as 'TRADE NOW' | 'WAIT FOR LEVEL' | 'AVOID',
    scorePct: quantReport.scorePct,
    finalVerdict: verdictResult.verdict,
    setupGrade: verdictResult.setupGrade,
    gradeBadge: verdictResult.gradeLabel,
    confluenceScorePct: verdictResult.confluenceScorePct,
    verdictDirectionalScorePct: verdictResult.directionalScorePct,
    verdictWeights: verdictResult.timeframeWeights,
    isInEntryZone: !blockedByTrap && verdictResult.hasActionableVerdict && isInEntry,
    distanceToEntryPct: distToEntry,
    optionsSuggestion: verdictResult.optionsRecommendation?.recommendedContract,
    isAlertActive: existingItem?.isAlertActive ?? true,
    alertTriggered: !blockedByTrap && verdictResult.hasActionableVerdict && isInEntry,
    alertReason: !blockedByTrap && verdictResult.hasActionableVerdict && isInEntry ? `${isIntraday ? '⚡ Intraday' : '🌊 Swing'} Optimal Entry Zone reached!` : undefined,
    entryRange: {
      min: entryMin,
      max: entryMax,
      text: verdictResult.entryZone.text
    },
    stopLoss: {
      price: verdictResult.strictStopLoss.price,
      pct: verdictResult.strictStopLoss.pct
    },
    target1: {
      price: verdictResult.target1.price,
      pct: verdictResult.target1.pct
    },
    target2: {
      price: verdictResult.target2.price,
      pct: verdictResult.target2.pct
    },
    riskRewardText: verdictResult.riskRewardText,
    horizon: effectiveHorizon,
    timeframe,
    timesfmResult,
    quantEngineResult,
    smcIctResult,
    actionTrigger: quantReport.directNichod.actionTrigger,
    coreDriver: quantReport.directNichod.coreDriver,
    timestamp: now.getTime(),
    dateTimeFormatted: full,
    timeOnlyFormatted: timeOnly,
    dateOnlyFormatted: dateOnly,
    note: existingItem?.note
  };

  return {
    timesfmResult,
    quantEngineResult,
    smcIctResult,
    finalVerdict,
    item
  };
}

/**
 * Fetches real candle data for a symbol and specified timeframe interval
 */
export async function fetchCandlesForTimeframe(
  symbol: string,
  timeframe: '5m' | '15m' | '1h' | '1d' = '15m'
): Promise<TimeSeriesPoint[]> {
  const cleanSym = symbol.trim().toUpperCase();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);
  try {
    const range = WATCHLIST_HISTORY_RANGE[timeframe];
    const res = await fetch(`/api/market/fetch?provider=yahoo&symbol=${encodeURIComponent(cleanSym)}&range=${range}&interval=${timeframe}`, { signal: controller.signal });
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.data) && json.data.length > 0) {
        return json.data;
      }
    }
  } catch (err) {
    console.warn(`Could not fetch candles for ${symbol} @ ${timeframe}:`, err);
  }
  finally { clearTimeout(timeout); }
  return [];
}
