import type { OptionChainPayload } from './indianOptionsEngine';
import type { TimeSeriesPoint } from '../types';
import type { SyntheticBuildupSignal } from './syntheticBuildupMatrix';

export interface DirectionalFlowSignal {
  available: boolean;
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  scorePct: number;
  label: string;
  detail: string;
  sampleSize?: number;
}

export interface VolumeSpikeSignal {
  available: boolean;
  isSpike: boolean;
  currentVolume: number;
  averageVolume: number;
  ratio: number;
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  detail: string;
  sampleSize: number;
}

export interface MarketFlowSignals {
  optionChainOi?: DirectionalFlowSignal;
  futuresOi?: DirectionalFlowSignal;
  volumeSpike: VolumeSpikeSignal;
  priceVolumePressure?: PriceVolumePressureSignal;
  syntheticBuildup?: SyntheticBuildupSignal;
  trapRisk?: TrapRiskSignal;
}

export interface PriceVolumePressureSignal {
  available: boolean;
  classification: 'LONG_BUILDUP_PROXY' | 'SHORT_BUILDUP_PROXY' | 'PRICE_VOLUME_DIVERGENCE' | 'NO_SPIKE' | 'UNAVAILABLE';
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  scorePct: number;
  relativeVolume: number;
  sampleSize: number;
  label: string;
  detail: string;
}

export interface TrapRiskSignal {
  available: boolean;
  kind: 'BULL_TRAP' | 'BEAR_TRAP' | 'NONE';
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  scorePct: number;
  relativeVolume: number;
  referenceLevel?: number;
  label: string;
  detail: string;
}

export function cacheLiveOptionChainSignal(symbol: string, signal: DirectionalFlowSignal): void {
  if (typeof window === 'undefined' || !signal.available) return;
  try {
    localStorage.setItem(`timesfm_live_option_oi_${symbol.toUpperCase()}`, JSON.stringify({ signal, savedAt: Date.now() }));
  } catch { /* Storage is optional; live verdict can still use this in-memory signal. */ }
}

export function readRecentOptionChainSignal(symbol: string, maxAgeMs = 5 * 60 * 1000): DirectionalFlowSignal | undefined {
  if (typeof window === 'undefined') return undefined;
  try {
    const saved = JSON.parse(localStorage.getItem(`timesfm_live_option_oi_${symbol.toUpperCase()}`) || 'null');
    return saved && Date.now() - saved.savedAt <= maxAgeMs && saved.signal?.available ? saved.signal : undefined;
  } catch { return undefined; }
}

export function cacheLiveFuturesOiSignal(symbol: string, signal: DirectionalFlowSignal): void {
  if (typeof window === 'undefined' || !signal.available) return;
  try { localStorage.setItem(`timesfm_live_futures_oi_${symbol.toUpperCase()}`, JSON.stringify({ signal, savedAt: Date.now() })); } catch { /* optional */ }
}

export function readRecentFuturesOiSignal(symbol: string, maxAgeMs = 5 * 60 * 1000): DirectionalFlowSignal | undefined {
  if (typeof window === 'undefined') return undefined;
  try {
    const saved = JSON.parse(localStorage.getItem(`timesfm_live_futures_oi_${symbol.toUpperCase()}`) || 'null');
    return saved && Date.now() - saved.savedAt <= maxAgeMs && saved.signal?.available ? saved.signal : undefined;
  } catch { return undefined; }
}

/**
 * Directional option pressure from broker-observed OI and premium changes.
 * CE premium up + OI buildup contributes bullish pressure; PE premium up contributes bearish pressure.
 * Weighting is |OI change|, normalized to [-100,+100], and restricted to strikes within 2% of spot.
 * A first snapshot (zero OI delta) is deliberately unavailable, not neutral.
 */
export function analyzeOptionChainOi(chain: OptionChainPayload): DirectionalFlowSignal {
  if (chain.sourceState !== 'LIVE' || !chain.isLiveFeed || chain.underlyingPrice <= 0) {
    return { available: false, direction: 'NEUTRAL', scorePct: 0, label: 'Unavailable', detail: 'Requires a verified live broker option chain.' };
  }
  const rows = chain.options.filter(row => Math.abs(row.strike / chain.underlyingPrice - 1) <= 0.02);
  let bullishWeight = 0;
  let bearishWeight = 0;
  for (const row of rows) {
    const callOiDelta = Number(row.call.changeInOi) || 0;
    const putOiDelta = Number(row.put.changeInOi) || 0;
    const callBuildup = row.call.buildup;
    const putBuildup = row.put.buildup;
    if (callOiDelta !== 0 && callBuildup) {
      if (callBuildup === 'Long Buildup' || callBuildup === 'Short Covering') bullishWeight += Math.abs(callOiDelta);
      else bearishWeight += Math.abs(callOiDelta);
    }
    if (putOiDelta !== 0 && putBuildup) {
      if (putBuildup === 'Short Buildup' || putBuildup === 'Long Unwinding') bullishWeight += Math.abs(putOiDelta);
      else bearishWeight += Math.abs(putOiDelta);
    }
  }
  const total = bullishWeight + bearishWeight;
  if (total === 0) {
    return { available: false, direction: 'NEUTRAL', scorePct: 0, label: 'Waiting for OI change', detail: 'Live quotes are connected, but no interval OI buildup with premium confirmation has been observed yet.', sampleSize: rows.length };
  }
  const scorePct = Math.round(((bullishWeight - bearishWeight) / total) * 100);
  const direction = scorePct >= 15 ? 'BULLISH' : scorePct <= -15 ? 'BEARISH' : 'NEUTRAL';
  return {
    available: true,
    direction,
    scorePct,
    label: direction === 'NEUTRAL' ? 'Mixed OI buildup' : `${direction} option OI buildup`,
    detail: `Near-ATM OI change pressure: ${scorePct > 0 ? '+' : ''}${scorePct}% (CE/PE premium-confirmed, ${rows.length} strikes).`,
    sampleSize: rows.length
  };
}

/** Uses the last candle's volume against up to 20 preceding completed bars. */
export function analyzeVolumeSpike(candles: TimeSeriesPoint[], currentVolume?: number): VolumeSpikeSignal {
  const last = candles[candles.length - 1];
  const volumeNow = Number.isFinite(currentVolume) && Number(currentVolume) > 0
    ? Number(currentVolume)
    : Number(last?.volume) || 0;
  const prior = candles.slice(0, -1).map(c => Number(c.volume) || 0).filter(v => v > 0).slice(-20);
  const averageVolume = prior.length ? prior.reduce((sum, v) => sum + v, 0) / prior.length : 0;
  const ratio = averageVolume > 0 ? volumeNow / averageVolume : 0;
  const isSpike = prior.length >= 5 && ratio >= 1.5;
  const priceChangePct = last && last.open && last.open > 0 ? (last.value - last.open) / last.open : 0;
  const direction = !isSpike || Math.abs(priceChangePct) < 0.001 ? 'NEUTRAL' : priceChangePct > 0 ? 'BULLISH' : 'BEARISH';
  return {
    available: volumeNow > 0 && averageVolume > 0,
    isSpike,
    currentVolume: volumeNow,
    averageVolume,
    ratio,
    direction,
    detail: averageVolume > 0
      ? `${isSpike ? 'Volume spike' : 'No volume spike'}: ${ratio.toFixed(2)}× prior ${prior.length}-bar average${direction !== 'NEUTRAL' ? `, ${direction.toLowerCase()} candle` : ''}.`
      : 'Volume history is unavailable; no spike is inferred.',
    sampleSize: prior.length
  };
}

/**
 * Price-volume positioning proxy, not measured open interest.
 * Uses signed close-location value (CLV=(2C-H-L)/(H-L)) times the current/prior-volume ratio.
 * OI and trader intent are not identifiable from price and volume alone.
 */
export function analyzePriceVolumePressure(candles: TimeSeriesPoint[], currentVolume?: number): PriceVolumePressureSignal {
  const last = candles.at(-1);
  const priorVolumes = candles.slice(-21, -1).map(c => Number(c.volume) || 0).filter(v => v > 0);
  const vol = Number.isFinite(currentVolume) && Number(currentVolume) > 0 ? Number(currentVolume) : Number(last?.volume) || 0;
  const avg = priorVolumes.length ? priorVolumes.reduce((sum, v) => sum + v, 0) / priorVolumes.length : 0;
  const ratio = avg > 0 ? vol / avg : 0;
  const high = Number(last?.high), low = Number(last?.low), close = Number(last?.value), open = Number(last?.open);
  const valid = !!last && priorVolumes.length >= 5 && avg > 0 && vol > 0 &&
    [high, low, close, open].every(Number.isFinite) && open > 0 && high > low && close >= low && close <= high;
  if (!valid) return { available: false, classification: 'UNAVAILABLE', direction: 'NEUTRAL', scorePct: 0, relativeVolume: ratio, sampleSize: priorVolumes.length, label: 'Price-volume proxy unavailable', detail: 'Requires OHLC and at least five earlier non-zero volume bars; it cannot measure actual OI.' };
  const clv = Math.max(-1, Math.min(1, (2 * close - high - low) / (high - low)));
  const bodyPct = (close - open) / open;
  const scorePct = Math.round(clv * Math.min(1, ratio / 1.5) * 100);
  let classification: PriceVolumePressureSignal['classification'] = 'NO_SPIKE';
  let direction: PriceVolumePressureSignal['direction'] = 'NEUTRAL';
  if (ratio >= 1.5 && bodyPct > 0 && clv >= 0.2) { classification = 'LONG_BUILDUP_PROXY'; direction = 'BULLISH'; }
  else if (ratio >= 1.5 && bodyPct < 0 && clv <= -0.2) { classification = 'SHORT_BUILDUP_PROXY'; direction = 'BEARISH'; }
  else if (ratio >= 1.5 && Math.abs(clv) >= 0.2) { classification = 'PRICE_VOLUME_DIVERGENCE'; direction = clv > 0 ? 'BULLISH' : 'BEARISH'; }
  const label = classification === 'LONG_BUILDUP_PROXY' ? 'Long buildup proxy (not OI)' : classification === 'SHORT_BUILDUP_PROXY' ? 'Short buildup proxy (not OI)' : classification === 'PRICE_VOLUME_DIVERGENCE' ? 'Price-volume divergence' : 'No buildup proxy';
  return { available: true, classification, direction, scorePct, relativeVolume: ratio, sampleSize: priorVolumes.length, label, detail: `${label}: volume ${ratio.toFixed(2)}× prior ${priorVolumes.length}-bar mean; close-location value ${clv.toFixed(2)}. Price/volume cannot confirm actual open interest.` };
}

/** Detects only a completed-bar rejection beyond the preceding 20-bar range, with volume confirmation. */
export function detectPriceVolumeTrap(candles: TimeSeriesPoint[], currentVolume?: number): TrapRiskSignal {
  const last = candles.at(-1);
  const prior = candles.slice(-21, -1);
  const volumes = prior.map(c => Number(c.volume) || 0).filter(v => v > 0);
  const avgVol = volumes.length ? volumes.reduce((sum, v) => sum + v, 0) / volumes.length : 0;
  const volume = Number.isFinite(currentVolume) && Number(currentVolume) > 0 ? Number(currentVolume) : Number(last?.volume) || 0;
  const ratio = avgVol > 0 ? volume / avgVol : 0;
  const numbers = last ? [last.open, last.high, last.low, last.value].map(Number) : [];
  if (!last || prior.length < 5 || volumes.length < 5 || !numbers.every(Number.isFinite) || !(last.high! > last.low!)) {
    return { available: false, kind: 'NONE', direction: 'NEUTRAL', scorePct: 0, relativeVolume: ratio, label: 'Trap check unavailable', detail: 'Requires valid OHLCV and at least five preceding bars.' };
  }
  const [open, high, low, close] = numbers;
  const rangeHigh = Math.max(...prior.map(c => Number(c.high ?? c.value)));
  const rangeLow = Math.min(...prior.map(c => Number(c.low ?? c.value)));
  const range = high - low;
  const clv = (2 * close - high - low) / range;
  const trValues = prior.slice(-14).map((bar, i, arr) => {
    const prev = prior[prior.length - arr.length + i - 1];
    const h = Number(bar.high ?? bar.value), l = Number(bar.low ?? bar.value), prevClose = Number(prev?.value ?? bar.value);
    return Math.max(h - l, Math.abs(h - prevClose), Math.abs(l - prevClose));
  }).filter(v => Number.isFinite(v) && v > 0);
  const atr = trValues.length ? trValues.reduce((s, v) => s + v, 0) / trValues.length : range;
  const upperPen = high - rangeHigh;
  const lowerPen = rangeLow - low;
  const bull = ratio >= 1.5 && upperPen > 0 && close < rangeHigh && clv <= -0.2 && (close - open) < 0;
  const bear = ratio >= 1.5 && lowerPen > 0 && close > rangeLow && clv >= 0.2 && (close - open) > 0;
  if (!bull && !bear) return { available: true, kind: 'NONE', direction: 'NEUTRAL', scorePct: 0, relativeVolume: ratio, label: ratio < 1.5 ? 'No volume-confirmed trap' : 'No range-rejection trap', detail: `No confirmed 20-bar range rejection; relative volume ${ratio.toFixed(2)}×.` };
  const isBull = bull;
  const penetration = (isBull ? upperPen : lowerPen) / Math.max(atr, 1e-9);
  const rejection = isBull ? Math.max(0, Math.min(1, (rangeHigh - close) / range)) : Math.max(0, Math.min(1, (close - rangeLow) / range));
  const volumeStrength = Math.max(0, Math.min(1, (ratio - 1) / 2));
  const penetrationStrength = Math.max(0, Math.min(1, penetration / 0.5));
  const scorePct = Math.round(100 * (0.45 * volumeStrength + 0.35 * rejection + 0.20 * penetrationStrength));
  const kind = isBull ? 'BULL_TRAP' : 'BEAR_TRAP';
  const direction = isBull ? 'BEARISH' : 'BULLISH';
  const level = isBull ? rangeHigh : rangeLow;
  return { available: true, kind, direction, scorePct, relativeVolume: ratio, referenceLevel: level, label: `Potential ${isBull ? 'bull' : 'bear'} trap`, detail: `${isBull ? 'High swept then close returned below' : 'Low swept then close returned above'} the prior 20-bar range (${level.toFixed(2)}); volume ${ratio.toFixed(2)}×, heuristic trap-risk score ${scorePct}/100. Confirm on the next completed bar.` };
}

export function analyzeFuturesOi(priceChangePct: number, oiChange: number, oiChangePct: number): DirectionalFlowSignal {
  if (![priceChangePct, oiChange, oiChangePct].every(Number.isFinite) || oiChange === 0 || Math.abs(priceChangePct) < 0.05) {
    return { available: false, direction: 'NEUTRAL', scorePct: 0, label: 'Waiting for futures OI change', detail: 'Requires two live futures OI snapshots and a measurable underlying price move.' };
  }
  const direction = priceChangePct > 0 ? 'BULLISH' : 'BEARISH';
  const buildup = oiChange > 0
    ? (priceChangePct > 0 ? 'Long buildup' : 'Short buildup')
    : (priceChangePct > 0 ? 'Short covering' : 'Long unwinding');
  const pressure = Math.min(100, Math.round(Math.abs(oiChangePct) * 10));
  return { available: true, direction, scorePct: direction === 'BULLISH' ? pressure : -pressure, label: buildup, detail: `${buildup}: futures OI ${oiChange > 0 ? '+' : ''}${oiChangePct.toFixed(2)}% with price ${priceChangePct > 0 ? '+' : ''}${priceChangePct.toFixed(2)}%.` };
}
