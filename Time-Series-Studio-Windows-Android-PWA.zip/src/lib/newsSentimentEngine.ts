import { TimeSeriesPoint, NewsSentiment } from '../types';

export interface GroundedNewsItem {
  title: string;
  source: string;
  sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  impact: 'HIGH' | 'MEDIUM' | 'LOW';
  timeAgo: string;
  snippet: string;
  url?: string;
}

export interface NewsSentimentReport {
  symbol: string;
  name: string;
  overallSentiment: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  sentimentScore: number; // -100 to +100
  sentimentConfidence: 'HIGH' | 'MEDIUM' | 'LOW';
  scoreImpactPct: number; // -10% to +10%
  sentimentSummary: string;
  headlines: GroundedNewsItem[];
  keyBullishFactors: string[];
  keyBearishRisks: string[];
  timestamp: string;
  isLiveNews: boolean;
  statusLabel: 'LIVE_SEARCH_GROUNDED' | 'UNAVAILABLE';
}

/**
 * Enriches time series points with genuine sentiment scores if available.
 * Does NOT generate fake news headlines or fabricate external articles.
 */
export function enrichTimeSeriesWithNewsSentiment(
  points: TimeSeriesPoint[],
  _symbol: string,
  liveReport?: NewsSentimentReport | null
): TimeSeriesPoint[] {
  if (!points || points.length === 0) return [];

  // If live verified report exists, attach the real sentiment to recent candles
  if (liveReport && liveReport.headlines && liveReport.headlines.length > 0) {
    const len = points.length;
    const sentimentPerPoint = liveReport.sentimentScore / 100;

    return points.map((pt, idx) => {
      // Apply sentiment only to recent bars in the window
      const isRecent = idx >= len - 5;
      const matchingNews: NewsSentiment | undefined = isRecent && liveReport.headlines[0] ? {
        sentiment: liveReport.headlines[0].sentiment,
        score: sentimentPerPoint,
        headline: liveReport.headlines[0].title,
        source: liveReport.headlines[0].source,
        category: 'Macro',
        impactMultiplier: 1 + (liveReport.scoreImpactPct / 100)
      } : undefined;

      return {
        ...pt,
        newsSentiment: matchingNews
      };
    });
  }

  // If no live news, return points cleanly without fabricating fake articles
  return points.map(pt => ({
    ...pt,
    newsSentiment: undefined
  }));
}
