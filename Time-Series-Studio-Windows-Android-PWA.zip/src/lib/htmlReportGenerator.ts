import { StockSummaryReportData } from '../types';

/**
 * Generates and triggers the download of a standalone, offline-ready HTML report
 * containing all 5 metrics, entry guides, historical dataset scope, and risk analysis.
 */
export function downloadStockSummaryHtmlReport(report: StockSummaryReportData) {
  const {
    symbol,
    name,
    currencySymbol,
    currentMarketPrice,
    changePct = 0,
    changeAmount = 0,
    direction,
    actionRecommendation,
    actionBadgeText,
    actionReason,
    historicalSpan,
    entryGuide,
    targetOne,
    targetTwo,
    targetThree,
    strictStoploss,
    frequency,
    lastUpdated,
    summaryNote
  } = report;

  const now = new Date();
  const dateFormatted = now.toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const timeFormatted = now.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  const fmt = (n: number) =>
    `${currencySymbol}${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const isPositive = changePct >= 0;

  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${symbol} - Time Series Studio Stock Summary & Price Target Report</title>
  <style>
    :root {
      --bg: #0b0f19;
      --card-bg: #111827;
      --card-border: #1f293d;
      --text-main: #f3f4f6;
      --text-muted: #9ca3af;
      --cyan: #06b6d4;
      --emerald: #10b981;
      --amber: #f59e0b;
      --rose: #f43f5e;
      --indigo: #6366f1;
      --purple: #a855f7;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
    body {
      background-color: var(--bg);
      color: var(--text-main);
      padding: 24px;
      line-height: 1.5;
    }
    .container {
      max-width: 1100px;
      margin: 0 auto;
      background: var(--card-bg);
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 32px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 1px solid var(--card-border);
      padding-bottom: 20px;
      margin-bottom: 24px;
      flex-wrap: wrap;
      gap: 16px;
    }
    .badge {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 9999px;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      background: rgba(6, 182, 212, 0.15);
      color: var(--cyan);
      border: 1px solid rgba(6, 182, 212, 0.3);
      margin-bottom: 8px;
    }
    .title {
      font-size: 28px;
      font-weight: 800;
      color: #ffffff;
      display: flex;
      align-items: center;
      gap: 10px;
      flex-wrap: wrap;
    }
    .symbol-pill {
      font-size: 16px;
      background: #030712;
      color: var(--cyan);
      padding: 4px 10px;
      border-radius: 6px;
      border: 1px solid #374151;
      font-family: monospace;
    }
    .meta-time {
      font-size: 13px;
      color: var(--text-muted);
      text-align: right;
    }
    .scope-box {
      background: #030712;
      border: 1px solid #1f293d;
      border-radius: 12px;
      padding: 14px 18px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      flex-wrap: wrap;
      gap: 12px;
    }
    .verdict-box {
      background: rgba(6, 182, 212, 0.08);
      border: 1px solid rgba(6, 182, 212, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
    }
    .verdict-title {
      font-size: 15px;
      font-weight: 800;
      color: var(--cyan);
      margin-bottom: 4px;
      font-family: monospace;
    }
    .entry-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 14px;
      margin-bottom: 24px;
    }
    .entry-card {
      background: #030712;
      border: 1px solid rgba(6, 182, 212, 0.25);
      border-radius: 10px;
      padding: 14px;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
      gap: 16px;
      margin-bottom: 28px;
    }
    .card {
      background: #030712;
      border-radius: 12px;
      padding: 20px 16px;
      border: 1px solid var(--card-border);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .card.cmp { border-color: rgba(6, 182, 212, 0.4); }
    .card.t1 { border-color: rgba(245, 158, 11, 0.4); }
    .card.t2 { border-color: rgba(16, 182, 129, 0.4); }
    .card.t3 { border-color: rgba(168, 85, 247, 0.4); }
    .card.sl { border-color: rgba(244, 63, 94, 0.4); }
    .card-label {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 8px;
    }
    .card-price {
      font-size: 24px;
      font-weight: 900;
      font-family: monospace;
      margin-bottom: 6px;
    }
    .card-meta {
      font-size: 12px;
      font-family: monospace;
      font-weight: 600;
    }
    .card-footer {
      margin-top: 14px;
      padding-top: 10px;
      border-top: 1px solid rgba(255,255,255,0.06);
      font-size: 11px;
      color: var(--text-muted);
    }
    .exit-rule {
      font-size: 10px;
      color: #93c5fd;
      margin-top: 4px;
      font-weight: 500;
    }
    .text-cyan { color: var(--cyan); }
    .text-emerald { color: var(--emerald); }
    .text-amber { color: var(--amber); }
    .text-rose { color: var(--rose); }
    .text-purple { color: var(--purple); }
    .strategy-box {
      background: #030712;
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 16px 20px;
      font-size: 12px;
      color: var(--text-main);
      margin-top: 20px;
    }
    .footer {
      margin-top: 32px;
      padding-top: 16px;
      border-top: 1px solid var(--card-border);
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      color: var(--text-muted);
      flex-wrap: wrap;
      gap: 8px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div>
        <div class="badge">Local Statistical Forecast Baseline (not pretrained TimesFM)</div>
        <div class="title">
          <span>${name}</span>
          <span class="symbol-pill">${symbol}</span>
        </div>
      </div>
      <div class="meta-time">
        <div><strong>Generated:</strong> ${dateFormatted}</div>
        <div><strong>Report Timestamp:</strong> ${timeFormatted}</div>
      </div>
    </div>

    <!-- Historical Dataset Scope -->
    <div class="scope-box">
      <div>
        <span style="color: var(--text-muted);">Historical Calculation Scope:</span>
        <strong style="color: #ffffff; font-family: monospace; margin-left: 6px;">${historicalSpan.durationText}</strong>
        <span style="color: var(--cyan); margin-left: 6px;">(${historicalSpan.frequency})</span>
      </div>
      <div>
        <span style="color: var(--text-muted);">Date Range:</span>
        <strong style="color: #ffffff; font-family: monospace; margin-left: 6px;">${historicalSpan.startDate} → ${historicalSpan.endDate}</strong>
      </div>
    </div>

    <!-- Action Verdict -->
    <div class="verdict-box">
      <div class="verdict-title">🎯 TIMING VERDICT: ${actionBadgeText}</div>
      <div style="font-size: 12px; color: var(--text-main); margin-top: 4px;">${actionReason}</div>
    </div>

    <!-- Recommended Entry Levels -->
    <div class="entry-grid">
      <div class="entry-card">
        <div style="font-size: 10px; text-transform: uppercase; color: var(--cyan); font-weight: 700; font-family: monospace;">Ideal Buy Zone</div>
        <div style="font-size: 18px; font-weight: 900; font-family: monospace; color: var(--cyan); margin-top: 4px;">${entryGuide.idealEntryRange}</div>
        <div style="font-size: 10px; color: var(--text-muted); margin-top: 4px;">Accumulation corridor</div>
      </div>
      <div class="entry-card">
        <div style="font-size: 10px; text-transform: uppercase; color: var(--emerald); font-weight: 700; font-family: monospace;">Aggressive Entry (CMP)</div>
        <div style="font-size: 18px; font-weight: 900; font-family: monospace; color: #ffffff; margin-top: 4px;">${fmt(entryGuide.aggressiveEntry)}</div>
        <div style="font-size: 10px; color: var(--text-muted); margin-top: 4px;">Immediate market entry</div>
      </div>
      <div class="entry-card">
        <div style="font-size: 10px; text-transform: uppercase; color: var(--amber); font-weight: 700; font-family: monospace;">Conservative Pullback Dip</div>
        <div style="font-size: 18px; font-weight: 900; font-family: monospace; color: var(--amber); margin-top: 4px;">${fmt(entryGuide.conservativePullbackEntry)}</div>
        <div style="font-size: 10px; color: var(--text-muted); margin-top: 4px;">Support floor limit buy</div>
      </div>
    </div>

    <!-- 5 Core Targets Grid -->
    <div class="grid">
      <!-- CMP -->
      <div class="card cmp">
        <div>
          <div class="card-label text-cyan">1. Current Price (CMP)</div>
          <div class="card-price text-cyan">${fmt(currentMarketPrice)}</div>
          <div class="card-meta" style="color: ${isPositive ? 'var(--emerald)' : 'var(--rose)'};">
            ${isPositive ? '+' : ''}${changePct}% (${isPositive ? '+' : ''}${fmt(changeAmount)})
          </div>
        </div>
        <div class="card-footer">
          Real-time market price benchmark
        </div>
      </div>

      <!-- Target 1 -->
      <div class="card t1">
        <div>
          <div class="card-label text-amber">2. Target 1 (T1)</div>
          <div class="card-price text-amber">${fmt(targetOne.targetPrice)}</div>
          <div class="card-meta text-amber">
            +${targetOne.returnPct}% • ${targetOne.probabilityPct !== undefined ? `${targetOne.probabilityPct}% calibrated` : 'Probability not calibrated'}
          </div>
        </div>
        <div class="card-footer">
          ⏱ <strong>${targetOne.timeframeText}</strong>
          <div class="exit-rule">🚪 ${targetOne.exitStrategy || 'Book 50% & SL to Cost'}</div>
        </div>
      </div>

      <!-- Target 2 -->
      <div class="card t2">
        <div>
          <div class="card-label text-emerald">3. Target 2 (T2)</div>
          <div class="card-price text-emerald">${fmt(targetTwo.targetPrice)}</div>
          <div class="card-meta text-emerald">
            +${targetTwo.returnPct}% • ${targetTwo.probabilityPct !== undefined ? `${targetTwo.probabilityPct}% calibrated` : 'Probability not calibrated'}
          </div>
        </div>
        <div class="card-footer">
          ⏱ <strong>${targetTwo.timeframeText}</strong>
          <div class="exit-rule">🚪 ${targetTwo.exitStrategy || 'Book 30% & Trail 20 EMA'}</div>
        </div>
      </div>

      <!-- Target 3 -->
      <div class="card t3">
        <div>
          <div class="card-label text-purple">4. Target 3 (T3)</div>
          <div class="card-price text-purple">${fmt(targetThree.targetPrice)}</div>
          <div class="card-meta text-purple">
            +${targetThree.returnPct}% • ${targetThree.probabilityPct !== undefined ? `${targetThree.probabilityPct}% calibrated` : 'Probability not calibrated'}
          </div>
        </div>
        <div class="card-footer">
          ⏱ <strong>${targetThree.timeframeText}</strong>
          <div class="exit-rule">🚪 ${targetThree.exitStrategy || 'Final target exit'}</div>
        </div>
      </div>

      <!-- Strict Stoploss -->
      <div class="card sl">
        <div>
          <div class="card-label text-rose">5. Strict Stoploss</div>
          <div class="card-price text-rose">${fmt(strictStoploss.stoplossPrice)}</div>
          <div class="card-meta text-rose">
            ${strictStoploss.riskPct}% Risk (${fmt(strictStoploss.riskAmount)})
          </div>
        </div>
        <div class="card-footer">
          🛡 <strong>1 : ${strictStoploss.riskRewardRatio} RRR</strong>
          <div style="font-size: 10px; color: var(--text-muted); margin-top: 4px;">Hard daily close invalidation</div>
        </div>
      </div>
    </div>

    <!-- Strategy Rule -->
    <div class="strategy-box">
      <strong>Strict Trailing & Execution Rule:</strong> ${strictStoploss.trailingRule}
    </div>

    <div class="footer">
      <div>Powered by a local statistical heuristic; forecast ranges are uncalibrated</div>
      <div>Strictly for quantitative decision-support and educational analysis.</div>
    </div>
  </div>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${symbol}_TimesFM_Stock_Summary_${new Date().toISOString().split('T')[0]}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
