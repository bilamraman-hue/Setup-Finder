import { TimeSeriesPoint } from '../types';
import { calculateSyntheticBuildupMatrix, type SyntheticBuildupTimeframe } from './syntheticBuildupMatrix';
import { calculateTimeframeWeightedVerdict } from './timeframeVerdictWeights';

export const BACKTEST_LOOKBACK_BARS: Record<SyntheticBuildupTimeframe, number> = {
  '5m': 4500, '15m': 1500, '1h': 3500, '1d': 1250
};

export type BacktestStrategyType = 
  | 'timesfm_momentum'
  | 'smc_fvg_retest'
  | 'cpr_orb_breakout'
  | 'rsi_mean_reversion'
  | 'timeframe_weighted_setup';

export interface BacktestOptions {
  lookbackBars?: number;
  strategy?: BacktestStrategyType;
  riskRewardRatio?: number; // e.g. 1.5, 2.0, 2.5, 3.0
  useTrailingStop?: boolean;
  initialCapital?: number; // e.g. 1000000
  riskPerTradePct?: number; // e.g. 1.0%
  slippagePct?: number; // e.g. 0.02%
  feePctPerTrade?: number; // e.g. 0.03% per side (brokerage + statutory charges)
  timeframe?: SyntheticBuildupTimeframe;
}

export interface BacktestSignal {
  id: string;
  index: number;
  exitIndex: number;
  timestamp: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice: number;
  targetPrice: number;
  stopLossPrice: number;
  outcome: 'TARGET_HIT' | 'STOPLOSS_HIT' | 'TRAILING_STOP_HIT' | 'ACTIVE';
  grossReturnPct: number;
  netReturnPct: number;
  returnPct: number; // Net return %
  pnlAmount: number;
  feesPaid: number;
  barsHeld: number;
  reason: string;
}

export interface EquityCurvePoint {
  timestamp: string;
  equity: number;
  drawdownPct: number;
  benchmarkEquity: number;
}

export interface BacktestResult {
  symbol: string;
  strategy: BacktestStrategyType;
  strategyName: string;
  timeframe: SyntheticBuildupTimeframe;
  lookbackBars: number;
  totalSignals: number;
  wins: number;
  losses: number;
  winRatePct: number;
  avgReturnPct: number;
  avgWinPct: number;
  avgLossPct: number;
  profitFactor: number;
  sharpeRatio: number;
  sortinoRatio: number;
  expectancyPct: number;
  maxDrawdownPct: number;
  recoveryFactor: number;
  consecutiveWins: number;
  consecutiveLosses: number;
  initialCapital: number;
  finalEquity: number;
  netProfitAmount: number;
  netReturnPct: number;
  buyAndHoldReturnPct: number;
  totalFeesPaid: number;
  equityCurve: EquityCurvePoint[];
  signals: BacktestSignal[];
  chartPoints: {
    timestamp: string;
    close: number;
    high: number;
    low: number;
    signal?: BacktestSignal;
  }[];
  isSampleSufficient: boolean;
  statusMessage?: string;
}

/** A practical reporting floor, not a statistical guarantee of profitability. */
export const MIN_BACKTEST_TRADES_FOR_RELIABLE_SAMPLE = 30;

const STRATEGY_NAMES: Record<BacktestStrategyType, string> = {
  timesfm_momentum: 'Quantitative Momentum Breakout',
  smc_fvg_retest: 'Smart Money (SMC) FVG & Order Block Retest',
  cpr_orb_breakout: 'Central Pivot Range (CPR) Breakout',
  rsi_mean_reversion: 'Dynamic RSI & Bollinger Mean Reversion',
  timeframe_weighted_setup: 'Timeframe Weighted Price-Volume Setup'
};

/**
 * Runs a strictly deterministic backtest simulation over historical time series points.
 * - No look-ahead bias: Signals on bar `i` use only data up to `i`, forward simulation runs on `i+1` onwards.
 * - Realistic transaction costs & slippage.
 * - Zero fabricated fallback statistics: All metrics computed strictly from executed trades.
 */
export function runBacktestSimulation(
  points: TimeSeriesPoint[],
  symbol: string,
  optionsOrLookback: number | BacktestOptions = 60
): BacktestResult {
  const options: BacktestOptions = typeof optionsOrLookback === 'number'
    ? { lookbackBars: optionsOrLookback }
    : optionsOrLookback;

  const timeframe: SyntheticBuildupTimeframe = options.timeframe && ['5m', '15m', '1h', '1d'].includes(options.timeframe) ? options.timeframe : '1h';
  const lookbackBars = Math.max(1, Math.floor(options.lookbackBars ?? BACKTEST_LOOKBACK_BARS[timeframe]));
  const strategy = options.strategy && STRATEGY_NAMES[options.strategy] ? options.strategy : 'timesfm_momentum';
  const rrRatio = Number.isFinite(options.riskRewardRatio) && (options.riskRewardRatio ?? 0) > 0 ? options.riskRewardRatio! : 2.0;
  const useTrailingStop = options.useTrailingStop ?? true;
  const initialCapital = Math.max(0.01, Number.isFinite(options.initialCapital) ? options.initialCapital! : 1000000);
  const riskPerTradePct = Math.max(0, Math.min(100, Number.isFinite(options.riskPerTradePct) ? options.riskPerTradePct! : 1.0));
  const slippagePct = Math.max(0, Number.isFinite(options.slippagePct) ? options.slippagePct! : 0.02);
  const feePctPerTrade = Math.max(0, Number.isFinite(options.feePctPerTrade) ? options.feePctPerTrade! : 0.03);

  const pts = points && Array.isArray(points)
    ? points.map((point, index) => ({ point, index }))
      .filter(({ point }) => Number.isFinite(point.value) && point.value > 0)
      .sort((a, b) => {
        const ta = Date.parse(a.point.timestamp);
        const tb = Date.parse(b.point.timestamp);
        return Number.isFinite(ta) && Number.isFinite(tb) ? ta - tb || a.index - b.index : a.index - b.index;
      })
      .map(({ point }) => point)
    : [];
  const validLen = pts.length;
  
  // Use recent lookback window
  const windowSlice = pts.slice(-Math.min(validLen, lookbackBars));
  const count = windowSlice.length;

  const strategyName = STRATEGY_NAMES[strategy] || strategy;

  // Handle insufficient data cleanly without fabricating numbers
  if (count < 10) {
    const firstP = windowSlice[0]?.value || 100;
    return {
      symbol,
      strategy,
      strategyName,
      timeframe,
      lookbackBars: count,
      totalSignals: 0,
      wins: 0,
      losses: 0,
      winRatePct: 0,
      avgReturnPct: 0,
      avgWinPct: 0,
      avgLossPct: 0,
      profitFactor: 0,
      sharpeRatio: 0,
      sortinoRatio: 0,
      expectancyPct: 0,
      maxDrawdownPct: 0,
      recoveryFactor: 0,
      consecutiveWins: 0,
      consecutiveLosses: 0,
      initialCapital,
      finalEquity: initialCapital,
      netProfitAmount: 0,
      netReturnPct: 0,
      buyAndHoldReturnPct: 0,
      totalFeesPaid: 0,
      equityCurve: windowSlice.map(p => ({
        timestamp: p.timestamp.split('T')[0],
        equity: initialCapital,
        drawdownPct: 0,
        benchmarkEquity: initialCapital * (p.value / firstP)
      })),
      signals: [],
      chartPoints: windowSlice.map(pt => ({
        timestamp: pt.timestamp.split('T')[0],
        close: pt.value,
        high: pt.high ?? pt.value,
        low: pt.low ?? pt.value
      })),
      isSampleSufficient: false,
      statusMessage: 'Insufficient historical candle data (minimum 10 bars required).'
    };
  }

  const signals: BacktestSignal[] = [];
  const chartPoints = windowSlice.map((pt) => {
    const open = Number.isFinite(pt.open) ? pt.open! : pt.value;
    const rawHigh = Number.isFinite(pt.high) ? pt.high! : pt.value;
    const rawLow = Number.isFinite(pt.low) ? pt.low! : pt.value;
    return {
      timestamp: pt.timestamp.split('T')[0],
      close: pt.value,
      open,
      high: Math.max(rawHigh, rawLow, open, pt.value),
      low: Math.min(rawHigh, rawLow, open, pt.value),
      signal: undefined as BacktestSignal | undefined
    };
  });

  const maxHoldingPeriod = 9;
  let lastSignalIndex = -10;
  let lastExitIndex = -1;

  for (let i = 5; i < count - maxHoldingPeriod; i++) {
    // Avoid overlapping signals too closely
    if (i - lastSignalIndex < 3 || i <= lastExitIndex) continue;

    const current = windowSlice[i];
    const prev = windowSlice[i - 1];
    const prev2 = windowSlice[i - 2];

    const currentClose = current.value;
    const prevClose = prev.value;
    const prev2Close = prev2.value;

    const rsi = current.covariates?.rsi_14 ?? Number.NaN;
    const volRatio = current.covariates?.volume_ratio ?? Number.NaN;

    let triggerType: 'BUY' | 'SELL' | null = null;
    let reason = '';

    // Strategy 1: Quantitative Momentum Breakout
    if (strategy === 'timesfm_momentum') {
      const isUpMomentum = currentClose > prevClose && prevClose > prev2Close * 0.998;
      const isDownMomentum = currentClose < prevClose && prevClose < prev2Close * 1.002;

      if ((isUpMomentum && rsi >= 48 && rsi <= 68) || (rsi < 35 && currentClose > prevClose)) {
        triggerType = 'BUY';
        reason = rsi < 35 ? 'Oversold Support Rebound' : 'Multi-Patch Trend Continuation';
      } else if (isDownMomentum && (rsi <= 45 || rsi > 72)) {
        triggerType = 'SELL';
        reason = rsi > 72 ? 'Overbought Resistance Exhaustion' : 'Downside Displacement';
      }
    }
    // Historical OHLCV only: actual OI is deliberately omitted from backtests.
    else if (strategy === 'timeframe_weighted_setup') {
      const sample = windowSlice.slice(Math.max(0, i - 60), i + 1);
      const closes = sample.map(bar => bar.value);
      const recentMove = currentClose - (closes[Math.max(0, closes.length - 11)] ?? prevClose);
      let trSum = 0; let trCount = 0;
      for (let j = Math.max(1, sample.length - 14); j < sample.length; j++) {
        const bar = sample[j]; const prior = sample[j - 1];
        trSum += Math.max((bar.high ?? bar.value) - (bar.low ?? bar.value), Math.abs((bar.high ?? bar.value) - prior.value), Math.abs((bar.low ?? bar.value) - prior.value));
        trCount++;
      }
      const atr = trCount ? trSum / trCount : 0;
      const priceActionSigned = atr > 0 ? Math.max(-100, Math.min(100, (recentMove / atr) * 50)) : 0;
      const priorVolumes = sample.slice(0, -1).slice(-20).map(bar => Number(bar.volume)).filter(Number.isFinite);
      const currentVolume = Number(current.volume);
      const averageVolume = priorVolumes.length ? priorVolumes.reduce((sum, value) => sum + value, 0) / priorVolumes.length : 0;
      const volumeAvailable = Number.isFinite(currentVolume) && currentVolume >= 0 && averageVolume > 0;
      const volumeRatio = volumeAvailable ? currentVolume / averageVolume : 0;
      const open = Number(current.open ?? currentClose);
      const volumeDirection = !volumeAvailable || currentClose === open ? 'NEUTRAL' : currentClose > open ? 'BULLISH' : 'BEARISH';
      const volumeStrengthPct = volumeAvailable ? Math.max(0, Math.min(100, ((volumeRatio - 1) / 1.5) * 100)) : 0;
      const matrix = calculateSyntheticBuildupMatrix(sample, timeframe);
      const verdict = calculateTimeframeWeightedVerdict({
        timeframe, priceActionSigned, volumeAvailable, volumeDirection, volumeStrengthPct,
        syntheticBuildup: matrix, liveOiSignals: []
      });
      if (verdict.direction === 'BULLISH') {
        triggerType = 'BUY'; reason = `Timeframe-weighted OHLCV score ${verdict.directionalScorePct}% (${timeframe}); no historical OI used`;
      } else if (verdict.direction === 'BEARISH') {
        triggerType = 'SELL'; reason = `Timeframe-weighted OHLCV score ${verdict.directionalScorePct}% (${timeframe}); no historical OI used`;
      }
    }
    // Strategy 2: Smart Money (SMC) FVG & Order Block Retest
    else if (strategy === 'smc_fvg_retest') {
      const hasBullishFvg = (windowSlice[i - 1].low ?? windowSlice[i - 1].value) > (windowSlice[i - 3].high ?? windowSlice[i - 3].value);
      const hasBearishFvg = (windowSlice[i - 1].high ?? windowSlice[i - 1].value) < (windowSlice[i - 3].low ?? windowSlice[i - 3].value);

      if (hasBullishFvg && currentClose >= (windowSlice[i - 1].low ?? currentClose * 0.995)) {
        triggerType = 'BUY';
        reason = 'Bullish Fair Value Gap 50% Consequent Encroachment Retest';
      } else if (hasBearishFvg && currentClose <= (windowSlice[i - 1].high ?? currentClose * 1.005)) {
        triggerType = 'SELL';
        reason = 'Bearish FVG Mitigation & Order Block Rejection';
      }
    }
    // Strategy 3: CPR & Opening Range Breakout
    else if (strategy === 'cpr_orb_breakout') {
      const pHigh = prev.high ?? prevClose;
      const pLow = prev.low ?? prevClose;
      const cprPivot = (pHigh + pLow + prevClose) / 3;
      const cprTop = (cprPivot - (pHigh + pLow) / 2) + cprPivot;
      const cprBottom = (cprPivot * 2) - cprTop;

      if (currentClose > cprTop && prevClose <= cprTop && volRatio > 1.05) {
        triggerType = 'BUY';
        reason = 'CPR Top Central Floor Breakout with Volume Expansion';
      } else if (currentClose < cprBottom && prevClose >= cprBottom) {
        triggerType = 'SELL';
        reason = 'CPR Bottom Central Breakdown Acceleration';
      }
    }
    // Strategy 4: Dynamic RSI & Bollinger Mean Reversion
    else if (strategy === 'rsi_mean_reversion') {
      if (rsi < 32 && currentClose > prevClose) {
        triggerType = 'BUY';
        reason = `Oversold Mean Reversion (RSI: ${rsi.toFixed(1)}) towards 20 SMA`;
      } else if (rsi > 70 && currentClose < prevClose) {
        triggerType = 'SELL';
        reason = `Overbought Mean Reversion (RSI: ${rsi.toFixed(1)})`;
      }
    }

    if (!triggerType) continue;

    // Apply entry slippage
    // The signal is known after bar i closes; enter on the next bar's open.
    const rawEntryPrice = chartPoints[i + 1].open;
    const entryPrice = triggerType === 'BUY'
      ? Math.round(rawEntryPrice * (1 + slippagePct / 100) * 100) / 100
      : Math.round(rawEntryPrice * (1 - slippagePct / 100) * 100) / 100;
    
    // Dynamic ATR-based Stop & Target
    const atrStart = Math.max(0, i - 13);
    let atrSum = 0;
    let atrCount = 0;
    for (let j = atrStart; j <= i; j++) {
      const previousClose = j > 0 ? chartPoints[j - 1].close : chartPoints[j].close;
      const tr = Math.max(
        chartPoints[j].high - chartPoints[j].low,
        Math.abs(chartPoints[j].high - previousClose),
        Math.abs(chartPoints[j].low - previousClose)
      );
      atrSum += tr;
      atrCount++;
    }
    const atrEst = atrCount > 0 ? atrSum / atrCount : 0;
    if (!(atrEst > 0)) continue;
    const stopDistance = atrEst * 1.2;
    const targetDistance = stopDistance * rrRatio;

    const targetPrice = triggerType === 'BUY'
      ? Math.round((entryPrice + targetDistance) * 100) / 100
      : Math.max(0.01, Math.round((entryPrice - targetDistance) * 100) / 100);

    const stopLossPrice = triggerType === 'BUY'
      ? Math.round((entryPrice - stopDistance) * 100) / 100
      : Math.round((entryPrice + stopDistance) * 100) / 100;

    // Forward Simulation strictly on bars i+1 onwards (NO LOOK-AHEAD)
    let outcome: 'TARGET_HIT' | 'STOPLOSS_HIT' | 'TRAILING_STOP_HIT' | 'ACTIVE' = 'ACTIVE';
    let rawExitPrice = entryPrice;
    let barsHeld = 0;
    let exitIndex = i + 1;
    let trailingSl = stopLossPrice;
    let isBreakevenProtected = false;

    for (let f = i + 1; f < count; f++) {
      barsHeld = f - i;
      exitIndex = f;
      const fHigh = chartPoints[f].high;
      const fLow = chartPoints[f].low;
      const fClose = chartPoints[f].close;
      const fOpen = chartPoints[f].open;

      if (triggerType === 'BUY') {
        // If a bar touches both the active stop and target, assume the stop filled first.
        if (fOpen <= trailingSl) {
          outcome = isBreakevenProtected ? 'TRAILING_STOP_HIT' : 'STOPLOSS_HIT';
          rawExitPrice = fOpen;
          break;
        }
        if (fLow <= trailingSl) {
          outcome = isBreakevenProtected ? 'TRAILING_STOP_HIT' : 'STOPLOSS_HIT';
          rawExitPrice = trailingSl;
          break;
        }
        if (fHigh >= targetPrice) {
          outcome = 'TARGET_HIT';
          rawExitPrice = targetPrice;
          break;
        }
        // Update the trailing stop only after evaluating this bar; it becomes active next bar.
        if (useTrailingStop) {
          if (!isBreakevenProtected && fHigh >= entryPrice + stopDistance * 0.9) {
            trailingSl = entryPrice;
            isBreakevenProtected = true;
          } else if (isBreakevenProtected && fHigh >= entryPrice + stopDistance * 1.5) {
            trailingSl = Math.max(trailingSl, fHigh - atrEst * 1.2);
          }
        }
      } else {
        // Conservative same-bar ordering: test the already-active stop before the target.
        if (fOpen >= trailingSl) {
          outcome = isBreakevenProtected ? 'TRAILING_STOP_HIT' : 'STOPLOSS_HIT';
          rawExitPrice = fOpen;
          break;
        }
        if (fHigh >= trailingSl) {
          outcome = isBreakevenProtected ? 'TRAILING_STOP_HIT' : 'STOPLOSS_HIT';
          rawExitPrice = trailingSl;
          break;
        }
        if (fLow <= targetPrice) {
          outcome = 'TARGET_HIT';
          rawExitPrice = targetPrice;
          break;
        }
        if (useTrailingStop) {
          if (!isBreakevenProtected && fLow <= entryPrice - stopDistance * 0.9) {
            trailingSl = entryPrice;
            isBreakevenProtected = true;
          } else if (isBreakevenProtected && fLow <= entryPrice - stopDistance * 1.5) {
            trailingSl = Math.min(trailingSl, fLow + atrEst * 1.2);
          }
        }
      }

      if (barsHeld >= maxHoldingPeriod) {
        rawExitPrice = fClose;
        const netGain = triggerType === 'BUY' ? rawExitPrice - entryPrice : entryPrice - rawExitPrice;
        outcome = netGain >= 0 ? 'TARGET_HIT' : 'STOPLOSS_HIT';
        break;
      }
    }

    // Apply exit slippage
    const exitPrice = triggerType === 'BUY'
      ? Math.round(rawExitPrice * (1 - slippagePct / 100) * 100) / 100
      : Math.round(rawExitPrice * (1 + slippagePct / 100) * 100) / 100;

    const grossReturnPct = triggerType === 'BUY'
      ? Math.round(((exitPrice - entryPrice) / entryPrice) * 1000) / 10
      : Math.round(((entryPrice - exitPrice) / entryPrice) * 1000) / 10;

    // Position sizing: Risk 1% of capital
    const riskAmount = (initialCapital * riskPerTradePct) / 100;
    const riskDistance = Math.abs(entryPrice - stopLossPrice);
    if (!(riskDistance > 0)) continue;
    const qty = Math.floor(riskAmount / riskDistance);
    if (qty < 1) continue;
    const tradeTurnover = qty * entryPrice + qty * exitPrice;
    const feesPaid = Math.round(tradeTurnover * (feePctPerTrade / 100) * 100) / 100;
    const grossPnl = qty * (triggerType === 'BUY' ? exitPrice - entryPrice : entryPrice - exitPrice);
    const pnlAmount = Math.round((grossPnl - feesPaid) * 100) / 100;
    const netReturnPct = Math.round((pnlAmount / (qty * entryPrice)) * 1000) / 10;

    const sigObj: BacktestSignal = {
      id: `sig-${i}-${triggerType}`,
      index: i,
      exitIndex,
      timestamp: chartPoints[i].timestamp,
      type: triggerType,
      entryPrice,
      exitPrice,
      targetPrice,
      stopLossPrice,
      outcome,
      grossReturnPct,
      netReturnPct,
      returnPct: netReturnPct,
      pnlAmount,
      feesPaid,
      barsHeld: Math.max(1, barsHeld),
      reason
    };

    signals.push(sigObj);
    chartPoints[i].signal = sigObj;
    lastSignalIndex = i;
    lastExitIndex = exitIndex;
  }

  // Calculate genuine statistics strictly from completed trades
  const completedSignals = signals.filter(s => s.outcome !== 'ACTIVE');
  const winTrades = completedSignals.filter(s => s.netReturnPct > 0);
  const lossTrades = completedSignals.filter(s => s.netReturnPct <= 0);

  const wins = winTrades.length;
  const losses = lossTrades.length;
  const totalCompleted = completedSignals.length;

  const winRatePct = totalCompleted > 0 
    ? Math.round((wins / totalCompleted) * 1000) / 10 
    : 0;

  const grossGains = winTrades.reduce((acc, s) => acc + s.pnlAmount, 0);
  const grossLosses = Math.abs(lossTrades.reduce((acc, s) => acc + s.pnlAmount, 0));
  const avgWinPct = wins > 0 ? Math.round((winTrades.reduce((acc, s) => acc + s.netReturnPct, 0) / wins) * 10) / 10 : 0;
  const avgLossPct = losses > 0 ? Math.round((lossTrades.reduce((acc, s) => acc + Math.abs(s.netReturnPct), 0) / losses) * 10) / 10 : 0;

  const totalReturn = completedSignals.reduce((acc, s) => acc + s.netReturnPct, 0);
  const avgReturnPct = totalCompleted > 0 
    ? Math.round((totalReturn / totalCompleted) * 10) / 10 
    : 0;

  const profitFactor = grossLosses > 0 
    ? Math.round((grossGains / grossLosses) * 100) / 100 
    : (grossGains > 0 ? Infinity : 0);

  const winRatio = totalCompleted > 0 ? wins / totalCompleted : 0;
  const lossRatio = totalCompleted > 0 ? losses / totalCompleted : 0;
  const expectancyPct = Math.round((winRatio * avgWinPct - lossRatio * avgLossPct) * 100) / 100;

  let consecutiveWins = 0;
  let maxConsWins = 0;
  let consecutiveLosses = 0;
  let maxConsLosses = 0;

  for (const s of completedSignals) {
    if (s.netReturnPct > 0) {
      consecutiveWins++;
      consecutiveLosses = 0;
      if (consecutiveWins > maxConsWins) maxConsWins = consecutiveWins;
    } else {
      consecutiveLosses++;
      consecutiveWins = 0;
      if (consecutiveLosses > maxConsLosses) maxConsLosses = consecutiveLosses;
    }
  }

  // Equity Curve & Drawdown Tracking
  let currentEquity = initialCapital;
  let peakEquity = initialCapital;
  let maxDd = 0;
  let totalFeesPaid = 0;

  const firstPrice = windowSlice[0].value || 100;
  const lastPrice = windowSlice[windowSlice.length - 1].value || 100;
  const buyAndHoldReturnPct = Math.round(((lastPrice - firstPrice) / firstPrice) * 1000) / 10;

  const equityCurve: EquityCurvePoint[] = [];

  for (let k = 0; k < windowSlice.length; k++) {
    const pt = windowSlice[k];
    const matchingSignal = completedSignals.find(s => s.exitIndex === k);
    if (matchingSignal) {
      currentEquity += matchingSignal.pnlAmount;
      totalFeesPaid += matchingSignal.feesPaid;
    }

    if (currentEquity > peakEquity) peakEquity = currentEquity;
    const dd = peakEquity > 0 ? ((peakEquity - currentEquity) / peakEquity) * 100 : 0;
    if (dd > maxDd) maxDd = dd;

    const benchmarkEq = initialCapital * (pt.value / firstPrice);

    equityCurve.push({
      timestamp: pt.timestamp.split('T')[0],
      equity: Math.round(currentEquity),
      drawdownPct: Math.round(dd * 10) / 10,
      benchmarkEquity: Math.round(benchmarkEq)
    });
  }

  const finalEquity = currentEquity;
  const netProfitAmount = Math.round((finalEquity - initialCapital) * 100) / 100;
  const netReturnPct = Math.round(((finalEquity - initialCapital) / initialCapital) * 1000) / 10;
  const maxDrawdownPct = Math.round(maxDd * 10) / 10;
  const recoveryFactor = maxDrawdownPct > 0 
    ? Math.round((netReturnPct / maxDrawdownPct) * 10) / 10 
    : 0;

  // Per-trade Sharpe and Sortino (not annualized because bar frequency is not guaranteed daily).
  const returnsArray = completedSignals.map(s => s.netReturnPct / 100);
  const meanRet = returnsArray.length > 0 ? returnsArray.reduce((a, b) => a + b, 0) / returnsArray.length : 0;
  const variance = returnsArray.length > 1
    ? returnsArray.reduce((sum, r) => sum + Math.pow(r - meanRet, 2), 0) / (returnsArray.length - 1)
    : 0;
  const downsideVariance = returnsArray.length > 1
    ? returnsArray.filter(r => r < 0).reduce((sum, r) => sum + Math.pow(r, 2), 0) / Math.max(1, lossTrades.length)
    : 0;

  const stdDev = Math.sqrt(variance);
  const downsideStd = Math.sqrt(downsideVariance);

  const sharpeRatio = stdDev > 0 ? Math.round((meanRet / stdDev) * 100) / 100 : 0;
  const sortinoRatio = downsideStd > 0 ? Math.round((meanRet / downsideStd) * 100) / 100 : 0;

  return {
    symbol,
    strategy,
    strategyName,
    timeframe,
    lookbackBars: count,
    totalSignals: signals.length,
    wins,
    losses,
    winRatePct,
    avgReturnPct,
    avgWinPct,
    avgLossPct,
    profitFactor,
    sharpeRatio,
    sortinoRatio,
    expectancyPct,
    maxDrawdownPct,
    recoveryFactor,
    consecutiveWins: maxConsWins,
    consecutiveLosses: maxConsLosses,
    initialCapital,
    finalEquity,
    netProfitAmount,
    netReturnPct,
    buyAndHoldReturnPct,
    totalFeesPaid: Math.round(totalFeesPaid * 100) / 100,
    equityCurve,
    signals,
    chartPoints,
    isSampleSufficient: totalCompleted >= MIN_BACKTEST_TRADES_FOR_RELIABLE_SAMPLE,
    statusMessage: totalCompleted === 0
      ? 'No completed trades triggered in this historical window.'
      : totalCompleted < MIN_BACKTEST_TRADES_FOR_RELIABLE_SAMPLE
        ? `Only ${totalCompleted} completed trades. Treat these statistics as highly uncertain.`
        : undefined
  };
}
