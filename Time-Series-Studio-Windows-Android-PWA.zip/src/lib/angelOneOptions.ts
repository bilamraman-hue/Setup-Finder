import { buildInstitutionalOptionChain, parseBrokerOptionChain, type OptionChainPayload, type OptionExpiryInfo } from './indianOptionsEngine.ts';
import { analyzeFuturesOi, type DirectionalFlowSignal } from './marketFlowSignals';

const SCRIP_MASTER_URL = 'https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json';
const SMART_API_ROOT = 'https://apiconnect.angelone.in/rest/secure/angelbroking';
const MAX_QUOTE_TOKENS = 50;
const STRIKES_EACH_SIDE = 15;

interface AngelScrip {
  token: string;
  symbol: string;
  name: string;
  expiry: string;
  strike: string | number;
  lotsize: string | number;
  instrumenttype: string;
  exch_seg: string;
  tick_size?: string | number;
}

interface AngelConfig {
  apiKey?: string;
  customHeaders?: Record<string, string>;
}

interface AngelContractSnapshot {
  ltp: number;
  oi: number;
  capturedAt: number;
}

let scripMasterCache: { rows: AngelScrip[]; expiresAt: number } | null = null;
const previousContractSnapshots = new Map<string, AngelContractSnapshot>();
const previousFuturesSnapshots = new Map<string, AngelContractSnapshot>();

function normalizeUnderlying(value: string): string {
  const symbol = value.toUpperCase().replace(/\.NS$|\.BO$/i, '').replace(/[^A-Z0-9]/g, '');
  if (symbol === 'NIFTY50') return 'NIFTY';
  if (symbol === 'BANKNIFTY') return 'BANKNIFTY';
  if (symbol === 'NIFTYFINANCIALSERVICES') return 'FINNIFTY';
  if (symbol === 'TATAMOTORS') return 'TATAMOTORS';
  return symbol;
}

function angelExpiryDate(value: string): Date | null {
  const match = value.toUpperCase().match(/^(\d{1,2})([A-Z]{3})(\d{4})$/);
  if (!match) return null;
  const month = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'].indexOf(match[2]);
  if (month < 0) return null;
  const date = new Date(Date.UTC(Number(match[3]), month, Number(match[1])));
  return Number.isNaN(date.getTime()) ? null : date;
}

function angelExpiryLabel(date: Date, index: number): string {
  const month = date.toLocaleString('en-US', { month: 'short', timeZone: 'UTC' });
  const year = date.getUTCFullYear();
  const dateLabel = date.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
  return `${dateLabel} (${index === 0 ? 'Current' : index === 1 ? 'Next' : 'Far'} Expiry · ${month} ${year})`;
}

async function getScripMaster(): Promise<AngelScrip[]> {
  if (scripMasterCache && scripMasterCache.expiresAt > Date.now()) return scripMasterCache.rows;
  const response = await fetch(SCRIP_MASTER_URL, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`Angel One instrument master request failed (${response.status}).`);
  const json = await response.json();
  if (!Array.isArray(json)) throw new Error('Angel One returned an invalid instrument master.');
  const rows = json as AngelScrip[];
  scripMasterCache = { rows, expiresAt: Date.now() + 6 * 60 * 60 * 1000 };
  return rows;
}

function authorizationHeaders(config: AngelConfig): Record<string, string> {
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ...(config.customHeaders || {})
  };
  const accessToken = config.apiKey?.trim();
  if (accessToken && !headers.Authorization && !headers.authorization) {
    headers.Authorization = accessToken.startsWith('Bearer ') ? accessToken : `Bearer ${accessToken}`;
  }
  return headers;
}

function positiveNumber(value: unknown): number {
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric > 0 ? numeric : 0;
}

function contractStrike(scrip: AngelScrip): number {
  const raw = Number(scrip.strike);
  // Angel One's instrument master stores option strikes in paise.
  return Number.isFinite(raw) ? (raw >= 100000 ? raw / 100 : raw) : 0;
}

function quoteItems(body: any): any[] {
  const data = body?.data;
  if (Array.isArray(data?.fetched)) return data.fetched;
  if (Array.isArray(data?.fetchedData)) return data.fetchedData;
  if (Array.isArray(data)) return data;
  return [];
}

function greekMap(body: any): Map<string, any> {
  const rows = Array.isArray(body?.data) ? body.data : [];
  return new Map(rows.map((row: any) => [`${Number(row.strikePrice)}:${String(row.optionType).toUpperCase()}`, row]));
}

function classifyBuildup(priceChange: number, oiChange: number): OptionChainPayload['options'][number]['call']['buildup'] {
  if (oiChange > 0 && priceChange > 0) return 'Long Buildup';
  if (oiChange > 0 && priceChange < 0) return 'Short Buildup';
  if (oiChange < 0 && priceChange > 0) return 'Short Covering';
  if (oiChange < 0 && priceChange < 0) return 'Long Unwinding';
  return undefined;
}

export async function fetchAngelOneOptionChain(input: {
  symbol: string;
  name: string;
  cmp: number;
  expiryIndex: number;
  config: AngelConfig;
}): Promise<OptionChainPayload> {
  if (!input.config.apiKey) throw new Error('Angel One SmartAPI JWT access token is missing.');
  const headers = authorizationHeaders(input.config);
  for (const required of ['X-PrivateKey', 'X-UserType', 'X-SourceID', 'X-ClientLocalIP', 'X-ClientPublicIP', 'X-MACAddress']) {
    if (!Object.keys(headers).some(key => key.toLowerCase() === required.toLowerCase())) {
      throw new Error(`Angel One SmartAPI setup is missing the ${required} header.`);
    }
  }

  const normalizedSymbol = normalizeUnderlying(input.symbol);
  const master = await getScripMaster();
  const eligible = master.filter(row =>
    row.exch_seg === 'NFO' &&
    (row.instrumenttype === 'OPTIDX' || row.instrumenttype === 'OPTSTK') &&
    normalizeUnderlying(row.name || '') === normalizedSymbol &&
    Boolean(angelExpiryDate(row.expiry))
  );
  if (!eligible.length) throw new Error(`No Angel One NSE option contracts found for ${input.symbol}.`);

  const expiryDates = [...new Map(eligible.map(row => [row.expiry, angelExpiryDate(row.expiry)!])).entries()]
    .filter(([, date]) => date.getTime() >= Date.now() - 24 * 60 * 60 * 1000)
    .sort((a, b) => a[1].getTime() - b[1].getTime());
  if (!expiryDates.length) throw new Error(`Angel One has no active option expiries for ${input.symbol}.`);
  const chosenIndex = Math.min(Math.max(0, input.expiryIndex), expiryDates.length - 1);
  const [expiryCode, expiryDate] = expiryDates[chosenIndex];
  const expiryContracts = eligible.filter(row => row.expiry === expiryCode);
  const strikeByValue = new Map<number, { CE?: AngelScrip; PE?: AngelScrip }>();
  for (const contract of expiryContracts) {
    const strike = contractStrike(contract);
    if (!strike) continue;
    const type = contract.symbol.toUpperCase().endsWith('CE') ? 'CE' : contract.symbol.toUpperCase().endsWith('PE') ? 'PE' : null;
    if (!type) continue;
    const pair = strikeByValue.get(strike) || {};
    pair[type] = contract;
    strikeByValue.set(strike, pair);
  }
  const allStrikes = [...strikeByValue.keys()].sort((a, b) => a - b);
  if (!allStrikes.length) throw new Error(`Angel One returned no strike ladder for ${input.symbol} ${expiryCode}.`);
  const atmIndex = allStrikes.reduce((best, strike, index) => Math.abs(strike - input.cmp) < Math.abs(allStrikes[best] - input.cmp) ? index : best, 0);
  const selectedStrikes = allStrikes.slice(Math.max(0, atmIndex - STRIKES_EACH_SIDE), atmIndex + STRIKES_EACH_SIDE + 1);
  const selectedContracts = selectedStrikes.flatMap(strike => {
    const pair = strikeByValue.get(strike)!;
    return [pair.CE, pair.PE].filter((contract): contract is AngelScrip => Boolean(contract));
  });
  const fetchedByToken = new Map<string, any>();

  for (let offset = 0; offset < selectedContracts.length; offset += MAX_QUOTE_TOKENS) {
    const contracts = selectedContracts.slice(offset, offset + MAX_QUOTE_TOKENS);
    const quoteResponse = await fetch(`${SMART_API_ROOT}/market/v1/quote/`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ mode: 'FULL', exchangeTokens: { NFO: contracts.map(contract => String(contract.token)) } })
    });
    if (!quoteResponse.ok) throw new Error(`Angel One quote request failed (${quoteResponse.status}).`);
    const quoteBody = await quoteResponse.json();
    if (!quoteBody?.status) throw new Error(quoteBody?.message || 'Angel One rejected the market quote request.');
    for (const item of quoteItems(quoteBody)) {
      const token = String(item.symbolToken || item.symboltoken || item.token || '');
      if (token) fetchedByToken.set(token, item);
    }
    if (offset + MAX_QUOTE_TOKENS < selectedContracts.length) {
      // SmartAPI market quote endpoint is limited to one request per second.
      await new Promise(resolve => setTimeout(resolve, 1050));
    }
  }

  const greekResponse = await fetch(`${SMART_API_ROOT}/marketData/v1/optionGreek`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ name: normalizedSymbol, expirydate: expiryCode })
  });
  if (!greekResponse.ok) throw new Error(`Angel One Greeks request failed (${greekResponse.status}).`);
  const greekBody = await greekResponse.json();
  if (!greekBody?.status) throw new Error(greekBody?.message || 'Angel One did not return option Greeks.');
  const greeks = greekMap(greekBody);
  if (!greeks.size) throw new Error('Angel One returned no option Greeks for this expiry.');
  const now = Date.now();
  const chainRows = selectedStrikes.map(strike => {
    const pair = strikeByValue.get(strike)!;
    const makeSide = (contract: AngelScrip | undefined, type: 'CE' | 'PE') => {
      if (!contract) return undefined;
      const quote = fetchedByToken.get(String(contract.token));
      if (!quote) return undefined;
      const ltp = positiveNumber(quote.ltp);
      if (!ltp) return undefined;
      const oi = positiveNumber(quote.opnInterest ?? quote.openInterest ?? quote.oi);
      const greeksRow = greeks.get(`${strike}:${type}`);
      if (!greeksRow || !positiveNumber(greeksRow.impliedVolatility)) return undefined;
      const snapshotKey = `${normalizedSymbol}:${expiryCode}:${contract.token}`;
      const previous = previousContractSnapshots.get(snapshotKey);
      const oiChange = previous ? oi - previous.oi : 0;
      const snapshotPriceChange = previous ? ltp - previous.ltp : 0;
      const close = positiveNumber(quote.close || quote.closePrice);
      const dailyChange = Number.isFinite(Number(quote.netChange))
        ? Number(quote.netChange)
        : (close > 0 ? ltp - close : 0);
      const providerPercentChange = quote.percentChange === undefined || quote.percentChange === null || quote.percentChange === ''
        ? NaN
        : Number(quote.percentChange);
      const dailyPercentChange = Number.isFinite(providerPercentChange)
        ? providerPercentChange
        : (close > 0 ? (dailyChange / close) * 100 : 0);
      previousContractSnapshots.set(snapshotKey, { ltp, oi, capturedAt: now });
      return {
        lastPrice: ltp,
        change: dailyChange,
        percentChange: dailyPercentChange,
        bid: positiveNumber(quote.depth?.buy?.[0]?.price || quote.buyPrice || quote.bidPrice),
        ask: positiveNumber(quote.depth?.sell?.[0]?.price || quote.sellPrice || quote.askPrice),
        openInterest: oi,
        changeInOi: oiChange,
        volume: positiveNumber(quote.tradeVolume || quote.volume),
        impliedVolatility: positiveNumber(greeksRow.impliedVolatility),
        delta: Number(greeksRow.delta) || undefined,
        gamma: Number(greeksRow.gamma) || undefined,
        theta: Number(greeksRow.theta) || undefined,
        vega: Number(greeksRow.vega) || undefined,
        buildup: classifyBuildup(snapshotPriceChange, oiChange)
      };
    };
    return { strike, CE: makeSide(pair.CE, 'CE'), PE: makeSide(pair.PE, 'PE') };
  }).filter(row => row.CE && row.PE);
  if (!chainRows.length) throw new Error('Angel One returned no strikes with complete quotes and Greeks.');

  const expirations: OptionExpiryInfo[] = expiryDates.map(([, date], index) => {
    const dte = Math.max(0, Math.ceil((date.getTime() - now) / 86400000));
    const dateStr = date.toISOString().slice(0, 10);
    const nextDate = expiryDates[index + 1]?.[1];
    const isMonthly = !nextDate || nextDate.getUTCMonth() !== date.getUTCMonth() || nextDate.getUTCFullYear() !== date.getUTCFullYear();
    return {
      timestamp: date.getTime(),
      dateStr,
      label: angelExpiryLabel(date, index),
      daysToExpiry: dte,
      isMonthly
    };
  });
  const selectedExpiry = expirations[chosenIndex];
  const response = parseBrokerOptionChain(chainRows, input.symbol, input.name, input.cmp, chosenIndex, 'Angel One SmartAPI', selectedExpiry);
  if (response.sourceState !== 'LIVE' || !response.options.length) throw new Error('Angel One returned no usable live option quotes.');

  const daysToExpiry = selectedExpiry?.daysToExpiry ?? Math.max(0, Math.ceil((expiryDate.getTime() - now) / 86400000));
  response.expirationDates = expirations;
  response.selectedExpiry = selectedExpiry || response.selectedExpiry;
  response.provider = 'Angel One SmartAPI · live quotes';
  response.contractTypeLabel = `${response.instrumentType === 'INDEX' ? 'NSE Index Options' : 'NSE Equity Options'} · ${response.options.length}-strike live window`;
  const actualLotSize = Number(selectedContracts.find(contract => Number(contract.lotsize) > 0)?.lotsize) || response.lotSize;
  response.lotSize = actualLotSize;
  const strikeDiffs = selectedStrikes.slice(1).map((strike, index) => strike - selectedStrikes[index]).filter(value => value > 0);
  const strikeSteps = [...strikeDiffs].sort((a, b) => a - b);
  if (strikeSteps.length) response.strikeInterval = strikeSteps[Math.floor(strikeSteps.length / 2)];
  response.options = response.options.map(row => ({
    ...row,
    call: {
      ...row.call,
      thetaLot: Math.round(row.call.theta * actualLotSize),
      gexCr: Math.round(((row.call.openInterest * actualLotSize * row.call.gamma * response.underlyingPrice ** 2 * 0.01) / 10000000) * 100) / 100,
      buildup: chainRows.find(item => item.strike === row.strike)?.CE?.buildup
    },
    put: {
      ...row.put,
      thetaLot: Math.round(row.put.theta * actualLotSize),
      gexCr: Math.round((-(row.put.openInterest * actualLotSize * row.put.gamma * response.underlyingPrice ** 2 * 0.01) / 10000000) * 100) / 100,
      buildup: chainRows.find(item => item.strike === row.strike)?.PE?.buildup
    }
  }));
  response.options = response.options.map(row => ({
    ...row,
    netGexCr: Math.round((row.call.gexCr + row.put.gexCr) * 100) / 100
  }));
  const totalCallGexCr = response.options.reduce((sum, row) => sum + row.call.gexCr, 0);
  const totalPutGexCr = response.options.reduce((sum, row) => sum + row.put.gexCr, 0);
  const totalNetGexCr = totalCallGexCr + totalPutGexCr;
  const atmRow = response.options.find(row => row.isAtm) || response.options.reduce((best, row) =>
    Math.abs(row.strike - response.underlyingPrice) < Math.abs(best.strike - response.underlyingPrice) ? row : best,
  response.options[0]);
  const atmIv = Math.round(((atmRow.call.impliedVolatility + atmRow.put.impliedVolatility) / 2) * 10) / 10;
  const impliedMovePoints = Math.round(response.underlyingPrice * (atmIv / 100) * Math.sqrt(Math.max(daysToExpiry, 1) / 365) * 10) / 10;
  const maxCallOi = Math.max(...response.options.map(row => row.call.openInterest));
  const maxPutOi = Math.max(...response.options.map(row => row.put.openInterest));
  const maxCallGex = response.options.reduce((best, row) => row.call.gexCr > best.call.gexCr ? row : best, response.options[0]);
  const maxPutGex = response.options.reduce((best, row) => Math.abs(row.put.gexCr) > Math.abs(best.put.gexCr) ? row : best, response.options[0]);
  const maxGammaRow = response.options.reduce((best, row) => row.call.gamma + row.put.gamma > best.call.gamma + best.put.gamma ? row : best, response.options[0]);
  response.gexMetrics = {
    ...response.gexMetrics,
    totalCallGexCr: Math.round(totalCallGexCr * 100) / 100,
    totalPutGexCr: Math.round(totalPutGexCr * 100) / 100,
    totalNetGexCr: Math.round(totalNetGexCr * 100) / 100,
    zeroGammaFlipStrike: null,
    gexRegime: totalNetGexCr >= 0 ? 'POSITIVE_GAMMA' : 'NEGATIVE_GAMMA',
    regimeDescription: totalNetGexCr >= 0
      ? 'Positive net gamma in the displayed strike range.'
      : 'Negative net gamma in the displayed strike range.',
    callGexResistanceStrike: maxCallGex.strike,
    putGexSupportStrike: maxPutGex.strike,
    maxGammaStrike: maxGammaRow.strike
  };
  response.atmIv = atmIv;
  response.maxCallOi = maxCallOi;
  response.maxPutOi = maxPutOi;
  // Historical IV rank/percentile and realized volatility are intentionally unavailable
  // without an observed history; current IV and implied move come from Angel One data.
  response.ivMetrics = {
    ...response.ivMetrics,
    atmIv,
    impliedMovePoints,
    impliedMovePct: response.underlyingPrice > 0 ? Math.round((impliedMovePoints / response.underlyingPrice) * 1000) / 10 : 0,
    volatilityRegime: 'UNAVAILABLE',
    quantStrategyRecommendation: 'Historical IV rank and realized volatility were not supplied; no volatility-pricing strategy recommendation is available.'
  };
  return response;
}

export interface AngelFuturesOiSnapshot {
  available: boolean;
  symbol: string;
  contract?: string;
  expiry?: string;
  price?: number;
  oi?: number;
  oiChange?: number;
  oiChangePct?: number;
  priceChangePct?: number;
  signal: DirectionalFlowSignal;
  capturedAt: number;
}

export async function fetchAngelOneFuturesOi(symbol: string, config: AngelConfig): Promise<AngelFuturesOiSnapshot> {
  if (!config.apiKey) throw new Error('Angel One SmartAPI JWT access token is missing.');
  const headers = authorizationHeaders(config);
  for (const required of ['X-PrivateKey', 'X-UserType', 'X-SourceID', 'X-ClientLocalIP', 'X-ClientPublicIP', 'X-MACAddress']) {
    if (!Object.keys(headers).some(key => key.toLowerCase() === required.toLowerCase())) throw new Error(`Angel One SmartAPI setup is missing the ${required} header.`);
  }
  const normalizedSymbol = normalizeUnderlying(symbol);
  const now = Date.now();
  const contracts = (await getScripMaster()).filter(row =>
    row.exch_seg === 'NFO' && (row.instrumenttype === 'FUTSTK' || row.instrumenttype === 'FUTIDX') &&
    normalizeUnderlying(row.name || '') === normalizedSymbol && angelExpiryDate(row.expiry)?.getTime()! >= now
  ).sort((a, b) => angelExpiryDate(a.expiry)!.getTime() - angelExpiryDate(b.expiry)!.getTime());
  const contract = contracts[0];
  if (!contract) throw new Error(`No active Angel One stock-futures contract is available for ${symbol}.`);
  const response = await fetch(`${SMART_API_ROOT}/market/v1/quote/`, {
    method: 'POST', headers,
    body: JSON.stringify({ mode: 'FULL', exchangeTokens: { NFO: [String(contract.token)] } })
  });
  if (!response.ok) throw new Error(`Angel One futures quote request failed (${response.status}).`);
  const body = await response.json();
  if (!body?.status) throw new Error(body?.message || 'Angel One rejected the stock-futures quote request.');
  const quote = quoteItems(body).find(item => String(item.symbolToken || item.symboltoken || item.token || '') === String(contract.token)) || quoteItems(body)[0];
  const price = positiveNumber(quote?.ltp);
  const oi = positiveNumber(quote?.opnInterest ?? quote?.openInterest ?? quote?.oi);
  if (!price || !oi) throw new Error(`Angel One did not supply price and OI for ${contract.symbol}.`);
  const key = `${normalizedSymbol}:${contract.expiry}:${contract.token}`;
  const previous = previousFuturesSnapshots.get(key);
  previousFuturesSnapshots.set(key, { ltp: price, oi, capturedAt: now });
  const oiChange = previous ? oi - previous.oi : 0;
  const priceChangePct = previous?.ltp ? ((price - previous.ltp) / previous.ltp) * 100 : 0;
  const oiChangePct = previous?.oi ? (oiChange / previous.oi) * 100 : 0;
  const signal = analyzeFuturesOi(priceChangePct, oiChange, oiChangePct);
  return {
    available: signal.available, symbol: normalizedSymbol, contract: contract.symbol, expiry: contract.expiry,
    price, oi, oiChange, oiChangePct, priceChangePct, signal, capturedAt: now
  };
}

export async function fetchAngelOneFuturesOiBatch(symbols: string[], config: AngelConfig): Promise<Record<string, AngelFuturesOiSnapshot>> {
  if (!config.apiKey) throw new Error('Angel One SmartAPI JWT access token is missing.');
  const headers = authorizationHeaders(config);
  for (const required of ['X-PrivateKey', 'X-UserType', 'X-SourceID', 'X-ClientLocalIP', 'X-ClientPublicIP', 'X-MACAddress']) {
    if (!Object.keys(headers).some(key => key.toLowerCase() === required.toLowerCase())) throw new Error(`Angel One SmartAPI setup is missing the ${required} header.`);
  }
  const master = await getScripMaster();
  const now = Date.now();
  const contracts = new Map<string, AngelScrip>();
  for (const inputSymbol of [...new Set(symbols.map(normalizeUnderlying))]) {
    const match = master.filter(row =>
      row.exch_seg === 'NFO' && (row.instrumenttype === 'FUTSTK' || row.instrumenttype === 'FUTIDX') &&
      normalizeUnderlying(row.name || '') === inputSymbol && (angelExpiryDate(row.expiry)?.getTime() || 0) >= now
    ).sort((a, b) => angelExpiryDate(a.expiry)!.getTime() - angelExpiryDate(b.expiry)!.getTime())[0];
    if (match) contracts.set(inputSymbol, match);
  }
  const output: Record<string, AngelFuturesOiSnapshot> = {};
  const entries = [...contracts.entries()];
  for (let offset = 0; offset < entries.length; offset += MAX_QUOTE_TOKENS) {
    const batch = entries.slice(offset, offset + MAX_QUOTE_TOKENS);
    const response = await fetch(`${SMART_API_ROOT}/market/v1/quote/`, {
      method: 'POST', headers,
      body: JSON.stringify({ mode: 'FULL', exchangeTokens: { NFO: batch.map(([, contract]) => String(contract.token)) } })
    });
    if (!response.ok) throw new Error(`Angel One futures batch quote request failed (${response.status}).`);
    const body = await response.json();
    if (!body?.status) throw new Error(body?.message || 'Angel One rejected the futures batch quote request.');
    const items = quoteItems(body);
    for (const [key, contract] of batch) {
      const quote = items.find(item => String(item.symbolToken || item.symboltoken || item.token || '') === String(contract.token));
      const price = positiveNumber(quote?.ltp);
      const oi = positiveNumber(quote?.opnInterest ?? quote?.openInterest ?? quote?.oi);
      if (!price || !oi) continue;
      const snapshotKey = `${key}:${contract.expiry}:${contract.token}`;
      const previous = previousFuturesSnapshots.get(snapshotKey);
      previousFuturesSnapshots.set(snapshotKey, { ltp: price, oi, capturedAt: now });
      const oiChange = previous ? oi - previous.oi : 0;
      const priceChangePct = previous?.ltp ? ((price - previous.ltp) / previous.ltp) * 100 : 0;
      const oiChangePct = previous?.oi ? (oiChange / previous.oi) * 100 : 0;
      const signal = analyzeFuturesOi(priceChangePct, oiChange, oiChangePct);
      output[key] = {
        available: signal.available, symbol: key, contract: contract.symbol, expiry: contract.expiry,
        price, oi, oiChange, oiChangePct, priceChangePct, signal, capturedAt: now
      };
    }
    if (offset + MAX_QUOTE_TOKENS < entries.length) await new Promise(resolve => setTimeout(resolve, 1050));
  }
  return output;
}

export function isAngelOneConfig(config: any): boolean {
  return Boolean(config && (
    /angelone\.in/i.test(config.url || config.customUrl || '') ||
    /angel one|angelone/i.test(config.customApiName || '')
  ));
}

export function simulatedOptionChain(symbol: string, name: string, cmp: number, expiryIndex: number): OptionChainPayload {
  return buildInstitutionalOptionChain(symbol, name, cmp, expiryIndex);
}
