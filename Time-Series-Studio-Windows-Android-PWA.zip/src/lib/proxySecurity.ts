import dns from 'dns';
import { promisify } from 'util';

const lookup = promisify(dns.lookup);

export interface ProxyValidationResult {
  allowed: boolean;
  reason?: string;
  targetUrl?: string;
}

// IP ranges in CIDR to block (SSRF protection)
const BLOCKED_IP_PATTERNS = [
  // IPv4 Loopback
  /^127\./,
  // IPv4 Private Networks (RFC 1918)
  /^10\./,
  /^192\.168\./,
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
  // IPv4 Link-Local (RFC 3927, includes AWS/GCP metadata service 169.254.169.254)
  /^169\.254\./,
  // IPv4 Current Network / Broadcast
  /^0\./,
  /^255\.255\.255\.255/,
  // IPv4 Carrier-Grade NAT (RFC 6598)
  /^100\.(6[4-9]|[7-9][0-9]|1[0-1][0-9]|12[0-7])\./,
  // IPv6 Loopback & Private
  /^::1$/,
  /^fc00:/i,
  /^fd[0-9a-f]{2}:/i,
  /^fe80:/i
];

const BLOCKED_HOSTNAMES = [
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  '::1',
  'metadata.google.internal',
  'metadata.internal',
  'instance-data',
  '169.254.169.254'
];

/**
 * Validates a target URL against SSRF attacks.
 * Verifies protocol is HTTPS (or allowed public HTTP), resolves DNS,
 * and confirms IP is not in any private/reserved CIDR block.
 */
export async function validateProxyUrl(rawUrl: string): Promise<ProxyValidationResult> {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { allowed: false, reason: 'URL must be a non-empty string.' };
  }

  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return { allowed: false, reason: 'Invalid URL format.' };
  }

  // Enforce HTTPS
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { allowed: false, reason: `Disallowed protocol: ${parsed.protocol}. Only https:// and http:// are allowed.` };
  }

  const hostname = parsed.hostname.toLowerCase();

  // Check blocked hostnames
  if (BLOCKED_HOSTNAMES.includes(hostname) || hostname.endsWith('.localhost') || hostname.endsWith('.internal')) {
    return { allowed: false, reason: `Blocked hostname: ${hostname}. Local and internal hostnames are prohibited.` };
  }

  // Placeholder check
  if (
    hostname.includes('api.myserver.com') ||
    hostname.includes('myserver.com') ||
    hostname.includes('example.com') ||
    hostname.includes('your-api-host.com')
  ) {
    return {
      allowed: false,
      reason: 'Placeholder domain detected. Please enter a valid broker/market data endpoint.'
    };
  }

  // Resolve hostname DNS to check IP address
  try {
    const addresses = await lookup(hostname, { all: true });
    if (!addresses || addresses.length === 0) {
      return { allowed: false, reason: `Unable to resolve DNS for ${hostname}.` };
    }

    for (const addr of addresses) {
      const ip = addr.address;
      for (const pattern of BLOCKED_IP_PATTERNS) {
        if (pattern.test(ip)) {
          return {
            allowed: false,
            reason: `Target hostname ${hostname} resolved to a prohibited private/internal IP address (${ip}).`
          };
        }
      }
    }
  } catch (err: any) {
    return { allowed: false, reason: `DNS lookup failed for ${hostname}: ${err.message}` };
  }

  return { allowed: true, targetUrl: parsed.toString() };
}
