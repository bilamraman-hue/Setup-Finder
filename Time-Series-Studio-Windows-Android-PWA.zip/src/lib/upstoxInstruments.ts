/**
 * Upstox Instrument Key Mapping & URL Formatter
 * Upstox API v2 requires instrument keys in format:
 * - Equities: NSE_EQ|INE002A01018
 * - Indices: NSE_INDEX|Nifty 50, NSE_INDEX|Nifty Bank, BSE_INDEX|SENSEX
 * - Commodities: MCX_COMM|GOLD, MCX_COMM|SILVER
 */

export const UPSTOX_INSTRUMENT_MAP: Record<string, string> = {
  // Major Indices
  'NIFTY': 'NSE_INDEX|Nifty 50',
  'NIFTY 50': 'NSE_INDEX|Nifty 50',
  'NIFTY50': 'NSE_INDEX|Nifty 50',
  '^NSEI': 'NSE_INDEX|Nifty 50',
  'BANKNIFTY': 'NSE_INDEX|Nifty Bank',
  'NIFTY BANK': 'NSE_INDEX|Nifty Bank',
  'FINNIFTY': 'NSE_INDEX|Nifty Fin Service',
  'MIDCPNIFTY': 'NSE_INDEX|NIFTY MID SELECT',
  'NIFTY NEXT 50': 'NSE_INDEX|Nifty Next 50',
  'NIFTY IT': 'NSE_INDEX|Nifty IT',
  'SENSEX': 'BSE_INDEX|SENSEX',
  '^BSESN': 'BSE_INDEX|SENSEX',

  // NIFTY 50 & Major Equities (ISIN Codes)
  'RELIANCE': 'NSE_EQ|INE002A01018',
  'TCS': 'NSE_EQ|INE467B01029',
  'HDFCBANK': 'NSE_EQ|INE040A01034',
  'INFY': 'NSE_EQ|INE009A01021',
  'ICICIBANK': 'NSE_EQ|INE090A01021',
  'SBIN': 'NSE_EQ|INE062A01020',
  'BHARTIARTL': 'NSE_EQ|INE397D01024',
  'TATAMOTORS': 'NSE_EQ|INE155A01022',
  'TMPV': 'NSE_EQ|INE155A01022',
  'ITC': 'NSE_EQ|INE154A01025',
  'KOTAKBANK': 'NSE_EQ|INE237A01028',
  'LT': 'NSE_EQ|INE018A01030',
  'AXISBANK': 'NSE_EQ|INE238A01034',
  'MARUTI': 'NSE_EQ|INE585B01010',
  'SUNPHARMA': 'NSE_EQ|INE044A01036',
  'TITAN': 'NSE_EQ|INE280A01028',
  'BAJFINANCE': 'NSE_EQ|INE296A01024',
  'BAJAJFINSV': 'NSE_EQ|INE918I01026',
  'ASIANPAINT': 'NSE_EQ|INE021A01026',
  'WIPRO': 'NSE_EQ|INE075A01022',
  'HCLTECH': 'NSE_EQ|INE860A01027',
  'NTPC': 'NSE_EQ|INE733E01010',
  'POWERGRID': 'NSE_EQ|INE752E01010',
  'TATASTEEL': 'NSE_EQ|INE081A01020',
  'JSWSTEEL': 'NSE_EQ|INE019A01038',
  'COALINDIA': 'NSE_EQ|INE522F01014',
  'ADANIENT': 'NSE_EQ|INE423A01024',
  'ADANIPORTS': 'NSE_EQ|INE742F01042',
  'ULTRACEMCO': 'NSE_EQ|INE481G01011',
  'ONGC': 'NSE_EQ|INE213A01029',
  'NESTLEIND': 'NSE_EQ|INE239A01024',
  'HEROMOTOCO': 'NSE_EQ|INE158A01026',
  'BAJAJ-AUTO': 'NSE_EQ|INE917I01010',
  'EICHERMOT': 'NSE_EQ|INE066A01021',
  'GRASIM': 'NSE_EQ|INE047A01021',
  'HINDUNILVR': 'NSE_EQ|INE030A01027',
  'DIVISLAB': 'NSE_EQ|INE361B01024',
  'CIPLA': 'NSE_EQ|INE059A01026',
  'DRREDDY': 'NSE_EQ|INE089A01023',
  'APOLLOHOSP': 'NSE_EQ|INE437A01024',
  'TECHM': 'NSE_EQ|INE669C01036',
  'BPCL': 'NSE_EQ|INE029A01011',
  'BRITANNIA': 'NSE_EQ|INE216A01030',
  'INDUSINDBK': 'NSE_EQ|INE095A01012',
  'HINDALCO': 'NSE_EQ|INE038A01020',
  'SBILIFE': 'NSE_EQ|INE123W01016',
  'HDFCLIFE': 'NSE_EQ|INE795G01014',
  'BEL': 'NSE_EQ|INE263A01024',
  'HAL': 'NSE_EQ|INE066F01012',
  'TRENT': 'NSE_EQ|INE849A01020',
  'ZOMATO': 'NSE_EQ|INE758T01015',
  'JIOFIN': 'NSE_EQ|INE758E01017',
  'SUZLON': 'NSE_EQ|INE040H01021',
  'SYRMA': 'NSE_EQ|INE0DY501015',
  'VEDL': 'NSE_EQ|INE205A01025',
  'IRFC': 'NSE_EQ|INE053F01010',
  'BHEL': 'NSE_EQ|INE257A01026',
  'IOC': 'NSE_EQ|INE242A01010',
  'GAIL': 'NSE_EQ|INE129A01019',
  'DLF': 'NSE_EQ|INE271C01023',
  'PFC': 'NSE_EQ|INE134E01011',
  'RECLTD': 'NSE_EQ|INE020B01018',
  'MOTHERSON': 'NSE_EQ|INE775A01035',
  'POLYCAB': 'NSE_EQ|INE455K01017',
  'PERSISTENT': 'NSE_EQ|INE262H01013',
  'SIEMENS': 'NSE_EQ|INE003A01024',
  'ABB': 'NSE_EQ|INE117A01022',
  'CHOLAFIN': 'NSE_EQ|INE121A01024',
  'MUTHOOTFIN': 'NSE_EQ|INE414G01012',
  'TVSMOTOR': 'NSE_EQ|INE494B01023',
  'SHREECEM': 'NSE_EQ|INE070A01015',
  'PIDILITIND': 'NSE_EQ|INE318A01026',
  'HAVELLS': 'NSE_EQ|INE176B01034',
  'DABUR': 'NSE_EQ|INE016A01026',
  'GODREJCP': 'NSE_EQ|INE102D01028',
  'BERGEPAINT': 'NSE_EQ|INE463A01038',
  'INDIGO': 'NSE_EQ|INE646L01027',
  'AUROPHARMA': 'NSE_EQ|INE406A01037',
  'LUPIN': 'NSE_EQ|INE326A01037',
  'AMBUJACEM': 'NSE_EQ|INE079A01024',
  'ACC': 'NSE_EQ|INE012A01025',
  'BANKBARODA': 'NSE_EQ|INE028A01039',
  'PNB': 'NSE_EQ|INE160A01022',
  'CANBK': 'NSE_EQ|INE476A01014',
  'UNIONBANK': 'NSE_EQ|INE692A01016',
  'IDFCFIRSTB': 'NSE_EQ|INE092T01019',
  'FEDERALBNK': 'NSE_EQ|INE171A01029',
  'TATACOMM': 'NSE_EQ|INE151A01013',
  'TATACONSUM': 'NSE_EQ|INE192A01025',
  'TATAELXSI': 'NSE_EQ|INE670A01012',
  'VOLTAS': 'NSE_EQ|INE226A01021',
  'COLPAL': 'NSE_EQ|INE259A01022',
  'MARICO': 'NSE_EQ|INE196A01026',
  'SRF': 'NSE_EQ|INE647A01010',
  'CUMMINSIND': 'NSE_EQ|INE298A01020',
  'BOSCHLTD': 'NSE_EQ|INE323A01026',
  'ASHOKLEY': 'NSE_EQ|INE214T01019',
  'BALKRISIND': 'NSE_EQ|INE787D01026',
  'MRF': 'NSE_EQ|INE883A01011',
  'PAGEIND': 'NSE_EQ|INE761H01023',
  'LTIM': 'NSE_EQ|INE214A01026',
  'OFSS': 'NSE_EQ|INE881D01027',
  'MPHASIS': 'NSE_EQ|INE356A01018',
  'COFORGE': 'NSE_EQ|INE591G01017',
  'LTTS': 'NSE_EQ|INE010V01017',
  'KPITTECH': 'NSE_EQ|INE04I401011',
  'TATACHEM': 'NSE_EQ|INE092A01019',
  'DEEPAKNTR': 'NSE_EQ|INE288B01029',
  'PIIND': 'NSE_EQ|INE603J01030',
  'NAVINFLUOR': 'NSE_EQ|INE048G01026',
  'ASTRAL': 'NSE_EQ|INE006I01046',
  'SUPREMEIND': 'NSE_EQ|INE195A01028',
  'DIXON': 'NSE_EQ|INE935N01020',
  'KAYNES': 'NSE_EQ|INE918Z01012',
  'CGPOWER': 'NSE_EQ|INE067A01029',
  'SUNDRMFAST': 'NSE_EQ|INE387A01021',
  'TIINDIA': 'NSE_EQ|INE974X01010',
  'APLAPOLLO': 'NSE_EQ|INE702C01027',
  'HDFCAMC': 'NSE_EQ|INE127D01025',
  'NAM-INDIA': 'NSE_EQ|INE298J01013',
  'BSE': 'NSE_EQ|INE118H01025',
  'CDSL': 'NSE_EQ|INE736A01011',
  'MCX': 'NSE_EQ|INE745G01035',
  'CAMS': 'NSE_EQ|INE596I01012',
  'IEX': 'NSE_EQ|INE022Q01020',
  'KFINTECH': 'NSE_EQ|INE138Y01010',
  'M&M': 'NSE_EQ|INE155A01022',
  'TATAPOWER': 'NSE_EQ|INE245A01021',
  'SWIGGY': 'NSE_EQ|INE00H001014',
  'PAYTM': 'NSE_EQ|INE982J01020',
  'IREDA': 'NSE_EQ|INE202E01016',
  'RVNL': 'NSE_EQ|INE415G01027',
  'NHPC': 'NSE_EQ|INE848E01016',
  'SJVN': 'NSE_EQ|INE002L01015',
  'EXIDEIND': 'NSE_EQ|INE302A01020',
  'AMBER': 'NSE_EQ|INE371P01015',
  'PRESTIGE': 'NSE_EQ|INE411L01011',
  'OBEROIRLTY': 'NSE_EQ|INE893J01029',
  'GODREJPROP': 'NSE_EQ|INE484J01027',
  'PHOENIXLTD': 'NSE_EQ|INE211B01039',
  'MAZDOCK': 'NSE_EQ|INE249Z01012',
  'COCHINSHIP': 'NSE_EQ|INE704P01017',
  'BDL': 'NSE_EQ|INE171Z01018',
  'POLICYBZR': 'NSE_EQ|INE417T01026',
  'NYKAA': 'NSE_EQ|INE388Y01029',
  'DELHIVERY': 'NSE_EQ|INE148O01028',
  'KALYANKJIL': 'NSE_EQ|INE303R01014',
  'KPIL': 'NSE_EQ|INE220B01022'
};

export const POPULAR_COMPANY_ALIASES: Record<string, string> = {
  'TATA MOTORS': 'TATAMOTORS',
  'TATA MOTOR': 'TATAMOTORS',
  'TATAMOTOR': 'TATAMOTORS',
  'TMPV': 'TATAMOTORS',
  'TMCV': 'TATAMOTORS',
  'RELIANCE IND': 'RELIANCE',
  'RELIANCE INDUSTRIES': 'RELIANCE',
  'RIL': 'RELIANCE',
  'TATA CONSULTANCY': 'TCS',
  'TATA CONSULTANCY SERVICES': 'TCS',
  'HDFC BANK': 'HDFCBANK',
  'HDFC': 'HDFCBANK',
  'INFOSYS': 'INFY',
  'STATE BANK OF INDIA': 'SBIN',
  'STATE BANK': 'SBIN',
  'SBI': 'SBIN',
  'ICICI BANK': 'ICICIBANK',
  'ICICI': 'ICICIBANK',
  'BHARTI AIRTEL': 'BHARTIARTL',
  'AIRTEL': 'BHARTIARTL',
  'LARSEN & TOUBRO': 'LT',
  'LARSEN': 'LT',
  'L&T': 'LT',
  'KOTAK MAHINDRA': 'KOTAKBANK',
  'KOTAK BANK': 'KOTAKBANK',
  'KOTAK': 'KOTAKBANK',
  'MARUTI SUZUKI': 'MARUTI',
  'AXIS BANK': 'AXISBANK',
  'AXIS': 'AXISBANK',
  'TATA STEEL': 'TATASTEEL',
  'BAJAJ FINANCE': 'BAJFINANCE',
  'BAJAJ FINSERV': 'BAJAJFINSV',
  'ASIAN PAINTS': 'ASIANPAINT',
  'SUN PHARMA': 'SUNPHARMA',
  'SUN PHARMACEUTICALS': 'SUNPHARMA',
  'HINDUSTAN UNILEVER': 'HINDUNILVR',
  'HUL': 'HINDUNILVR',
  'TATA POWER': 'TATAPOWER',
  'TATA CONSUMER': 'TATACONSUM',
  'NIFTY': 'NIFTY 50',
  'NIFTY50': 'NIFTY 50',
  '^NSEI': 'NIFTY 50',
  'BANK NIFTY': 'BANKNIFTY',
  'NIFTY BANK': 'BANKNIFTY',
  '^NSEBANK': 'BANKNIFTY',
  'FIN NIFTY': 'FINNIFTY',
  'BSE SENSEX': 'SENSEX',
  '^BSESN': 'SENSEX',
  'MCX GOLD': 'GOLD',
  'MCX SILVER': 'SILVER',
  'MCX CRUDE': 'CRUDEOIL',
  'CRUDE OIL': 'CRUDEOIL',
  'NATURAL GAS': 'NATURALGAS'
};

/**
 * Normalizes user queries or symbols into clean canonical tickers.
 * Removes exchange extensions (.NS, .BO) and resolves company names.
 */
export function normalizeSymbol(input: string): string {
  if (!input) return 'RELIANCE';
  let clean = input.trim().toUpperCase()
    .replace(/\.NS$/i, '')
    .replace(/\.BO$/i, '')
    .replace(/^NSE:/i, '')
    .replace(/^BSE:/i, '');

  if (POPULAR_COMPANY_ALIASES[clean]) {
    return POPULAR_COMPANY_ALIASES[clean];
  }

  const noSpaces = clean.replace(/[\s\-_]/g, '');
  if (POPULAR_COMPANY_ALIASES[noSpaces]) {
    return POPULAR_COMPANY_ALIASES[noSpaces];
  }

  return clean;
}

/**
 * Resolves any Indian stock ticker or symbol to a valid Upstox instrument key.
 * If already in format EXCHANGE_SEGMENT|IDENTIFIER, returns as-is.
 */
export function resolveUpstoxInstrumentKey(symbol: string): string {
  const normalized = normalizeSymbol(symbol);
  if (normalized.includes('|')) {
    return normalized;
  }
  if (UPSTOX_INSTRUMENT_MAP[normalized]) {
    return UPSTOX_INSTRUMENT_MAP[normalized];
  }
  const noSpaces = normalized.replace(/[\s\-_]/g, '');
  if (UPSTOX_INSTRUMENT_MAP[noSpaces]) {
    return UPSTOX_INSTRUMENT_MAP[noSpaces];
  }
  // Default format for NSE Equity (ensuring no spaces)
  return `NSE_EQ|${noSpaces}`;
}

/**
 * Intelligently transforms any Upstox URL endpoint, replacing placeholders
 * and guaranteeing valid Upstox v2 format.
 */
export function formatUpstoxEndpoint(
  url: string,
  symbol: string,
  interval: string,
  range: string
): string {
  const instrumentKey = resolveUpstoxInstrumentKey(symbol);
  const now = new Date();
  const toDate = now.toISOString().split('T')[0];

  let daysBack =
    range === '1mo' ? 30 :
    range === '3mo' ? 90 :
    range === '1y' ? 365 :
    range === '2y' ? 730 : 180;

  // Custom horizon per interval to ensure rich candle count for TimesFM
  if (interval === '1wk' || interval === 'week') {
    daysBack = Math.max(730, daysBack); // At least 2 years for weekly candles
  } else if (interval === '15m' || interval === '30m' || interval === '1h' || interval === '1m') {
    daysBack = Math.min(60, Math.max(15, daysBack)); // 15 to 60 days for intraday
  }

  const fromDateObj = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
  const fromDate = fromDateObj.toISOString().split('T')[0];

  // Upstox interval mapping: 1minute, 30minute, day, week, month
  let upstoxInterval = 'day';
  if (interval === '1m' || interval === '1minute') upstoxInterval = '1minute';
  else if (interval === '5m' || interval === '15m' || interval === '30m' || interval === '1h') upstoxInterval = '30minute';
  else if (interval === '1wk' || interval === 'week') upstoxInterval = 'week';
  else if (interval === '1mo' || interval === 'month') upstoxInterval = 'month';
  else upstoxInterval = 'day';

  const encodedKey = encodeURIComponent(instrumentKey);

  // In Upstox API v2, historical-candle with to_date and from_date works for 30minute, day, and week
  if (url.includes('/historical-candle')) {
    return `https://api.upstox.com/v2/historical-candle/${encodedKey}/${upstoxInterval}/${toDate}/${fromDate}`;
  }

  // Generic tag substitution
  return url
    .replace(/\{instrumentKey\}/gi, encodedKey)
    .replace(/\{instrument_key\}/gi, encodedKey)
    .replace(/\{symbol\}/gi, encodedKey)
    .replace(/\{ticker\}/gi, encodedKey)
    .replace(/\{to_date\}/gi, toDate)
    .replace(/\{from_date\}/gi, fromDate)
    .replace(/\{interval\}/gi, upstoxInterval)
    .replace(/\{range\}/gi, fromDate);
}
