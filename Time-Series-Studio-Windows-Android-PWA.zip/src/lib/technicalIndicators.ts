// Advanced Technical Indicators Engine for TimesFM Base Chart
// Computes VWAP, Bollinger Bands, Pivot Points & CPR, Supertrend, Volume MA, and Key Levels

import { TimeSeriesPoint, ForecastPoint } from '../types';

/**
 * Enriches historical time series points with technical covariates
 * (rsi_14, macd_histogram, volume_ratio, bollinger_pct, volatility_atr_pct)
 */
export function enrichTimeSeriesWithIndicators(points: TimeSeriesPoint[]): TimeSeriesPoint[] {
  if (points.length === 0) return [];

  const closes = points.map(p => p.value);
  const validVolumes = points.map(p => Number.isFinite(p.volume) && (p.volume ?? 0) > 0 ? p.volume! : null);

  // Seed each EMA with its period SMA; don't expose MACD before both EMAs and
  // the 9-period signal line are fully initialized.
  const ema = (values: Array<number | undefined>, period: number): Array<number | undefined> => {
    const result: Array<number | undefined> = Array(values.length).fill(undefined);
    const first = values.findIndex(value => value !== undefined);
    if (first < 0 || values.length < first + period) return result;
    let current = 0;
    for (let i = first; i < first + period; i++) current += values[i]!;
    current /= period;
    result[first + period - 1] = current;
    const alpha = 2 / (period + 1);
    for (let i = first + period; i < values.length; i++) {
      if (values[i] === undefined) continue;
      current = values[i]! * alpha + current * (1 - alpha);
      result[i] = current;
    }
    return result;
  };

  const closeValues: Array<number | undefined> = closes;
  const ema12 = ema(closeValues, 12);
  const ema26 = ema(closeValues, 26);
  const macdLine = closes.map((_, i) => ema12[i] !== undefined && ema26[i] !== undefined ? ema12[i]! - ema26[i]! : undefined);
  const macdSignal = ema(macdLine, 9);
  const macdHistogram = macdLine.map((value, i) => value !== undefined && macdSignal[i] !== undefined ? value - macdSignal[i]! : undefined);

  // 1. Calculate RSI 14
  const rsiValues: Array<number | undefined> = [];
  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 0; i < points.length; i++) {
    if (i === 0) {
      rsiValues.push(undefined);
      continue;
    }
    const change = closes[i] - closes[i - 1];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? -change : 0;
    if (i <= 14) {
      avgGain += gain;
      avgLoss += loss;
      if (i === 14) {
        avgGain /= 14;
        avgLoss /= 14;
      }
      rsiValues.push(i < 14 ? undefined : (avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - (100 / (1 + avgGain / avgLoss))));
    } else {
      avgGain = (avgGain * 13 + gain) / 14;
      avgLoss = (avgLoss * 13 + loss) / 14;
      const rsi = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - (100 / (1 + avgGain / avgLoss));
      rsiValues.push(Math.round(rsi * 10) / 10);
    }
  }

  // 2. Volume ratio vs the available, observed volume values only.
  const volRatios: Array<number | undefined> = [];
  for (let i = 0; i < points.length; i++) {
    const start = Math.max(0, i - 19);
    const currentVolume = validVolumes[i];
    if (currentVolume === null) {
      volRatios.push(undefined);
    } else {
      const priorVolumes = validVolumes.slice(start, i).filter((v): v is number => v !== null);
      if (priorVolumes.length === 0) {
        volRatios.push(undefined);
        continue;
      }
      const avgVol = priorVolumes.reduce((a, b) => a + b, 0) / priorVolumes.length;
      volRatios.push(avgVol > 0 ? Math.round((currentVolume / avgVol) * 100) / 100 : undefined);
    }
  }

  // 3. Bollinger %
  const bbPct: number[] = [];
  for (let i = 0; i < points.length; i++) {
    const start = Math.max(0, i - 19);
    const slice = closes.slice(start, i + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
    const std = Math.sqrt(variance) || 1;
    const upper = mean + 2 * std;
    const lower = mean - 2 * std;
    const width = upper - lower;
    const pct = width > 0 ? ((closes[i] - lower) / width) * 100 : 50;
    bbPct.push(Math.round(pct * 1000) / 1000);
  }

  // 4. Wilder ATR as a price percentage. When OHLC is unavailable, close-to-close
  // absolute movement is the only observable range information; no fixed ATR is invented.
  const trueRanges = points.map((point, i) => {
    const high = Number.isFinite(point.high) ? point.high! : point.value;
    const low = Number.isFinite(point.low) ? point.low! : point.value;
    if (i === 0) return Math.max(0, high - low);
    const previousClose = closes[i - 1];
    return Math.max(high - low, Math.abs(high - previousClose), Math.abs(low - previousClose));
  });
  const atrPct: number[] = [];
  let atr = 0;
  for (let i = 0; i < points.length; i++) {
    if (i < 14) {
      atr = (atr * i + trueRanges[i]) / (i + 1);
    } else {
      atr = (atr * 13 + trueRanges[i]) / 14;
    }
    atrPct.push(points[i].value > 0 ? Math.round((atr / points[i].value) * 10000) / 100 : 0);
  }

  // 5. Return enriched points
  return points.map((p, i) => {
    const rsi = rsiValues[i];
    const volRatio = volRatios[i];
    const bPct = bbPct[i] ?? 50;

    const covariates = { ...(p.covariates || {}) };
    delete covariates.rsi_14;
    return {
      ...p,
      covariates: {
        ...covariates,
        ...(rsi === undefined ? {} : { rsi_14: rsi }),
        ...(macdHistogram[i] === undefined ? {} : { macd_histogram: Math.round(macdHistogram[i]! * 10000) / 10000 }),
        ...(volRatio === undefined ? {} : { volume_ratio: volRatio }),
        bollinger_pct: bPct,
        volatility_atr_pct: atrPct[i]
      }
    };
  });
}

export interface CandlePoint {
  index: number;
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  isForecast?: boolean;
  forecastMean?: number;
  forecastP10?: number;
  forecastP25?: number;
  forecastP50?: number;
  forecastP75?: number;
  forecastP90?: number;
  isAnomaly?: boolean;
  anomalySeverity?: 'low' | 'medium' | 'high' | 'critical';
}

export interface BollingerBandPoint {
  upper: number;
  middle: number;
  lower: number;
  bandwidth: number;
  pctB: number;
}

export interface SupertrendPoint {
  supertrend: number;
  direction: 'UP' | 'DOWN'; // UP = Bullish (Green), DOWN = Bearish (Red)
  signal?: 'BUY' | 'SELL';
}

export interface PivotLevels {
  pivot: number; // P = (H + L + C) / 3
  tc: number;    // Top Central Pivot = (P - BC) + P
  bc: number;    // Bottom Central Pivot = (H + L) / 2
  r1: number;    // 2P - L
  r2: number;    // P + (H - L)
  r3: number;    // H + 2*(P - L)
  s1: number;    // 2P - H
  s2: number;    // P - (H - L)
  s3: number;    // L - 2*(H - P)
  dayHigh: number;
  dayLow: number;
  cprWidth: 'NARROW' | 'MEDIUM' | 'WIDE';
  cprTrendBias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
}

export interface KeyLevelsSummary {
  dayHigh: number;
  dayLow: number;
  recentHigh52w: number;
  recentLow52w: number;
  vwapCurrent: number;
  supertrendCurrent: number;
  supertrendStatus: 'BULLISH' | 'BEARISH';
  bollingerUpper: number;
  bollingerLower: number;
  timesFmTargetP90: number;
  timesFmTargetP50: number;
  timesFmFloorP10: number;
}

/**
 * Normalizes input TimeSeriesPoints and ForecastPoints into consistent CandlePoints
 */
export function buildCandleSeries(
  history: TimeSeriesPoint[],
  forecasts: ForecastPoint[] = []
): CandlePoint[] {
  const candles: CandlePoint[] = [];

  let prevClose = history.length > 0 ? (history[0].open || history[0].value) : 100;

  history.forEach((pt, idx) => {
    const close = pt.value;
    const open = pt.open ?? prevClose;
    const high = pt.high ?? Math.max(open, close) * 1.0035;
    const low = pt.low ?? Math.min(open, close) * 0.9965;
    const volume = pt.volume ?? Math.floor(100000 + Math.abs(close * 350) + (idx % 7) * 45000);

    candles.push({
      index: idx,
      timestamp: pt.timestamp,
      open,
      high,
      low,
      close,
      volume,
      isForecast: false,
      isAnomaly: pt.isAnomaly,
      anomalySeverity: pt.anomalySeverity
    });

    prevClose = close;
  });

  // Append forecasts as projection candles
  forecasts.forEach((fc, idx) => {
    const close = fc.p50 ?? fc.mean;
    const open = prevClose;
    const high = Math.max(open, close, fc.p75 ?? close);
    const low = Math.min(open, close, fc.p25 ?? close);
    const volume = Math.floor(120000 + (idx % 5) * 30000);

    candles.push({
      index: history.length + idx,
      timestamp: fc.timestamp,
      open,
      high,
      low,
      close,
      volume,
      isForecast: true,
      forecastMean: fc.mean,
      forecastP10: fc.p10,
      forecastP25: fc.p25,
      forecastP50: fc.p50,
      forecastP75: fc.p75,
      forecastP90: fc.p90
    });

    prevClose = close;
  });

  return candles;
}

/**
 * Calculates VWAP (Volume Weighted Average Price)
 * Cumulative (Typical Price * Volume) / Cumulative Volume
 */
export function calculateVWAP(candles: CandlePoint[]): number[] {
  let cumVolume = 0;
  let cumTypicalVolume = 0;

  const typicalPrices: number[] = [];
  return candles.map((c) => {
    const typicalPrice = (c.high + c.low + c.close) / 3;
    typicalPrices.push(typicalPrice);
    const vol = Number.isFinite(c.volume) && c.volume > 0 ? c.volume : 0;
    cumVolume += vol;
    cumTypicalVolume += typicalPrice * vol;
    return cumVolume > 0
      ? cumTypicalVolume / cumVolume
      : typicalPrices.reduce((sum, price) => sum + price, 0) / typicalPrices.length;
  });
}

/**
 * Calculates Bollinger Bands (20 Period, 2 StdDev)
 */
export function calculateBollingerBands(
  candles: CandlePoint[],
  period: number = 20,
  multiplier: number = 2.0
): (BollingerBandPoint | null)[] {
  const result: (BollingerBandPoint | null)[] = [];

  for (let i = 0; i < candles.length; i++) {
    if (i < period - 1) {
      // Not enough periods for full 20-period BB, calculate partial SMA & bands
      const slice = candles.slice(0, i + 1);
      const avg = slice.reduce((sum, c) => sum + c.close, 0) / slice.length;
      const variance = slice.reduce((sum, c) => sum + Math.pow(c.close - avg, 2), 0) / slice.length;
      const std = Math.sqrt(variance);
      const upper = avg + multiplier * std;
      const lower = avg - multiplier * std;
      const width = upper - lower;
      const pctB = width > 0 ? (candles[i].close - lower) / width : 0.5;
      result.push({
        upper,
        middle: avg,
        lower,
        bandwidth: ((upper - lower) / avg) * 100,
        pctB
      });
      continue;
    }

    const window = candles.slice(i - period + 1, i + 1);
    const mean = window.reduce((acc, c) => acc + c.close, 0) / period;
    const variance = window.reduce((acc, c) => acc + Math.pow(c.close - mean, 2), 0) / period;
    const stdDev = Math.sqrt(variance);

    const upper = mean + multiplier * stdDev;
    const lower = mean - multiplier * stdDev;
    const width = upper - lower;
    const pctB = width > 0 ? (candles[i].close - lower) / width : 0.5;

    result.push({
      upper,
      middle: mean,
      lower,
      bandwidth: ((upper - lower) / mean) * 100,
      pctB
    });
  }

  return result;
}

/**
 * Calculates Pivot Points & CPR (Central Pivot Range) based on latest trading session
 */
export function calculatePivotLevels(candles: CandlePoint[]): PivotLevels {
  if (candles.length === 0) {
    return {
      pivot: 0, tc: 0, bc: 0, r1: 0, r2: 0, r3: 0, s1: 0, s2: 0, s3: 0,
      dayHigh: 0, dayLow: 0, cprWidth: 'MEDIUM', cprTrendBias: 'NEUTRAL'
    };
  }

  // Use recent trading window to calculate representative High, Low, Close
  const historicalOnly = candles.filter(c => !c.isForecast);
  const sample = historicalOnly.slice(-25); // Recent session
  const high = Math.max(...sample.map(c => c.high));
  const low = Math.min(...sample.map(c => c.low));
  const close = sample[sample.length - 1]?.close || candles[0].close;

  const P = (high + low + close) / 3;
  const BC = (high + low) / 2;
  const TC = (P - BC) + P;

  const R1 = (2 * P) - low;
  const R2 = P + (high - low);
  const R3 = high + 2 * (P - low);

  const S1 = (2 * P) - high;
  const S2 = P - (high - low);
  const S3 = low - 2 * (high - P);

  const cprWidthPct = Math.abs(TC - BC) / (P || 1) * 100;
  const cprWidth: 'NARROW' | 'MEDIUM' | 'WIDE' = 
    cprWidthPct < 0.35 ? 'NARROW' : cprWidthPct > 0.85 ? 'WIDE' : 'MEDIUM';

  const cprTrendBias: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 
    close > Math.max(TC, BC) ? 'BULLISH' : close < Math.min(TC, BC) ? 'BEARISH' : 'NEUTRAL';

  return {
    pivot: Number(P.toFixed(2)),
    tc: Number(Math.max(TC, BC).toFixed(2)),
    bc: Number(Math.min(TC, BC).toFixed(2)),
    r1: Number(R1.toFixed(2)),
    r2: Number(R2.toFixed(2)),
    r3: Number(R3.toFixed(2)),
    s1: Number(S1.toFixed(2)),
    s2: Number(S2.toFixed(2)),
    s3: Number(S3.toFixed(2)),
    dayHigh: Number(high.toFixed(2)),
    dayLow: Number(low.toFixed(2)),
    cprWidth,
    cprTrendBias
  };
}

/**
 * Calculates Supertrend Indicator (Period 10, Multiplier 3)
 */
export function calculateSupertrend(
  candles: CandlePoint[],
  period: number = 10,
  multiplier: number = 3.0
): SupertrendPoint[] {
  const result: SupertrendPoint[] = [];

  // Calculate True Range (TR)
  const tr: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i === 0) {
      tr.push(candles[i].high - candles[i].low);
    } else {
      const hMinusL = candles[i].high - candles[i].low;
      const hMinusPc = Math.abs(candles[i].high - candles[i - 1].close);
      const lMinusPc = Math.abs(candles[i].low - candles[i - 1].close);
      tr.push(Math.max(hMinusL, hMinusPc, lMinusPc));
    }
  }

  // Calculate ATR
  const atr: number[] = [];
  let atrSum = 0;
  for (let i = 0; i < candles.length; i++) {
    if (i < period) {
      atrSum += tr[i];
      atr.push(atrSum / (i + 1));
    } else {
      const currentAtr = (atr[i - 1] * (period - 1) + tr[i]) / period;
      atr.push(currentAtr);
    }
  }

  let prevSupertrend = 0;
  let prevDirection: 'UP' | 'DOWN' = 'UP';

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const currentAtr = atr[i] || (c.high - c.low);
    const hl2 = (c.high + c.low) / 2;

    const basicUpper = hl2 + multiplier * currentAtr;
    const basicLower = hl2 - multiplier * currentAtr;

    let finalUpper = basicUpper;
    let finalLower = basicLower;

    if (i > 0) {
      const prevC = candles[i - 1];
      const prevFinalUpper = result[i - 1]?.direction === 'DOWN' ? result[i - 1].supertrend : basicUpper;
      const prevFinalLower = result[i - 1]?.direction === 'UP' ? result[i - 1].supertrend : basicLower;

      if (basicUpper < prevFinalUpper || prevC.close > prevFinalUpper) {
        finalUpper = basicUpper;
      } else {
        finalUpper = prevFinalUpper;
      }

      if (basicLower > prevFinalLower || prevC.close < prevFinalLower) {
        finalLower = basicLower;
      } else {
        finalLower = prevFinalLower;
      }
    }

    let direction: 'UP' | 'DOWN' = prevDirection;
    let supertrend = direction === 'UP' ? finalLower : finalUpper;

    if (i > 0) {
      if (prevDirection === 'UP' && c.close < finalLower) {
        direction = 'DOWN';
        supertrend = finalUpper;
      } else if (prevDirection === 'DOWN' && c.close > finalUpper) {
        direction = 'UP';
        supertrend = finalLower;
      } else {
        direction = prevDirection;
        supertrend = direction === 'UP' ? finalLower : finalUpper;
      }
    } else {
      direction = c.close >= hl2 ? 'UP' : 'DOWN';
      supertrend = direction === 'UP' ? finalLower : finalUpper;
    }

    let signal: 'BUY' | 'SELL' | undefined = undefined;
    if (i > 0 && prevDirection !== direction) {
      signal = direction === 'UP' ? 'BUY' : 'SELL';
    }

    result.push({
      supertrend: Number(supertrend.toFixed(2)),
      direction,
      signal
    });

    prevDirection = direction;
    prevSupertrend = supertrend;
  }

  return result;
}

/**
 * Calculates 20-period Volume Moving Average
 */
export function calculateVolumeSMA(candles: CandlePoint[], period: number = 20): number[] {
  const result: number[] = [];
  for (let i = 0; i < candles.length; i++) {
    const start = Math.max(0, i - period + 1);
    const slice = candles.slice(start, i + 1);
    const sum = slice.reduce((acc, c) => acc + c.volume, 0);
    result.push(Math.round(sum / slice.length));
  }
  return result;
}

/**
 * Adapts candle series to selected timeframe
 * ('1m' | '5m' | '15m' | '1H' | '1D' | '1W' | '1M')
 */
export function resampleCandlesForTimeframe(
  baseCandles: CandlePoint[],
  timeframe: string
): CandlePoint[] {
  if (baseCandles.length === 0) return [];

  let factor = 1;
  switch (timeframe) {
    case '1m': factor = 1; break;
    case '5m': factor = 2; break;
    case '15m': factor = 3; break;
    case '1H': factor = 4; break;
    case '1D': factor = 1; break;
    case '1W': factor = 5; break;
    case '1M': factor = 10; break;
    default: factor = 1;
  }

  if (factor === 1 || baseCandles.length < 15) {
    return baseCandles;
  }

  const resampled: CandlePoint[] = [];
  for (let i = 0; i < baseCandles.length; i += factor) {
    const chunk = baseCandles.slice(i, i + factor);
    if (chunk.length === 0) continue;

    const open = chunk[0].open;
    const close = chunk[chunk.length - 1].close;
    const high = Math.max(...chunk.map(c => c.high));
    const low = Math.min(...chunk.map(c => c.low));
    const volume = chunk.reduce((sum, c) => sum + c.volume, 0);
    const last = chunk[chunk.length - 1];

    resampled.push({
      index: resampled.length,
      timestamp: last.timestamp,
      open,
      high,
      low,
      close,
      volume,
      isForecast: last.isForecast,
      forecastMean: last.forecastMean,
      forecastP10: last.forecastP10,
      forecastP25: last.forecastP25,
      forecastP50: last.forecastP50,
      forecastP75: last.forecastP75,
      forecastP90: last.forecastP90,
      isAnomaly: chunk.some(c => c.isAnomaly),
      anomalySeverity: chunk.find(c => c.anomalySeverity)?.anomalySeverity
    });
  }

  return resampled;
}

/**
 * Calculates Simple Moving Average (SMA)
 */
export function calculateSMA(candles: CandlePoint[], period: number = 20): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < candles.length; i++) {
    if (i < period - 1) {
      const slice = candles.slice(0, i + 1);
      const avg = slice.reduce((sum, c) => sum + c.close, 0) / slice.length;
      result.push(Number(avg.toFixed(2)));
    } else {
      const slice = candles.slice(i - period + 1, i + 1);
      const avg = slice.reduce((sum, c) => sum + c.close, 0) / period;
      result.push(Number(avg.toFixed(2)));
    }
  }
  return result;
}

/**
 * Calculates Exponential Moving Average (EMA)
 */
export function calculateEMA(candles: CandlePoint[], period: number = 20): (number | null)[] {
  const result: (number | null)[] = [];
  const k = 2 / (period + 1);
  let prevEma: number | null = null;

  for (let i = 0; i < candles.length; i++) {
    const close = candles[i].close;
    if (prevEma === null) {
      prevEma = close;
    } else {
      prevEma = close * k + prevEma * (1 - k);
    }
    result.push(Number(prevEma.toFixed(2)));
  }
  return result;
}

/**
 * Calculates Relative Strength Index (RSI - 14)
 */
export function calculateRSI(candles: CandlePoint[], period: number = 14): (number | null)[] {
  const result: (number | null)[] = [];
  if (candles.length === 0) return result;

  let avgGain = 0;
  let avgLoss = 0;

  for (let i = 0; i < candles.length; i++) {
    if (i === 0) {
      result.push(50);
      continue;
    }

    const diff = candles[i].close - candles[i - 1].close;
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? -diff : 0;

    if (i <= period) {
      avgGain += gain / period;
      avgLoss += loss / period;
      if (i === period) {
        const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        const rsi = 100 - (100 / (1 + rs));
        result.push(Number(rsi.toFixed(2)));
      } else {
        result.push(50);
      }
    } else {
      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
      const rsi = 100 - (100 / (1 + rs));
      result.push(Number(rsi.toFixed(2)));
    }
  }
  return result;
}
