// Named Watchlist store. Each independent list is capped at 38 unique symbols.
// Legacy lists are migrated in chunks so older symbols aren't silently discarded.

import { QuantHorizon } from './quantSetupEngine';
import type { VolumeSpikeSignal } from './marketFlowSignals';
import type { MarketFlowSignals } from './marketFlowSignals';
import type { VerdictWeightProfile } from './timeframeVerdictWeights';

export interface WatchlistScanItem {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  cmp: number;
  prevClose?: number;
  changePct?: number;
  volumeSpike?: VolumeSpikeSignal;
  marketFlow?: Partial<MarketFlowSignals>;
  marketFlowAt?: number;
  currentSessionVolume?: number;
  direction: 'LONG' | 'SHORT' | 'NEUTRAL';
  status: 'TRADE NOW' | 'WAIT FOR LEVEL' | 'AVOID';
  scorePct: number;
  // Final Verdict Attributes
  finalVerdict?: 'BUY / ACCUMULATE' | 'SELL / SHORT' | 'CONFLICT — AVOID / WAIT' | 'NEUTRAL CONSOLIDATION';
  setupGrade?: 'GRADE_A_PLUS' | 'GRADE_A' | 'GRADE_B' | 'NO_TRADE';
  gradeBadge?: string;
  confluenceScorePct?: number;
  verdictDirectionalScorePct?: number;
  verdictWeights?: VerdictWeightProfile;
  analysisDataStatus?: string;
  isInEntryZone?: boolean;
  distanceToEntryPct?: number;
  optionsSuggestion?: string;
  // Alert Monitoring
  isAlertActive?: boolean;
  alertTriggered?: boolean;
  alertReason?: string;
  entryRange: {
    min: number;
    max: number;
    text: string;
  };
  stopLoss: {
    price: number;
    pct: number;
  };
  target1: {
    price: number;
    pct: number;
  };
  target2: {
    price: number;
    pct: number;
  };
  riskRewardText: string;
  horizon: QuantHorizon;
  timeframe?: '5m' | '15m' | '1h' | '1d';
  // 1. TimesFM 3.0 Engine Result
  timesfmResult?: {
    trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
    expectedMovePct: number;
    velocity: 'HIGH' | 'MODERATE' | 'STEADY';
    horizonCandles: number;
    confidencePct?: number;
    p10Support: number;
    p50Median: number;
    p90Resistance: number;
    signalSummary: string;
  };
  // 2. Quant Engine Result
  quantEngineResult?: {
    scorePct: number;
    direction: string;
    zScore: number;
    atrValue?: number;
    rsi14: number;
    cprRelation: 'ABOVE_CPR' | 'INSIDE_CPR' | 'BELOW_CPR';
    cprPivot: number;
    cprTop: number;
    cprBottom: number;
    volumeProfilePoc: number;
    volumeProfileVah: number;
    volumeProfileVal: number;
    riskRewardText: string;
    signalSummary: string;
  };
  // 3. SMC / ICT / FVG Result
  smcIctResult?: {
    marketStructure: 'BOS' | 'CHOCH' | 'CONSOLIDATION';
    chochActive: boolean;
    sslSwept: boolean;
    bslSwept: boolean;
    fvgZone: [number, number];
    fvgStatus: 'UNMITIGATED' | '50% MITIGATED' | 'FULLY FILLED';
    bullishOrderBlock: number;
    bearishOrderBlock: number;
    pricingZone: 'DISCOUNT' | 'PREMIUM' | 'EQUILIBRIUM';
    signalSummary: string;
  };
  actionTrigger: string;
  coreDriver: string;
  timestamp: number;
  dateTimeFormatted: string;
  timeOnlyFormatted: string;
  dateOnlyFormatted: string;
  note?: string;
}

export const MAX_WATCHLIST_LIMIT = 38;
const STORAGE_KEY = 'timesfm_watchlist_scan_v2'; // active-list compatibility key
const LISTS_STORAGE_KEY = 'timesfm_watchlists_v1';
const ACTIVE_LIST_KEY = 'timesfm_active_watchlist_v1';

export interface WatchlistDefinition { id: string; name: string; items: WatchlistScanItem[]; updatedAt: number; }

function uniqueAndLimit(items: WatchlistScanItem[]): WatchlistScanItem[] {
  const seen = new Set<string>();
  return items.filter(item => {
    const key = String(item?.symbol || '').trim().toUpperCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, MAX_WATCHLIST_LIMIT);
}

function readDefinitions(): WatchlistDefinition[] {
  try {
    const raw = localStorage.getItem(LISTS_STORAGE_KEY);
    const stored = raw ? JSON.parse(raw) : null;
    if (Array.isArray(stored) && stored.length) {
      const definitions = stored.filter((list: any) => list && typeof list.id === 'string' && typeof list.name === 'string')
        .map((list: any) => ({ ...list, items: uniqueAndLimit(Array.isArray(list.items) ? list.items : []), updatedAt: Number(list.updatedAt) || Date.now() }));
      if (definitions.length) return definitions;
    }
    const legacyRaw = localStorage.getItem(STORAGE_KEY);
    const legacy = legacyRaw ? JSON.parse(legacyRaw) : [];
    const rows: WatchlistScanItem[] = Array.isArray(legacy) ? legacy : [];
    const chunks: WatchlistDefinition[] = [];
    for (let i = 0; i < rows.length; i += MAX_WATCHLIST_LIMIT) {
      const ordinal = chunks.length;
      chunks.push({ id: ordinal === 0 ? 'watchlist_default' : `watchlist_migrated_${ordinal + 1}`, name: ordinal === 0 ? 'My Watchlist' : `Migrated ${ordinal + 1}`, items: uniqueAndLimit(rows.slice(i, i + MAX_WATCHLIST_LIMIT)), updatedAt: Date.now() });
    }
    if (!chunks.length) chunks.push({ id: 'watchlist_default', name: 'My Watchlist', items: [], updatedAt: Date.now() });
    localStorage.setItem(LISTS_STORAGE_KEY, JSON.stringify(chunks));
    if (!localStorage.getItem(ACTIVE_LIST_KEY)) localStorage.setItem(ACTIVE_LIST_KEY, chunks[0].id);
    return chunks;
  } catch (error) {
    console.error('Could not load watchlist definitions:', error);
    return [{ id: 'watchlist_default', name: 'My Watchlist', items: [], updatedAt: Date.now() }];
  }
}

function writeDefinitions(definitions: WatchlistDefinition[]): void {
  const normalized = definitions.map(list => ({ ...list, items: uniqueAndLimit(list.items) }));
  localStorage.setItem(LISTS_STORAGE_KEY, JSON.stringify(normalized));
  const activeId = getActiveWatchlistId();
  const active = normalized.find(list => list.id === activeId) || normalized[0];
  if (active) localStorage.setItem(STORAGE_KEY, JSON.stringify(active.items));
}

export function getWatchlists(): WatchlistDefinition[] { return readDefinitions(); }

export function getActiveWatchlistId(): string {
  const definitions = readDefinitions();
  const savedId = localStorage.getItem(ACTIVE_LIST_KEY);
  const activeId = definitions.some(list => list.id === savedId) ? savedId! : definitions[0].id;
  if (activeId !== savedId) localStorage.setItem(ACTIVE_LIST_KEY, activeId);
  return activeId;
}

export function setActiveWatchlistId(id: string): boolean {
  if (!readDefinitions().some(list => list.id === id)) return false;
  localStorage.setItem(ACTIVE_LIST_KEY, id);
  const list = readDefinitions().find(row => row.id === id)!;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list.items));
  return true;
}

export function createWatchlist(name?: string): WatchlistDefinition {
  const definitions = readDefinitions();
  const id = `watchlist_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const cleanName = String(name || '').trim().slice(0, 32) || `Watchlist ${definitions.length + 1}`;
  const created = { id, name: cleanName, items: [], updatedAt: Date.now() };
  definitions.push(created);
  writeDefinitions(definitions);
  setActiveWatchlistId(id);
  return created;
}

export function renameWatchlist(id: string, name: string): boolean {
  const cleanName = name.trim().slice(0, 32);
  if (!cleanName) return false;
  const definitions = readDefinitions();
  const target = definitions.find(list => list.id === id);
  if (!target) return false;
  target.name = cleanName; target.updatedAt = Date.now(); writeDefinitions(definitions); return true;
}

export function deleteWatchlist(id: string): boolean {
  const definitions = readDefinitions();
  if (definitions.length <= 1 || !definitions.some(list => list.id === id)) return false;
  const wasActive = getActiveWatchlistId() === id;
  const remaining = definitions.filter(list => list.id !== id);
  writeDefinitions(remaining);
  if (wasActive) setActiveWatchlistId(remaining[0].id);
  return true;
}

export function formatDateTime(date: Date = new Date()): {
  full: string;
  dateOnly: string;
  timeOnly: string;
} {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const d = date.getDate().toString().padStart(2, '0');
  const m = months[date.getMonth()];
  const y = date.getFullYear();

  let hours = date.getHours();
  const minutes = date.getMinutes().toString().padStart(2, '0');
  const seconds = date.getSeconds().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const hStr = hours.toString().padStart(2, '0');

  const full = `${d} ${m} ${y}, ${hStr}:${minutes}:${seconds} ${ampm}`;
  const dateOnly = `${d} ${m} ${y}`;
  const timeOnly = `${hStr}:${minutes} ${ampm}`;

  return { full, dateOnly, timeOnly };
}

export function getWatchlistFromStorage(watchlistId: string = getActiveWatchlistId()): WatchlistScanItem[] {
  try {
    return readDefinitions().find(list => list.id === watchlistId)?.items ?? [];
  } catch (err) {
    console.error('Error reading watchlist from storage:', err);
    return [];
  }
}

export function saveWatchlistToStorage(items: WatchlistScanItem[], watchlistId: string = getActiveWatchlistId()): void {
  try {
    const definitions = readDefinitions();
    const target = definitions.find(list => list.id === watchlistId);
    if (!target) return;
    target.items = uniqueAndLimit(items);
    target.updatedAt = Date.now();
    writeDefinitions(definitions);
  } catch (err) {
    console.error('Error saving watchlist to storage:', err);
  }
}

/**
 * Add or update a stock in the Watchlist Scan.
 * If list is already at 100 items, the oldest (last) item is automatically evicted.
 */
export function addOrUpdateWatchlistStock(
  stock: Omit<WatchlistScanItem, 'timestamp' | 'dateTimeFormatted' | 'timeOnlyFormatted' | 'dateOnlyFormatted'>
): {
  watchlist: WatchlistScanItem[];
  evictedStock: WatchlistScanItem | null;
  isUpdate: boolean;
  limitReached: boolean;
} {
  const currentList = getWatchlistFromStorage();
  const now = new Date();
  const { full, dateOnly, timeOnly } = formatDateTime(now);

  const existingIdx = currentList.findIndex(
    item => item.symbol.toUpperCase() === stock.symbol.toUpperCase()
  );

  const fullItem: WatchlistScanItem = {
    ...stock,
    timestamp: now.getTime(),
    dateTimeFormatted: full,
    dateOnlyFormatted: dateOnly,
    timeOnlyFormatted: timeOnly
  };

  let evictedStock: WatchlistScanItem | null = null;
  let updatedList: WatchlistScanItem[] = [];

  if (existingIdx >= 0) {
    // Stock already exists: update and move to the top
    const filtered = currentList.filter((_, idx) => idx !== existingIdx);
    updatedList = [fullItem, ...filtered];
  } else {
    // New stock being added:
    if (currentList.length >= MAX_WATCHLIST_LIMIT) {
      return { watchlist: currentList, evictedStock: null, isUpdate: false, limitReached: true };
    } else {
      updatedList = [fullItem, ...currentList];
    }
  }

  saveWatchlistToStorage(updatedList);

  return {
    watchlist: updatedList,
    evictedStock,
    isUpdate: existingIdx >= 0,
    limitReached: false
  };
}

/**
 * Bulk add or scan stocks into the Watchlist Scan.
 * Maintains the per-list 38-symbol limit and reports the number that did not fit.
 */
export function bulkAddWatchlistStocks(
  stocks: Omit<WatchlistScanItem, 'timestamp' | 'dateTimeFormatted' | 'timeOnlyFormatted' | 'dateOnlyFormatted'>[]
): {
  watchlist: WatchlistScanItem[];
  evictedCount: number;
} {
  const currentList = getWatchlistFromStorage();
  const now = new Date();
  const { full, dateOnly, timeOnly } = formatDateTime(now);

  const bySymbol = new Map<string, typeof stocks[number]>();
  for (const stock of stocks) bySymbol.set(stock.symbol.trim().toUpperCase(), stock);
  const incomingSymbols = new Set(bySymbol.keys());
  const currentBySymbol = new Set(currentList.map(item => item.symbol.trim().toUpperCase()));
  const updatedExisting: WatchlistScanItem[] = [];
  const nowItems: WatchlistScanItem[] = Array.from(bySymbol.values()).map((s, idx) => ({
    ...s,
    timestamp: now.getTime() - idx * 10,
    dateTimeFormatted: full,
    dateOnlyFormatted: dateOnly,
    timeOnlyFormatted: timeOnly
  }));

  for (const item of nowItems) if (currentBySymbol.has(item.symbol.trim().toUpperCase())) updatedExisting.push(item);
  const retained = currentList.filter(item => !incomingSymbols.has(item.symbol.trim().toUpperCase()));
  const newItems = nowItems.filter(item => !currentBySymbol.has(item.symbol.trim().toUpperCase()));
  const room = Math.max(0, MAX_WATCHLIST_LIMIT - updatedExisting.length - retained.length);
  const acceptedNew = newItems.slice(0, room);
  const evictedCount = newItems.length - acceptedNew.length;
  const trimmed = uniqueAndLimit([...updatedExisting, ...retained, ...acceptedNew]);

  saveWatchlistToStorage(trimmed);

  return {
    watchlist: trimmed,
    evictedCount
  };
}

/**
 * Refreshes data ONLY for stocks that are already in the watchlist at that time.
 * Under NO circumstances does it add new stocks.
 */
export function refreshExistingWatchlistStocks(
  updater: (item: WatchlistScanItem) => Partial<WatchlistScanItem>
): WatchlistScanItem[] {
  const currentList = getWatchlistFromStorage();
  if (currentList.length === 0) return [];

  const now = new Date();
  const { full, dateOnly, timeOnly } = formatDateTime(now);

  const updatedList: WatchlistScanItem[] = currentList.map(item => {
    const freshUpdates = updater(item);
    return {
      ...item,
      ...freshUpdates,
      timestamp: now.getTime(),
      dateTimeFormatted: full,
      dateOnlyFormatted: dateOnly,
      timeOnlyFormatted: timeOnly
    };
  });

  saveWatchlistToStorage(updatedList);
  return updatedList;
}

export function removeWatchlistStock(symbol: string): WatchlistScanItem[] {
  const currentList = getWatchlistFromStorage();
  const updated = currentList.filter(item => item.symbol.toUpperCase() !== symbol.toUpperCase());
  saveWatchlistToStorage(updated);
  return updated;
}

export function clearWatchlistStorage(): void {
  try {
    saveWatchlistToStorage([]);
  } catch (err) {
    console.error('Error clearing watchlist:', err);
  }
}
