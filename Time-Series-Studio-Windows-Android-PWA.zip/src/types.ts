export type ModelVersion = 'timesfm-3.0' | 'timesfm-2.5' | 'timesfm-1.0';

export type FrequencyType = 'auto' | 'hourly' | 'daily' | 'weekly' | 'monthly';

export type StrategyHorizon = 'Intraday (1D)' | 'Swing (3-5D)' | 'Positional (1-2M)';

export type BaseTimeframe = '5m' | '15m' | '1h' | '1D';

export type ExecutionMode = 'local_device' | 'server_cloud';

export type MarketProvider = 'yahoo' | 'binance' | 'alphavantage' | 'custom_api' | 'csv_import';

export type DataQualityState = 'LIVE' | 'CACHED' | 'SIMULATED' | 'UNAVAILABLE';

export interface MarketFetchResult {
  symbol: string;
  name: string;
  data: TimeSeriesPoint[];
  covariates: CovariateDefinition[];
  unit: string;
  frequency: 'daily' | 'hourly' | 'weekly';
  source: string;
  sourceState: DataQualityState;
  fetchedAt: string;
  isLiveFeed: boolean;
  statusMessage?: string;
}

export type TradingSignal = 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'SELL' | 'STRONG_SELL';

export interface PositionSizing {
  accountCapital: number;
  riskPerTradePct: number;
  riskCapitalAmount: number;
  riskPerShare: number;
  recommendedQuantity: number;
  totalExposureAmount: number;
  maxAllowedExposure: number;
  leverageRatio: number;
  ruleExplanation: string;
}

export interface CovariateDefinition {
  name: string;
  type: 'numeric' | 'binary' | 'categorical';
  description?: string;
  defaultValue?: number;
  min?: number;
  max?: number;
}

export type NewsSentimentType = 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';

export interface NewsSentiment {
  score: number; // -1.0 (Very Bearish/Negative) to +1.0 (Very Bullish/Positive)
  sentiment: NewsSentimentType;
  headline?: string;
  source?: string;
  category?: 'Earnings' | 'Macro' | 'Product' | 'Analyst' | 'Regulatory' | 'General';
  impactMultiplier?: number;
}

export interface TimeSeriesPoint {
  timestamp: string; // ISO or date string
  value: number; // typically close price
  open?: number;
  high?: number;
  low?: number;
  volume?: number;
  covariates?: Record<string, number>;
  isAnomaly?: boolean;
  anomalyScore?: number;
  anomalySeverity?: 'low' | 'medium' | 'high' | 'critical';
  newsSentiment?: NewsSentiment; // News sentiment score, classification & headline
}

export interface ForecastPoint {
  timestamp: string;
  mean: number;
  p025?: number; // 95% Confidence Cone Lower Bound (Quantile 0.025 / 0.05)
  p10: number;
  p25: number;
  p50: number;
  p75: number;
  p90: number;
  p975?: number; // 95% Confidence Cone Upper Bound (Quantile 0.975 / 0.95)
  covariates?: Record<string, number>;
  actual?: number; // if backtesting
}

export interface ModelConfig {
  model: ModelVersion;
  horizon: number;
  contextLength: number;
  frequency: FrequencyType;
  frequencyToken?: number;
  confidenceLevel: 50 | 80 | 95;
  useCovariates: boolean;
  normalisation: 'revin' | 'standard' | 'minmax';
  patchLength: 16 | 32 | 64;
  anomalyThreshold: number; // e.g. 2.5 z-score
  executionMode?: ExecutionMode;
  strategyHorizon?: StrategyHorizon;
  baseTimeframe?: BaseTimeframe;
}

export interface ForecastMetrics {
  mae: number;
  rmse: number;
  mape: number;
  smape: number;
  coverageRate: number; // % of actuals inside confidence band
  mda?: number; // Mean Directional Accuracy (% of correct up/down predictions)
  sharpeProxy?: number; // Deprecated; only set from an explicitly documented evaluation.
  profitFactor?: number; // Deprecated; only set from completed, costed trades.
}

export interface TradingMetrics {
  signal: TradingSignal;
  projectedReturnPct: number;
  directionalConfidence?: number; // Only present after empirical calibration.
  targetMedianPrice: number;
  supportFloorP10: number;
  resistanceCeilingP90: number;
  valueAtRiskPct: number; // max drawdown risk at p10
  riskRewardRatio: number; // upside (p90 - p50) / downside (p50 - p10)
  rsi14?: number;
  sma20?: number;
  sma50?: number;
  atr14?: number;
}

export interface DecompositionResult {
  timestamps: string[];
  observed: number[];
  trend: number[];
  seasonal: number[];
  residual: number[];
  period: number;
}

export interface AnomalyItem {
  index: number;
  timestamp: string;
  actual: number;
  expected: number;
  score: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  upperBound: number;
  lowerBound: number;
  reason: string;
}

export interface ForecastResult {
  engineName?: string;
  history: TimeSeriesPoint[];
  forecasts: ForecastPoint[];
  metrics?: ForecastMetrics;
  tradingMetrics?: TradingMetrics;
  decomposition?: DecompositionResult;
  anomalies: AnomalyItem[];
  modelConfig: ModelConfig;
  frequencyToken?: number;
  frequencyName?: string;
  executionTimeMs: number;
  isLocalExecution?: boolean;
}

export interface DatasetPreset {
  id: string;
  title: string;
  symbol: string;
  category: 'Equities' | 'Crypto' | 'Indices & ETFs' | 'Commodities' | 'Forex' | 'Indian Equity' | 'Indian Commodity' | 'Indian Index' | 'Indian Stocks & Commodities';
  description: string;
  unit: string;
  frequency: FrequencyType;
  recommendedHorizon: number;
  covariates: CovariateDefinition[];
  data: TimeSeriesPoint[];
  futureCovariates?: Record<string, number>[];
}

export interface AIAnalysisReport {
  summary: string;
  trendAnalysis: string;
  seasonalityAndPatterns: string;
  forecastOutlook: string;
  covariateImpacts: string[];
  riskSignals: string[];
  recommendations: string[];
  tradingRecommendation?: string;
  stockSummaryReport?: StockSummaryReportData;
  timestamp: string;
}

export type TradeActionVerdict = 'TRADE_NOW' | 'WAIT_FOR_DIP' | 'WAIT_FOR_BREAKOUT' | 'AVOID_HIGH_RISK';

export interface EntryLevelGuide {
  idealEntryRange: string; // e.g. "₹2,975.00 – ₹2,995.00"
  idealEntryMin: number;
  idealEntryMax: number;
  aggressiveEntry: number; // CMP / immediate
  conservativePullbackEntry: number; // buy on dip to 20 EMA / support
  breakoutTriggerLevel: number; // buy on breakout above swing high
  entryStrategyText: string;
}

export interface HistoricalDataSpan {
  startDate: string;
  endDate: string;
  durationText: string; // e.g. "2 Years 4 Months (512 Daily Candles)"
  totalCandles: number;
  frequency: string;
  providerName: string;
}

export interface TargetLevel {
  label: string; // e.g. "Target 1 (T1)"
  targetPrice: number;
  returnPct: number; // e.g. +3.4%
  estimatedSteps: number; // e.g. 4
  timeframeText: string; // e.g. "3-5 Trading Days"
  estimatedDate: string; // e.g. "Sep 24, 2026"
  description: string;
  probabilityPct?: number; // Only present when empirically calibrated.
  exitStrategy?: string; // e.g. "Book 50% profit & move Stoploss to Cost price"
}

export interface StrictStoploss {
  stoplossPrice: number;
  riskPct: number; // e.g. -3.5%
  riskAmount: number; // e.g. ₹55.00
  supportBasis: string;
  riskRewardRatio: number;
  trailingRule: string;
  maxCapitalRiskPct: number;
}

export interface StockSummaryReportData {
  symbol: string;
  name: string;
  unit: string;
  currencySymbol: string;
  currentMarketPrice: number;
  previousClose?: number;
  changePct?: number;
  changeAmount?: number;
  direction: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  signal: TradingSignal;
  actionRecommendation: TradeActionVerdict;
  actionBadgeText: string;
  actionReason: string;
  historicalSpan: HistoricalDataSpan;
  entryGuide: EntryLevelGuide;
  targetOne: TargetLevel;
  targetTwo: TargetLevel;
  targetThree: TargetLevel;
  strictStoploss: StrictStoploss;
  forecastHorizonSteps: number;
  frequency: string;
  lastUpdated: string;
  summaryNote: string;
}

export interface ProviderFetchConfig {
  provider: MarketProvider;
  symbol: string;
  range?: string; // e.g. 1mo, 3mo, 6mo, 1y
  interval?: string; // e.g. 1d, 1h, 15m, 1wk
  dataType?: 'live' | 'historical' | 'both';
  apiKey?: string;
  customApiName?: string;
  customUrl?: string;
  customHeaders?: Record<string, string>;
  customPath?: string;
  customMethod?: 'GET' | 'POST';
  customBody?: string;
  customAuthHeader?: string;
  customAuthType?: 'Bearer' | 'ApiKey' | 'Custom';
  customCurrency?: string;
  customDataSample?: string;
  isConnected?: boolean;
  lastTestedAt?: string;
}
