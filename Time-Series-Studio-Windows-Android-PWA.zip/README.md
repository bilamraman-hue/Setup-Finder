﻿# Time Series Studio

A React + Express market-data and time-series analysis PWA. Forecast outputs currently come from a local statistical heuristic; this project does **not** bundle or run Google's pretrained TimesFM model. Forecast bands are approximate and have no measured coverage guarantee.

## Windows development and production

Prerequisites: Node.js 22.12 or later (Node 22 LTS recommended).

1. Extract this ZIP to a folder.
2. Open PowerShell in that folder and run `npm install`.
3. Copy `.env.example` to `.env`. Add `GEMINI_API_KEY` only if using the Gemini-powered AI features. Market-data features may need provider-specific API credentials configured inside the app.
4. Run `npm run dev`, then open `http://localhost:3000`.
5. For a production bundle, run `npm run build`, then `npm start`. The Express server listens on port 3000.

## Install on Windows and Android

The project is an installable Progressive Web App. For a direct Windows localhost launch, use the separate `Time-Series-Studio-Windows-Local.zip` delivery: extract the complete folder and double-click `Time-Series-Studio.exe`. It bundles the Node runtime and starts the Express app on a loopback-only port; leave its console window open while using the app, then press Enter there to stop the server. The launcher opens the default browser, where Edge can install the localhost PWA.

For Android installation:

1. Deploy the production Node server behind an HTTPS URL. Keep the `/api/*` routes on the same origin as the web app. Configure TLS at your hosting provider or reverse proxy.
2. On Windows, open that HTTPS URL in Microsoft Edge and choose **Install this site as an app** from the browser menu/address bar.
3. On Android, open that HTTPS URL in Chrome and choose **Install app** or **Add to Home screen**.

`localhost` is local to each device, so an Android phone cannot use the Windows PC's `127.0.0.1` address as its own server. Android installation requires a reachable HTTPS deployment; browser APIs, data providers and AI endpoints also require connectivity. The service worker caches the built shell/assets, but live market data and API-backed forecasts are not offline features.

## Forecast model status

The in-app `timesfmEngine.ts` is explicitly labeled as a local statistical heuristic. It does not contain TimesFM weights or execute Google's TimesFM architecture. Watchlist drift/interval estimates are statistical calculations, not TimesFM quantiles, and confidence is not calibrated. A true TimesFM-3 backend would require a separately deployed compatible inference service and explicit handling of model-weight licensing and hardware/runtime requirements. No such backend or credentials are part of this ZIP.

Google's TimesFM repository states that the TimesFM-3 pretrained weights are distributed under a separate non-commercial license; review its current terms before deploying weights: https://github.com/google-research/timesfm. The repository's code license does not itself grant rights to the model weights.

## Math and interpretation notes

- Technical indicators require observed data. RSI, ATR, and volume ratios are shown as unavailable if their inputs are missing or insufficient.
- Backtests enter on the next bar after a signal and apply the configured costs/slippage. Same-bar stop/target ambiguity is resolved conservatively as a stop first.
- Option-chain Greeks may be Black-Scholes estimates when the feed does not provide them. IV rank/percentile and historical volatility are unavailable without historical series. Broker feeds must be configured for live data; generated sample chains are labeled simulated.
- These estimates are not investment advice. Validate data-provider entitlements, exchange calendars, instrument metadata, and order fills before relying on any output.

## Watchlist and saved setups

- Create, rename, switch, or delete named watchlists. Each list holds up to **38 unique symbols**; adding a 39th is refused rather than silently evicting a saved symbol. Existing single-list data is migrated in 38-symbol chunks.
- Watchlist scanning computes a timeframe-specific synthetic buildup matrix: 5m MBI, 15m CBS, 1h price-change plus volume Z-score, and >1h PBI. When required history is available, this contributes **15% of final heuristic alignment**; if unavailable, it is excluded from the blend. It remains a **price/volume proxy, not actual open interest** and cannot identify trader positions. Verified broker option-chain/futures OI is kept separate.
- Matching TradingView Pine Script v6 indicator (adjustable thresholds, volume lookbacks, ATR lengths, candle colors, and top-right dashboard): `pine/Multi-Timeframe-Synthetic-Price-Volume-Buildup-Matrix.pine`.
- Final watchlist decisions use explicit timeframe weights (price action / volume / synthetic matrix / live OI): 5m **40/25/15/20**, 15m **45/25/15/15**, 1h **50/20/15/15**, and 1d **55/15/15/15**. If verified live OI is absent, its share is redistributed to price action and volume; OI never gets simulated. Missing evidence is excluded and its weight redistributed. Direction is symmetric: bullish support ≥60/100 gives BUY bias, ≤40/100 gives SELL bias, and 41–59 remains neutral; a trade verdict also needs the existing risk/reward and trap gates. These are transparent heuristic allocations, not empirically proven optimal weights or calibrated probabilities.
- The trap check detects a high-volume wick beyond the prior 20-bar high/low that closes back inside the range. It labels a potential trap, adjusts confluence, and blocks an opposing trade only at a high heuristic risk score (70/100). The score is not a probability; next-bar confirmation is still required.
- The Watchlist timeframe selector fetches and recalculates every symbol on that timeframe. Qualified Grade A+ then Grade A setups sort first; non-qualifying or unavailable rows stay visible at the bottom. A ticker search lets users add a symbol directly to the active list.
- **My Setups → Find Setups** scans every named watchlist sequentially, using 5m → 15m → 1h → 1d within each list. It fetches actual timeframe candles, keeps the strongest qualifying duplicate per symbol/timeframe, shows qualification age, and removes a timeframe only after the full scan finds no qualifying copy in any list. If any relevant fetch is unavailable, its existing setup is retained because it was not evaluated. TTLs: 5m: 2h, 15m: 6h, 1h: 48h, 1d: 120h.
- A setup is saved only when its explicit grade is A/A+, confluence is at least 65%, the verdict and direction agree, and a positive CMP is present. Setups are stored locally per device; running **Find Setups** performs fresh candle requests and does not simulate unavailable data.
- Backtests can use the timeframe-weighted price/volume strategy. Selecting a timeframe fetches that interval's actual candles, applies the corresponding final-verdict weights, and uses bounded lookback profiles (5m: 4,500, 15m: 1,500, 1h: 3,500, 1d: 1,250 bars, capped by available history). Historical OI is never fabricated; the model transparently redistributes its weight when live OI is absent.
- Saved setups are device-local. They do not sync between Windows and Android installations.

## Build scripts

- `npm run dev` — local Express + Vite development server
- `npm run build` — PWA assets and production server bundle
- `npm start` — production Express server
- `npm run lint` — TypeScript check
- `npm test` — project tests
