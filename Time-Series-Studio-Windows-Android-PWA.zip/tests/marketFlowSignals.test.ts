import { describe, expect, it } from 'vitest';
import { analyzeFuturesOi, analyzeOptionChainOi, analyzeVolumeSpike, analyzePriceVolumePressure, detectPriceVolumeTrap, cacheLiveOptionChainSignal, readRecentOptionChainSignal } from '../src/lib/marketFlowSignals';
import type { OptionChainPayload } from '../src/lib/indianOptionsEngine';
import type { TimeSeriesPoint } from '../src/types';
import { computeMultiEngineWatchlistAnalysis } from '../src/lib/watchlistAnalysisEngine';
import { calculateFinalVerdict } from '../src/components/FinalVerdictModal';
import { evaluateQuantSetup } from '../src/lib/quantSetupEngine';

function liveChain(callBuildup?: 'Long Buildup' | 'Short Buildup' | 'Short Covering' | 'Long Unwinding', putBuildup?: 'Long Buildup' | 'Short Buildup' | 'Short Covering' | 'Long Unwinding', oiDelta = 100): OptionChainPayload {
  return {
    sourceState: 'LIVE', isLiveFeed: true, underlyingPrice: 100, options: [{
      strike: 100, isAtm: true,
      call: { changeInOi: oiDelta, buildup: callBuildup },
      put: { changeInOi: oiDelta, buildup: putBuildup }
    }]
  } as unknown as OptionChainPayload;
}

describe('market flow signal math', () => {
  it('uses only live near-ATM premium-confirmed OI changes for option-chain bias', () => {
    expect(analyzeOptionChainOi(liveChain('Long Buildup', 'Long Buildup')).scorePct).toBe(0);
    expect(analyzeOptionChainOi(liveChain('Long Buildup', 'Short Buildup')).direction).toBe('BULLISH');
    expect(analyzeOptionChainOi(liveChain(undefined, undefined, 0)).available).toBe(false);
    const simulated = liveChain('Long Buildup');
    simulated.sourceState = 'SIMULATED';
    simulated.isLiveFeed = false;
    expect(analyzeOptionChainOi(simulated).available).toBe(false);
  });

  it('compares current session volume to preceding bars and requires five observations', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 6 }, (_, index) => ({
      timestamp: String(index), open: 100, value: index === 5 ? 101 : 100,
      volume: index === 5 ? 200 : 100
    }));
    const signal = analyzeVolumeSpike(candles);
    expect(signal.isSpike).toBe(true);
    expect(signal.ratio).toBe(2);
    expect(signal.direction).toBe('BULLISH');
    expect(analyzeVolumeSpike(candles.slice(-5)).available).toBe(true);
    expect(analyzeVolumeSpike(candles.slice(-5)).isSpike).toBe(false);
  });

  it('labels price/volume buildup as a proxy and never as measured OI', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 21 }, (_, index) => ({
      timestamp: String(index), open: 100, high: 101, low: 99, value: 100.5, volume: index === 20 ? 2000 : 1000
    }));
    const signal = analyzePriceVolumePressure(candles);
    expect(signal.classification).toBe('LONG_BUILDUP_PROXY');
    expect(signal.direction).toBe('BULLISH');
    expect(signal.relativeVolume).toBe(2);
    expect(signal.label).toContain('not OI');
  });

  it('flags a high-volume upper-range rejection as a potential bull trap', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 21 }, (_, index) => ({
      timestamp: String(index), open: 100, high: 101, low: 99, value: 100.2, volume: index === 20 ? 2000 : 1000
    }));
    candles[20] = { timestamp: 'last', open: 100.8, high: 102, low: 99.5, value: 99.8, volume: 2000 };
    const signal = detectPriceVolumeTrap(candles);
    expect(signal.kind).toBe('BULL_TRAP');
    expect(signal.direction).toBe('BEARISH');
    expect(signal.scorePct).toBeGreaterThan(0);
  });

  it('flags a lower-range flush with a strong close as a potential bear trap', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 21 }, (_, index) => ({
      timestamp: String(index), open: 100, high: 101, low: 99, value: 100.2, volume: 1000
    }));
    candles[20] = { timestamp: 'last', open: 98.5, high: 100.5, low: 98, value: 100.2, volume: 2000 };
    expect(detectPriceVolumeTrap(candles).kind).toBe('BEAR_TRAP');
    candles[20].volume = 1000;
    expect(detectPriceVolumeTrap(candles).kind).toBe('NONE');
  });

  it('blocks an aligned directional verdict when a high-risk opposing trap is present', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 31 }, (_, i) => {
      const close = 100 + i;
      return { timestamp: String(i), open: close - 0.2, high: close + 0.5, low: close - 0.5, value: close, volume: i === 30 ? 10000 : 1000 };
    });
    candles[30] = { timestamp: 'last', open: 130.5, high: 131, low: 129, value: 128.8, volume: 10000 };
    const quant = evaluateQuantSetup('ABC', 'ABC', candles, 'Intraday (5m/15m)', '₹');
    quant.direction = 'LONG'; // isolate the trap gate from the quant engine's directional classification
    const priceVolumePressure = analyzePriceVolumePressure(candles);
    const trapRisk = detectPriceVolumeTrap(candles);
    expect(trapRisk.kind).toBe('BULL_TRAP');
    const result = calculateFinalVerdict('Intraday (5m/15m)', candles, 'ABC', 'ABC', '₹', {
      direction: 'BULLISH', currentMarketPrice: 128.8
    }, quant, null, {
      volumeSpike: { ...analyzeVolumeSpike(candles), isSpike: false, direction: 'NEUTRAL' }, priceVolumePressure, trapRisk,
      syntheticBuildup: { available: false, timeframe: '15m', formulaLabel: 'test', category: 'UNAVAILABLE', direction: 'NEUTRAL', metric: 0, confidencePct: 0, detail: 'test fixture' }
    });
    expect(result.trapBlocksVerdict).toBe(true);
    expect(result.verdict).toBe('CONFLICT — AVOID / WAIT');
    expect(result.capitalAllocationPct).toBe(0);
  });

  it('classifies futures OI buildup from price and OI changes and ignores baseline snapshots', () => {
    expect(analyzeFuturesOi(0.3, 100, 2).label).toBe('Long buildup');
    expect(analyzeFuturesOi(-0.3, 100, 2).label).toBe('Short buildup');
    expect(analyzeFuturesOi(0.3, -100, -2).label).toBe('Short covering');
    expect(analyzeFuturesOi(0, 0, 0).available).toBe(false);
  });

  it('passes recent verified OI flow into the watchlist verdict and adjusts confluence', () => {
    const candles: TimeSeriesPoint[] = Array.from({ length: 8 }, (_, i) => ({
      timestamp: String(i), value: 100 + i, open: 99 + i, high: 101 + i, low: 98 + i, volume: 1000
    }));
    const base = computeMultiEngineWatchlistAnalysis('ABC', 'ABC Ltd', candles, 'Intraday (5m/15m)', '15m');
    const storedValues = new Map<string, string>();
    Object.defineProperty(globalThis, 'window', { configurable: true, value: {} });
    Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: {
      setItem: (key: string, value: string) => storedValues.set(key, value),
      getItem: (key: string) => storedValues.get(key) || null
    } });
    const signal = { available: true, direction: 'BULLISH' as const, scorePct: 80, label: 'Bullish buildup', detail: 'test' };
    cacheLiveOptionChainSignal('ABC', signal);
    const withFlow = computeMultiEngineWatchlistAnalysis('ABC', 'ABC Ltd', candles, 'Intraday (5m/15m)', '15m');
    expect(withFlow.item.marketFlow?.optionChainOi?.direction).toBe('BULLISH');
    expect(withFlow.finalVerdict.confluenceScorePct).toBeGreaterThan(base.finalVerdict.confluenceScorePct);
    storedValues.set('timesfm_live_option_oi_ABC', JSON.stringify({ signal, savedAt: Date.now() - 6 * 60 * 1000 }));
    expect(readRecentOptionChainSignal('ABC')).toBeUndefined();
    Object.defineProperty(globalThis, 'window', { configurable: true, value: undefined });
    Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: undefined });
  });
});
