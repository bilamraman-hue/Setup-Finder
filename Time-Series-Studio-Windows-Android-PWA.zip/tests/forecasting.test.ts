import { describe, it, expect } from 'vitest';
import { runTimesFmForecast, RevIN, computeStats } from '../src/lib/timesfmEngine';
import { TimeSeriesPoint, ModelConfig } from '../src/types';

describe('TimesFM / Quantitative Forecasting Engine Suite', () => {
  const samplePoints: TimeSeriesPoint[] = Array.from({ length: 60 }, (_, i) => ({
    timestamp: `2026-01-${String(i + 1).padStart(2, '0')}`,
    value: 1000 + Math.sin(i / 5) * 50 + i * 2,
    open: 1000 + i * 2 - 2,
    high: 1000 + i * 2 + 5,
    low: 1000 + i * 2 - 5,
    volume: 150000
  }));

  const sampleConfig: ModelConfig = {
    model: 'timesfm-3.0',
    horizon: 16,
    contextLength: 64,
    frequency: 'daily',
    confidenceLevel: 95,
    useCovariates: false,
    normalisation: 'revin',
    patchLength: 32,
    anomalyThreshold: 2.5
  };

  it('preserves quantile monotonicity: p10 <= p25 <= p50 <= p75 <= p90', () => {
    const result = runTimesFmForecast(samplePoints, sampleConfig);

    expect(result.forecasts.length).toBe(16);
    for (const f of result.forecasts) {
      expect(f.p10).toBeLessThanOrEqual(f.p25);
      expect(f.p25).toBeLessThanOrEqual(f.p50);
      expect(f.p50).toBeLessThanOrEqual(f.p75);
      expect(f.p75).toBeLessThanOrEqual(f.p90);
      // Prices should never be negative for an equity time series
      expect(f.p10).toBeGreaterThan(0);
    }
  });

  it('verifies RevIN Reversible Instance Normalization round-trip accuracy', () => {
    const revin = new RevIN();
    const rawValues = [1200.5, 1215.0, 1198.2, 1240.8, 1235.1];
    const normalized = revin.normalize(rawValues);

    const stats = computeStats(normalized);
    expect(stats.mean).toBeCloseTo(0, 4);
    expect(stats.std).toBeCloseTo(1, 4);

    const reconstructed = revin.denormalize(normalized);
    for (let i = 0; i < rawValues.length; i++) {
      expect(reconstructed[i]).toBeCloseTo(rawValues[i], 4);
    }
  });

  it('truthfully labels engine name and identifies execution metadata', () => {
    const result = runTimesFmForecast(samplePoints, sampleConfig);
    expect(result.engineName).toBeDefined();
    expect(result.engineName).toBe('Local Statistical Heuristic (not Google TimesFM)');
    expect(result.metrics).toBeUndefined();
    expect(result.executionTimeMs).toBeGreaterThanOrEqual(0);
  });
});
