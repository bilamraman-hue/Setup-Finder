import { describe, it, expect, beforeEach } from 'vitest';
import { saveMarketCandlesToDb, getCachedMarketCandles } from '../src/lib/localDatabase';
import { enrichTimeSeriesWithNewsSentiment, NewsSentimentReport } from '../src/lib/newsSentimentEngine';
import { TimeSeriesPoint } from '../src/types';

describe('Market Data Truthfulness & Local SQLite Cache Suite', () => {
  const sampleCandles: TimeSeriesPoint[] = [
    { timestamp: '2026-03-01', open: 1200, high: 1220, low: 1195, value: 1210, volume: 500000 },
    { timestamp: '2026-03-02', open: 1210, high: 1235, low: 1205, value: 1230, volume: 650000 }
  ];

  it('persists and retrieves market candles from local SQLite database', async () => {
    await saveMarketCandlesToDb('TESTSTOCK', '1d', sampleCandles, true);

    const cached = await getCachedMarketCandles('TESTSTOCK', '1d');
    expect(cached).not.toBeNull();
    expect(cached?.data.length).toBe(2);
    expect(cached?.data[0].value).toBe(1210);
    expect(cached?.data[1].value).toBe(1230);
    expect(cached?.isLive).toBe(true);
    expect(cached?.fetchedAt).toBeDefined();
  });

  it('returns null when symbol is not present in local SQLite cache', async () => {
    const cached = await getCachedMarketCandles('NON_EXISTENT_SYMBOL_XYZ', '1d');
    expect(cached).toBeNull();
  });

  it('news enrichment does not fabricate fake headlines when news is unavailable', () => {
    const rawPoints: TimeSeriesPoint[] = [
      { timestamp: '2026-03-01', value: 100 },
      { timestamp: '2026-03-02', value: 105 }
    ];

    const enriched = enrichTimeSeriesWithNewsSentiment(rawPoints, 'TCS', null);
    expect(enriched.length).toBe(2);
    // News sentiment must be undefined when no verified live report exists
    expect(enriched[0].newsSentiment).toBeUndefined();
    expect(enriched[1].newsSentiment).toBeUndefined();
  });

  it('attaches verified search-grounded news when live report is provided', () => {
    const rawPoints: TimeSeriesPoint[] = [
      { timestamp: '2026-03-01', value: 100 },
      { timestamp: '2026-03-02', value: 105 }
    ];

    const verifiedReport: NewsSentimentReport = {
      symbol: 'TCS',
      name: 'Tata Consultancy Services',
      overallSentiment: 'BULLISH',
      sentimentScore: 65,
      sentimentConfidence: 'HIGH',
      scoreImpactPct: 5,
      sentimentSummary: 'Strong quarterly order book expansions reported.',
      headlines: [
        {
          title: 'TCS signs $1B multi-year cloud transformation contract',
          source: 'Live Economic Times',
          sentiment: 'POSITIVE',
          impact: 'HIGH',
          timeAgo: '2h ago',
          snippet: 'Major European banking mandate awarded.',
          url: 'https://economictimes.indiatimes.com/tech'
        }
      ],
      keyBullishFactors: ['Order wins'],
      keyBearishRisks: ['Currency risk'],
      timestamp: new Date().toISOString(),
      isLiveNews: true,
      statusLabel: 'LIVE_SEARCH_GROUNDED'
    };

    const enriched = enrichTimeSeriesWithNewsSentiment(rawPoints, 'TCS', verifiedReport);
    expect(enriched[1].newsSentiment).toBeDefined();
    expect(enriched[1].newsSentiment?.headline).toContain('cloud transformation');
    expect(enriched[1].newsSentiment?.source).toBe('Live Economic Times');
  });
});
