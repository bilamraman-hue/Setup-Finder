import { describe, expect, it } from 'vitest';
import { hasSufficientWatchlistHistory, MIN_WATCHLIST_CANDLES } from '../src/lib/watchlistAnalysisEngine';

describe('Find Setups history sufficiency', () => {
  it('uses the complete baseline length required by each price/volume formula', () => {
    expect(MIN_WATCHLIST_CANDLES).toEqual({ '5m': 10, '15m': 21, '1h': 50, '1d': 21 });
    for (const [timeframe, minimum] of Object.entries(MIN_WATCHLIST_CANDLES) as Array<[keyof typeof MIN_WATCHLIST_CANDLES, number]>) {
      expect(hasSufficientWatchlistHistory(timeframe, minimum - 1)).toBe(false);
      expect(hasSufficientWatchlistHistory(timeframe, minimum)).toBe(true);
    }
  });

  it('rejects invalid counts rather than treating them as sufficient evidence', () => {
    expect(hasSufficientWatchlistHistory('1h', Number.NaN)).toBe(false);
    expect(hasSufficientWatchlistHistory('1h', -1)).toBe(false);
  });
});
