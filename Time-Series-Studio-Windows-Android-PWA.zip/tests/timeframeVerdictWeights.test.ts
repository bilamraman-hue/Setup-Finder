import { describe, expect, it } from 'vitest';
import { calculateTimeframeWeightedVerdict, TIMEFRAME_VERDICT_WEIGHT_PROFILES } from '../src/lib/timeframeVerdictWeights';
import type { SyntheticBuildupSignal } from '../src/lib/syntheticBuildupMatrix';
import { calculateFinalVerdict } from '../src/components/FinalVerdictModal';
import { evaluateQuantSetup } from '../src/lib/quantSetupEngine';
import type { TimeSeriesPoint } from '../src/types';

const matrix = (direction: SyntheticBuildupSignal['direction']): SyntheticBuildupSignal => ({
  available: true, timeframe: '15m', formulaLabel: 'test', category: direction === 'BULLISH' ? 'LONG_BUILDUP' : direction === 'BEARISH' ? 'SHORT_BUILDUP' : 'NEUTRAL', direction, metric: 2, confidencePct: 100, detail: 'test'
});

describe('timeframe-specific final verdict weights', () => {
  it('uses progressively slower timeframe allocations and keeps the live matrix at 15%', () => {
    expect(TIMEFRAME_VERDICT_WEIGHT_PROFILES['5m']).toEqual({ priceAction: 40, volume: 25, syntheticMatrix: 15, liveOi: 20 });
    for (const timeframe of ['5m', '15m', '1h', '1d'] as const) {
      const result = calculateTimeframeWeightedVerdict({
        timeframe, priceActionSigned: 0, volumeAvailable: true, volumeDirection: 'NEUTRAL', volumeStrengthPct: 0,
        syntheticBuildup: matrix('NEUTRAL'), liveOiSignals: []
      });
      expect(result.weights.syntheticMatrix).toBe(15);
      expect(result.weights.liveOi).toBe(0);
      expect(result.weights.priceAction + result.weights.volume + result.weights.syntheticMatrix).toBeCloseTo(100, 0);
    }
  });

  it('produces symmetric bullish, bearish, and neutral outcomes', () => {
    const make = (side: 'BULLISH' | 'BEARISH' | 'NEUTRAL') => calculateTimeframeWeightedVerdict({
      timeframe: '15m', priceActionSigned: side === 'BULLISH' ? 100 : side === 'BEARISH' ? -100 : 0,
      volumeAvailable: true, volumeDirection: side, volumeStrengthPct: side === 'NEUTRAL' ? 0 : 100,
      syntheticBuildup: matrix(side), liveOiSignals: []
    });
    const bull = make('BULLISH'), bear = make('BEARISH'), neutral = make('NEUTRAL');
    expect(bull.direction).toBe('BULLISH');
    expect(bear.direction).toBe('BEARISH');
    expect(bull.directionalScorePct + bear.directionalScorePct).toBe(100);
    expect(neutral.direction).toBe('NEUTRAL');
    expect(neutral.directionalScorePct).toBe(50);
  });

  it('excludes unavailable OI and includes only available live OI signals', () => {
    const base = { timeframe: '5m' as const, priceActionSigned: 0, volumeAvailable: true, volumeDirection: 'NEUTRAL' as const, volumeStrengthPct: 0, syntheticBuildup: matrix('NEUTRAL') };
    const noOi = calculateTimeframeWeightedVerdict({ ...base, liveOiSignals: [{ available: false, scorePct: 100 }] });
    const liveOi = calculateTimeframeWeightedVerdict({ ...base, liveOiSignals: [{ available: true, scorePct: 100 }] });
    expect(noOi.weights.liveOi).toBe(0);
    expect(liveOi.weights.liveOi).toBe(20);
    expect(liveOi.direction).toBe('BULLISH');
  });

  it('returns symmetric BUY, SELL, and neutral final verdicts from the weighted signal', () => {
    const build = (isUp: boolean): TimeSeriesPoint[] => Array.from({ length: 30 }, (_, i) => {
      const close = isUp ? 100 + i : 130 - i;
      return { timestamp: String(i), open: close - (isUp ? 0.2 : -0.2), high: close + 0.5, low: close - 0.5, value: close, volume: 1000 };
    });
    const run = (forecast: 'BULLISH' | 'BEARISH', technical: 'LONG' | 'SHORT', score: number, history: TimeSeriesPoint[]) => {
      const quant = evaluateQuantSetup('ABC', 'ABC', history, 'Intraday (5m/15m)', '₹');
      quant.direction = technical;
      quant.scorePct = score;
      quant.riskRewardRatio = 2;
      return calculateFinalVerdict('Intraday (5m/15m)', history, 'ABC', 'ABC', '₹', {
        direction: forecast, currentMarketPrice: history.at(-1)!.value
      }, quant, null, {
        volumeSpike: { available: true, isSpike: false, currentVolume: 1000, averageVolume: 1000, ratio: 1, direction: 'NEUTRAL', detail: 'No spike', sampleSize: 20 },
        syntheticBuildup: { ...matrix('NEUTRAL'), timeframe: '15m' },
        trapRisk: { available: true, kind: 'NONE', direction: 'NEUTRAL', scorePct: 0, relativeVolume: 1, label: 'No trap', detail: 'No trap' }
      });
    };
    const bull = run('BULLISH', 'LONG', 90, build(true));
    const bear = run('BEARISH', 'SHORT', 90, build(false));
    const neutral = run('BULLISH', 'SHORT', 40, build(false));
    expect(bull.verdict).toBe('BUY / ACCUMULATE');
    expect(bear.verdict).toBe('SELL / SHORT');
    expect(bull.directionalScorePct + bear.directionalScorePct).toBe(100);
    expect(neutral.verdict).toBe('NEUTRAL CONSOLIDATION');
    expect(neutral.capitalAllocationPct).toBe(0);
  });
});
