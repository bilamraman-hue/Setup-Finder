import { describe, it, expect } from 'vitest';
import {
  computeBlackScholes,
  buildInstitutionalOptionChain,
  parseBrokerOptionChain
} from '../src/lib/indianOptionsEngine';

describe('Institutional Options Engine Suite', () => {
  it('Black-Scholes call and put Greeks conform to mathematical boundaries', () => {
    const spot = 24500;
    const strike = 24500;
    const daysToExpiry = 7;
    const riskFreeRate = 0.065;
    const iv = 0.14;

    const greeks = computeBlackScholes(spot, strike, daysToExpiry, riskFreeRate, iv);

    // Call delta between 0 and 1
    expect(greeks.callDelta).toBeGreaterThanOrEqual(0);
    expect(greeks.callDelta).toBeLessThanOrEqual(1);

    // Put delta between -1 and 0
    expect(greeks.putDelta).toBeGreaterThanOrEqual(-1);
    expect(greeks.putDelta).toBeLessThanOrEqual(0);

    // Delta difference between call and put is approximately 1
    expect(greeks.callDelta - greeks.putDelta).toBeCloseTo(1, 2);

    // Gamma and Vega are positive
    expect(greeks.gamma).toBeGreaterThan(0);
    expect(greeks.vega).toBeGreaterThan(0);

    // Option prices are strictly positive
    expect(greeks.callPrice).toBeGreaterThan(0);
    expect(greeks.putPrice).toBeGreaterThan(0);
  });

  it('correctly sets sourceState to SIMULATED for spot-calibrated BSM model', () => {
    const chain = buildInstitutionalOptionChain('NIFTY', 'NIFTY 50 Index', 24500);

    expect(chain.sourceState).toBe('SIMULATED');
    expect(chain.isLiveFeed).toBe(false);
    expect(chain.provider).toContain('Black-Scholes');
    expect(chain.options.length).toBeGreaterThan(10);
  });

  it('correctly sets sourceState to LIVE when parsed from real broker data', () => {
    const mockBrokerData = {
      status: 'success',
      data: [
        {
          strike_price: 1260,
          call_options: {
            market_data: { ltp: 28.5, oi: 12000, volume: 4500, bid_price: 28.3, ask_price: 28.7 },
            option_greeks: { delta: 0.52, iv: 22.4 }
          },
          put_options: {
            market_data: { ltp: 22.0, oi: 9500, volume: 3800, bid_price: 21.8, ask_price: 22.2 },
            option_greeks: { delta: -0.48, iv: 23.1 }
          }
        },
        {
          strike_price: 1280,
          call_options: {
            market_data: { ltp: 18.2, oi: 15000, volume: 6200, bid_price: 18.0, ask_price: 18.4 },
            option_greeks: { delta: 0.38, iv: 21.8 }
          },
          put_options: {
            market_data: { ltp: 31.5, oi: 6000, volume: 2100, bid_price: 31.2, ask_price: 31.8 },
            option_greeks: { delta: -0.62, iv: 23.8 }
          }
        }
      ]
    };

    const parsed = parseBrokerOptionChain(mockBrokerData, 'RELIANCE', 'Reliance Industries', 1260, 0, 'AngelOne');
    expect(parsed.sourceState).toBe('LIVE');
    expect(parsed.isLiveFeed).toBe(true);
    expect(parsed.provider).toContain('Real Broker Feed');
  });
});
