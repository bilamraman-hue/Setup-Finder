import { describe, it, expect } from 'vitest';
import { runBacktestSimulation, BacktestSignal, BACKTEST_LOOKBACK_BARS } from '../src/lib/backtestEngine';
import { TimeSeriesPoint } from '../src/types';

describe('Backtesting Engine Integrity & Math Verification Suite', () => {
  it('should handle empty or insufficient datasets without fabricating fake statistics', () => {
    const emptyPoints: TimeSeriesPoint[] = [];
    const result = runBacktestSimulation(emptyPoints, 'TEST', 60);

    expect(result.totalSignals).toBe(0);
    expect(result.wins).toBe(0);
    expect(result.losses).toBe(0);
    expect(result.winRatePct).toBe(0);
    expect(result.profitFactor).toBe(0);
    expect(result.sharpeRatio).toBe(0);
    expect(result.sortinoRatio).toBe(0);
    expect(result.isSampleSufficient).toBe(false);
  });

  it('should calculate win rate strictly from completed trades', () => {
    // Generate 30 monotonic upward points where momentum triggers
    const points: TimeSeriesPoint[] = [];
    let price = 100;
    for (let i = 0; i < 35; i++) {
      price += 1.5;
      points.push({
        timestamp: `2026-01-${String(i + 1).padStart(2, '0')}`,
        value: price,
        high: price + 1,
        low: price - 0.5,
        covariates: { rsi_14: 55, volume_ratio: 1.2 }
      });
    }

    const result = runBacktestSimulation(points, 'UP_TREND', 35);
    if (result.totalSignals > 0) {
      const calculatedWinRate = (result.wins / (result.wins + result.losses)) * 100;
      expect(result.winRatePct).toBeCloseTo(calculatedWinRate, 1);
      // Net profit must reflect actual completed trade PnL
      const sumPnl = result.signals.filter(s => s.outcome !== 'ACTIVE').reduce((acc, s) => acc + s.pnlAmount, 0);
      expect(result.netProfitAmount).toBeCloseTo(sumPnl, 1);
    }
  });

  it('should deduct transaction costs and slippage from trade outcomes', () => {
    const points: TimeSeriesPoint[] = [];
    let p = 500;
    for (let i = 0; i < 30; i++) {
      p += (i % 2 === 0 ? 3 : -1);
      points.push({
        timestamp: `2026-02-${String(i + 1).padStart(2, '0')}`,
        value: p,
        high: p + 2,
        low: p - 2,
        covariates: { rsi_14: 52, volume_ratio: 1.1 }
      });
    }

    const result = runBacktestSimulation(points, 'FEES_TEST', {
      lookbackBars: 30,
      feePctPerTrade: 0.05, // 0.05% brokerage/STT
      slippagePct: 0.02
    });

    if (result.signals.length > 0) {
      for (const sig of result.signals) {
        expect(sig.feesPaid).toBeGreaterThan(0);
        // Net return should be less than gross return due to fees and slippage
        expect(sig.netReturnPct).toBeLessThan(sig.grossReturnPct);
      }
    }
  });

  it('strictly prevents look-ahead bias: signals use past data, execution starts on bar i+1', () => {
    const points: TimeSeriesPoint[] = [];
    for (let i = 0; i < 40; i++) {
      points.push({
        timestamp: `2026-03-${String(i + 1).padStart(2, '0')}`,
        value: 200 + i * 2,
        high: 202 + i * 2,
        low: 199 + i * 2,
        covariates: { rsi_14: 50, volume_ratio: 1.0 }
      });
    }

    const result = runBacktestSimulation(points, 'LOOKAHEAD_TEST', 40);
    for (const sig of result.signals) {
      // Index of signal must be at least 5 bars in, and barsHeld must be >= 1
      expect(sig.index).toBeGreaterThanOrEqual(5);
      expect(sig.barsHeld).toBeGreaterThanOrEqual(1);
    }
  });

  it('runs the timeframe-weighted price/volume strategy with timeframe-specific lookback and without historical OI', () => {
    const points: TimeSeriesPoint[] = [];
    let price = 100;
    for (let i = 0; i < 160; i++) {
      const open = price;
      price += 0.8;
      points.push({ timestamp: new Date(Date.UTC(2026, 0, 1 + i)).toISOString(), open, value: price, high: price + 0.25, low: open - 0.25, volume: 1000 + i * 2 });
    }
    const result = runBacktestSimulation(points, 'WEIGHTED_TEST', { timeframe: '15m', strategy: 'timeframe_weighted_setup' });
    expect(BACKTEST_LOOKBACK_BARS['5m']).toBe(4500);
    expect(BACKTEST_LOOKBACK_BARS['5m']).toBe(4500);
    expect(BACKTEST_LOOKBACK_BARS['15m']).toBeGreaterThan(BACKTEST_LOOKBACK_BARS['1d']);
    expect(result.timeframe).toBe('15m');
    expect(result.lookbackBars).toBe(points.length);
    expect(result.strategyName).toContain('Timeframe Weighted');
    expect(result.signals.length).toBeGreaterThan(0);
    expect(result.signals.every(signal => signal.reason.includes('no historical OI used'))).toBe(true);
  });
});
