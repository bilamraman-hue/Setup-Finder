import { describe, it, expect, beforeEach } from 'vitest';
import {
  getPaperPortfolio,
  openVirtualTrade,
  updatePositionPrices,
  closeVirtualTrade,
  resetPaperPortfolio
} from '../src/lib/paperTradingStore';

describe('Paper Trading & Portfolio Ledger Suite', () => {
  beforeEach(() => {
    resetPaperPortfolio();
  });

  it('deducts trade capital and charges transaction fee on order entry', () => {
    const initialPortfolio = getPaperPortfolio();
    expect(initialPortfolio.virtualCash).toBe(1000000);

    const position = openVirtualTrade({
      symbol: 'RELIANCE',
      name: 'Reliance Industries',
      direction: 'LONG',
      entryPrice: 1250,
      quantity: 100, // 1,25,000 turnover
      stopLoss: 1200,
      target1: 1300,
      target2: 1350,
      score: 80
    });

    expect(position).not.toBeNull();
    const updated = getPaperPortfolio();
    expect(updated.positions.length).toBe(1);

    // Turnover = 125,000, 0.03% fee = 37.5
    expect(updated.totalFeesPaid).toBeCloseTo(37.5, 1);
    expect(updated.virtualCash).toBeLessThan(1000000 - 125000);
  });

  it('triggers target hit and realizes net profit on favorable price movement', () => {
    openVirtualTrade({
      symbol: 'TCS',
      name: 'TCS Ltd',
      direction: 'LONG',
      entryPrice: 3900,
      quantity: 10,
      stopLoss: 3800,
      target1: 4000,
      target2: 4100,
      score: 75
    });

    // Price hits target 2
    const updated = updatePositionPrices({ TCS: 4150 });
    expect(updated.positions.length).toBe(0);
    expect(updated.closedTrades.length).toBe(1);
    expect(updated.closedTrades[0].status).toBe('TARGET2_HIT');
    expect(updated.realizedPnl).toBeGreaterThan(0);
  });

  it('triggers stop loss and realizes loss on adverse movement', () => {
    openVirtualTrade({
      symbol: 'INFY',
      name: 'Infosys',
      direction: 'LONG',
      entryPrice: 1800,
      quantity: 20,
      stopLoss: 1750,
      target1: 1850,
      target2: 1900,
      score: 65
    });

    // Price breaches stop loss
    const updated = updatePositionPrices({ INFY: 1740 });
    expect(updated.positions.length).toBe(0);
    expect(updated.closedTrades.length).toBe(1);
    expect(updated.closedTrades[0].status).toBe('STOPPED_OUT');
    expect(updated.realizedPnl).toBeLessThan(0);
  });
});
