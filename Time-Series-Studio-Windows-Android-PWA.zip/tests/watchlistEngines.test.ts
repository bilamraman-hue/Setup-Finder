import { describe, it, expect } from 'vitest';
import { computeMultiEngineWatchlistAnalysis } from '../src/lib/watchlistAnalysisEngine';
import { TimeSeriesPoint } from '../src/types';

describe('Watchlist Multi-Engine Mathematical Verification Suite', () => {
  const sampleCandles: TimeSeriesPoint[] = [
    { timestamp: '2026-10-01 09:15', open: 1000, high: 1010, low: 995, value: 1008, volume: 15000 },
    { timestamp: '2026-10-01 09:30', open: 1008, high: 1020, low: 1005, value: 1018, volume: 22000 },
    { timestamp: '2026-10-01 09:45', open: 1018, high: 1025, low: 1012, value: 1015, volume: 18000 },
    { timestamp: '2026-10-01 10:00', open: 1015, high: 1030, low: 1014, value: 1028, volume: 30000 },
    { timestamp: '2026-10-01 10:15', open: 1028, high: 1035, low: 1022, value: 1032, volume: 25000 },
    { timestamp: '2026-10-01 10:30', open: 1032, high: 1042, low: 1029, value: 1038, volume: 28000 },
    { timestamp: '2026-10-01 10:45', open: 1038, high: 1045, low: 1035, value: 1044, volume: 32000 },
    { timestamp: '2026-10-01 11:00', open: 1044, high: 1055, low: 1040, value: 1050, volume: 35000 }
  ];

  it('computes local log-return drift and an uncalibrated horizon-scaled interval', () => {
    const analysis = computeMultiEngineWatchlistAnalysis(
      'RELIANCE',
      'Reliance Industries',
      sampleCandles,
      'Intraday (5m/15m)',
      '15m',
      '₹'
    );

    const tfm = analysis.timesfmResult;
    expect(tfm).toBeDefined();
    expect(['BULLISH', 'BEARISH', 'SIDEWAYS']).toContain(tfm.trend);
    expect(tfm.p10Support).toBeLessThan(tfm.p50Median);
    expect(tfm.p50Median).toBeLessThan(tfm.p90Resistance);
    expect(tfm.confidencePct).toBeUndefined();
    expect(tfm.horizonCandles).toBe(8);
  });

  it('computes authentic Quant Engine CPR, RSI, and Volume Profile POC levels', () => {
    const analysis = computeMultiEngineWatchlistAnalysis(
      'TCS',
      'Tata Consultancy Services',
      sampleCandles,
      'Swing (3–4 Days)',
      '1d',
      '₹'
    );

    const quant = analysis.quantEngineResult;
    expect(quant).toBeDefined();
    expect(['ABOVE_CPR', 'INSIDE_CPR', 'BELOW_CPR']).toContain(quant.cprRelation);
    expect(quant.cprPivot).toBeGreaterThan(0);
    expect(quant.rsi14).toBeGreaterThan(0);
    expect(quant.volumeProfilePoc).toBeGreaterThan(0);
    expect(quant.scorePct).toBeGreaterThanOrEqual(0);
    expect(quant.scorePct).toBeLessThanOrEqual(100);
  });

  it('computes SMC / ICT order blocks, Fair Value Gaps, and discount/premium pricing zones', () => {
    const analysis = computeMultiEngineWatchlistAnalysis(
      'DIXON',
      'Dixon Tech',
      sampleCandles,
      'Swing (3–4 Days)',
      '1h',
      '₹'
    );

    const smc = analysis.smcIctResult;
    expect(smc).toBeDefined();
    expect(['BOS', 'CHOCH', 'CONSOLIDATION']).toContain(smc.marketStructure);
    expect(['DISCOUNT', 'PREMIUM', 'EQUILIBRIUM']).toContain(smc.pricingZone);
    expect(smc.bullishOrderBlock).toBeGreaterThan(0);
    expect(smc.fvgZone.length).toBe(2);
    expect(['UNMITIGATED', '50% MITIGATED', 'FULLY FILLED']).toContain(smc.fvgStatus);
  });

  it('dynamically adapts calculations when switching between Intraday (5m/15m) and Swing (1d)', () => {
    const intraAnalysis = computeMultiEngineWatchlistAnalysis(
      'INFY',
      'Infosys',
      sampleCandles,
      'Intraday (5m/15m)',
      '5m',
      '₹'
    );

    const swingAnalysis = computeMultiEngineWatchlistAnalysis(
      'INFY',
      'Infosys',
      sampleCandles,
      'Swing (3–4 Days)',
      '1d',
      '₹'
    );

    expect(intraAnalysis.item.timeframe).toBe('5m');
    expect(intraAnalysis.item.horizon).toBe('Intraday (5m/15m)');
    expect(intraAnalysis.timesfmResult.horizonCandles).toBe(8);

    expect(swingAnalysis.item.timeframe).toBe('1d');
    expect(swingAnalysis.item.horizon).toBe('Swing (3–4 Days)');
    expect(swingAnalysis.timesfmResult.horizonCandles).toBe(12);

    expect(intraAnalysis.finalVerdict.verdict).toBeDefined();
    expect(swingAnalysis.finalVerdict.verdict).toBeDefined();

    // Verify Intraday vs Swing targets & stoploss calibration
    expect(intraAnalysis.finalVerdict.target1.pct).toBeLessThanOrEqual(swingAnalysis.finalVerdict.target1.pct + 0.5);
    expect(intraAnalysis.finalVerdict.entryZone.min).toBeDefined();
    expect(swingAnalysis.finalVerdict.entryZone.min).toBeDefined();
  });
});
