import { describe, expect, it } from 'vitest';
import type { TimeSeriesPoint } from '../src/types';
import { blendSyntheticBuildupVerdict, calculateSyntheticBuildupMatrix, syntheticBuildupSupportScore } from '../src/lib/syntheticBuildupMatrix';

function candles(count: number, lastCloseDelta = 0.5, lastVolume = 3000): TimeSeriesPoint[] {
  return Array.from({ length: count }, (_, i) => {
    const close = 100 + i * 0.02;
    return { timestamp: String(i), open: close - 0.1, high: close + 0.2, low: close - 0.2, value: close, volume: i === count - 1 ? lastVolume : 1000 };
  }).map((bar, i, all) => i === count - 1 ? { ...bar, open: all[i - 1].value, value: all[i - 1].value + lastCloseDelta, high: all[i - 1].value + Math.max(lastCloseDelta, 0.2), low: all[i - 1].value + Math.min(lastCloseDelta, -0.2) } : bar);
}

describe('multi-timeframe synthetic buildup matrix', () => {
  it('classifies MBI long buildup using body efficiency and EMA relative volume', () => {
    const signal = calculateSyntheticBuildupMatrix(candles(12, 1, 4000), '5m');
    expect(signal.category).toBe('LONG_BUILDUP');
    expect(signal.efficiency).toBeGreaterThanOrEqual(0.6);
    expect(signal.relativeVolume).toBeGreaterThan(1.2);
  });

  it('classifies intraday CBS and daily PBI using ATR and volume baseline', () => {
    expect(calculateSyntheticBuildupMatrix(candles(25, 1, 4000), '15m').category).toBe('LONG_BUILDUP');
    expect(calculateSyntheticBuildupMatrix(candles(25, 1, 4000), '1d').category).toBe('LONG_BUILDUP');
    expect(calculateSyntheticBuildupMatrix(candles(25, -1, 4000), '15m').category).toBe('SHORT_BUILDUP');
    expect(calculateSyntheticBuildupMatrix(candles(25, -1, 4000), '1d').category).toBe('SHORT_BUILDUP');
  });

  it('uses positive swing Z-volume with price percentage and reports warmup as unavailable', () => {
    const signal = calculateSyntheticBuildupMatrix(candles(52, 1, 4000), '1h');
    expect(signal.category).toBe('LONG_BUILDUP');
    expect(calculateSyntheticBuildupMatrix(candles(52, -1, 4000), '1h').category).toBe('SHORT_BUILDUP');
    expect(calculateSyntheticBuildupMatrix(candles(10), '1h').available).toBe(false);
  });

  it('labels unconfirmed price rises/falls as weaker covering/unwinding proxies', () => {
    expect(calculateSyntheticBuildupMatrix(candles(12, 0.001, 1000), '5m').category).toBe('SHORT_COVERING');
    expect(calculateSyntheticBuildupMatrix(candles(12, -0.001, 1000), '5m').category).toBe('LONG_UNWINDING');
  });

  it('gives weak moves half-strength support and strong moves the full matrix allocation', () => {
    const strong = calculateSyntheticBuildupMatrix(candles(12, 1, 4000), '5m');
    expect(syntheticBuildupSupportScore(strong, 'BULLISH')).toBeGreaterThan(50);
    expect(syntheticBuildupSupportScore(strong, 'BEARISH')).toBeLessThan(50);
    expect(syntheticBuildupSupportScore(strong, 'NEUTRAL')).toBe(50);
    const blend = blendSyntheticBuildupVerdict(60, strong, 'BULLISH');
    expect(blend).toBe(Math.round(60 * 0.85 + syntheticBuildupSupportScore(strong, 'BULLISH') * 0.15));
    expect(blendSyntheticBuildupVerdict(60, { ...strong, available: false }, 'BULLISH')).toBe(60);
  });
});
