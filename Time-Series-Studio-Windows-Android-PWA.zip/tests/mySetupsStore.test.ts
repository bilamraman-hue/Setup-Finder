import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const makeStorage = () => {
  const data = new Map<string, string>();
  return {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => { data.set(key, String(value)); },
    removeItem: (key: string) => { data.delete(key); },
    clear: () => data.clear()
  };
};

import {
  clearAllSetups,
  getActiveSetups,
  isGradeAQualified,
  SETUP_TTL_MS,
  syncSetupsFromWatchlistScan
} from '../src/lib/mySetupsStore';

describe('My Setups qualification and persistence', () => {
  const local = makeStorage();
  const session = makeStorage();

  beforeEach(() => {
    vi.stubGlobal('localStorage', local);
    vi.stubGlobal('sessionStorage', session);
    vi.stubGlobal('window', { dispatchEvent: vi.fn(), addEventListener: vi.fn(), removeEventListener: vi.fn() });
    local.clear();
    session.clear();
    clearAllSetups();
  });

  afterEach(() => vi.useRealTimers());

  const qualified = {
    id: 'test-reliance', symbol: 'RELIANCE', name: 'Reliance Industries', exchange: 'NSE',
    cmp: 2500, prevClose: 2480, changePct: 0.8, direction: 'LONG' as const,
    status: 'TRADE NOW' as const, scorePct: 75, confluenceScorePct: 65,
    setupGrade: 'GRADE_A' as const, gradeBadge: 'Grade A', finalVerdict: 'BUY / ACCUMULATE' as const,
    entryRange: { min: 2490, max: 2510, text: '₹2490–₹2510' },
    stopLoss: { price: 2450, pct: 2 }, target1: { price: 2575, pct: 3 },
    target2: { price: 2650, pct: 6 }, riskRewardText: '1:1.5',
    horizon: 'Swing (3–4 Days)' as const, timeframe: '1d' as const,
    actionTrigger: 'Breakout', coreDriver: 'Trend', timestamp: Date.now(),
    dateTimeFormatted: '', timeOnlyFormatted: '', dateOnlyFormatted: ''
  };

  it('requires Grade A/A+, a directional verdict, direction, and at least 65% confluence', () => {
    expect(isGradeAQualified(qualified)).toBe(true);
    expect(isGradeAQualified({ ...qualified, confluenceScorePct: 64.99 })).toBe(false);
    expect(isGradeAQualified({ ...qualified, finalVerdict: 'CONFLICT — AVOID / WAIT' })).toBe(false);
    expect(isGradeAQualified({ ...qualified, setupGrade: 'GRADE_B', confluenceScorePct: 95 })).toBe(false);
    expect(isGradeAQualified({ ...qualified, direction: 'NEUTRAL' })).toBe(false);
    expect(isGradeAQualified({ ...qualified, cmp: 0 })).toBe(false);
  });

  it('persists one symbol across timeframes and expires each qualification at its declared TTL', () => {
    const start = new Date('2026-10-09T10:00:00Z');
    vi.useFakeTimers();
    vi.setSystemTime(start);
    syncSetupsFromWatchlistScan([qualified], '1d');
    syncSetupsFromWatchlistScan([{ ...qualified, timeframe: '5m' }], '5m');
    expect(getActiveSetups()).toHaveLength(1);
    expect(getActiveSetups()[0].activeTimeframeList.sort()).toEqual(['1d', '5m']);
    expect(getActiveSetups()[0].timeframes['5m']?.ttlMs).toBe(SETUP_TTL_MS['5m']);

    vi.setSystemTime(new Date(start.getTime() + SETUP_TTL_MS['5m'] + 1));
    expect(getActiveSetups()).toHaveLength(1);
    expect(getActiveSetups()[0].activeTimeframeList).toEqual(['1d']);
    vi.setSystemTime(new Date(start.getTime() + SETUP_TTL_MS['1d'] + 1));
    expect(getActiveSetups()).toHaveLength(0);
  });

  it('keeps independent direction, grade, score, levels, and analysis evidence per timeframe', () => {
    syncSetupsFromWatchlistScan([qualified], '1d');
    const intraday = {
      ...qualified,
      timeframe: '5m' as const,
      direction: 'SHORT' as const,
      finalVerdict: 'SELL / SHORT' as const,
      setupGrade: 'GRADE_A_PLUS' as const,
      confluenceScorePct: 84,
      entryRange: { min: 2510, max: 2520, text: '₹2510–₹2520' },
      stopLoss: { price: 2540, pct: 0.8 },
      target1: { price: 2470, pct: 1.6 },
      target2: { price: 2440, pct: 2.8 },
      coreDriver: 'Intraday rejection',
      actionTrigger: 'Break of 5m low',
      marketFlow: { trapRisk: { available: true, kind: 'BULL_TRAP' as const, direction: 'BEARISH' as const, scorePct: 76, relativeVolume: 1.8, label: 'Potential bull trap', detail: 'Rejected prior high' } }
    };
    syncSetupsFromWatchlistScan([intraday], '5m');

    const saved = getActiveSetups()[0];
    expect(saved.timeframes['1d']?.direction).toBe('LONG');
    expect(saved.timeframes['1d']?.setupGrade).toBe('GRADE_A');
    expect(saved.timeframes['1d']?.entryRange.min).toBe(2490);
    expect(saved.timeframes['5m']?.direction).toBe('SHORT');
    expect(saved.timeframes['5m']?.setupGrade).toBe('GRADE_A_PLUS');
    expect(saved.timeframes['5m']?.confluenceScorePct).toBe(84);
    expect(saved.timeframes['5m']?.stopLoss.price).toBe(2540);
    expect(saved.timeframes['5m']?.analysis?.coreDriver).toBe('Intraday rejection');
    expect(saved.timeframes['5m']?.analysis?.marketFlow?.trapRisk?.kind).toBe('BULL_TRAP');
  });

  it('records material changes between fresh scans and reports disqualification', () => {
    syncSetupsFromWatchlistScan([qualified], '1d');
    const changed = { ...qualified, direction: 'SHORT' as const, finalVerdict: 'SELL / SHORT' as const, confluenceScorePct: 78 };
    const changedScan = syncSetupsFromWatchlistScan([changed], '1d');
    expect(changedScan.changes[0]).toContain('direction LONG → SHORT');
    expect(getActiveSetups()[0].scanChanges?.[0].description).toContain('direction LONG → SHORT');

    const removedScan = syncSetupsFromWatchlistScan([{ ...changed, setupGrade: 'NO_TRADE', confluenceScorePct: 20, finalVerdict: 'NEUTRAL CONSOLIDATION' }], '1d', undefined, true);
    expect(removedScan.changes[0]).toContain('setup disqualified');
    expect(getActiveSetups()).toHaveLength(0);
  });

  it('does not save a Grade A label with insufficient score', () => {
    const result = syncSetupsFromWatchlistScan([{ ...qualified, confluenceScorePct: 40 }], '1d');
    expect(result.updatedCount).toBe(0);
    expect(result.activeSetups).toHaveLength(0);
  });

  it('removes only the fully rescanned timeframe after a disqualification and repairs the primary timeframe', () => {
    syncSetupsFromWatchlistScan([qualified], '1d');
    syncSetupsFromWatchlistScan([{ ...qualified, timeframe: '5m' }], '5m');
    syncSetupsFromWatchlistScan([{ ...qualified, timeframe: '1d', setupGrade: 'NO_TRADE', confluenceScorePct: 20, finalVerdict: 'NEUTRAL CONSOLIDATION' }], '1d', undefined, true);
    const remaining = getActiveSetups()[0];
    expect(remaining.activeTimeframeList).toEqual(['5m']);
    expect(remaining.primaryTimeframe).toBe('5m');
    expect(remaining.timeframes['1d']).toBeUndefined();
  });

  it('preserves a timeframe when a scan has no usable data and therefore no evaluated rows', () => {
    syncSetupsFromWatchlistScan([qualified], '1d');
    syncSetupsFromWatchlistScan([], '1d', undefined, true);
    expect(getActiveSetups()[0].activeTimeframeList).toEqual(['1d']);
  });
});
