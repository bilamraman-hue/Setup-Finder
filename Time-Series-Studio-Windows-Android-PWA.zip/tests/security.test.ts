import { describe, it, expect } from 'vitest';
import { validateProxyUrl } from '../src/lib/proxySecurity';
import { verifyFirebaseIdToken } from '../src/lib/authVerify';

describe('Security & SSRF Mitigation Suite', () => {
  it('should block SSRF requests to localhost and 127.0.0.1', async () => {
    const r1 = await validateProxyUrl('http://localhost:3000/api/secret');
    expect(r1.allowed).toBe(false);
    expect(r1.reason).toContain('prohibited');

    const r2 = await validateProxyUrl('http://127.0.0.1:8080/admin');
    expect(r2.allowed).toBe(false);

    const r3 = await validateProxyUrl('http://0.0.0.0:80');
    expect(r3.allowed).toBe(false);
  });

  it('should block SSRF requests to cloud metadata service (169.254.169.254)', async () => {
    const res = await validateProxyUrl('http://169.254.169.254/computeMetadata/v1/');
    expect(res.allowed).toBe(false);
    expect(res.reason).toContain('prohibited');
  });

  it('should block SSRF requests to Google metadata hostnames', async () => {
    const res = await validateProxyUrl('http://metadata.google.internal/computeMetadata/v1/');
    expect(res.allowed).toBe(false);
  });

  it('should block non-HTTP/HTTPS protocols like file:// or ftp://', async () => {
    const r1 = await validateProxyUrl('file:///etc/passwd');
    expect(r1.allowed).toBe(false);

    const r2 = await validateProxyUrl('ftp://example.com/dump');
    expect(r2.allowed).toBe(false);
  });

  it('should block placeholder domains to prevent broken requests', async () => {
    const res = await validateProxyUrl('https://api.myserver.com/v1/quotes');
    expect(res.allowed).toBe(false);
    expect(res.reason).toContain('Placeholder domain');
  });

  it('should allow legitimate public HTTPS broker/market data endpoints', async () => {
    const res = await validateProxyUrl('https://query1.finance.yahoo.com/v8/finance/chart/RELIANCE.NS');
    expect(res.allowed).toBe(true);
    expect(res.targetUrl).toContain('https://query1.finance.yahoo.com');
  });
});

describe('Firebase Auth Cryptographic Validation Suite', () => {
  it('should reject empty or missing tokens', async () => {
    await expect(verifyFirebaseIdToken('')).rejects.toThrow('Token is required');
  });

  it('should reject malformed tokens with wrong segment count', async () => {
    await expect(verifyFirebaseIdToken('only.two.segments.extra')).rejects.toThrow('Malformed JWT');
  });

  it('should reject tokens with non-RS256 algorithm (e.g. HS256 / none)', async () => {
    const fakeHeader = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64');
    const fakePayload = Buffer.from(JSON.stringify({ sub: '123' })).toString('base64');
    const fakeToken = `${fakeHeader}.${fakePayload}.sig`;

    await expect(verifyFirebaseIdToken(fakeToken)).rejects.toThrow('Invalid token algorithm');
  });

  it('should reject tokens missing kid in header', async () => {
    const fakeHeader = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).toString('base64');
    const fakePayload = Buffer.from(JSON.stringify({ sub: '123' })).toString('base64');
    const fakeToken = `${fakeHeader}.${fakePayload}.sig`;

    await expect(verifyFirebaseIdToken(fakeToken)).rejects.toThrow('missing key ID (kid)');
  });
});
