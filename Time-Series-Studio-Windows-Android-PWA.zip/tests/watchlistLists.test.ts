import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  MAX_WATCHLIST_LIMIT,
  addOrUpdateWatchlistStock,
  createWatchlist,
  getActiveWatchlistId,
  getWatchlistFromStorage,
  getWatchlists,
  saveWatchlistToStorage,
  setActiveWatchlistId
} from '../src/lib/watchlistStore';

const storage = () => {
  const map = new Map<string, string>();
  return { getItem: (k: string) => map.get(k) ?? null, setItem: (k: string, v: string) => map.set(k, String(v)), removeItem: (k: string) => map.delete(k), clear: () => map.clear() };
};

describe('separate watchlists with 38-symbol cap', () => {
  const local = storage();
  beforeEach(() => { local.clear(); vi.stubGlobal('localStorage', local); });

  it('migrates an older long list into 38-symbol chunks without dropping rows', () => {
    const legacy = Array.from({ length: 80 }, (_, i) => ({ symbol: `S${i}`, timestamp: i }));
    local.setItem('timesfm_watchlist_scan_v2', JSON.stringify(legacy));
    const lists = getWatchlists();
    expect(lists.map(list => list.items.length)).toEqual([38, 38, 4]);
    expect(lists.reduce((sum, list) => sum + list.items.length, 0)).toBe(80);
    expect(lists.every(list => list.items.length <= MAX_WATCHLIST_LIMIT)).toBe(true);
  });

  it('keeps watchlists isolated and does not evict when an active list is full', () => {
    const first = getWatchlists()[0];
    const rows = Array.from({ length: MAX_WATCHLIST_LIMIT }, (_, i) => ({ symbol: `S${i}`, cmp: 100 } as any));
    saveWatchlistToStorage(rows, first.id);
    expect(setActiveWatchlistId(first.id)).toBe(true);
    const blocked = addOrUpdateWatchlistStock({ ...rows[0], symbol: 'EXTRA' });
    expect(blocked.limitReached).toBe(true);
    expect(blocked.watchlist).toHaveLength(38);
    expect(blocked.watchlist.map(row => row.symbol)).not.toContain('EXTRA');

    const second = createWatchlist('Swing setups');
    expect(getActiveWatchlistId()).toBe(second.id);
    saveWatchlistToStorage([{ ...rows[0], symbol: 'ONLY2' }], second.id);
    expect(getWatchlistFromStorage(second.id).map(row => row.symbol)).toEqual(['ONLY2']);
    expect(getWatchlistFromStorage(first.id)).toHaveLength(38);
  });
});
